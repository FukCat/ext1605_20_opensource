import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

// 
// Decompiled by Procyon v0.6.0
// 

public class 62YKh89KaQO5R1WqA37t9fNk2191Mala27h9b075I8uT2rscmhG1HR4XO6lSD1y6Jg6Lm6db94Z49V974K4QxZ3zSG9W1A implements 6Xshyu98BPKD0Kj2ysQ0pQPP3OrJj1w2t5T0uPrGog033gntT8UTcBftyFyvZHgyra2lx4a1692nuiLk581IYI8n94RXWk8Ry
{
    private final HashMap<61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, float[]> 0jQxZ1dVC518Y32Z1425p2LEer8Ex9wWwb3RWTp79I88VOPE42N1kQ516HmO;
    
    public 62YKh89KaQO5R1WqA37t9fNk2191Mala27h9b075I8uT2rscmhG1HR4XO6lSD1y6Jg6Lm6db94Z49V974K4QxZ3zSG9W1A() {
        this.0jQxZ1dVC518Y32Z1425p2LEer8Ex9wWwb3RWTp79I88VOPE42N1kQ516HmO = new HashMap<61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, float[]>();
    }
    
    public void 7w1lB4c92lMJbh1WTsqK8RWVdY460iP4FuXe5pstl82DxM6koOm8O527VIZ9(final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 key, final float[] value) {
        if (value.length != 1536) {
            throw new IllegalArgumentException("Invalid biome map");
        }
        this.0jQxZ1dVC518Y32Z1425p2LEer8Ex9wWwb3RWTp79I88VOPE42N1kQ516HmO.put(key, value);
    }
    
    public void 3AndXWge0Me8Q040iwfs6eu0O3Y09uh0xQI51Sv3WSs5ZG8n7t4xbP8BL96U(final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 key) {
        this.0jQxZ1dVC518Y32Z1425p2LEer8Ex9wWwb3RWTp79I88VOPE42N1kQ516HmO.remove(key);
    }
    
    @Override
    public double 39mJVmq3bl4dbH51995p9tocRB43bFXruO32GkxVTy54fzIxdy5dt9OeTC2A(final int n, final int n2, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer layer) {
        int n3 = n % 16;
        if (n3 < 0) {
            n3 += 15;
        }
        int n4 = n2 % 16;
        if (n4 < 0) {
            n4 += 15;
        }
        for (final Map.Entry entry : this.0jQxZ1dVC518Y32Z1425p2LEer8Ex9wWwb3RWTp79I88VOPE42N1kQ516HmO.entrySet()) {
            if (((61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3)entry.getKey()).8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM != n / 16) {
                continue;
            }
            if (((61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3)entry.getKey()).0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174 != n2 / 16) {
                continue;
            }
            return ((float[])entry.getValue())[layer.ordinal() * 16 * 16 * 2 + n3 * 2 + n4 * 16 * 2];
        }
        return 0.0;
    }
    
    @Override
    public double 4hoZRS129yUan88AHp1ksCfja1h93mYKfFda82Qtd8pqKm7G4bgpnYsijiMu(final int n, final int n2, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer layer) {
        int n3 = n % 16;
        if (n3 < 0) {
            n3 += 16;
        }
        int n4 = n2 % 16;
        if (n4 < 0) {
            n4 += 16;
        }
        for (final Map.Entry entry : this.0jQxZ1dVC518Y32Z1425p2LEer8Ex9wWwb3RWTp79I88VOPE42N1kQ516HmO.entrySet()) {
            if (((61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3)entry.getKey()).8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM != n / 16) {
                continue;
            }
            if (((61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3)entry.getKey()).0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174 != n2 / 16) {
                continue;
            }
            return ((float[])entry.getValue())[layer.ordinal() * 16 * 16 * 2 + n3 * 2 + n4 * 16 * 2 + 1];
        }
        return 0.0;
    }
    
    @Override
    public 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8(final int n, final int n2, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer layer) {
        return 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.2dCM22Pc7rV0IQo46JM3ja84x9AHCGNPeSCDVFoTi3969B8hv2sM7nr6o61r(this.39mJVmq3bl4dbH51995p9tocRB43bFXruO32GkxVTy54fzIxdy5dt9OeTC2A(n, n2, layer), this.4hoZRS129yUan88AHp1ksCfja1h93mYKfFda82Qtd8pqKm7G4bgpnYsijiMu(n, n2, layer), layer);
    }
}
