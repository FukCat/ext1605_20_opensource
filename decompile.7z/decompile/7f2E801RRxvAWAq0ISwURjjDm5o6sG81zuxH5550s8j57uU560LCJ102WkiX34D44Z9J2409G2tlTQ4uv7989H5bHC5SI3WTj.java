import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 7f2E801RRxvAWAq0ISwURjjDm5o6sG81zuxH5550s8j57uU560LCJ102WkiX34D44Z9J2409G2tlTQ4uv7989H5bHC5SI3WTj extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 0y6ehE80O5d2g0N63BOr0e1D22PbLpBU19H6RRS77cM7nOvvXCeA3jnkYtqY;
    public int 6YFivzHwQ8NT5bZ44H7r85OF0q989U83qDHSQ1b0YyC9QFg98pf7n0Sk8SQF;
    public int 8tX67MMqbRLIeks8xEWc9cL3i0mlA0w5ac0JKzMUx7iWw2vHZJ6Ibhs9uhP2;
    public int 6Bym6hpq0acZ1pDQ8s76BblhaOH4An9s3hP8KF63gK0SQgX6gm9baazbO223;
    public int 52G2Aj85o4F3zzbrKZV772OVT70f8dmehQ92RE570mb815A7TLHR5v8RcJ96;
    
    public 7f2E801RRxvAWAq0ISwURjjDm5o6sG81zuxH5550s8j57uU560LCJ102WkiX34D44Z9J2409G2tlTQ4uv7989H5bHC5SI3WTj() {
    }
    
    public 7f2E801RRxvAWAq0ISwURjjDm5o6sG81zuxH5550s8j57uU560LCJ102WkiX34D44Z9J2409G2tlTQ4uv7989H5bHC5SI3WTj(final int 0y6ehE80O5d2g0N63BOr0e1D22PbLpBU19H6RRS77cM7nOvvXCeA3jnkYtqY, final int 6yFivzHwQ8NT5bZ44H7r85OF0q989U83qDHSQ1b0YyC9QFg98pf7n0Sk8SQF, final int 8tX67MMqbRLIeks8xEWc9cL3i0mlA0w5ac0JKzMUx7iWw2vHZJ6Ibhs9uhP2, final int 6Bym6hpq0acZ1pDQ8s76BblhaOH4An9s3hP8KF63gK0SQgX6gm9baazbO223, final int 52G2Aj85o4F3zzbrKZV772OVT70f8dmehQ92RE570mb815A7TLHR5v8RcJ96) {
        this.0y6ehE80O5d2g0N63BOr0e1D22PbLpBU19H6RRS77cM7nOvvXCeA3jnkYtqY = 0y6ehE80O5d2g0N63BOr0e1D22PbLpBU19H6RRS77cM7nOvvXCeA3jnkYtqY;
        this.6YFivzHwQ8NT5bZ44H7r85OF0q989U83qDHSQ1b0YyC9QFg98pf7n0Sk8SQF = 6yFivzHwQ8NT5bZ44H7r85OF0q989U83qDHSQ1b0YyC9QFg98pf7n0Sk8SQF;
        this.8tX67MMqbRLIeks8xEWc9cL3i0mlA0w5ac0JKzMUx7iWw2vHZJ6Ibhs9uhP2 = 8tX67MMqbRLIeks8xEWc9cL3i0mlA0w5ac0JKzMUx7iWw2vHZJ6Ibhs9uhP2;
        this.6Bym6hpq0acZ1pDQ8s76BblhaOH4An9s3hP8KF63gK0SQgX6gm9baazbO223 = 6Bym6hpq0acZ1pDQ8s76BblhaOH4An9s3hP8KF63gK0SQgX6gm9baazbO223;
        this.52G2Aj85o4F3zzbrKZV772OVT70f8dmehQ92RE570mb815A7TLHR5v8RcJ96 = 52G2Aj85o4F3zzbrKZV772OVT70f8dmehQ92RE570mb815A7TLHR5v8RcJ96;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.0y6ehE80O5d2g0N63BOr0e1D22PbLpBU19H6RRS77cM7nOvvXCeA3jnkYtqY = dataInputStream.readShort();
        this.6YFivzHwQ8NT5bZ44H7r85OF0q989U83qDHSQ1b0YyC9QFg98pf7n0Sk8SQF = dataInputStream.readInt();
        this.8tX67MMqbRLIeks8xEWc9cL3i0mlA0w5ac0JKzMUx7iWw2vHZJ6Ibhs9uhP2 = dataInputStream.read();
        this.6Bym6hpq0acZ1pDQ8s76BblhaOH4An9s3hP8KF63gK0SQgX6gm9baazbO223 = dataInputStream.readInt();
        this.52G2Aj85o4F3zzbrKZV772OVT70f8dmehQ92RE570mb815A7TLHR5v8RcJ96 = dataInputStream.read();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeShort(this.0y6ehE80O5d2g0N63BOr0e1D22PbLpBU19H6RRS77cM7nOvvXCeA3jnkYtqY);
        dataOutputStream.writeInt(this.6YFivzHwQ8NT5bZ44H7r85OF0q989U83qDHSQ1b0YyC9QFg98pf7n0Sk8SQF);
        dataOutputStream.write(this.8tX67MMqbRLIeks8xEWc9cL3i0mlA0w5ac0JKzMUx7iWw2vHZJ6Ibhs9uhP2);
        dataOutputStream.writeInt(this.6Bym6hpq0acZ1pDQ8s76BblhaOH4An9s3hP8KF63gK0SQgX6gm9baazbO223);
        dataOutputStream.write(this.52G2Aj85o4F3zzbrKZV772OVT70f8dmehQ92RE570mb815A7TLHR5v8RcJ96);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.4BSSVKz2IX8Y9r5Q3DwU0Q7Sx00S23lIL7H1gKgrw4U5090QoKeWVI6tE4op(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 12;
    }
}
