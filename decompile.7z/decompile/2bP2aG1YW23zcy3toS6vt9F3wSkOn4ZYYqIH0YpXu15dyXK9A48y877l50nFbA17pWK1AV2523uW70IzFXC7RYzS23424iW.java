// 
// Decompiled by Procyon v0.6.0
// 

public class 2bP2aG1YW23zcy3toS6vt9F3wSkOn4ZYYqIH0YpXu15dyXK9A48y877l50nFbA17pWK1AV2523uW70IzFXC7RYzS23424iW
{
    @Deprecated
    public 2bP2aG1YW23zcy3toS6vt9F3wSkOn4ZYYqIH0YpXu15dyXK9A48y877l50nFbA17pWK1AV2523uW70IzFXC7RYzS23424iW 129vp7nC1SmrEQ1NFCDUp1bn87harL8gZ5CQxlX4rNs21p7br5UZ2lMC3ZWf(final String s) {
        return this;
    }
    
    @Deprecated
    public void 9Wy0IprT238K01VTSQBof99j4dGHj0MRm62o3qv81U3Bs6vaGohy2GFf359c(final 32F1yUU8h44nGw0Lwu5Xj02u28q8lJFUbRZpxInrjOcM7LAizm0JWXp7mU8H1mO2Xciti5z88lqDMikZs4qkAa6D9NH9l42 32F1yUU8h44nGw0Lwu5Xj02u28q8lJFUbRZpxInrjOcM7LAizm0JWXp7mU8H1mO2Xciti5z88lqDMikZs4qkAa6D9NH9l42, final 4L97I0W7s4m4Tv1fogKEz7QjbgDuXDv9u399K1b5215al4Os1MOAy1l6gA991nr99XFhivH8z4ojDJT80GCImU2Pdjm9x51a1ymh 4l97I0W7s4m4Tv1fogKEz7QjbgDuXDv9u399K1b5215al4Os1MOAy1l6gA991nr99XFhivH8z4ojDJT80GCImU2Pdjm9x51a1ymh, final int n, final int n2, final float n3, final float n4, final float n5, final float n6) {
    }
}
