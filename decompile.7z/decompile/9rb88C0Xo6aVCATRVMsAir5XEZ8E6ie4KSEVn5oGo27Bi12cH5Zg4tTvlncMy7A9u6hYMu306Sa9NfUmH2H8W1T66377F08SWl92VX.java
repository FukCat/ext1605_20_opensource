import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 9rb88C0Xo6aVCATRVMsAir5XEZ8E6ie4KSEVn5oGo27Bi12cH5Zg4tTvlncMy7A9u6hYMu306Sa9NfUmH2H8W1T66377F08SWl92VX extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 5MrEi05hkY9xeqywf09ju5u5YdiFF4e82XlFP8RhERre7Ha3f3zd8on9C9sG;
    public int 7j867xY7W267077M88MNW0Ee49ZeUHmj0d5G60jnz8OCjj9O39pTE9MP0k8a;
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.5MrEi05hkY9xeqywf09ju5u5YdiFF4e82XlFP8RhERre7Ha3f3zd8on9C9sG = dataInputStream.readInt();
        this.7j867xY7W267077M88MNW0Ee49ZeUHmj0d5G60jnz8OCjj9O39pTE9MP0k8a = dataInputStream.readInt();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.5MrEi05hkY9xeqywf09ju5u5YdiFF4e82XlFP8RhERre7Ha3f3zd8on9C9sG);
        dataOutputStream.writeInt(this.7j867xY7W267077M88MNW0Ee49ZeUHmj0d5G60jnz8OCjj9O39pTE9MP0k8a);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.8tLB45RGT8TG9y00q7owsZ1vgx3TPh6z2aBS0LuxxIDKs8XHjVm70CghjvQM(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 8;
    }
}
