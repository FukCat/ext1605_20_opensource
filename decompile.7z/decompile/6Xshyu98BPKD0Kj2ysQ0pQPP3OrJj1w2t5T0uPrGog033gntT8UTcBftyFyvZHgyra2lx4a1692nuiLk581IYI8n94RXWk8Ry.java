import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.WeakHashMap;

// 
// Decompiled by Procyon v0.6.0
// 

public interface 6Xshyu98BPKD0Kj2ysQ0pQPP3OrJj1w2t5T0uPrGog033gntT8UTcBftyFyvZHgyra2lx4a1692nuiLk581IYI8n94RXWk8Ry
{
    double 39mJVmq3bl4dbH51995p9tocRB43bFXruO32GkxVTy54fzIxdy5dt9OeTC2A(final int p0, final int p1, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer p2);
    
    double 4hoZRS129yUan88AHp1ksCfja1h93mYKfFda82Qtd8pqKm7G4bgpnYsijiMu(final int p0, final int p1, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer p2);
    
    5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8(final int p0, final int p1, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer p2);
    
    public static class Utils
    {
        private static final WeakHashMap<6Xshyu98BPKD0Kj2ysQ0pQPP3OrJj1w2t5T0uPrGog033gntT8UTcBftyFyvZHgyra2lx4a1692nuiLk581IYI8n94RXWk8Ry, Utils> 2m0i0yp0898q2l57HTnHC4r48B8F4ZmrFXxq96WAKk59I36sNOCwY214PNjR;
        private final 6Xshyu98BPKD0Kj2ysQ0pQPP3OrJj1w2t5T0uPrGog033gntT8UTcBftyFyvZHgyra2lx4a1692nuiLk581IYI8n94RXWk8Ry 6G8IbpB1j39K15omtz2I96X36TWY4ln14ueN38e0HSY85Oc2Fu9QoY1fRstW;
        
        private Utils(final 6Xshyu98BPKD0Kj2ysQ0pQPP3OrJj1w2t5T0uPrGog033gntT8UTcBftyFyvZHgyra2lx4a1692nuiLk581IYI8n94RXWk8Ry 6g8IbpB1j39K15omtz2I96X36TWY4ln14ueN38e0HSY85Oc2Fu9QoY1fRstW) {
            this.6G8IbpB1j39K15omtz2I96X36TWY4ln14ueN38e0HSY85Oc2Fu9QoY1fRstW = 6g8IbpB1j39K15omtz2I96X36TWY4ln14ueN38e0HSY85Oc2Fu9QoY1fRstW;
        }
        
        public static Utils 2n3qE9TNSbq6jFP0jVF6MZR791V18lhzx1FrS1vTgw66qgr9H9NUnl54vO2R(final 6Xshyu98BPKD0Kj2ysQ0pQPP3OrJj1w2t5T0uPrGog033gntT8UTcBftyFyvZHgyra2lx4a1692nuiLk581IYI8n94RXWk8Ry key) {
            Utils value = Utils.2m0i0yp0898q2l57HTnHC4r48B8F4ZmrFXxq96WAKk59I36sNOCwY214PNjR.get(key);
            if (value == null) {
                value = new Utils(key);
                Utils.2m0i0yp0898q2l57HTnHC4r48B8F4ZmrFXxq96WAKk59I36sNOCwY214PNjR.put(value.6G8IbpB1j39K15omtz2I96X36TWY4ln14ueN38e0HSY85Oc2Fu9QoY1fRstW, value);
            }
            return value;
        }
        
        public 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 2L2822HFv0Zs3L6g73SmXjqyWS7YT96y6ZshUIa6nFgwp5KcjgV15AJ304yM(final int n, final int n2, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer layer) {
            final HashMap hashMap = new HashMap(16);
            for (int i = 0; i < 16; ++i) {
                for (int j = 0; j < 16; ++j) {
                    final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8 = this.6G8IbpB1j39K15omtz2I96X36TWY4ln14ueN38e0HSY85Oc2Fu9QoY1fRstW.7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8(n * 16 + i, n2 * 16 + j, layer);
                    final Integer n3 = hashMap.get(7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8);
                    Integer value;
                    if (n3 == null) {
                        value = 1;
                    }
                    else {
                        value = n3 + 1;
                    }
                    hashMap.put(7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8, value);
                }
            }
            int intValue = 0;
            5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl = null;
            for (final Map.Entry entry : hashMap.entrySet()) {
                if ((int)entry.getValue() > intValue) {
                    intValue = (int)entry.getValue();
                    5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl = (5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl)entry.getKey();
                }
            }
            if (5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl == null) {
                System.err.println("!BIOME GENERATOR BUG (please report on bug tracker)!");
                System.err.println("biome list:");
                for (final Map.Entry entry2 : hashMap.entrySet()) {
                    System.err.println(entry2.getKey().toString() + "/" + entry2.getValue());
                }
                throw new 0s4z1P1z6Mycshvrh7U45xQ5uzkeKte2a6iOg67555Kfi9FcKuGBjUZ6AKOF46UVy8Rw8v7QNjvm8xR1g7Kg30QH5G6Z3();
            }
            return 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl;
        }
        
        static {
            2m0i0yp0898q2l57HTnHC4r48B8F4ZmrFXxq96WAKk59I36sNOCwY214PNjR = new WeakHashMap<6Xshyu98BPKD0Kj2ysQ0pQPP3OrJj1w2t5T0uPrGog033gntT8UTcBftyFyvZHgyra2lx4a1692nuiLk581IYI8n94RXWk8Ry, Utils>();
        }
    }
}
