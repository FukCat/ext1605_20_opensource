import java.io.InputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.CopyOption;
import java.nio.file.Paths;
import java.io.File;
import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public abstract class 0tRIg5039Sr06FBUA8Nk84hWF4i12HTUp48K7X0a61BOGUJuXr9EGzfveTQHkVgbLZccG00W5BZ8vfz0JHD6qQX652b2bc4etl
{
    private boolean 8ZqN9dwV3VXplxMbT675xbKuZ9WVpo5A3rH3w2t1eH001YiEhb0a090uRQrl;
    
    public 0tRIg5039Sr06FBUA8Nk84hWF4i12HTUp48K7X0a61BOGUJuXr9EGzfveTQHkVgbLZccG00W5BZ8vfz0JHD6qQX652b2bc4etl() {
        this.8ZqN9dwV3VXplxMbT675xbKuZ9WVpo5A3rH3w2t1eH001YiEhb0a090uRQrl = false;
    }
    
    public abstract String 0H71qF1boc09yQe30H3ltUC5l82Fid7J740kClTMGz8ZC4S66xG2s59POXO2();
    
    public abstract boolean 4OjZEoPxA0x4pjSZ22wVm3rWf8dTpmR2s15oMOMQDzjN06Z5Bhw6tzf56WRo(final Object... p0);
    
    public abstract String 4Ge8V2yp1QwBoa8Mr14P4r95AK433TyF7pk53odNhq9OPq9SC0H9BAKperQ4();
    
    public abstract String 2T1cRu98U38NwNJ143B1A5cb5ILSxdfW5UX9t3C708g82XI842xrwPj0vF0Z();
    
    public abstract String 11S5IdEEKXzqMyVmBaFhF6pT01hvB63Y79C25Z224vEZmrM9cvXB1433RL79();
    
    public void 4z2V2j0bZ6SM056tTMJr8zE2Adkmze6BYmsc21583X859BA28wxHN3EhCIau() {
        if (this.8ZqN9dwV3VXplxMbT675xbKuZ9WVpo5A3rH3w2t1eH001YiEhb0a090uRQrl) {
            return;
        }
        final File file = new File(Minecraft.74365lSUZG8SRi4QcP0LdVO61o0N3570jYi74Tv6MwBh3c90i6CydLQuxD79(), "/texturepacks/" + this.4Ge8V2yp1QwBoa8Mr14P4r95AK433TyF7pk53odNhq9OPq9SC0H9BAKperQ4() + ".zip");
        if (file.exists()) {
            this.8ZqN9dwV3VXplxMbT675xbKuZ9WVpo5A3rH3w2t1eH001YiEhb0a090uRQrl = true;
            return;
        }
        try {
            1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.2w11sSa7Bs9LcLsC7934u93KQ7ddy7D30Qm40R9Tadk9wwIXYd41bvx16wT6.2qsmfjKT1Qgdapuq7wRh5WHa5D8UesXIrS4e7J3j2XJ3ioal9qCu2MakuA7R.6ha0FA24k2u2ZHMX1mw2dm7Ab1KfFx74nq1YDgBS7RE83i88Q5j1H15ia7cw("Unlocked: " + this.2T1cRu98U38NwNJ143B1A5cb5ILSxdfW5UX9t3C708g82XI842xrwPj0vF0Z() + "\n(" + this.11S5IdEEKXzqMyVmBaFhF6pT01hvB63Y79C25Z224vEZmrM9cvXB1433RL79() + ")", 5000);
            final InputStream 5v4Cs6sI06e6Hjpg3rSI82gG008x14C2jag2OM7ADaW5U8a3DYSrf570CJm6 = 1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.5v4Cs6sI06e6Hjpg3rSI82gG008x14C2jag2OM7ADaW5U8a3DYSrf570CJm6(this.0H71qF1boc09yQe30H3ltUC5l82Fid7J740kClTMGz8ZC4S66xG2s59POXO2());
            Files.copy(5v4Cs6sI06e6Hjpg3rSI82gG008x14C2jag2OM7ADaW5U8a3DYSrf570CJm6, Paths.get(file.getPath(), new String[0]), StandardCopyOption.REPLACE_EXISTING);
            5v4Cs6sI06e6Hjpg3rSI82gG008x14C2jag2OM7ADaW5U8a3DYSrf570CJm6.close();
            this.8ZqN9dwV3VXplxMbT675xbKuZ9WVpo5A3rH3w2t1eH001YiEhb0a090uRQrl = true;
        }
        catch (final IOException ex) {
            7l2e0fYR96rf6dpREUY30xWh65d1rOc3abJQrqtvYEW6GNMN9qeJW237wlzS37y9Xt8xV209FRDRzpsI4HOsGN7skzB8a0.100zpjGx871CfQ97LIlXB4L1a18kKl6sZ3OLerqmn87iT5wYRd5Zq70vJ0m3("Deploy " + this.4Ge8V2yp1QwBoa8Mr14P4r95AK433TyF7pk53odNhq9OPq9SC0H9BAKperQ4() + " failed");
            ex.printStackTrace();
        }
    }
}
