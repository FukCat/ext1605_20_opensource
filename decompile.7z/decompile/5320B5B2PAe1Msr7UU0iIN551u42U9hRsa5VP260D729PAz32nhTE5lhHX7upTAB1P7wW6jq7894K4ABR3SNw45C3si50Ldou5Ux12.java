import java.io.DataInput;
import java.io.IOException;
import java.io.DataOutput;

// 
// Decompiled by Procyon v0.6.0
// 

public class 5320B5B2PAe1Msr7UU0iIN551u42U9hRsa5VP260D729PAz32nhTE5lhHX7upTAB1P7wW6jq7894K4ABR3SNw45C3si50Ldou5Ux12 extends 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi
{
    public String 1UBe19rU9818tEIAN2P7x38668eh2o12tTR7R800pabtP6YuUZB34Tf4b5XQ;
    
    public 5320B5B2PAe1Msr7UU0iIN551u42U9hRsa5VP260D729PAz32nhTE5lhHX7upTAB1P7wW6jq7894K4ABR3SNw45C3si50Ldou5Ux12() {
    }
    
    public 5320B5B2PAe1Msr7UU0iIN551u42U9hRsa5VP260D729PAz32nhTE5lhHX7upTAB1P7wW6jq7894K4ABR3SNw45C3si50Ldou5Ux12(final String 1uBe19rU9818tEIAN2P7x38668eh2o12tTR7R800pabtP6YuUZB34Tf4b5XQ) {
        this.1UBe19rU9818tEIAN2P7x38668eh2o12tTR7R800pabtP6YuUZB34Tf4b5XQ = 1uBe19rU9818tEIAN2P7x38668eh2o12tTR7R800pabtP6YuUZB34Tf4b5XQ;
        if (1uBe19rU9818tEIAN2P7x38668eh2o12tTR7R800pabtP6YuUZB34Tf4b5XQ == null) {
            throw new IllegalArgumentException("Empty string not allowed");
        }
    }
    
    @Override
    void 7OU3N2lgEecd9p9DtAmaF5EwE4f0u28Oaa9zcxqnm3XW1bDsPewY15rIFs80(final DataOutput dataOutput) throws IOException {
        dataOutput.writeUTF(this.1UBe19rU9818tEIAN2P7x38668eh2o12tTR7R800pabtP6YuUZB34Tf4b5XQ);
    }
    
    @Override
    void 96fSDIRBY01vu6bNpWo4KQJG8fCN2WIew9WR04d4yvq9Lxko60PpMIEkyn00(final DataInput dataInput) throws IOException {
        this.1UBe19rU9818tEIAN2P7x38668eh2o12tTR7R800pabtP6YuUZB34Tf4b5XQ = dataInput.readUTF();
    }
    
    @Override
    public byte 3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr() {
        return 8;
    }
    
    @Override
    public String toString() {
        return "" + this.1UBe19rU9818tEIAN2P7x38668eh2o12tTR7R800pabtP6YuUZB34Tf4b5XQ;
    }
}
