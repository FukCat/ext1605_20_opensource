import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 36dil34Oo3A318ky64nU3rrSxQ08rML17zPKq7Dd4z3uRg437K73e81h1g7HD2qGDexXs0TCz816m397F1h1g8gXlMIEdQcQ implements 7soGcRyClKm262tv21ia5Io4pGbRhP8v7wGr7xH4O8Z59AC85O8Wqq7I2NOcUep0i03wj8GnnF845Ipyk386GCma9111dZE1
{
    private String 1Fu9C3vyTjF5nQEWTLQ7X4s5Q8c6Yc3XQHP9sQT10FvKq1R9kbSqZ8tJ8kAn;
    private Minecraft 052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w;
    private String 8QiR474wO74sqFB143vZ23U63qMzc9sRuH0aCz7Sy6Kyf3Tb9uTIY8hAsXzb;
    private long 7sI24elao7itr9BPu6v7TsS02Q7n394hLy2Ao8nDw2KaTijs8198wxT2chzc;
    private boolean 9dBQn6dp46yx170Qm892S298O1lRO3Ej2P23B49gBHIc8sQ3rcpvddf09STN;
    
    public 36dil34Oo3A318ky64nU3rrSxQ08rML17zPKq7Dd4z3uRg437K73e81h1g7HD2qGDexXs0TCz816m397F1h1g8gXlMIEdQcQ(final Minecraft 052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w) {
        this.1Fu9C3vyTjF5nQEWTLQ7X4s5Q8c6Yc3XQHP9sQT10FvKq1R9kbSqZ8tJ8kAn = "";
        this.8QiR474wO74sqFB143vZ23U63qMzc9sRuH0aCz7Sy6Kyf3Tb9uTIY8hAsXzb = "";
        this.7sI24elao7itr9BPu6v7TsS02Q7n394hLy2Ao8nDw2KaTijs8198wxT2chzc = System.currentTimeMillis();
        this.9dBQn6dp46yx170Qm892S298O1lRO3Ej2P23B49gBHIc8sQ3rcpvddf09STN = false;
        this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w = 052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w;
    }
    
    public void 1al1z6HPjcWM58JEP12wdfVcpfrt5ppq0e18tXA4FxZIe21vyQVOriQ3684E(final String s) {
        this.9dBQn6dp46yx170Qm892S298O1lRO3Ej2P23B49gBHIc8sQ3rcpvddf09STN = false;
        this.04pgl36aK0r5F0lK02ufmDHG0d0sdr4uKAKd8FaQjsoqi7akk00hGu71gM00(s);
    }
    
    @Override
    public void 0ZAWW2m4DC7SxPr6o6N8d8D6Sxs3w0LjEl1nE5lRl2hU1aDiS8C0S8E92SVk(final String s) {
        this.9dBQn6dp46yx170Qm892S298O1lRO3Ej2P23B49gBHIc8sQ3rcpvddf09STN = true;
        this.04pgl36aK0r5F0lK02ufmDHG0d0sdr4uKAKd8FaQjsoqi7akk00hGu71gM00(this.8QiR474wO74sqFB143vZ23U63qMzc9sRuH0aCz7Sy6Kyf3Tb9uTIY8hAsXzb);
    }
    
    public void 04pgl36aK0r5F0lK02ufmDHG0d0sdr4uKAKd8FaQjsoqi7akk00hGu71gM00(final String 8QiR474wO74sqFB143vZ23U63qMzc9sRuH0aCz7Sy6Kyf3Tb9uTIY8hAsXzb) {
        if (!this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.1z4ObCPpG0p71XzmKI5pA52oCuNeQd7W52IDk8415gt4kK2zAQcGob4V39RR) {
            if (!this.9dBQn6dp46yx170Qm892S298O1lRO3Ej2P23B49gBHIc8sQ3rcpvddf09STN) {
                throw new 3tBcECvmFGJwIt49c5e7aQGWU25l6ZwG4jqJN8w81FeWxZ273df1Ogits7X89eg1Rs5gI25HcycLN0wThA7Zry9G9I5xN();
            }
        }
        else {
            this.8QiR474wO74sqFB143vZ23U63qMzc9sRuH0aCz7Sy6Kyf3Tb9uTIY8hAsXzb = 8QiR474wO74sqFB143vZ23U63qMzc9sRuH0aCz7Sy6Kyf3Tb9uTIY8hAsXzb;
            final 2CHDJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd 2chdJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd = new 2CHDJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd(this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw);
            final int 4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc = 2chdJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd.4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc();
            final int 1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4 = 2chdJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd.1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4();
            GL11.glClear(256);
            GL11.glMatrixMode(5889);
            GL11.glLoadIdentity();
            GL11.glOrtho(0.0, (double)4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc, (double)1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4, 0.0, 100.0, 300.0);
            GL11.glMatrixMode(5888);
            GL11.glLoadIdentity();
            GL11.glTranslatef(0.0f, 0.0f, -200.0f);
        }
    }
    
    @Override
    public void 48c4c5XvS2yf4SVtO4Z3DncCXvl3LP8BGC12I7nt661Q5Bo7ai3pgw9ZUT9p(final String 1Fu9C3vyTjF5nQEWTLQ7X4s5Q8c6Yc3XQHP9sQT10FvKq1R9kbSqZ8tJ8kAn) {
        if (!this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.1z4ObCPpG0p71XzmKI5pA52oCuNeQd7W52IDk8415gt4kK2zAQcGob4V39RR) {
            if (!this.9dBQn6dp46yx170Qm892S298O1lRO3Ej2P23B49gBHIc8sQ3rcpvddf09STN) {
                throw new 3tBcECvmFGJwIt49c5e7aQGWU25l6ZwG4jqJN8w81FeWxZ273df1Ogits7X89eg1Rs5gI25HcycLN0wThA7Zry9G9I5xN();
            }
        }
        else {
            this.7sI24elao7itr9BPu6v7TsS02Q7n394hLy2Ao8nDw2KaTijs8198wxT2chzc = 0L;
            this.1Fu9C3vyTjF5nQEWTLQ7X4s5Q8c6Yc3XQHP9sQT10FvKq1R9kbSqZ8tJ8kAn = 1Fu9C3vyTjF5nQEWTLQ7X4s5Q8c6Yc3XQHP9sQT10FvKq1R9kbSqZ8tJ8kAn;
            this.2b248hJW0CFQmYQrpRa3nLJYBe6E70gJB7r0fcMK5K0ucf260ZtBr92047tV(-1);
            this.7sI24elao7itr9BPu6v7TsS02Q7n394hLy2Ao8nDw2KaTijs8198wxT2chzc = 0L;
        }
    }
    
    @Override
    public void 2b248hJW0CFQmYQrpRa3nLJYBe6E70gJB7r0fcMK5K0ucf260ZtBr92047tV(final int n) {
        if (!this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.1z4ObCPpG0p71XzmKI5pA52oCuNeQd7W52IDk8415gt4kK2zAQcGob4V39RR) {
            if (!this.9dBQn6dp46yx170Qm892S298O1lRO3Ej2P23B49gBHIc8sQ3rcpvddf09STN) {
                throw new 3tBcECvmFGJwIt49c5e7aQGWU25l6ZwG4jqJN8w81FeWxZ273df1Ogits7X89eg1Rs5gI25HcycLN0wThA7Zry9G9I5xN();
            }
        }
        else {
            final long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis - this.7sI24elao7itr9BPu6v7TsS02Q7n394hLy2Ao8nDw2KaTijs8198wxT2chzc >= 20L) {
                this.7sI24elao7itr9BPu6v7TsS02Q7n394hLy2Ao8nDw2KaTijs8198wxT2chzc = currentTimeMillis;
                final 2CHDJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd 2chdJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd = new 2CHDJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd(this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw);
                final int 4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc = 2chdJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd.4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc();
                final int 1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4 = 2chdJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd.1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4();
                GL11.glClear(256);
                GL11.glMatrixMode(5889);
                GL11.glLoadIdentity();
                GL11.glOrtho(0.0, (double)4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc, (double)1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4, 0.0, 100.0, 300.0);
                GL11.glMatrixMode(5888);
                GL11.glLoadIdentity();
                GL11.glTranslatef(0.0f, 0.0f, -200.0f);
                GL11.glClear(16640);
                final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
                GL11.glBindTexture(3553, this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8("/dirt.png"));
                final float n2 = 32.0f;
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.0xlkp29IV3dqDsM1STBVfF0j99RiS6z898o5R0ZD1U10LYpJKhI0806gUiFW();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8v7F8G8g1104wyQ7q86jd6WFsS0S8C9C5G6r53pazN5nIQt79hRlifP4WcDq(789516);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(0.0, 1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4, 0.0, 0.0, 1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4 / n2);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc, 1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4, 0.0, 4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc / n2, 1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4 / n2);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc, 0.0, 0.0, 4TahmnleBXdYY38cIu9CQ9rvkIj8A9Z3EAkDI08C4P3XZLg2Oz957RaOFKwc / n2, 0.0);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(0.0, 0.0, 0.0, 0.0, 0.0);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                if (n >= 0) {
                    final int n3 = 100;
                    final int n4 = 2;
                    final int n5 = 13;
                    final int n6 = 1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4 - 16;
                    GL11.glDisable(3553);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.0xlkp29IV3dqDsM1STBVfF0j99RiS6z898o5R0ZD1U10LYpJKhI0806gUiFW();
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8v7F8G8g1104wyQ7q86jd6WFsS0S8C9C5G6r53pazN5nIQt79hRlifP4WcDq(8421504);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(n5, n6, 0.0);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(n5, n6 + n4, 0.0);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(n5 + n3, n6 + n4, 0.0);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(n5 + n3, n6, 0.0);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8v7F8G8g1104wyQ7q86jd6WFsS0S8C9C5G6r53pazN5nIQt79hRlifP4WcDq(8454016);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(n5, n6, 0.0);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(n5, n6 + n4, 0.0);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(n5 + n, n6 + n4, 0.0);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(n5 + n, n6, 0.0);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                    GL11.glEnable(3553);
                }
                this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.4gTIxYqR91GOe6nJ3qln6t9eH31Cng1A7QRR4E59Vhz8La6hfSFZ0nzE6aF2.7O80YtY13ocjL32iQirNQ7EqMUSsWbw50vG6T0eNj0T6K7665q49ol6j3MF1(this.8QiR474wO74sqFB143vZ23U63qMzc9sRuH0aCz7Sy6Kyf3Tb9uTIY8hAsXzb, 13, 1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4 - 40, 16777215);
                this.052BGHDX3b10GJbC2NA08TqcGjei0lrPM3j1IpuScd0vK89RXL0Qz1C7gR9w.4gTIxYqR91GOe6nJ3qln6t9eH31Cng1A7QRR4E59Vhz8La6hfSFZ0nzE6aF2.7O80YtY13ocjL32iQirNQ7EqMUSsWbw50vG6T0eNj0T6K7665q49ol6j3MF1(this.1Fu9C3vyTjF5nQEWTLQ7X4s5Q8c6Yc3XQHP9sQT10FvKq1R9kbSqZ8tJ8kAn, 13, 1bSpi35qTFft8sO8Hoh6bfxcTlpFtdeap71u0QTW8biy1494Qs61xzq7n7V4 - 28, 1090519039);
                Display.update();
                try {
                    Thread.yield();
                }
                catch (final Exception ex) {}
            }
        }
    }
}
