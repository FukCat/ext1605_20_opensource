import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 6E28xCT2Hz4T67MyVptaKwOouh1rUHw3QX4UZ2KmTd2Og19gJ4NYtVu5PFp6zYPv2S6G1LFOSHL5Pz3w9nIwO9yEOror6ke4A0iPHD extends 30a14b8670TpOgDYqya84etR7JlL5C8KILqCqsHHTt61TDGF6x8vAs2QVzyg5c3c363u5zk47qehIEn2YedE71xoM5BW9
{
    public boolean 2dhsb8T240yl38UFtaBHLzbY5Pq40xnN3Bu20HO00lMJOoDK4ZY7bHHyhNih;
    public int 53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc;
    public String 03rDPlFFjq9pib38ouvvTQa2doh2l18SKq3dD9U45aQ4a98HV07F5oqr7237;
    
    public 6E28xCT2Hz4T67MyVptaKwOouh1rUHw3QX4UZ2KmTd2Og19gJ4NYtVu5PFp6zYPv2S6G1LFOSHL5Pz3w9nIwO9yEOror6ke4A0iPHD() {
        this.2dhsb8T240yl38UFtaBHLzbY5Pq40xnN3Bu20HO00lMJOoDK4ZY7bHHyhNih = false;
        this.53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc = -1;
        this.03rDPlFFjq9pib38ouvvTQa2doh2l18SKq3dD9U45aQ4a98HV07F5oqr7237 = "";
    }
    
    public 6E28xCT2Hz4T67MyVptaKwOouh1rUHw3QX4UZ2KmTd2Og19gJ4NYtVu5PFp6zYPv2S6G1LFOSHL5Pz3w9nIwO9yEOror6ke4A0iPHD(final String 7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS, final int 53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc) {
        this.2dhsb8T240yl38UFtaBHLzbY5Pq40xnN3Bu20HO00lMJOoDK4ZY7bHHyhNih = false;
        this.53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc = -1;
        this.03rDPlFFjq9pib38ouvvTQa2doh2l18SKq3dD9U45aQ4a98HV07F5oqr7237 = "";
        this.53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc = 53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc;
        this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS = 7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc = dataInputStream.readInt();
        this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS = dataInputStream.readUTF();
        this.03rDPlFFjq9pib38ouvvTQa2doh2l18SKq3dD9U45aQ4a98HV07F5oqr7237 = dataInputStream.readUTF();
        try {
            this.2dhsb8T240yl38UFtaBHLzbY5Pq40xnN3Bu20HO00lMJOoDK4ZY7bHHyhNih = 3TRs4A75rS0TtcUL36iKx34E6k4NB1XXM6i8cs9Khd3OUdqLNT1q99wqrgwtn53Nk1LerxKV5f8Dlt8MOX4uKK6df8l.8s2o5kgQR2KUW7HYNe66V6nvFcbh46mjpeKP79Ox3XiV7okbLUZKWede01qz(this.53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc + "" + this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS, this.03rDPlFFjq9pib38ouvvTQa2doh2l18SKq3dD9U45aQ4a98HV07F5oqr7237);
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc);
        dataOutputStream.writeUTF(this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS);
        try {
            dataOutputStream.writeUTF(this.03rDPlFFjq9pib38ouvvTQa2doh2l18SKq3dD9U45aQ4a98HV07F5oqr7237 = 3TRs4A75rS0TtcUL36iKx34E6k4NB1XXM6i8cs9Khd3OUdqLNT1q99wqrgwtn53Nk1LerxKV5f8Dlt8MOX4uKK6df8l.8K1P472wUu8B0s89g2ZZ6Qn9pn5bZzk2gP3rg589enPD1Im9FYHL53OgM5K6(this.53NZ7DU3AQ1m4WPAng6jf7tkEcec5ou1U41r4VF97BQx4283p4P8jQqpRtdc + "" + this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS, 3TRs4A75rS0TtcUL36iKx34E6k4NB1XXM6i8cs9Khd3OUdqLNT1q99wqrgwtn53Nk1LerxKV5f8Dlt8MOX4uKK6df8l.5lX8X5yivf7DSGr0s2G13Eu4UeF1813nrrHhGM1pL8m1fFm44I8s6apKHz60));
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        if (this.2dhsb8T240yl38UFtaBHLzbY5Pq40xnN3Bu20HO00lMJOoDK4ZY7bHHyhNih) {
            7l2e0fYR96rf6dpREUY30xWh65d1rOc3abJQrqtvYEW6GNMN9qeJW237wlzS37y9Xt8xV209FRDRzpsI4HOsGN7skzB8a0.4TOtWqH41d7jD9655kwO3Cg5UDFI8gwADO0lrcf8Wo27yqT11iUXxA20819F("[SecureChat] valid");
            01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.36fV28118dKFG2m0b7LfVD4kB8xETB1drZw35Ez94lGRqlV6j136WD3dAM71(this);
        }
        else {
            7l2e0fYR96rf6dpREUY30xWh65d1rOc3abJQrqtvYEW6GNMN9qeJW237wlzS37y9Xt8xV209FRDRzpsI4HOsGN7skzB8a0.4TOtWqH41d7jD9655kwO3Cg5UDFI8gwADO0lrcf8Wo27yqT11iUXxA20819F("[SecureChat] RESPONSE");
        }
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS.length() + this.03rDPlFFjq9pib38ouvvTQa2doh2l18SKq3dD9U45aQ4a98HV07F5oqr7237.length() + 4;
    }
}
