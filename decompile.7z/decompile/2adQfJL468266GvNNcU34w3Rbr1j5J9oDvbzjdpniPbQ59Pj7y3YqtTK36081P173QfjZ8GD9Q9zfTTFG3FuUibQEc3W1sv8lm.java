import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2adQfJL468266GvNNcU34w3Rbr1j5J9oDvbzjdpniPbQ59Pj7y3YqtTK36081P173QfjZ8GD9Q9zfTTFG3FuUibQEc3W1sv8lm extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public String 3T6IrHc0X9Ak14eK63Iy1S97LYXXvTsap6WKwScI4v0JScM46awBh6Uc2cXN;
    
    public 2adQfJL468266GvNNcU34w3Rbr1j5J9oDvbzjdpniPbQ59Pj7y3YqtTK36081P173QfjZ8GD9Q9zfTTFG3FuUibQEc3W1sv8lm() {
    }
    
    public 2adQfJL468266GvNNcU34w3Rbr1j5J9oDvbzjdpniPbQ59Pj7y3YqtTK36081P173QfjZ8GD9Q9zfTTFG3FuUibQEc3W1sv8lm(final String 3t6IrHc0X9Ak14eK63Iy1S97LYXXvTsap6WKwScI4v0JScM46awBh6Uc2cXN) {
        this.3T6IrHc0X9Ak14eK63Iy1S97LYXXvTsap6WKwScI4v0JScM46awBh6Uc2cXN = 3t6IrHc0X9Ak14eK63Iy1S97LYXXvTsap6WKwScI4v0JScM46awBh6Uc2cXN;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.3T6IrHc0X9Ak14eK63Iy1S97LYXXvTsap6WKwScI4v0JScM46awBh6Uc2cXN = dataInputStream.readUTF();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeUTF(this.3T6IrHc0X9Ak14eK63Iy1S97LYXXvTsap6WKwScI4v0JScM46awBh6Uc2cXN);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.3YipMjs4E41m0IZ0Ze7BFl1HTgRfKkkz490VwVIMQnFg6c2WqRjJr0Y536Bd(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 4 + this.3T6IrHc0X9Ak14eK63Iy1S97LYXXvTsap6WKwScI4v0JScM46awBh6Uc2cXN.length() + 4;
    }
}
