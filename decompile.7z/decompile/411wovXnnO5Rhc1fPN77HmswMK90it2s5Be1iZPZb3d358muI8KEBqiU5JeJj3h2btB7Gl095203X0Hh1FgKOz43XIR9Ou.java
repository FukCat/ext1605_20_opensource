// 
// Decompiled by Procyon v0.6.0
// 

public class 411wovXnnO5Rhc1fPN77HmswMK90it2s5Be1iZPZb3d358muI8KEBqiU5JeJj3h2btB7Gl095203X0Hh1FgKOz43XIR9Ou extends 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03
{
    public 411wovXnnO5Rhc1fPN77HmswMK90it2s5Be1iZPZb3d358muI8KEBqiU5JeJj3h2btB7Gl095203X0Hh1FgKOz43XIR9Ou(final int n, final int n2, final int n3, final String s) {
        super(n, n2, n3, 150, 20, s);
    }
}
