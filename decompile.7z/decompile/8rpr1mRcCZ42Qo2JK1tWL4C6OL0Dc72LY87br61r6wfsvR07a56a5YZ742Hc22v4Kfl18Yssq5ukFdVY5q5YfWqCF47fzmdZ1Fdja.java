import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.util.zip.GZIPOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.DataInput;
import java.io.DataInputStream;
import java.util.zip.GZIPInputStream;
import java.io.InputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 8rpr1mRcCZ42Qo2JK1tWL4C6OL0Dc72LY87br61r6wfsvR07a56a5YZ742Hc22v4Kfl18Yssq5ukFdVY5q5YfWqCF47fzmdZ1Fdja
{
    public static 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 0m5h26V9ZV6Zs60a7lfRofk6Z8nORG55r9yTihMQNW85jp82W1rGPribGSUz(final InputStream in) throws IOException {
        final DataInputStream dataInputStream = new DataInputStream(new GZIPInputStream(in));
        8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 5AgJ3LMvk94JEBsy4DSgeu0z9DeBIBDd71q4gEu5LqSMiHvex10H9MTmo7Kg;
        try {
            5AgJ3LMvk94JEBsy4DSgeu0z9DeBIBDd71q4gEu5LqSMiHvex10H9MTmo7Kg = 5AgJ3LMvk94JEBsy4DSgeu0z9DeBIBDd71q4gEu5LqSMiHvex10H9MTmo7Kg(dataInputStream);
        }
        finally {
            dataInputStream.close();
        }
        return 5AgJ3LMvk94JEBsy4DSgeu0z9DeBIBDd71q4gEu5LqSMiHvex10H9MTmo7Kg;
    }
    
    public static void 8Fhlt542FJAc7BX0rO8g6TV0Bj63Zo6X215xpm9y4Zb2u9hx46pB4yhavF8p(final 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419, final OutputStream out) throws IOException {
        final DataOutputStream dataOutputStream = new DataOutputStream(new GZIPOutputStream(out));
        try {
            7EbMH8de151SR2L2arZXn97IO8Xqqb8NOxUMR1w853ZlfQ6ZC55i7yf660kJ(8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419, dataOutputStream);
        }
        finally {
            dataOutputStream.close();
        }
    }
    
    public static 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 76rrKQX3zh98MYRCA8Apy47z9e85x0JDu5k1N24qYSidXPfeppX3PP6LHx2o(final byte[] buf) throws IOException {
        final DataInputStream dataInputStream = new DataInputStream(new GZIPInputStream(new ByteArrayInputStream(buf)));
        8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 5AgJ3LMvk94JEBsy4DSgeu0z9DeBIBDd71q4gEu5LqSMiHvex10H9MTmo7Kg;
        try {
            5AgJ3LMvk94JEBsy4DSgeu0z9DeBIBDd71q4gEu5LqSMiHvex10H9MTmo7Kg = 5AgJ3LMvk94JEBsy4DSgeu0z9DeBIBDd71q4gEu5LqSMiHvex10H9MTmo7Kg(dataInputStream);
        }
        finally {
            dataInputStream.close();
        }
        return 5AgJ3LMvk94JEBsy4DSgeu0z9DeBIBDd71q4gEu5LqSMiHvex10H9MTmo7Kg;
    }
    
    public static byte[] 41uf45GyLcZ89a34DR9o9PyAe3Lqx165i9Cis55125ir6Q16Ya5w878DK9eI(final 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419) throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final DataOutputStream dataOutputStream = new DataOutputStream(new GZIPOutputStream(out));
        try {
            7EbMH8de151SR2L2arZXn97IO8Xqqb8NOxUMR1w853ZlfQ6ZC55i7yf660kJ(8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419, dataOutputStream);
        }
        finally {
            dataOutputStream.close();
        }
        return out.toByteArray();
    }
    
    public static 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 5AgJ3LMvk94JEBsy4DSgeu0z9DeBIBDd71q4gEu5LqSMiHvex10H9MTmo7Kg(final DataInput dataInput) throws IOException {
        final 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi 5ldnVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814 = 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi.5LDNVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814(dataInput);
        if (5ldnVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814 instanceof 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419) {
            return (8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419)5ldnVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814;
        }
        throw new IOException("Root tag must be a named compound tag");
    }
    
    public static void 7EbMH8de151SR2L2arZXn97IO8Xqqb8NOxUMR1w853ZlfQ6ZC55i7yf660kJ(final 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419, final DataOutput dataOutput) throws IOException {
        03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi.78J371L0tO529ZkE8c9oYbZ1V4VtvwmXY8SqyrOhkx0OrNxa9X2sjgw70byi(8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419, dataOutput);
    }
}
