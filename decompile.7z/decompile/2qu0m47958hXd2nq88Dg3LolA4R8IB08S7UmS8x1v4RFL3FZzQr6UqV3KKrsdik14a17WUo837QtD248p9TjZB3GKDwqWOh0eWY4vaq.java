import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2qu0m47958hXd2nq88Dg3LolA4R8IB08S7UmS8x1v4RFL3FZzQr6UqV3KKrsdik14a17WUo837QtD248p9TjZB3GKDwqWOh0eWY4vaq extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        throw new UnsupportedOperationException("Not implemented yet");
    }
}
