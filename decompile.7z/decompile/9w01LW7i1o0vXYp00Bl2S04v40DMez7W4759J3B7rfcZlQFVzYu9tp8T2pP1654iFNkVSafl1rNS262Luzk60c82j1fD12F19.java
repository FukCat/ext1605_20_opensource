// 
// Decompiled by Procyon v0.6.0
// 

public interface 9w01LW7i1o0vXYp00Bl2S04v40DMez7W4759J3B7rfcZlQFVzYu9tp8T2pP1654iFNkVSafl1rNS262Luzk60c82j1fD12F19
{
    boolean 529kIgbItU22E3O3VE3qip6Qg03EgH4PNYZ29GuyhqQB304wIp4IGgc624cq(final int p0, final int p1);
    
    9m2wWv7Y0P6wvrh59Qp3DG2Cs297QBiT9d3C2Ym8a3VBQf0y8ksZza1rWedXIKg0UcWrch6Q377o8vJ607zis39k6dbDXymg 6uz6MEe3z610A8yihFN1eCW159ctDGOl6n48O7y7X2q0Yixy69v50LXjBrL0(final int p0, final int p1);
    
    void 9HvnUEDIYe2D6w2c4s3vEdxWDr4HT9Kt8yfTJQZ4213Mk2g4vN94lpy586WQ(final 9w01LW7i1o0vXYp00Bl2S04v40DMez7W4759J3B7rfcZlQFVzYu9tp8T2pP1654iFNkVSafl1rNS262Luzk60c82j1fD12F19 p0, final int p1, final int p2);
    
    boolean 3yhb0qt06Y3sH18UM4iF8Iq7icIw0GFaL4TKavQ444bRN735itOe4j6L81Zs(final boolean p0, final 7soGcRyClKm262tv21ia5Io4pGbRhP8v7wGr7xH4O8Z59AC85O8Wqq7I2NOcUep0i03wj8GnnF845Ipyk386GCma9111dZE1 p1);
    
    boolean 6C9JX2468X0rs93F94wqk7IQyXDSYb9p12Inq5Sh2RGt902z1M709QdbThN5();
    
    boolean 70n3YsWUITuDU1wR4V74m6e7v2TUoKTqIn85EfoSOOUg4r294E1l5I5JX7rM();
}
