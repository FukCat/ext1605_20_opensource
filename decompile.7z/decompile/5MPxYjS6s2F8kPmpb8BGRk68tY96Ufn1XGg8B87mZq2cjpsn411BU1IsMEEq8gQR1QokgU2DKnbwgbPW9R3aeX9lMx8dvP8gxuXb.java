// 
// Decompiled by Procyon v0.6.0
// 

public class 5MPxYjS6s2F8kPmpb8BGRk68tY96Ufn1XGg8B87mZq2cjpsn411BU1IsMEEq8gQR1QokgU2DKnbwgbPW9R3aeX9lMx8dvP8gxuXb extends 9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned
{
    public 5MPxYjS6s2F8kPmpb8BGRk68tY96Ufn1XGg8B87mZq2cjpsn411BU1IsMEEq8gQR1QokgU2DKnbwgbPW9R3aeX9lMx8dvP8gxuXb(final int n) {
        super(n);
        this.2sdBrNjKX22uvdoss0gO3p8E1GnO8ZtGWb6b71FKPMKC1OqrDw0m6v2BG327 = 64;
    }
    
    @Override
    public boolean 0N8Tblq44D45hWE12nPmkuq9sOgtNeAo1rX80E96XFGn8QUj1F1vzKM511HQ(final 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex, final 4C3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4 4c3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4, final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final int n4) {
        if (n4 == 0) {
            return false;
        }
        if (n4 == 1) {
            return false;
        }
        int n5 = 0;
        if (n4 == 4) {
            n5 = 1;
        }
        if (n4 == 3) {
            n5 = 2;
        }
        if (n4 == 5) {
            n5 = 3;
        }
        final 3Ma29eR6ngg8ic3b5h6L86txMe0502T48UTrlRXf567kIlpo8Gsj6D8xhDv0nG534J62otdlEJFUxx3OsTl8lJj9yjY2YKI 3Ma29eR6ngg8ic3b5h6L86txMe0502T48UTrlRXf567kIlpo8Gsj6D8xhDv0nG534J62otdlEJFUxx3OsTl8lJj9yjY2YKI = new 3Ma29eR6ngg8ic3b5h6L86txMe0502T48UTrlRXf567kIlpo8Gsj6D8xhDv0nG534J62otdlEJFUxx3OsTl8lJj9yjY2YKI(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3, n5);
        if (3Ma29eR6ngg8ic3b5h6L86txMe0502T48UTrlRXf567kIlpo8Gsj6D8xhDv0nG534J62otdlEJFUxx3OsTl8lJj9yjY2YKI.0IQ041oSZa1J0Ct15s39E0KaU1sloo0wl4QU1RMrBemJkr7M54di2JgA429K()) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7OhRvcs86wy35mcXvZXvSp35C9G263nN06i0tvqI9n8Xlv9vFjpEAwrvbOSR(3Ma29eR6ngg8ic3b5h6L86txMe0502T48UTrlRXf567kIlpo8Gsj6D8xhDv0nG534J62otdlEJFUxx3OsTl8lJj9yjY2YKI);
            --43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex.79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp;
        }
        return true;
    }
}
