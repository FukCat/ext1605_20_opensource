import org.lwjgl.input.Mouse;
import java.nio.IntBuffer;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Cursor;
import java.awt.Component;

// 
// Decompiled by Procyon v0.6.0
// 

public class 73boxG1IIXqg88A2Bru5vDZR9Cpzvc05Wj8INt1g3ogfA3St8TbCO3dS187Jv0Vl6XjRMtZNJv4wj0S35TG8Bt5yMzPH2kfl
{
    private Component 60o3y0e0318bv5Q43Q8ui9E6kpz93i1qnJGgMc4Ym8dI5Grl7f4hWaHlk5Fu;
    private Cursor 706LyWDkFeGVkW1QC4KE40JI9kb6sh8sEWbUBdzMPVt8uvupRyZBmfp89eD1;
    public int 8zG67O8OYFeO4xLm3dp41WBsN9nQ75ViT4t93tHpSmdcHieBH6lK07RS5AaW;
    public int 7pHS9hWdfJQUwPH0oh9Yw0HcWVDHIS54S40rL9ke1MPAVRK99qhZq7y2wUur;
    private int 8X3tbnr05JfwT96D07zSg096lG5PFGz5XOFpQp7Dgm284ejdx1z4BMLMpobe;
    private long 79Bc401TMcl72L08Pxg1H0113svqWOc8995iyo3Lir8K42jg00L5qJs5AKCi;
    
    public 73boxG1IIXqg88A2Bru5vDZR9Cpzvc05Wj8INt1g3ogfA3St8TbCO3dS187Jv0Vl6XjRMtZNJv4wj0S35TG8Bt5yMzPH2kfl(final Component 60o3y0e0318bv5Q43Q8ui9E6kpz93i1qnJGgMc4Ym8dI5Grl7f4hWaHlk5Fu) {
        this.8X3tbnr05JfwT96D07zSg096lG5PFGz5XOFpQp7Dgm284ejdx1z4BMLMpobe = 10;
        this.79Bc401TMcl72L08Pxg1H0113svqWOc8995iyo3Lir8K42jg00L5qJs5AKCi = -1L;
        this.60o3y0e0318bv5Q43Q8ui9E6kpz93i1qnJGgMc4Ym8dI5Grl7f4hWaHlk5Fu = 60o3y0e0318bv5Q43Q8ui9E6kpz93i1qnJGgMc4Ym8dI5Grl7f4hWaHlk5Fu;
        final IntBuffer 1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2 = 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1R0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2(1);
        1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2.put(0);
        1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2.flip();
        final IntBuffer 1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh3 = 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1R0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2(1024);
        try {
            this.706LyWDkFeGVkW1QC4KE40JI9kb6sh8sEWbUBdzMPVt8uvupRyZBmfp89eD1 = new Cursor(32, 32, 16, 16, 1, 1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh3, 1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2);
        }
        catch (final LWJGLException ex) {
            ex.printStackTrace();
        }
    }
    
    public void 90saknE592QFhTGBXt0ceqRU24410UGDcZdmvgknAbl7KNpEHIYwGDlnn903() {
        Mouse.setGrabbed(true);
        this.8zG67O8OYFeO4xLm3dp41WBsN9nQ75ViT4t93tHpSmdcHieBH6lK07RS5AaW = 0;
        this.7pHS9hWdfJQUwPH0oh9Yw0HcWVDHIS54S40rL9ke1MPAVRK99qhZq7y2wUur = 0;
    }
    
    public void 2YsFAXv246x8upiAh3qP33MKBPMnmT6Ee09DUc66940373VtwqGy0nQC0kM7() {
        Mouse.setCursorPosition(this.60o3y0e0318bv5Q43Q8ui9E6kpz93i1qnJGgMc4Ym8dI5Grl7f4hWaHlk5Fu.getWidth() / 2, this.60o3y0e0318bv5Q43Q8ui9E6kpz93i1qnJGgMc4Ym8dI5Grl7f4hWaHlk5Fu.getHeight() / 2);
        Mouse.setGrabbed(false);
    }
    
    public void 5o9ZY0G7p5fNgZ9bi6900kXs8c75hP5NRVDW8yBdz4JLiLL672ME6CNTbp5C() {
        if (this.79Bc401TMcl72L08Pxg1H0113svqWOc8995iyo3Lir8K42jg00L5qJs5AKCi == -1L) {
            this.79Bc401TMcl72L08Pxg1H0113svqWOc8995iyo3Lir8K42jg00L5qJs5AKCi = System.currentTimeMillis();
        }
        final float n = (System.currentTimeMillis() - this.79Bc401TMcl72L08Pxg1H0113svqWOc8995iyo3Lir8K42jg00L5qJs5AKCi) / 1000.0f;
        this.79Bc401TMcl72L08Pxg1H0113svqWOc8995iyo3Lir8K42jg00L5qJs5AKCi = System.currentTimeMillis();
        if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7 != null) {
            for (int i = 0; i != 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7.length; ++i) {
                if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i] != null && (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getRXAxisValue() != 0.0f || 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getRYAxisValue() != 0.0f)) {
                    if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getRXAxisValue() != -1.0f || 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getRYAxisValue() != -1.0f) {
                        this.8zG67O8OYFeO4xLm3dp41WBsN9nQ75ViT4t93tHpSmdcHieBH6lK07RS5AaW = (int)(1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getRXAxisValue() * 500.0f * 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4T40SjxPM7Zgd16lkH4wCJeyIT159Gxi3Bz0h3trX928I683iCL1KZ3iK4Q6 * n);
                        if (this.8zG67O8OYFeO4xLm3dp41WBsN9nQ75ViT4t93tHpSmdcHieBH6lK07RS5AaW > -1 && this.8zG67O8OYFeO4xLm3dp41WBsN9nQ75ViT4t93tHpSmdcHieBH6lK07RS5AaW < 1) {
                            this.8zG67O8OYFeO4xLm3dp41WBsN9nQ75ViT4t93tHpSmdcHieBH6lK07RS5AaW = 0;
                        }
                        this.7pHS9hWdfJQUwPH0oh9Yw0HcWVDHIS54S40rL9ke1MPAVRK99qhZq7y2wUur = (int)(-1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getRYAxisValue() * 250.0f * 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4T40SjxPM7Zgd16lkH4wCJeyIT159Gxi3Bz0h3trX928I683iCL1KZ3iK4Q6 * n);
                        if (this.7pHS9hWdfJQUwPH0oh9Yw0HcWVDHIS54S40rL9ke1MPAVRK99qhZq7y2wUur > -1 && this.7pHS9hWdfJQUwPH0oh9Yw0HcWVDHIS54S40rL9ke1MPAVRK99qhZq7y2wUur < 1) {
                            this.7pHS9hWdfJQUwPH0oh9Yw0HcWVDHIS54S40rL9ke1MPAVRK99qhZq7y2wUur = 0;
                        }
                        if (this.8zG67O8OYFeO4xLm3dp41WBsN9nQ75ViT4t93tHpSmdcHieBH6lK07RS5AaW != 0 || this.7pHS9hWdfJQUwPH0oh9Yw0HcWVDHIS54S40rL9ke1MPAVRK99qhZq7y2wUur != 0) {
                            return;
                        }
                    }
                }
            }
        }
        this.8zG67O8OYFeO4xLm3dp41WBsN9nQ75ViT4t93tHpSmdcHieBH6lK07RS5AaW = Mouse.getDX();
        this.7pHS9hWdfJQUwPH0oh9Yw0HcWVDHIS54S40rL9ke1MPAVRK99qhZq7y2wUur = Mouse.getDY();
    }
}
