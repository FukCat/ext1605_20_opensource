import java.io.File;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 26s50tt2Gmh58T1rqi2LTnzitgBCdT2wkgadu80DokYaK5CLU2taVo0pYWUw5rDkI7glswGnQOl1P0RsIn4G795UvQ2CwA8u6n
{
    public static void main(final String[] array) {
        try {
            final Field declaredField = Minecraft.class.getDeclaredField("minecraftDir");
            AccessibleObject.setAccessible(new Field[] { declaredField }, true);
            declaredField.set(null, new File("."));
        }
        catch (final Exception ex) {
            ex.printStackTrace();
            return;
        }
        Minecraft.main(array);
    }
}
