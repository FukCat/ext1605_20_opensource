import javax.imageio.ImageIO;
import java.io.InputStream;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import java.awt.Graphics;
import java.awt.image.ImageObserver;
import java.awt.Image;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.awt.image.BufferedImage;
import java.util.HashMap;

// 
// Decompiled by Procyon v0.6.0
// 

public class 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u
{
    public static boolean 74SI37YptSL1M6a7AVrVZ9XFV92E9590238ZJV9zp8N1Su4F2h5qDXyzPKrx;
    private HashMap<String, Integer> 5UdGK0wEM6v4AGH0T941JK6d797bl9689948zI34Cha17gfLJBB3XuMO74Z5;
    private HashMap<Integer, BufferedImage> 668ZtS069T2Mwwo5o7gb186Pp684TPwjjYSq12A1mlbQjMmOCWkJ3a4Py77M;
    private IntBuffer 394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W;
    private ByteBuffer 9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6;
    private List<2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38> 1b5az140vr28pT9hLc684O25m9Evoa56NHU0937B5v1M9PKJWf8S413h2GFq;
    private Map<String, 2rCv0397007kD89EPcxiQ2JDAAi25AKiBd86823WZdJ9ug1NT497P2D5759oQ92r2Eq99Z1fP1UD4zvzHiLal32tpd3fcXlwIIm2m> 77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B;
    public 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S 78OxWKhpSoq2g2GiUNej2aKIJrP7X69zer9a141qoQdboWo1BnWwfu6q2Xhc;
    private boolean 57P4aWFVQ032sr5GrCh0u15J37F72M40X5n83L1d45UL3QxMP14AMhHMb9M3;
    public 448SZjo4GXVxd41rMkuleEoypZ381txmLy4zVLMTZ9Z9NV5SoR97zQ6f1786Wu4D3xaYdDLy54g9qva737VlgKM23A9xGH1EohC 8nB09v2wL31LD7473aXNMbJrX47AX71iPMP6yPX544heeDvxj78y5qTJYk68;
    public 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 2S9jv1MbYm5W1ar7Hsh1SgP21a6qr4sS0K72V1Lb4W5l3elheXn55WnwlcoA;
    
    public 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u(final 448SZjo4GXVxd41rMkuleEoypZ381txmLy4zVLMTZ9Z9NV5SoR97zQ6f1786Wu4D3xaYdDLy54g9qva737VlgKM23A9xGH1EohC 8nB09v2wL31LD7473aXNMbJrX47AX71iPMP6yPX544heeDvxj78y5qTJYk68, final 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S 78OxWKhpSoq2g2GiUNej2aKIJrP7X69zer9a141qoQdboWo1BnWwfu6q2Xhc) {
        this.5UdGK0wEM6v4AGH0T941JK6d797bl9689948zI34Cha17gfLJBB3XuMO74Z5 = new HashMap<String, Integer>();
        this.668ZtS069T2Mwwo5o7gb186Pp684TPwjjYSq12A1mlbQjMmOCWkJ3a4Py77M = new HashMap<Integer, BufferedImage>();
        this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W = 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1R0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2(1);
        this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6 = 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.91EuTmkXm8xAIAY7j7v6912p5y1QFEu55cAH1a443YZgof0oct95U9qVT07h(4194304);
        this.1b5az140vr28pT9hLc684O25m9Evoa56NHU0937B5v1M9PKJWf8S413h2GFq = new ArrayList<2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38>();
        this.77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B = new HashMap<String, 2rCv0397007kD89EPcxiQ2JDAAi25AKiBd86823WZdJ9ug1NT497P2D5759oQ92r2Eq99Z1fP1UD4zvzHiLal32tpd3fcXlwIIm2m>();
        this.57P4aWFVQ032sr5GrCh0u15J37F72M40X5n83L1d45UL3QxMP14AMhHMb9M3 = false;
        this.2S9jv1MbYm5W1ar7Hsh1SgP21a6qr4sS0K72V1Lb4W5l3elheXn55WnwlcoA = new 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8();
        this.8nB09v2wL31LD7473aXNMbJrX47AX71iPMP6yPX544heeDvxj78y5qTJYk68 = 8nB09v2wL31LD7473aXNMbJrX47AX71iPMP6yPX544heeDvxj78y5qTJYk68;
        this.78OxWKhpSoq2g2GiUNej2aKIJrP7X69zer9a141qoQdboWo1BnWwfu6q2Xhc = 78OxWKhpSoq2g2GiUNej2aKIJrP7X69zer9a141qoQdboWo1BnWwfu6q2Xhc;
    }
    
    public int 7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8(final String str) {
        final 3W0d28OFdXcKp4p5sJF2NY3wOKKdPb2FwuG0BLk9y18f2pN4kKKw9zLnwO3k3RS31Nz2bMsm8s5q4D0514o6bz9M7kScW8 1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0 = this.8nB09v2wL31LD7473aXNMbJrX47AX71iPMP6yPX544heeDvxj78y5qTJYk68.1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0;
        final Integer n = this.5UdGK0wEM6v4AGH0T941JK6d797bl9689948zI34Cha17gfLJBB3XuMO74Z5.get(str);
        if (n != null) {
            return n;
        }
        try {
            this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W.clear();
            6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.52DHX6qz0xD4W6xAaHcb3Y5lgdft9Ojb4P321YtSO802tDB5S0O0WW0iqaoO(this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W);
            final int value = this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W.get(0);
            if (str.startsWith("##")) {
                this.124rSc1BULjBUVqqDs8I2ysTI36fBwBRz97QzRP7TA178c1z90I3p54ydTJ5(this.80zP9Ek8WxGJ5syBZomdG8M4ZtYS42SYBhK71oYeN4bm2xDbka36t4NgCv5r(this.6Y6At49CUc59G341H19D7WD31Nq480a9ni7bM1Y4l5x2a18LJLiG1Z5Uv9sB(1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0.35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0(str.substring(2)))), value);
            }
            else if (str.startsWith("%%")) {
                this.57P4aWFVQ032sr5GrCh0u15J37F72M40X5n83L1d45UL3QxMP14AMhHMb9M3 = true;
                this.124rSc1BULjBUVqqDs8I2ysTI36fBwBRz97QzRP7TA178c1z90I3p54ydTJ5(this.6Y6At49CUc59G341H19D7WD31Nq480a9ni7bM1Y4l5x2a18LJLiG1Z5Uv9sB(1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0.35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0(str.substring(2))), value);
                this.57P4aWFVQ032sr5GrCh0u15J37F72M40X5n83L1d45UL3QxMP14AMhHMb9M3 = false;
            }
            else {
                this.124rSc1BULjBUVqqDs8I2ysTI36fBwBRz97QzRP7TA178c1z90I3p54ydTJ5(this.6Y6At49CUc59G341H19D7WD31Nq480a9ni7bM1Y4l5x2a18LJLiG1Z5Uv9sB(1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0.35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0(str)), value);
            }
            this.5UdGK0wEM6v4AGH0T941JK6d797bl9689948zI34Cha17gfLJBB3XuMO74Z5.put(str, value);
            return value;
        }
        catch (final IOException ex) {
            throw new RuntimeException("!!");
        }
        catch (final IllegalArgumentException cause) {
            System.err.println("Failed to load resource: " + str);
            throw new RuntimeException(cause);
        }
    }
    
    private BufferedImage 80zP9Ek8WxGJ5syBZomdG8M4ZtYS42SYBhK71oYeN4bm2xDbka36t4NgCv5r(final BufferedImage bufferedImage) {
        final int n = bufferedImage.getWidth() / 16;
        final BufferedImage bufferedImage2 = new BufferedImage(16, bufferedImage.getHeight() * n, 2);
        final Graphics graphics = bufferedImage2.getGraphics();
        for (int i = 0; i < n; ++i) {
            graphics.drawImage(bufferedImage, -i * 16, i * bufferedImage.getHeight(), null);
        }
        graphics.dispose();
        return bufferedImage2;
    }
    
    public int 1BSFEHd336lH8JfA2w35JiGWqukE049E001767W1o8r4eUhCdf1SuM948qw6(final BufferedImage value) {
        this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W.clear();
        6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.52DHX6qz0xD4W6xAaHcb3Y5lgdft9Ojb4P321YtSO802tDB5S0O0WW0iqaoO(this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W);
        final int value2 = this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W.get(0);
        this.124rSc1BULjBUVqqDs8I2ysTI36fBwBRz97QzRP7TA178c1z90I3p54ydTJ5(value, value2);
        this.668ZtS069T2Mwwo5o7gb186Pp684TPwjjYSq12A1mlbQjMmOCWkJ3a4Py77M.put(value2, value);
        return value2;
    }
    
    public void 124rSc1BULjBUVqqDs8I2ysTI36fBwBRz97QzRP7TA178c1z90I3p54ydTJ5(final BufferedImage bufferedImage, final int n) {
        GL11.glBindTexture(3553, n);
        if (5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.74SI37YptSL1M6a7AVrVZ9XFV92E9590238ZJV9zp8N1Su4F2h5qDXyzPKrx) {
            GL11.glTexParameteri(3553, 10241, 9987);
            GL11.glTexParameteri(3553, 10240, 9729);
        }
        else {
            GL11.glTexParameteri(3553, 10241, 3p9u95CB1CP0y3UiTUZMGY05o15X75Oi03v43rZTG0wGCHvXqU15Kt1Q8k8Op87au5qr4U1GCvu00LTfk2w3YhwqE0it1tw2g11k.48H3fYB8k2jE5s5HC81S9Sm600nFD73Lb4N90Pl1F0LSIx70mF1gldgvzgRz ? 9729 : 9728);
            GL11.glTexParameteri(3553, 10240, 3p9u95CB1CP0y3UiTUZMGY05o15X75Oi03v43rZTG0wGCHvXqU15Kt1Q8k8Op87au5qr4U1GCvu00LTfk2w3YhwqE0it1tw2g11k.48H3fYB8k2jE5s5HC81S9Sm600nFD73Lb4N90Pl1F0LSIx70mF1gldgvzgRz ? 9729 : 9728);
        }
        if (this.57P4aWFVQ032sr5GrCh0u15J37F72M40X5n83L1d45UL3QxMP14AMhHMb9M3) {
            GL11.glTexParameteri(3553, 10242, 10496);
            GL11.glTexParameteri(3553, 10243, 10496);
        }
        else {
            GL11.glTexParameteri(3553, 10242, 10497);
            GL11.glTexParameteri(3553, 10243, 10497);
        }
        final int width = bufferedImage.getWidth();
        final int height = bufferedImage.getHeight();
        final int[] rgbArray = new int[width * height];
        final byte[] src = new byte[width * height * 4];
        bufferedImage.getRGB(0, 0, width, height, rgbArray, 0, width);
        for (int i = 0; i < rgbArray.length; ++i) {
            final int n2 = rgbArray[i] >> 24 & 0xFF;
            int n3 = rgbArray[i] >> 16 & 0xFF;
            int n4 = rgbArray[i] >> 8 & 0xFF;
            int n5 = rgbArray[i] & 0xFF;
            if (this.78OxWKhpSoq2g2GiUNej2aKIJrP7X69zer9a141qoQdboWo1BnWwfu6q2Xhc != null && this.78OxWKhpSoq2g2GiUNej2aKIJrP7X69zer9a141qoQdboWo1BnWwfu6q2Xhc.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8) {
                final int n6 = (n3 * 30 + n4 * 59 + n5 * 11) / 100;
                final int n7 = (n3 * 30 + n4 * 70) / 100;
                final int n8 = (n3 * 30 + n5 * 70) / 100;
                n3 = n6;
                n4 = n7;
                n5 = n8;
            }
            src[i * 4 + 0] = (byte)n3;
            src[i * 4 + 1] = (byte)n4;
            src[i * 4 + 2] = (byte)n5;
            src[i * 4 + 3] = (byte)n2;
        }
        this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.clear();
        this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.put(src);
        this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.position(0).limit(src.length);
        GL11.glTexImage2D(3553, 0, 6408, width, height, 0, 6408, 5121, this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6);
        if (5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.74SI37YptSL1M6a7AVrVZ9XFV92E9590238ZJV9zp8N1Su4F2h5qDXyzPKrx) {
            for (int j = 1; j <= 4; ++j) {
                final int n9 = width >> j - 1;
                final int n10 = width >> j;
                final int n11 = height >> j;
                for (int k = 0; k < n10; ++k) {
                    for (int l = 0; l < n11; ++l) {
                        this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.putInt((k + l * n10) * 4, this.8dR3Cd1V5V635SNepi130Y8i2z6Hw0WVzdbc50mEHNK16h1w7K4VL6AzbQEr(this.8dR3Cd1V5V635SNepi130Y8i2z6Hw0WVzdbc50mEHNK16h1w7K4VL6AzbQEr(this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((k * 2 + 0 + (l * 2 + 0) * n9) * 4), this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((k * 2 + 1 + (l * 2 + 0) * n9) * 4)), this.8dR3Cd1V5V635SNepi130Y8i2z6Hw0WVzdbc50mEHNK16h1w7K4VL6AzbQEr(this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((k * 2 + 1 + (l * 2 + 1) * n9) * 4), this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((k * 2 + 0 + (l * 2 + 1) * n9) * 4))));
                    }
                }
                GL11.glTexImage2D(3553, j, 6408, n10, n11, 0, 6408, 5121, this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6);
            }
        }
    }
    
    public void 23swr7mqK54Yo1qph1JJ5nr7IZcL0bO0cEmdT4n3yev5424Oz6BOyfXVggMZ(final int i) {
        this.668ZtS069T2Mwwo5o7gb186Pp684TPwjjYSq12A1mlbQjMmOCWkJ3a4Py77M.remove(i);
        this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W.clear();
        this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W.put(i);
        this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W.flip();
        GL11.glDeleteTextures(this.394TB0pp40O4wrgZ8a6A9wkLzYcd408dFjKA2GvI34Uc87BXl21pn2tnfr1W);
    }
    
    public 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 18sPuflM7MzITpsQMp0Z6iSMvIjw2M11dgAXJ2ygsxK4Wo4E8txzK7oNV26k(final String s, final String s2) {
        9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8;
        if (2mJJdB3LsncojI8IS9KAhF1KG7slntud2SEi4bDkoEJ08tUHDrwj09XifPRx3s84uv4URo67oh4G23ml69HanQAJ0Tyicz5RWqN.59LAAw69s2Vsi9q69OVNn94vIoM0D8SnjA88iek48J3xU8o7I026LeYrIrYv.containsKey(s)) {
            9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 = 2mJJdB3LsncojI8IS9KAhF1KG7slntud2SEi4bDkoEJ08tUHDrwj09XifPRx3s84uv4URo67oh4G23ml69HanQAJ0Tyicz5RWqN.59LAAw69s2Vsi9q69OVNn94vIoM0D8SnjA88iek48J3xU8o7I026LeYrIrYv.get(s);
        }
        else {
            9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 = this.77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B.get(s);
        }
        if (9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 != null && 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt != null && !9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.8CmuW2WYm4zZd6GWotT1OdV34ZStAgIoG00cyqcuHMuyMM21HEh3GaZp4mpd) {
            if (9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.2Vb2BPcw9iYma1r4CTtS842M3ZVp80uvLAa97tWZc5r71YE09P0H340cc949 < 0) {
                9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.2Vb2BPcw9iYma1r4CTtS842M3ZVp80uvLAa97tWZc5r71YE09P0H340cc949 = this.1BSFEHd336lH8JfA2w35JiGWqukE049E001767W1o8r4eUhCdf1SuM948qw6(9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt);
            }
            else {
                this.124rSc1BULjBUVqqDs8I2ysTI36fBwBRz97QzRP7TA178c1z90I3p54ydTJ5(9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt, 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.2Vb2BPcw9iYma1r4CTtS842M3ZVp80uvLAa97tWZc5r71YE09P0H340cc949);
            }
            9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.8CmuW2WYm4zZd6GWotT1OdV34ZStAgIoG00cyqcuHMuyMM21HEh3GaZp4mpd = true;
        }
        if (9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 != null && 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.2Vb2BPcw9iYma1r4CTtS842M3ZVp80uvLAa97tWZc5r71YE09P0H340cc949 >= 0) {
            return 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8;
        }
        this.2S9jv1MbYm5W1ar7Hsh1SgP21a6qr4sS0K72V1Lb4W5l3elheXn55WnwlcoA.2Vb2BPcw9iYma1r4CTtS842M3ZVp80uvLAa97tWZc5r71YE09P0H340cc949 = this.7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8(s2);
        return this.2S9jv1MbYm5W1ar7Hsh1SgP21a6qr4sS0K72V1Lb4W5l3elheXn55WnwlcoA;
    }
    
    public 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 5p8xtwzWVoI05ckup5m7yNj4D3CTpW99OH3l0n7L5eU5WR0SOy074PaQ1648(final String s, final 1yvTo5vLKhtZ8Jdf75TPzqWv5K5FAzIHa4r19RT64mMh13Pj2aH0VKS6mi433493GrZdkE65w9B85LU6qAlbS6G55i1q0 1yvTo5vLKhtZ8Jdf75TPzqWv5K5FAzIHa4r19RT64mMh13Pj2aH0VKS6mi433493GrZdkE65w9B85LU6qAlbS6G55i1q0) {
        9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8;
        if (2mJJdB3LsncojI8IS9KAhF1KG7slntud2SEi4bDkoEJ08tUHDrwj09XifPRx3s84uv4URo67oh4G23ml69HanQAJ0Tyicz5RWqN.59LAAw69s2Vsi9q69OVNn94vIoM0D8SnjA88iek48J3xU8o7I026LeYrIrYv.containsKey(s)) {
            9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 = 2mJJdB3LsncojI8IS9KAhF1KG7slntud2SEi4bDkoEJ08tUHDrwj09XifPRx3s84uv4URo67oh4G23ml69HanQAJ0Tyicz5RWqN.59LAAw69s2Vsi9q69OVNn94vIoM0D8SnjA88iek48J3xU8o7I026LeYrIrYv.get(s);
        }
        else {
            9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 = this.77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B.get(s);
        }
        if (9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 == null) {
            if (this.77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B.containsKey(s)) {
                this.77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B.remove(s);
            }
            this.77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B.put(s, new 2rCv0397007kD89EPcxiQ2JDAAi25AKiBd86823WZdJ9ug1NT497P2D5759oQ92r2Eq99Z1fP1UD4zvzHiLal32tpd3fcXlwIIm2m(s, 1yvTo5vLKhtZ8Jdf75TPzqWv5K5FAzIHa4r19RT64mMh13Pj2aH0VKS6mi433493GrZdkE65w9B85LU6qAlbS6G55i1q0));
        }
        else {
            final 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd9 = 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8;
            ++9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd9.4A88fE1g769E02Wq6X1szwm91x4a4YqtgZUMP4xe7980Fslb1yvQLRrM19Nc;
        }
        return 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8;
    }
    
    public void 62w3m18v7eo2Sfp2516aZR4449f3EBG87x1c726dEH0Ez9DU77RPDnkKFRVt(final String s) {
        final 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 = this.77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B.get(s);
        if (9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 != null) {
            final 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd9 = 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8;
            --9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd9.4A88fE1g769E02Wq6X1szwm91x4a4YqtgZUMP4xe7980Fslb1yvQLRrM19Nc;
            if (9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.4A88fE1g769E02Wq6X1szwm91x4a4YqtgZUMP4xe7980Fslb1yvQLRrM19Nc == 0) {
                if (9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.2Vb2BPcw9iYma1r4CTtS842M3ZVp80uvLAa97tWZc5r71YE09P0H340cc949 >= 0) {
                    this.23swr7mqK54Yo1qph1JJ5nr7IZcL0bO0cEmdT4n3yev5424Oz6BOyfXVggMZ(9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.2Vb2BPcw9iYma1r4CTtS842M3ZVp80uvLAa97tWZc5r71YE09P0H340cc949);
                }
                this.77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B.remove(s);
            }
        }
    }
    
    public void 28Z4uM6w2C9HBIK0Je3x0ZTd15BEr7HSCMfM76jj6Ncia2M0shMqtHRVj7cg(final 2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38) {
        this.1b5az140vr28pT9hLc684O25m9Evoa56NHU0937B5v1M9PKJWf8S413h2GFq.add(2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38);
        2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.88ejD45Q8LEgM39W23b9PS53H72qux6CoqBH3EmIU8XRRLm3446Q9e3d4IQv();
    }
    
    public void 1imU9lL98dWgKDo5L9HJeZU7uS13MOdLQi7WA6lZy85H5Y88G3seCp1YUr33() {
        if (!Minecraft.8AX67fsnsj54328J9e6FiY9333555Xj726t2182u3TBB948QMZsZX2iz02iv) {
            return;
        }
        for (int i = 0; i < this.1b5az140vr28pT9hLc684O25m9Evoa56NHU0937B5v1M9PKJWf8S413h2GFq.size(); ++i) {
            final 2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38 = this.1b5az140vr28pT9hLc684O25m9Evoa56NHU0937B5v1M9PKJWf8S413h2GFq.get(i);
            2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.06P3mXenpD5L0FS19r771z79X4G6ToUmlYYq950W8EH6ukeiX4WQd6Wqr2uA = this.78OxWKhpSoq2g2GiUNej2aKIJrP7X69zer9a141qoQdboWo1BnWwfu6q2Xhc.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8;
            2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.88ejD45Q8LEgM39W23b9PS53H72qux6CoqBH3EmIU8XRRLm3446Q9e3d4IQv();
            this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.clear();
            this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.put(2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D);
            this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.position(0).limit(2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D.length);
            2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.67pfu6QiNl9iOE7h4B6hweUcCLhkFH4GmWRCJ90tW10o7698En8DsRlvG43E(this);
            for (int j = 0; j < 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.2r4qC4o6Ex5Qa6j5s9Q44419BRuE90j03wh4yL3yFS46YmB5u0nSpx5Z6wvl; ++j) {
                for (int k = 0; k < 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.2r4qC4o6Ex5Qa6j5s9Q44419BRuE90j03wh4yL3yFS46YmB5u0nSpx5Z6wvl; ++k) {
                    GL11.glTexSubImage2D(3553, 0, 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.5WM1LGW9GUgzeD24G7fCa6oIAGn7KuReXrb1632gE1jDa8S25J3Ulv2S0N6V % 16 * 16 + j * 16, 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.5WM1LGW9GUgzeD24G7fCa6oIAGn7KuReXrb1632gE1jDa8S25J3Ulv2S0N6V / 16 * 16 + k * 16, 16, 16, 6408, 5121, this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6);
                    if (5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.74SI37YptSL1M6a7AVrVZ9XFV92E9590238ZJV9zp8N1Su4F2h5qDXyzPKrx) {
                        for (int l = 1; l <= 4; ++l) {
                            final int n = 16 >> l - 1;
                            final int n2 = 16 >> l;
                            for (int n3 = 0; n3 < n2; ++n3) {
                                for (int n4 = 0; n4 < n2; ++n4) {
                                    this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.putInt((n3 + n4 * n2) * 4, this.386ocG7iMyUOx6119f9hmUYHd2WMb5XQ3khHy7s2n8304gSU8pbW2uC80370(this.386ocG7iMyUOx6119f9hmUYHd2WMb5XQ3khHy7s2n8304gSU8pbW2uC80370(this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((n3 * 2 + 0 + (n4 * 2 + 0) * n) * 4), this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((n3 * 2 + 1 + (n4 * 2 + 0) * n) * 4)), this.386ocG7iMyUOx6119f9hmUYHd2WMb5XQ3khHy7s2n8304gSU8pbW2uC80370(this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((n3 * 2 + 1 + (n4 * 2 + 1) * n) * 4), this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((n3 * 2 + 0 + (n4 * 2 + 1) * n) * 4))));
                                }
                            }
                            GL11.glTexSubImage2D(3553, l, 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.5WM1LGW9GUgzeD24G7fCa6oIAGn7KuReXrb1632gE1jDa8S25J3Ulv2S0N6V % 16 * n2, 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38.5WM1LGW9GUgzeD24G7fCa6oIAGn7KuReXrb1632gE1jDa8S25J3Ulv2S0N6V / 16 * n2, n2, n2, 6408, 5121, this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6);
                        }
                    }
                }
            }
        }
        for (int n5 = 0; n5 < this.1b5az140vr28pT9hLc684O25m9Evoa56NHU0937B5v1M9PKJWf8S413h2GFq.size(); ++n5) {
            final 2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF39 = this.1b5az140vr28pT9hLc684O25m9Evoa56NHU0937B5v1M9PKJWf8S413h2GFq.get(n5);
            if (2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF39.2wE0ZDF8ttwyn15gNPYYhp30w9E7M6vLpEj46bOw9yupTN6Yy7Z6duwQ9klA > 0) {
                this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.clear();
                this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.put(2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF39.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D);
                this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.position(0).limit(2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF39.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D.length);
                GL11.glBindTexture(3553, 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF39.2wE0ZDF8ttwyn15gNPYYhp30w9E7M6vLpEj46bOw9yupTN6Yy7Z6duwQ9klA);
                GL11.glTexSubImage2D(3553, 0, 0, 0, 16, 16, 6408, 5121, this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6);
                if (5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.74SI37YptSL1M6a7AVrVZ9XFV92E9590238ZJV9zp8N1Su4F2h5qDXyzPKrx) {
                    for (int n6 = 1; n6 <= 4; ++n6) {
                        final int n7 = 16 >> n6 - 1;
                        final int n8 = 16 >> n6;
                        for (int n9 = 0; n9 < n8; ++n9) {
                            for (int n10 = 0; n10 < n8; ++n10) {
                                this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.putInt((n9 + n10 * n8) * 4, this.386ocG7iMyUOx6119f9hmUYHd2WMb5XQ3khHy7s2n8304gSU8pbW2uC80370(this.386ocG7iMyUOx6119f9hmUYHd2WMb5XQ3khHy7s2n8304gSU8pbW2uC80370(this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((n9 * 2 + 0 + (n10 * 2 + 0) * n7) * 4), this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((n9 * 2 + 1 + (n10 * 2 + 0) * n7) * 4)), this.386ocG7iMyUOx6119f9hmUYHd2WMb5XQ3khHy7s2n8304gSU8pbW2uC80370(this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((n9 * 2 + 1 + (n10 * 2 + 1) * n7) * 4), this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6.getInt((n9 * 2 + 0 + (n10 * 2 + 1) * n7) * 4))));
                            }
                        }
                        GL11.glTexSubImage2D(3553, n6, 0, 0, n8, n8, 6408, 5121, this.9sl3tccXgP3kPaBu8O7FRb9TbDsLmH952o5CNmeae7m70QOfl8oVdK74JQx6);
                    }
                }
            }
        }
    }
    
    private int 386ocG7iMyUOx6119f9hmUYHd2WMb5XQ3khHy7s2n8304gSU8pbW2uC80370(final int n, final int n2) {
        return (((n & 0xFF000000) >> 24 & 0xFF) + ((n2 & 0xFF000000) >> 24 & 0xFF) >> 1 << 24) + ((n & 0xFEFEFE) + (n2 & 0xFEFEFE) >> 1);
    }
    
    private int 8dR3Cd1V5V635SNepi130Y8i2z6Hw0WVzdbc50mEHNK16h1w7K4VL6AzbQEr(final int n, final int n2) {
        int n3 = (n & 0xFF000000) >> 24 & 0xFF;
        int n4 = (n2 & 0xFF000000) >> 24 & 0xFF;
        int n5 = 255;
        if (n3 + n4 == 0) {
            n3 = 1;
            n4 = 1;
            n5 = 0;
        }
        return n5 << 24 | ((n >> 16 & 0xFF) * n3 + (n2 >> 16 & 0xFF) * n4) / (n3 + n4) << 16 | ((n >> 8 & 0xFF) * n3 + (n2 >> 8 & 0xFF) * n4) / (n3 + n4) << 8 | ((n & 0xFF) * n3 + (n2 & 0xFF) * n4) / (n3 + n4);
    }
    
    public void 9006A260FinF65160yy1tRxZa08HEJ1MIT4yk9xYNQlGL4i3Akg8kfUiiEwB() {
        final 3W0d28OFdXcKp4p5sJF2NY3wOKKdPb2FwuG0BLk9y18f2pN4kKKw9zLnwO3k3RS31Nz2bMsm8s5q4D0514o6bz9M7kScW8 1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0 = this.8nB09v2wL31LD7473aXNMbJrX47AX71iPMP6yPX544heeDvxj78y5qTJYk68.1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0;
        for (final int intValue : this.668ZtS069T2Mwwo5o7gb186Pp684TPwjjYSq12A1mlbQjMmOCWkJ3a4Py77M.keySet()) {
            this.124rSc1BULjBUVqqDs8I2ysTI36fBwBRz97QzRP7TA178c1z90I3p54ydTJ5(this.668ZtS069T2Mwwo5o7gb186Pp684TPwjjYSq12A1mlbQjMmOCWkJ3a4Py77M.get(intValue), intValue);
        }
        final Iterator<2rCv0397007kD89EPcxiQ2JDAAi25AKiBd86823WZdJ9ug1NT497P2D5759oQ92r2Eq99Z1fP1UD4zvzHiLal32tpd3fcXlwIIm2m> iterator2 = this.77z0zBJi59ajR0q8N80gh4XB6VTfIJHPhPade5CI0z43GC50w8SmXBpEY58B.values().iterator();
        while (iterator2.hasNext()) {
            iterator2.next().8CmuW2WYm4zZd6GWotT1OdV34ZStAgIoG00cyqcuHMuyMM21HEh3GaZp4mpd = false;
        }
        for (final String key : this.5UdGK0wEM6v4AGH0T941JK6d797bl9689948zI34Cha17gfLJBB3XuMO74Z5.keySet()) {
            try {
                BufferedImage bufferedImage;
                if (key.startsWith("##")) {
                    bufferedImage = this.80zP9Ek8WxGJ5syBZomdG8M4ZtYS42SYBhK71oYeN4bm2xDbka36t4NgCv5r(this.6Y6At49CUc59G341H19D7WD31Nq480a9ni7bM1Y4l5x2a18LJLiG1Z5Uv9sB(1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0.35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0(key.substring(2))));
                }
                else if (key.startsWith("%%")) {
                    this.57P4aWFVQ032sr5GrCh0u15J37F72M40X5n83L1d45UL3QxMP14AMhHMb9M3 = true;
                    bufferedImage = this.6Y6At49CUc59G341H19D7WD31Nq480a9ni7bM1Y4l5x2a18LJLiG1Z5Uv9sB(1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0.35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0(key.substring(2)));
                    this.57P4aWFVQ032sr5GrCh0u15J37F72M40X5n83L1d45UL3QxMP14AMhHMb9M3 = false;
                }
                else {
                    bufferedImage = this.6Y6At49CUc59G341H19D7WD31Nq480a9ni7bM1Y4l5x2a18LJLiG1Z5Uv9sB(1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0.35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0(key));
                }
                this.124rSc1BULjBUVqqDs8I2ysTI36fBwBRz97QzRP7TA178c1z90I3p54ydTJ5(bufferedImage, this.5UdGK0wEM6v4AGH0T941JK6d797bl9689948zI34Cha17gfLJBB3XuMO74Z5.get(key));
            }
            catch (final IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private BufferedImage 6Y6At49CUc59G341H19D7WD31Nq480a9ni7bM1Y4l5x2a18LJLiG1Z5Uv9sB(final InputStream input) throws IOException {
        final BufferedImage read = ImageIO.read(input);
        input.close();
        return read;
    }
    
    public void 2FngD4U0pd65pnJ2uUkjT0MQGf5Dn69MpHQ9hHdo5NZWQWiViGc62I6GRw3J(final int n) {
        if (n >= 0) {
            GL11.glBindTexture(3553, n);
        }
    }
    
    static {
        5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.74SI37YptSL1M6a7AVrVZ9XFV92E9590238ZJV9zp8N1Su4F2h5qDXyzPKrx = false;
    }
}
