import java.io.Writer;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.input.Keyboard;
import java.io.File;
import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S
{
    private static final String[] 2009868sA84t1qE7xT1JaAu9M56733JAdRH11t5o1I7PMb9E5yXOCB0q32Jp;
    private static final String[] 7W4FCn7Clp5FPwjP1PiK6t0x8OQH337gA9s6V0LG7j78tcwizO0c2dytg3Ox;
    private static final String[] 0601s25AwsXK8YAli4bSnf611cz09m3nihe6Wcjm69saa6xnYY1LDN3wqX7Q;
    public float 5zVh6As0u9k00iHSIIoh6zDv0onD74k519o6f2ih8xc0KCy6K6rx2u3Gr1yN;
    public float 0mEbE9q0w35M2d45vY0a4001t84W4p6pXah4cFiG6zT4q39Sh9a38knll5I9;
    public float 40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp;
    public boolean 04Kzn3g6jm44oXRhg42vgkhSp3y920BFeTuo1x44P0u66uRxc3Jy00C58cNP;
    public int 8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU;
    public boolean 12dOAZ6rdsoK466LNB5P9c3VTerNRQez6YZYpOMxF3OkQWAlV7lvWtX9u73K;
    public boolean 10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8;
    public boolean 41ci3bZ3JIAX8mLq08E3rvi0L2G4q8Z7n0x2RqlTd5R5pSL43XWO417u505z;
    public int 21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb;
    public boolean 00qzl4RT8l54y85wLI9tvI4Xq4v7B79spk9kgviaaRc40ZHM7a192U43PTTq;
    public float 0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR;
    public String 5cq9PhUp8LROyS1A2CPi3fyxFgmWABb66h72hAC97w32G831S582rHP9QCBn;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 7a0W1RU6Q8EbOS4A4lKs1uS0aGxdk63RpdvD08587ZlFAcxUAvMiu1kKm8pW;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 4WO3zvF2VJSJrydLjBu8Z2NY6rB4Yi5rkCoVAh3g1rSfaVFqR4WL0aI926u5;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 3c8SpV9K1ddvX9lx4h2hOD9G9m5o1dGknq2J8f296yrV8gFD43Hhtf2353fH;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 813LRkk7pVtE7Ko1lsl5pqeor841vBVm8sAWN9bz76DwrQR9odtq5d2RnS7S;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 2om4e4AYodl0O6AznpiYzPI1t109zUzPwqE02SJ4dXm7Q2ksR1N1fo08NmC7;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 400nmSgqkmWs4T9j7Z2Rtse46ME5W3lmkz88JuE91nRGK1LJ0n3MnjdVQG14;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 2Ykx4GZjpFlzho5iH00m9ZV3lKWAK1V1i7l8IwksoId2p1z5nv077OnTHG22;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 8sz2228sPity2FLj12vTITSeMt2C39BWEPskZ82JvrV6LDsFrv9g18uH23L1;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 8nj81Ha0z6kkA82L191Z2XuGhV8Ad5073HJWD34egOjVN9Y397KLC1a5ATH4;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 46vj9daTh0uJGzMJGq9U4y3lwd639qggdWifULDkKxYX586STsGYvVa6Nbc6;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 8zR7w7M0dCz141EgrKPTyPG0x4be73DnUpm3v39wugYiB00oRfG9xEdOaiDU;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5 0y3J835DcYjJCi69MHQUHF4jrOLdQx1Z31fkAA08625s5FJMK989j345coLD;
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5[] 34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj;
    protected Minecraft 2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242;
    private File 6I9CVwZE7S0FSi23yC45NoWL4vfGfuUn53W87SzCc741j2iob0KNR78kH295;
    public int 3x5HH0y4BeBhSApYdP36VY2fTO1Z0eTtVpWXhv1r5vH0wZgGhPH24D3y22Fa;
    public int 83Du5N39GKmrFsh28BjNwZ7As6n5k0B7yZJq2hlj0EE6RLWyH6Z684B7Rq89;
    public boolean 62p9oNt3fL95Z2GQCrZ6mc1ALIkgs35mKZ9ozwF97QlZmhcw5pU7GVl135uP;
    public boolean 25y1pfK8198W9Tm66cfxM95C77y782yiFE2iJ841XnrF5E5HedVA6X11kaDV;
    public int 169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq;
    public boolean 9UX0ZD1i0y7zcXk28p5XF7G1IawPyo5D04YmR388eC1Hn9D60kx7ZdzLF5D6;
    public boolean 2PZeKU2XX6DVQr0PddO0LpfaoOdt40powdd99RK1luEfC8ZBvPLza3Nz4hOa;
    public boolean 4o1uNoQSrg2YCL3639xyKEbxEX25zI2006R4TI63uHnqbhPYmAy503KepkPl;
    public boolean 9G35Lw0l42u913RwsiJ8b4oED565ckF66eprV7iUb2pWWs1p6q28aT020T9G;
    
    public 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S(final Minecraft 2shGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242, final File parent) {
        this.5zVh6As0u9k00iHSIIoh6zDv0onD74k519o6f2ih8xc0KCy6K6rx2u3Gr1yN = 1.0f;
        this.0mEbE9q0w35M2d45vY0a4001t84W4p6pXah4cFiG6zT4q39Sh9a38knll5I9 = 1.0f;
        this.40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp = 0.5f;
        this.04Kzn3g6jm44oXRhg42vgkhSp3y920BFeTuo1x44P0u66uRxc3Jy00C58cNP = false;
        this.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU = 1;
        this.12dOAZ6rdsoK466LNB5P9c3VTerNRQez6YZYpOMxF3OkQWAlV7lvWtX9u73K = true;
        this.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8 = false;
        this.41ci3bZ3JIAX8mLq08E3rvi0L2G4q8Z7n0x2RqlTd5R5pSL43XWO417u505z = false;
        this.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb = 1;
        this.00qzl4RT8l54y85wLI9tvI4Xq4v7B79spk9kgviaaRc40ZHM7a192U43PTTq = true;
        this.0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR = 0.5f;
        this.5cq9PhUp8LROyS1A2CPi3fyxFgmWABb66h72hAC97w32G831S582rHP9QCBn = "Default";
        this.7a0W1RU6Q8EbOS4A4lKs1uS0aGxdk63RpdvD08587ZlFAcxUAvMiu1kKm8pW = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Forward", 17);
        this.4WO3zvF2VJSJrydLjBu8Z2NY6rB4Yi5rkCoVAh3g1rSfaVFqR4WL0aI926u5 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Left", 30);
        this.3c8SpV9K1ddvX9lx4h2hOD9G9m5o1dGknq2J8f296yrV8gFD43Hhtf2353fH = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Back", 31);
        this.813LRkk7pVtE7Ko1lsl5pqeor841vBVm8sAWN9bz76DwrQR9odtq5d2RnS7S = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Right", 32);
        this.2om4e4AYodl0O6AznpiYzPI1t109zUzPwqE02SJ4dXm7Q2ksR1N1fo08NmC7 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Jump", 57);
        this.400nmSgqkmWs4T9j7Z2Rtse46ME5W3lmkz88JuE91nRGK1LJ0n3MnjdVQG14 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Inventory", 18);
        this.2Ykx4GZjpFlzho5iH00m9ZV3lKWAK1V1i7l8IwksoId2p1z5nv077OnTHG22 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Drop", 16);
        this.8sz2228sPity2FLj12vTITSeMt2C39BWEPskZ82JvrV6LDsFrv9g18uH23L1 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Chat", 20);
        this.8nj81Ha0z6kkA82L191Z2XuGhV8Ad5073HJWD34egOjVN9Y397KLC1a5ATH4 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Toggle fog", 33);
        this.46vj9daTh0uJGzMJGq9U4y3lwd639qggdWifULDkKxYX586STsGYvVa6Nbc6 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Sneak", 29);
        this.8zR7w7M0dCz141EgrKPTyPG0x4be73DnUpm3v39wugYiB00oRfG9xEdOaiDU = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Dash", 42);
        this.0y3J835DcYjJCi69MHQUHF4jrOLdQx1Z31fkAA08625s5FJMK989j345coLD = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Open console", 41);
        this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5[] { this.7a0W1RU6Q8EbOS4A4lKs1uS0aGxdk63RpdvD08587ZlFAcxUAvMiu1kKm8pW, this.4WO3zvF2VJSJrydLjBu8Z2NY6rB4Yi5rkCoVAh3g1rSfaVFqR4WL0aI926u5, this.3c8SpV9K1ddvX9lx4h2hOD9G9m5o1dGknq2J8f296yrV8gFD43Hhtf2353fH, this.813LRkk7pVtE7Ko1lsl5pqeor841vBVm8sAWN9bz76DwrQR9odtq5d2RnS7S, this.2om4e4AYodl0O6AznpiYzPI1t109zUzPwqE02SJ4dXm7Q2ksR1N1fo08NmC7, this.46vj9daTh0uJGzMJGq9U4y3lwd639qggdWifULDkKxYX586STsGYvVa6Nbc6, this.2Ykx4GZjpFlzho5iH00m9ZV3lKWAK1V1i7l8IwksoId2p1z5nv077OnTHG22, this.400nmSgqkmWs4T9j7Z2Rtse46ME5W3lmkz88JuE91nRGK1LJ0n3MnjdVQG14, this.8sz2228sPity2FLj12vTITSeMt2C39BWEPskZ82JvrV6LDsFrv9g18uH23L1, this.8nj81Ha0z6kkA82L191Z2XuGhV8Ad5073HJWD34egOjVN9Y397KLC1a5ATH4, this.8zR7w7M0dCz141EgrKPTyPG0x4be73DnUpm3v39wugYiB00oRfG9xEdOaiDU, this.0y3J835DcYjJCi69MHQUHF4jrOLdQx1Z31fkAA08625s5FJMK989j345coLD };
        this.3x5HH0y4BeBhSApYdP36VY2fTO1Z0eTtVpWXhv1r5vH0wZgGhPH24D3y22Fa = 12;
        this.83Du5N39GKmrFsh28BjNwZ7As6n5k0B7yZJq2hlj0EE6RLWyH6Z684B7Rq89 = 2;
        this.62p9oNt3fL95Z2GQCrZ6mc1ALIkgs35mKZ9ozwF97QlZmhcw5pU7GVl135uP = false;
        this.25y1pfK8198W9Tm66cfxM95C77y782yiFE2iJ841XnrF5E5HedVA6X11kaDV = false;
        this.169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq = 2;
        this.9UX0ZD1i0y7zcXk28p5XF7G1IawPyo5D04YmR388eC1Hn9D60kx7ZdzLF5D6 = true;
        this.2PZeKU2XX6DVQr0PddO0LpfaoOdt40powdd99RK1luEfC8ZBvPLza3Nz4hOa = true;
        this.4o1uNoQSrg2YCL3639xyKEbxEX25zI2006R4TI63uHnqbhPYmAy503KepkPl = true;
        this.9G35Lw0l42u913RwsiJ8b4oED565ckF66eprV7iUb2pWWs1p6q28aT020T9G = true;
        if (2shGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.2E4BZaw4wUzRdqs6H26gijBXYV2x4keaA5V5idykFk39ETvee94J18B7nBcD().toLowerCase().contains("nvidia")) {
            90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S.2009868sA84t1qE7xT1JaAu9M56733JAdRH11t5o1I7PMb9E5yXOCB0q32Jp[5] = "Silent Dream";
        }
        this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242 = 2shGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242;
        this.6I9CVwZE7S0FSi23yC45NoWL4vfGfuUn53W87SzCc741j2iob0KNR78kH295 = new File(parent, "options.txt");
        this.0l728J30UZxliSdA6uw526rj0wzRB9k8iKuKXp2He8caNFtMCv74LlHQ4282();
    }
    
    public 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S() {
        this.5zVh6As0u9k00iHSIIoh6zDv0onD74k519o6f2ih8xc0KCy6K6rx2u3Gr1yN = 1.0f;
        this.0mEbE9q0w35M2d45vY0a4001t84W4p6pXah4cFiG6zT4q39Sh9a38knll5I9 = 1.0f;
        this.40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp = 0.5f;
        this.04Kzn3g6jm44oXRhg42vgkhSp3y920BFeTuo1x44P0u66uRxc3Jy00C58cNP = false;
        this.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU = 1;
        this.12dOAZ6rdsoK466LNB5P9c3VTerNRQez6YZYpOMxF3OkQWAlV7lvWtX9u73K = true;
        this.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8 = false;
        this.41ci3bZ3JIAX8mLq08E3rvi0L2G4q8Z7n0x2RqlTd5R5pSL43XWO417u505z = false;
        this.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb = 1;
        this.00qzl4RT8l54y85wLI9tvI4Xq4v7B79spk9kgviaaRc40ZHM7a192U43PTTq = true;
        this.0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR = 0.5f;
        this.5cq9PhUp8LROyS1A2CPi3fyxFgmWABb66h72hAC97w32G831S582rHP9QCBn = "Default";
        this.7a0W1RU6Q8EbOS4A4lKs1uS0aGxdk63RpdvD08587ZlFAcxUAvMiu1kKm8pW = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Forward", 17);
        this.4WO3zvF2VJSJrydLjBu8Z2NY6rB4Yi5rkCoVAh3g1rSfaVFqR4WL0aI926u5 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Left", 30);
        this.3c8SpV9K1ddvX9lx4h2hOD9G9m5o1dGknq2J8f296yrV8gFD43Hhtf2353fH = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Back", 31);
        this.813LRkk7pVtE7Ko1lsl5pqeor841vBVm8sAWN9bz76DwrQR9odtq5d2RnS7S = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Right", 32);
        this.2om4e4AYodl0O6AznpiYzPI1t109zUzPwqE02SJ4dXm7Q2ksR1N1fo08NmC7 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Jump", 57);
        this.400nmSgqkmWs4T9j7Z2Rtse46ME5W3lmkz88JuE91nRGK1LJ0n3MnjdVQG14 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Inventory", 18);
        this.2Ykx4GZjpFlzho5iH00m9ZV3lKWAK1V1i7l8IwksoId2p1z5nv077OnTHG22 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Drop", 16);
        this.8sz2228sPity2FLj12vTITSeMt2C39BWEPskZ82JvrV6LDsFrv9g18uH23L1 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Chat", 20);
        this.8nj81Ha0z6kkA82L191Z2XuGhV8Ad5073HJWD34egOjVN9Y397KLC1a5ATH4 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Toggle fog", 33);
        this.46vj9daTh0uJGzMJGq9U4y3lwd639qggdWifULDkKxYX586STsGYvVa6Nbc6 = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Sneak", 29);
        this.8zR7w7M0dCz141EgrKPTyPG0x4be73DnUpm3v39wugYiB00oRfG9xEdOaiDU = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Dash", 42);
        this.0y3J835DcYjJCi69MHQUHF4jrOLdQx1Z31fkAA08625s5FJMK989j345coLD = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5("Open console", 41);
        this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj = new 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5[] { this.7a0W1RU6Q8EbOS4A4lKs1uS0aGxdk63RpdvD08587ZlFAcxUAvMiu1kKm8pW, this.4WO3zvF2VJSJrydLjBu8Z2NY6rB4Yi5rkCoVAh3g1rSfaVFqR4WL0aI926u5, this.3c8SpV9K1ddvX9lx4h2hOD9G9m5o1dGknq2J8f296yrV8gFD43Hhtf2353fH, this.813LRkk7pVtE7Ko1lsl5pqeor841vBVm8sAWN9bz76DwrQR9odtq5d2RnS7S, this.2om4e4AYodl0O6AznpiYzPI1t109zUzPwqE02SJ4dXm7Q2ksR1N1fo08NmC7, this.46vj9daTh0uJGzMJGq9U4y3lwd639qggdWifULDkKxYX586STsGYvVa6Nbc6, this.2Ykx4GZjpFlzho5iH00m9ZV3lKWAK1V1i7l8IwksoId2p1z5nv077OnTHG22, this.400nmSgqkmWs4T9j7Z2Rtse46ME5W3lmkz88JuE91nRGK1LJ0n3MnjdVQG14, this.8sz2228sPity2FLj12vTITSeMt2C39BWEPskZ82JvrV6LDsFrv9g18uH23L1, this.8nj81Ha0z6kkA82L191Z2XuGhV8Ad5073HJWD34egOjVN9Y397KLC1a5ATH4, this.8zR7w7M0dCz141EgrKPTyPG0x4be73DnUpm3v39wugYiB00oRfG9xEdOaiDU, this.0y3J835DcYjJCi69MHQUHF4jrOLdQx1Z31fkAA08625s5FJMK989j345coLD };
        this.3x5HH0y4BeBhSApYdP36VY2fTO1Z0eTtVpWXhv1r5vH0wZgGhPH24D3y22Fa = 12;
        this.83Du5N39GKmrFsh28BjNwZ7As6n5k0B7yZJq2hlj0EE6RLWyH6Z684B7Rq89 = 2;
        this.62p9oNt3fL95Z2GQCrZ6mc1ALIkgs35mKZ9ozwF97QlZmhcw5pU7GVl135uP = false;
        this.25y1pfK8198W9Tm66cfxM95C77y782yiFE2iJ841XnrF5E5HedVA6X11kaDV = false;
        this.169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq = 2;
        this.9UX0ZD1i0y7zcXk28p5XF7G1IawPyo5D04YmR388eC1Hn9D60kx7ZdzLF5D6 = true;
        this.2PZeKU2XX6DVQr0PddO0LpfaoOdt40powdd99RK1luEfC8ZBvPLza3Nz4hOa = true;
        this.4o1uNoQSrg2YCL3639xyKEbxEX25zI2006R4TI63uHnqbhPYmAy503KepkPl = true;
        this.9G35Lw0l42u913RwsiJ8b4oED565ckF66eprV7iUb2pWWs1p6q28aT020T9G = true;
    }
    
    public String 84WQ90yx219We269UyJB97L5INdDSA81vIwtA33L9W4FQ2cUDyY6pOFkeHiW(final int n) {
        return this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj[n].08YVi0miV0NCq8kgQVB3s086gcHnyy5wG3nCl3UVTdfLPyRbaq0dC2rfhcmD + ": " + Keyboard.getKeyName(this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj[n].7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN);
    }
    
    public void 43j9jV0unWNuT98kVCwtq2029meeD9248265E9EM8Vx3j4UkDI2XbPT5W0RD(final int n, final int 7m9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN) {
        this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj[n].7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN = 7m9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN;
        this.59328E75k38QTT7paHT5VB40Aa0vmAQcn30V2a2I2ojvg5kQe46yLLSd0h41();
    }
    
    public void 41q83du4HaW59MJ9dbgIw283tnp9FTGdKAIaz3G2fKFS8kiLN47ib74Ajr5A(final int n, final float n2) {
        if (n == 0) {
            this.5zVh6As0u9k00iHSIIoh6zDv0onD74k519o6f2ih8xc0KCy6K6rx2u3Gr1yN = n2;
            this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.1FtenBjtbWTQMx7w9NQ2pQqFxhc78G5Djz3ghM24o7Tc21uHI6Cx8s0PaRpG.3gErgdJ1s3Q9XvRI4j6W8TDm44V8LZbFaVOFC0f800gRAh9bmn3RlL91y9lw();
        }
        if (n == 1) {
            this.0mEbE9q0w35M2d45vY0a4001t84W4p6pXah4cFiG6zT4q39Sh9a38knll5I9 = n2;
            this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.1FtenBjtbWTQMx7w9NQ2pQqFxhc78G5Djz3ghM24o7Tc21uHI6Cx8s0PaRpG.3gErgdJ1s3Q9XvRI4j6W8TDm44V8LZbFaVOFC0f800gRAh9bmn3RlL91y9lw();
        }
        if (n == 3) {
            this.40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp = n2;
        }
        if (n == 11) {
            this.0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR = n2;
        }
    }
    
    public void 990874nZdx634bxSyP8662vVZm4CCxF145OGW0Ndz0kdVV9MnO7T5G6Oy3t9(final int n, final int n2) {
        if (n == 2) {
            this.04Kzn3g6jm44oXRhg42vgkhSp3y920BFeTuo1x44P0u66uRxc3Jy00C58cNP = !this.04Kzn3g6jm44oXRhg42vgkhSp3y920BFeTuo1x44P0u66uRxc3Jy00C58cNP;
        }
        if (n == 4) {
            this.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU = (this.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU + n2) % 6;
            if (this.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU < 0) {
                this.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU = ((GL11.glGetString(7937).toLowerCase().contains("graphics media") || GL11.glGetString(7937).toLowerCase().contains("4 series express")) ? 4 : 5);
            }
        }
        if (n == 5) {
            this.12dOAZ6rdsoK466LNB5P9c3VTerNRQez6YZYpOMxF3OkQWAlV7lvWtX9u73K = !this.12dOAZ6rdsoK466LNB5P9c3VTerNRQez6YZYpOMxF3OkQWAlV7lvWtX9u73K;
        }
        if (n == 6) {
            this.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8 = !this.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8;
            this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.9006A260FinF65160yy1tRxZa08HEJ1MIT4yk9xYNQlGL4i3Akg8kfUiiEwB();
        }
        if (n == 7) {
            Display.setVSyncEnabled(this.41ci3bZ3JIAX8mLq08E3rvi0L2G4q8Z7n0x2RqlTd5R5pSL43XWO417u505z = !this.41ci3bZ3JIAX8mLq08E3rvi0L2G4q8Z7n0x2RqlTd5R5pSL43XWO417u505z);
        }
        if (n == 8) {
            this.83Du5N39GKmrFsh28BjNwZ7As6n5k0B7yZJq2hlj0EE6RLWyH6Z684B7Rq89 = (this.83Du5N39GKmrFsh28BjNwZ7As6n5k0B7yZJq2hlj0EE6RLWyH6Z684B7Rq89 + n2) % 5;
            System.out.println("Difficulty is now " + this.83Du5N39GKmrFsh28BjNwZ7As6n5k0B7yZJq2hlj0EE6RLWyH6Z684B7Rq89);
        }
        if (n == 9) {
            --this.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb;
            if (this.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb < 0) {
                this.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb = 2;
            }
            if (this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.8D1HRxTuOIR0Ym42loo9d0NS42Qp45kaXeR154x9Ri712QaegW563ZU96VM0 != null) {
                this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.3q12kE4gY2LC8Kw67n8yg4OS4ErY1VwiiBFL18MB1pL4tbH7HW6oOa96GAZi.4qx7Cqo2hpoilsXLjli1zoEaWnL7dCCCjdA503Iyu70x5N2RrXC9qZ98XD5o();
            }
        }
        if (n == 10) {
            this.00qzl4RT8l54y85wLI9tvI4Xq4v7B79spk9kgviaaRc40ZHM7a192U43PTTq = !this.00qzl4RT8l54y85wLI9tvI4Xq4v7B79spk9kgviaaRc40ZHM7a192U43PTTq;
        }
        if (n == 12) {
            this.25y1pfK8198W9Tm66cfxM95C77y782yiFE2iJ841XnrF5E5HedVA6X11kaDV = !this.25y1pfK8198W9Tm66cfxM95C77y782yiFE2iJ841XnrF5E5HedVA6X11kaDV;
        }
        if (n == 20) {
            ++this.169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq;
            this.169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq %= 3;
            this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.0ef1dw6U62P0w8bU619gHGHeA4m17T8k6bnjfEQQwhJz0UwhJ6Kx9rBRdIvo.9r1511Jp0jE144f4MQc4NK82XBZn9UtKQ9T0m3371572UnC4jS4YM9eJUhB9();
        }
        if (n == 21) {
            this.9UX0ZD1i0y7zcXk28p5XF7G1IawPyo5D04YmR388eC1Hn9D60kx7ZdzLF5D6 = !this.9UX0ZD1i0y7zcXk28p5XF7G1IawPyo5D04YmR388eC1Hn9D60kx7ZdzLF5D6;
            this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.0ef1dw6U62P0w8bU619gHGHeA4m17T8k6bnjfEQQwhJz0UwhJ6Kx9rBRdIvo.9r1511Jp0jE144f4MQc4NK82XBZn9UtKQ9T0m3371572UnC4jS4YM9eJUhB9();
        }
        if (n == 22) {
            this.9G35Lw0l42u913RwsiJ8b4oED565ckF66eprV7iUb2pWWs1p6q28aT020T9G = !this.9G35Lw0l42u913RwsiJ8b4oED565ckF66eprV7iUb2pWWs1p6q28aT020T9G;
            this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.0ef1dw6U62P0w8bU619gHGHeA4m17T8k6bnjfEQQwhJz0UwhJ6Kx9rBRdIvo.9r1511Jp0jE144f4MQc4NK82XBZn9UtKQ9T0m3371572UnC4jS4YM9eJUhB9();
        }
        if (n == 23) {
            this.4o1uNoQSrg2YCL3639xyKEbxEX25zI2006R4TI63uHnqbhPYmAy503KepkPl = !this.4o1uNoQSrg2YCL3639xyKEbxEX25zI2006R4TI63uHnqbhPYmAy503KepkPl;
            this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.0ef1dw6U62P0w8bU619gHGHeA4m17T8k6bnjfEQQwhJz0UwhJ6Kx9rBRdIvo.9r1511Jp0jE144f4MQc4NK82XBZn9UtKQ9T0m3371572UnC4jS4YM9eJUhB9();
        }
        if (n == 24) {
            this.2PZeKU2XX6DVQr0PddO0LpfaoOdt40powdd99RK1luEfC8ZBvPLza3Nz4hOa = !this.2PZeKU2XX6DVQr0PddO0LpfaoOdt40powdd99RK1luEfC8ZBvPLza3Nz4hOa;
            this.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242.0ef1dw6U62P0w8bU619gHGHeA4m17T8k6bnjfEQQwhJz0UwhJ6Kx9rBRdIvo.9r1511Jp0jE144f4MQc4NK82XBZn9UtKQ9T0m3371572UnC4jS4YM9eJUhB9();
        }
        this.59328E75k38QTT7paHT5VB40Aa0vmAQcn30V2a2I2ojvg5kQe46yLLSd0h41();
    }
    
    public int 3yR0tLTb2b5Alv4vG4j3iy7Mh4tpbj3GRKxVH6u9Uz6IrG6l9F5B96couwIg(final int n) {
        return (n == 0 || n == 1 || n == 3 || n == 11) ? 1 : 0;
    }
    
    public float 4SJH266G4522Pw4gF4Mtv8cbSQpgw1N82bK41W0Kjqj7gshy90H7eU1JW3F4(final int n) {
        return (n == 0) ? this.5zVh6As0u9k00iHSIIoh6zDv0onD74k519o6f2ih8xc0KCy6K6rx2u3Gr1yN : ((n == 1) ? this.0mEbE9q0w35M2d45vY0a4001t84W4p6pXah4cFiG6zT4q39Sh9a38knll5I9 : ((n == 3) ? this.40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp : ((n == 11) ? this.0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR : 0.0f)));
    }
    
    public String 8akE4ycpP29ZNPe8U7TtIq1VzWnfb0Dy8d0ME93EebGs00PCtIc26x387brx(final int n) {
        return (n == 0) ? ("Music: " + ((this.5zVh6As0u9k00iHSIIoh6zDv0onD74k519o6f2ih8xc0KCy6K6rx2u3Gr1yN > 0.0f) ? ((int)(this.5zVh6As0u9k00iHSIIoh6zDv0onD74k519o6f2ih8xc0KCy6K6rx2u3Gr1yN * 100.0f) + "%") : "OFF")) : ((n == 1) ? ("Sound: " + ((this.0mEbE9q0w35M2d45vY0a4001t84W4p6pXah4cFiG6zT4q39Sh9a38knll5I9 > 0.0f) ? ((int)(this.0mEbE9q0w35M2d45vY0a4001t84W4p6pXah4cFiG6zT4q39Sh9a38knll5I9 * 100.0f) + "%") : "OFF")) : ((n == 2) ? ("Invert mouse: " + (this.04Kzn3g6jm44oXRhg42vgkhSp3y920BFeTuo1x44P0u66uRxc3Jy00C58cNP ? "ON" : "OFF")) : ((n == 3) ? ((this.40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp == 0.0f) ? "Sensitivity: *yawn*" : ((this.40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp == 1.0f) ? "Sensitivity: HYPERSPEED!!!" : ("Sensitivity: " + (int)(this.40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp * 200.0f) + "%"))) : ((n == 4) ? ("Render distance: " + 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S.2009868sA84t1qE7xT1JaAu9M56733JAdRH11t5o1I7PMb9E5yXOCB0q32Jp[this.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU]) : ((n == 5) ? ("View bobbing: " + (this.12dOAZ6rdsoK466LNB5P9c3VTerNRQez6YZYpOMxF3OkQWAlV7lvWtX9u73K ? "ON" : "OFF")) : ((n == 6) ? ("3d anaglyph: " + (this.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8 ? "ON" : "OFF")) : ((n == 7) ? ("Vertical sync: " + (this.41ci3bZ3JIAX8mLq08E3rvi0L2G4q8Z7n0x2RqlTd5R5pSL43XWO417u505z ? "ON" : "OFF")) : ((n == 8) ? ("Difficulty: " + 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S.7W4FCn7Clp5FPwjP1PiK6t0x8OQH337gA9s6V0LG7j78tcwizO0c2dytg3Ox[this.83Du5N39GKmrFsh28BjNwZ7As6n5k0B7yZJq2hlj0EE6RLWyH6Z684B7Rq89]) : ((n == 9) ? ("Graphics: " + 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S.0601s25AwsXK8YAli4bSnf611cz09m3nihe6Wcjm69saa6xnYY1LDN3wqX7Q[this.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb]) : ((n == 10) ? ("Pause on unfocus: " + (this.00qzl4RT8l54y85wLI9tvI4Xq4v7B79spk9kgviaaRc40ZHM7a192U43PTTq ? "ON" : "OFF")) : ((n == 11) ? ("FOV: " + ((this.0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR > 0.5) ? "+" : "") + (int)((this.0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR - 0.5) * 80.0)) : ((n == 12) ? ("Shaders: " + (this.25y1pfK8198W9Tm66cfxM95C77y782yiFE2iJ841XnrF5E5HedVA6X11kaDV ? "ON" : "OFF")) : ((n == 100) ? "Edit controls..." : ((n == 101) ? "Set Visuals..." : ((n == 20) ? ("Sh. Motion Blur: " + ((this.169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq == 2) ? "QUALITY" : ((this.169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq == 1) ? "PERF." : "OFF"))) : ((n == 21) ? ("Sh. Depth of Field: " + (this.9UX0ZD1i0y7zcXk28p5XF7G1IawPyo5D04YmR388eC1Hn9D60kx7ZdzLF5D6 ? "ON" : "OFF")) : ((n == 22) ? ("Sh. Anti Aliasing: " + (this.9G35Lw0l42u913RwsiJ8b4oED565ckF66eprV7iUb2pWWs1p6q28aT020T9G ? "ON" : "OFF")) : ((n == 23) ? ("Sh. Bloom: " + (this.4o1uNoQSrg2YCL3639xyKEbxEX25zI2006R4TI63uHnqbhPYmAy503KepkPl ? "ON" : "OFF")) : ((n == 24) ? ("Sh. SSR (BROKEN): " + (this.2PZeKU2XX6DVQr0PddO0LpfaoOdt40powdd99RK1luEfC8ZBvPLza3Nz4hOa ? "ON" : "OFF")) : "")))))))))))))))))));
    }
    
    public void 0l728J30UZxliSdA6uw526rj0wzRB9k8iKuKXp2He8caNFtMCv74LlHQ4282() {
        try {
            if (!this.6I9CVwZE7S0FSi23yC45NoWL4vfGfuUn53W87SzCc741j2iob0KNR78kH295.exists()) {
                return;
            }
            final BufferedReader bufferedReader = new BufferedReader(new FileReader(this.6I9CVwZE7S0FSi23yC45NoWL4vfGfuUn53W87SzCc741j2iob0KNR78kH295));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                final String[] split = line.split(":");
                if (split[0].equals("music")) {
                    this.5zVh6As0u9k00iHSIIoh6zDv0onD74k519o6f2ih8xc0KCy6K6rx2u3Gr1yN = this.73AXnU4fnKkF2FTVX236c26sjot95wyLtMHPOwkcTA7x6Fgu0Ec0cQhe5X2M(split[1]);
                }
                if (split[0].equals("sound")) {
                    this.0mEbE9q0w35M2d45vY0a4001t84W4p6pXah4cFiG6zT4q39Sh9a38knll5I9 = this.73AXnU4fnKkF2FTVX236c26sjot95wyLtMHPOwkcTA7x6Fgu0Ec0cQhe5X2M(split[1]);
                }
                if (split[0].equals("mouseSensitivity")) {
                    this.40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp = this.73AXnU4fnKkF2FTVX236c26sjot95wyLtMHPOwkcTA7x6Fgu0Ec0cQhe5X2M(split[1]);
                }
                if (split[0].equals("invertYMouse")) {
                    this.04Kzn3g6jm44oXRhg42vgkhSp3y920BFeTuo1x44P0u66uRxc3Jy00C58cNP = split[1].equals("true");
                }
                if (split[0].equals("viewDistance")) {
                    this.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU = Integer.parseInt(split[1]);
                }
                if (split[0].equals("bobView")) {
                    this.12dOAZ6rdsoK466LNB5P9c3VTerNRQez6YZYpOMxF3OkQWAlV7lvWtX9u73K = split[1].equals("true");
                }
                if (split[0].equals("anaglyph3d")) {
                    this.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8 = split[1].equals("true");
                }
                if (split[0].equals("limitFramerate")) {
                    this.41ci3bZ3JIAX8mLq08E3rvi0L2G4q8Z7n0x2RqlTd5R5pSL43XWO417u505z = split[1].equals("true");
                }
                if (split[0].equals("difficulty")) {
                    this.83Du5N39GKmrFsh28BjNwZ7As6n5k0B7yZJq2hlj0EE6RLWyH6Z684B7Rq89 = Integer.parseInt(split[1]);
                }
                if (split[0].equals("gxMode")) {
                    this.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb = Integer.parseInt(split[1]);
                }
                if (split[0].equals("pauseOnUnfocus")) {
                    this.00qzl4RT8l54y85wLI9tvI4Xq4v7B79spk9kgviaaRc40ZHM7a192U43PTTq = split[1].equals("true");
                }
                if (split[0].equals("fovMod")) {
                    this.0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR = this.73AXnU4fnKkF2FTVX236c26sjot95wyLtMHPOwkcTA7x6Fgu0Ec0cQhe5X2M(split[1]);
                }
                if (split[0].equals("skin")) {
                    this.5cq9PhUp8LROyS1A2CPi3fyxFgmWABb66h72hAC97w32G831S582rHP9QCBn = split[1];
                }
                if (split[0].equals("shadersOn")) {
                    this.25y1pfK8198W9Tm66cfxM95C77y782yiFE2iJ841XnrF5E5HedVA6X11kaDV = split[1].equals("true");
                }
                if (split[0].equals("shadersDOF")) {
                    this.9UX0ZD1i0y7zcXk28p5XF7G1IawPyo5D04YmR388eC1Hn9D60kx7ZdzLF5D6 = split[1].equals("true");
                }
                if (split[0].equals("shadersAA")) {
                    this.9G35Lw0l42u913RwsiJ8b4oED565ckF66eprV7iUb2pWWs1p6q28aT020T9G = split[1].equals("true");
                }
                if (split[0].equals("shadersBloom")) {
                    this.4o1uNoQSrg2YCL3639xyKEbxEX25zI2006R4TI63uHnqbhPYmAy503KepkPl = split[1].equals("true");
                }
                if (split[0].equals("shadersSSR")) {
                    this.2PZeKU2XX6DVQr0PddO0LpfaoOdt40powdd99RK1luEfC8ZBvPLza3Nz4hOa = split[1].equals("true");
                }
                if (split[0].equals("shadersMotionBlur")) {
                    this.169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq = Integer.parseInt(split[1]);
                }
                for (int i = 0; i < this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj.length; ++i) {
                    if (split[0].equals("key_" + this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj[i].08YVi0miV0NCq8kgQVB3s086gcHnyy5wG3nCl3UVTdfLPyRbaq0dC2rfhcmD)) {
                        this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj[i].7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN = Integer.parseInt(split[1]);
                    }
                }
            }
            bufferedReader.close();
        }
        catch (final Exception ex) {
            System.out.println("Failed to load options");
            ex.printStackTrace();
        }
    }
    
    private float 73AXnU4fnKkF2FTVX236c26sjot95wyLtMHPOwkcTA7x6Fgu0Ec0cQhe5X2M(final String s) {
        return s.equals("true") ? 1.0f : (s.equals("false") ? 0.0f : Float.parseFloat(s));
    }
    
    public void 59328E75k38QTT7paHT5VB40Aa0vmAQcn30V2a2I2ojvg5kQe46yLLSd0h41() {
        try {
            final PrintWriter printWriter = new PrintWriter(new FileWriter(this.6I9CVwZE7S0FSi23yC45NoWL4vfGfuUn53W87SzCc741j2iob0KNR78kH295));
            printWriter.println("music:" + this.5zVh6As0u9k00iHSIIoh6zDv0onD74k519o6f2ih8xc0KCy6K6rx2u3Gr1yN);
            printWriter.println("sound:" + this.0mEbE9q0w35M2d45vY0a4001t84W4p6pXah4cFiG6zT4q39Sh9a38knll5I9);
            printWriter.println("invertYMouse:" + this.04Kzn3g6jm44oXRhg42vgkhSp3y920BFeTuo1x44P0u66uRxc3Jy00C58cNP);
            printWriter.println("mouseSensitivity:" + this.40a7qx48qSa5U2x4LWl66TG6WTJtp89151v05JrdY06P49LaD6Vk2xbUfoJp);
            printWriter.println("viewDistance:" + this.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU);
            printWriter.println("bobView:" + this.12dOAZ6rdsoK466LNB5P9c3VTerNRQez6YZYpOMxF3OkQWAlV7lvWtX9u73K);
            printWriter.println("anaglyph3d:" + this.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8);
            printWriter.println("limitFramerate:" + this.41ci3bZ3JIAX8mLq08E3rvi0L2G4q8Z7n0x2RqlTd5R5pSL43XWO417u505z);
            printWriter.println("difficulty:" + this.83Du5N39GKmrFsh28BjNwZ7As6n5k0B7yZJq2hlj0EE6RLWyH6Z684B7Rq89);
            printWriter.println("gxMode:" + this.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb);
            printWriter.println("pauseOnUnfocus:" + this.00qzl4RT8l54y85wLI9tvI4Xq4v7B79spk9kgviaaRc40ZHM7a192U43PTTq);
            printWriter.println("fovMod:" + this.0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR);
            printWriter.println("skin:" + this.5cq9PhUp8LROyS1A2CPi3fyxFgmWABb66h72hAC97w32G831S582rHP9QCBn);
            printWriter.println("shadersOn:" + this.25y1pfK8198W9Tm66cfxM95C77y782yiFE2iJ841XnrF5E5HedVA6X11kaDV);
            printWriter.println("shadersSSR:" + this.2PZeKU2XX6DVQr0PddO0LpfaoOdt40powdd99RK1luEfC8ZBvPLza3Nz4hOa);
            printWriter.println("shadersDOF:" + this.9UX0ZD1i0y7zcXk28p5XF7G1IawPyo5D04YmR388eC1Hn9D60kx7ZdzLF5D6);
            printWriter.println("shadersAA:" + this.9G35Lw0l42u913RwsiJ8b4oED565ckF66eprV7iUb2pWWs1p6q28aT020T9G);
            printWriter.println("shadersBloom:" + this.4o1uNoQSrg2YCL3639xyKEbxEX25zI2006R4TI63uHnqbhPYmAy503KepkPl);
            printWriter.println("shadersMotionBlur:" + this.169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq);
            for (int i = 0; i < this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj.length; ++i) {
                printWriter.println("key_" + this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj[i].08YVi0miV0NCq8kgQVB3s086gcHnyy5wG3nCl3UVTdfLPyRbaq0dC2rfhcmD + ":" + this.34tRXH1CjOpAZDme2Q7tU3890o06SsFaei066N64qBqWR0rGbHkXkRF09UTj[i].7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN);
            }
            printWriter.close();
        }
        catch (final Exception ex) {
            System.out.println("Failed to save options");
            ex.printStackTrace();
        }
    }
    
    public String 4ZBw6818NpyygSj15g0tevwT2VRNee9iyV3HNltCy7o20mr67D74Di6czF41() {
        return "" + (this.9UX0ZD1i0y7zcXk28p5XF7G1IawPyo5D04YmR388eC1Hn9D60kx7ZdzLF5D6 ? "#define DOF_ENABLED\n" : "") + (this.2PZeKU2XX6DVQr0PddO0LpfaoOdt40powdd99RK1luEfC8ZBvPLza3Nz4hOa ? "#define SSR_ENABLED\n" : "") + (this.9G35Lw0l42u913RwsiJ8b4oED565ckF66eprV7iUb2pWWs1p6q28aT020T9G ? "#define AA_ENABLED\n" : "") + (this.4o1uNoQSrg2YCL3639xyKEbxEX25zI2006R4TI63uHnqbhPYmAy503KepkPl ? "#define BLOOM_ENABLED\n" : "") + "#define MOTIONBLUR_ENABLED " + this.169bjUeR039ZE547KDzev4W9h7Y3Gek7cJSjnnkGJUJ5aJI775p1a4lDV0kq + "\n";
    }
    
    static {
        2009868sA84t1qE7xT1JaAu9M56733JAdRH11t5o1I7PMb9E5yXOCB0q32Jp = new String[] { "HORIZON", "FAR", "NORMAL", "SHORT", "TINY", "DUALITY" };
        7W4FCn7Clp5FPwjP1PiK6t0x8OQH337gA9s6V0LG7j78tcwizO0c2dytg3Ox = new String[] { "Peaceful", "Easy", "Normal", "Hard", "Frail" };
        0601s25AwsXK8YAli4bSnf611cz09m3nihe6Wcjm69saa6xnYY1LDN3wqX7Q = new String[] { "FAST", "FANCY", "MAX PERF." };
    }
}
