// 
// Decompiled by Procyon v0.6.0
// 

public class 8P0d4MDLBrMafEuj8dQwPKwi7HfJH682O154X09Chh1Veqm5f7cruc9MUIjZFbzvCAJdw0uouKiUwwOe3gnKHroQ7s73 extends 55XXM28b6p84b4G2l6B1InnTc701h21NG7n6pZPb2RkqeSGMf12ZMp058OFNNJP04Q3WjX0S3IEUdu0p0YkM1TMGm5WXG2Nme6
{
    protected 8P0d4MDLBrMafEuj8dQwPKwi7HfJH682O154X09Chh1Veqm5f7cruc9MUIjZFbzvCAJdw0uouKiUwwOe3gnKHroQ7s73(final int n) {
        super(n, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.0e51g5n7QQ2bM6IT7Q28hAbJkebnbMOVd3lRo7XioWLAkvTHV9DQxASpl4S7);
        this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H = 59;
    }
    
    @Override
    public int 2b1pbetRmJyaMfSXs7k02a96ZB84GA6lI6KnMBwqDWfFcMKEifg20ytG350E(final int n) {
        if (n == 1) {
            return this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H - 16;
        }
        if (n == 0) {
            return 55XXM28b6p84b4G2l6B1InnTc701h21NG7n6pZPb2RkqeSGMf12ZMp058OFNNJP04Q3WjX0S3IEUdu0p0YkM1TMGm5WXG2Nme6.9pM4rkY0Wc1XwSMoqj9Qk179xj385KsgRK30VpH0H7V8kG8eU838ZQ40wef3.2b1pbetRmJyaMfSXs7k02a96ZB84GA6lI6KnMBwqDWfFcMKEifg20ytG350E(0);
        }
        if (n == 2 || n == 4) {
            return this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H + 1;
        }
        return this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H;
    }
    
    @Override
    public boolean 3HQ9sS7D9ugp9IB497sMFtBY2Y02cuF942Paru78kvAT9i29k8wPhryk9dFc(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final 4C3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4 4c3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4) {
        4c3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4.5P5Ql9128c12116V8DwNO5M8CXl4m4JhwaZ78O7qV4qBZIn0VEC5PPd9FXQJ();
        return true;
    }
}
