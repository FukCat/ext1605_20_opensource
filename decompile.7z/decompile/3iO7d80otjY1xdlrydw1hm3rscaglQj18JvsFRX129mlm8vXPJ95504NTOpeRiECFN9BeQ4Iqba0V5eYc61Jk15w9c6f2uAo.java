// 
// Decompiled by Procyon v0.6.0
// 

public class 3iO7d80otjY1xdlrydw1hm3rscaglQj18JvsFRX129mlm8vXPJ95504NTOpeRiECFN9BeQ4Iqba0V5eYc61Jk15w9c6f2uAo extends 3MUhW26C00YNqKph7VjmPP09H2sZCGW0Z4YY29XYinNLGHSOpIaTE2l3CZq0agyfP3ixQ2mReMhX6R95MWgn79AB6SfA
{
    public int 3p0gv43cL7j25sTw85c9cXfcP4HTk7W010VdL2XjgPV7V0w2R2sQvYNjSAja;
    private long 9zGIwX9EMBSwmRnPZ3gr71Z2dLYil9zWbXl9RsLwrSPMbyKh0wA2XB1Z2Ty5;
    public long 9Ft1ntRGi6sZW4Mx76MJ56sY5EDCH8sZOcj8x0LlFaIf5eqsjdISdMW9e938;
    public boolean 54O4q276dxP8y31413ENJjhqXBnFshV4S4ng8H76Bv5Y3Ma2DF7fbLk53PvO;
    public boolean 6a3I3v4L072y21iqK2Q4a7OJa1SIY587gNZ7teLm8k1uZzO68dY6lE8PKTBh;
    public boolean 9ajSfayfVo92Z68A5B2rvo13codHKhrUqqH2LRN64r7Ac066r0ki4BD2lC9w;
    public boolean 8s3a9ZFU1Lb4Y33KzN5HEwzzvMoj71d2qDVF231HNAJ36vP850tAYydwpyN6;
    
    public 3iO7d80otjY1xdlrydw1hm3rscaglQj18JvsFRX129mlm8vXPJ95504NTOpeRiECFN9BeQ4Iqba0V5eYc61Jk15w9c6f2uAo(final 4C3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4 4c3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4) {
        super(4c3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4);
        this.3p0gv43cL7j25sTw85c9cXfcP4HTk7W010VdL2XjgPV7V0w2R2sQvYNjSAja = 200;
        this.9zGIwX9EMBSwmRnPZ3gr71Z2dLYil9zWbXl9RsLwrSPMbyKh0wA2XB1Z2Ty5 = 1000L;
        this.9Ft1ntRGi6sZW4Mx76MJ56sY5EDCH8sZOcj8x0LlFaIf5eqsjdISdMW9e938 = 1000L;
        this.54O4q276dxP8y31413ENJjhqXBnFshV4S4ng8H76Bv5Y3Ma2DF7fbLk53PvO = false;
        this.6a3I3v4L072y21iqK2Q4a7OJa1SIY587gNZ7teLm8k1uZzO68dY6lE8PKTBh = false;
        this.9ajSfayfVo92Z68A5B2rvo13codHKhrUqqH2LRN64r7Ac066r0ki4BD2lC9w = false;
        this.8s3a9ZFU1Lb4Y33KzN5HEwzzvMoj71d2qDVF231HNAJ36vP850tAYydwpyN6 = false;
    }
    
    @Override
    public boolean 2tSgAvl2dacKfz51vYXX1g7aX9lCO0625v8uPjMV0hWFZUIgU12I5TzS008n(final 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex) {
        if (43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex.5P1b49yjUtk40LxWp0cULx98QzgbH9k0zk5GX23wZQUAD5Z5i99U0u0h97L4 == 0dby7k68oS8bMP61EdwuR2s558o8vwfZCMui3fm7WNgl5q0kgKt1Twtdb81iRcZM6DYIJZgxzus8L7aK8IV2h06A2w74wN.9F32myypilX6M7d4SOA4Xh1wlD0RDj6j7zJD209tweDLNY0d92U1I1qFh2u4.016D6B0WzYa1oAf8GVzuN3e04Nkxq5CzkT5YVZhj2l5H8LW20C9lkr0R7pc5) {
            this.3p0gv43cL7j25sTw85c9cXfcP4HTk7W010VdL2XjgPV7V0w2R2sQvYNjSAja += 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex.79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp;
            return true;
        }
        return super.2tSgAvl2dacKfz51vYXX1g7aX9lCO0625v8uPjMV0hWFZUIgU12I5TzS008n(43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex);
    }
    
    @Override
    public void 65OWt4O889mqXz3N43g2NIUJd92dmGKRI1JMHfMlw76kTUK1lEjssr367P4Q(final int n) {
        this.6Y0i4yJYn7AY7rxpP7O17O53CiF387wnu3Ql52YjuqI8748DqOEWf5a9p1M0 -= n;
        this.6Y0i4yJYn7AY7rxpP7O17O53CiF387wnu3Ql52YjuqI8748DqOEWf5a9p1M0 = 1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.2H957G8ip82G6rxfiUf3zblru0uP648DzY022SjD3PqVRZ2F11lS24e967i5(this.6Y0i4yJYn7AY7rxpP7O17O53CiF387wnu3Ql52YjuqI8748DqOEWf5a9p1M0, 0, 1);
    }
    
    @Override
    public void 560Okt42Yea9toSes6wp4IMe7oFyIq9277EC8W5BgE04qy9I27LP0uDL746n(final int n, final boolean b) {
        if (n >= 0 && n < 2) {
            super.560Okt42Yea9toSes6wp4IMe7oFyIq9277EC8W5BgE04qy9I27LP0uDL746n(n, b);
        }
    }
    
    public long 3fQ4Zvl6ZGZtMHz8BDhx9ci7pQP8EhDqu7Ri4ywsZ3854I2e4ev3W4B3R3iy() {
        return this.9zGIwX9EMBSwmRnPZ3gr71Z2dLYil9zWbXl9RsLwrSPMbyKh0wA2XB1Z2Ty5;
    }
    
    public boolean 6DmcXOP1jZRKDasP2440t8904Ry66MRC3K00nwd8iGDlPgYii5d1f50QVICF(final long n) {
        if (n < 0L) {
            if (this.9zGIwX9EMBSwmRnPZ3gr71Z2dLYil9zWbXl9RsLwrSPMbyKh0wA2XB1Z2Ty5 < n * -1L) {
                return false;
            }
        }
        else {
            this.9Ft1ntRGi6sZW4Mx76MJ56sY5EDCH8sZOcj8x0LlFaIf5eqsjdISdMW9e938 += n;
        }
        this.9zGIwX9EMBSwmRnPZ3gr71Z2dLYil9zWbXl9RsLwrSPMbyKh0wA2XB1Z2Ty5 += n;
        return true;
    }
    
    public boolean 018jLaFer93s1Ao41hTl8Co499i9rtr87X0l6Asj74ctkfz3zMwrb0xF99f5(final 1902uulnDdAkub863Ix3rm71bL5kvfdD69WJodWuN7PsaTVCd2r3PxE8x6z9wX4bI134l5oES8B2nCfn9cZ2Y3E9NgJ9EmdW 1902uulnDdAkub863Ix3rm71bL5kvfdD69WJodWuN7PsaTVCd2r3PxE8x6z9wX4bI134l5oES8B2nCfn9cZ2Y3E9NgJ9EmdW) {
        switch (8oqI2wPdj0X51V7IE9NA10Z09EoQ4JJq0D4gxkiYWMMs6P6n20d03MXlowLw9y9vhJlqW36UQIvZd8M4b26APc08Cdo31Vk.01Lqa7jqn5Lnc8H2326RUUWR0pcY5mVnw6E94jwT0DsG39Ak48kRz6LgkbXv[1902uulnDdAkub863Ix3rm71bL5kvfdD69WJodWuN7PsaTVCd2r3PxE8x6z9wX4bI134l5oES8B2nCfn9cZ2Y3E9NgJ9EmdW.ordinal()]) {
            case 1: {
                return this.6a3I3v4L072y21iqK2Q4a7OJa1SIY587gNZ7teLm8k1uZzO68dY6lE8PKTBh;
            }
            case 2: {
                return this.9ajSfayfVo92Z68A5B2rvo13codHKhrUqqH2LRN64r7Ac066r0ki4BD2lC9w;
            }
            case 3: {
                return this.54O4q276dxP8y31413ENJjhqXBnFshV4S4ng8H76Bv5Y3Ma2DF7fbLk53PvO;
            }
            case 4: {
                return this.8s3a9ZFU1Lb4Y33KzN5HEwzzvMoj71d2qDVF231HNAJ36vP850tAYydwpyN6;
            }
            default: {
                return false;
            }
        }
    }
    
    public boolean 2j3o3G4w9YEuL5Ti00BI486Z8qmmrnAgVGJYmg4Or967q661jjx3SsHBV6Ko(final int n) {
        switch (n) {
            case 2: {
                return this.6a3I3v4L072y21iqK2Q4a7OJa1SIY587gNZ7teLm8k1uZzO68dY6lE8PKTBh;
            }
            case 3: {
                return this.9ajSfayfVo92Z68A5B2rvo13codHKhrUqqH2LRN64r7Ac066r0ki4BD2lC9w;
            }
            case 1: {
                return this.54O4q276dxP8y31413ENJjhqXBnFshV4S4ng8H76Bv5Y3Ma2DF7fbLk53PvO;
            }
            case 4: {
                return this.8s3a9ZFU1Lb4Y33KzN5HEwzzvMoj71d2qDVF231HNAJ36vP850tAYydwpyN6;
            }
            default: {
                return false;
            }
        }
    }
}
