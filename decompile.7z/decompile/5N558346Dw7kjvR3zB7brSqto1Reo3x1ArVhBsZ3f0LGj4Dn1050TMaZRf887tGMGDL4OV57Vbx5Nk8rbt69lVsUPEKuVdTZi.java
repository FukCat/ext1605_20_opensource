import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 5N558346Dw7kjvR3zB7brSqto1Reo3x1ArVhBsZ3f0LGj4Dn1050TMaZRf887tGMGDL4OV57Vbx5Nk8rbt69lVsUPEKuVdTZi extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        final int n4 = 3;
        final int n5 = random.nextInt(2) + 2;
        final int n6 = random.nextInt(2) + 2;
        int n7 = 0;
        for (int i = n - n5 - 1; i <= n + n5 + 1; ++i) {
            for (int j = n2 - 1; j <= n2 + n4 + 1; ++j) {
                for (int k = n3 - n6 - 1; k <= n3 + n6 + 1; ++k) {
                    final 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ 6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(i, j, k);
                    if ((j == n2 - 1 || j == n2 + n4 + 1) && !6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF.9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                        return false;
                    }
                    if ((i == n - n5 - 1 || i == n + n5 + 1 || k == n3 - n6 - 1 || k == n3 + n6 + 1) && j == n2 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(i, j, k) == 0 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(i, j + 1, k) == 0) {
                        ++n7;
                    }
                }
            }
        }
        if (n7 >= 1 && n7 <= 5) {
            for (int l = n - n5 - 1; l <= n + n5 + 1; ++l) {
                for (int n8 = n2 + n4; n8 >= n2 - 1; --n8) {
                    for (int n9 = n3 - n6 - 1; n9 <= n3 + n6 + 1; ++n9) {
                        if (l != n - n5 - 1 && n8 != n2 - 1 && n9 != n3 - n6 - 1 && l != n + n5 + 1 && n8 != n2 + n4 + 1 && n9 != n3 + n6 + 1) {
                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(l, n8, n9, 0);
                        }
                        else if (n8 >= 0 && !5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(l, n8 - 1, n9).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(l, n8, n9, 0);
                        }
                        else if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(l, n8, n9).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                            if (n8 == n2 - 1 && random.nextInt(4) != 0) {
                                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(l, n8, n9, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.1H5dVFMurf00bTaGF43GOksQVhT6004aZ2djQEveJtHVm5U4ACck9T853X5s.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                            }
                            else {
                                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(l, n8, n9, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6rS3xbs7wahIF9bMwSla3UwNjKn0NEJxwOr6TzBWLXXgX67f27Rv4f3UQ7Hv.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                            }
                        }
                    }
                }
            }
            for (int n10 = 0; n10 < 2; ++n10) {
                for (int n11 = 0; n11 < 3; ++n11) {
                    final int n12 = n + random.nextInt(n5 * 2 + 1) - n5;
                    final int n13 = n3 + random.nextInt(n6 * 2 + 1) - n6;
                    if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n12, n2, n13) == 0) {
                        int n14 = 0;
                        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n12 - 1, n2, n13).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                            ++n14;
                        }
                        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n12 + 1, n2, n13).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                            ++n14;
                        }
                        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n12, n2, n13 - 1).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                            ++n14;
                        }
                        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n12, n2, n13 + 1).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                            ++n14;
                        }
                        if (n14 == 1) {
                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(n12, n2, n13, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06vDOK1oHQ49s4ep0eYM58NjzVjvojuaPT412iLRFZX84J0e1myg2lc1BP2t.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                            final 6enmE657iYVbTN0iMMWCsShLEv0Fb6935B88Ho7ge7tjl6HkmCv0ZNE9vqGuryooyrJpCie3DT8ZhU8TTBL60meAn91Zg8jo7j9fsbq 6enmE657iYVbTN0iMMWCsShLEv0Fb6935B88Ho7ge7tjl6HkmCv0ZNE9vqGuryooyrJpCie3DT8ZhU8TTBL60meAn91Zg8jo7j9fsbq = (6enmE657iYVbTN0iMMWCsShLEv0Fb6935B88Ho7ge7tjl6HkmCv0ZNE9vqGuryooyrJpCie3DT8ZhU8TTBL60meAn91Zg8jo7j9fsbq)5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6hPp92kZVrpu289Er027gE6XGPzFeGBQ5pS5JM73GUT6dyg108A5z3pHTQtS(n12, n2, n13);
                            for (int n15 = 0; n15 < 8; ++n15) {
                                final 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex 8363b3U93j3W4oeu3CK1UXQWeusjgy1uNk2i4nCo47GLGMZJ55JGB5LTaT3w = this.8363b3U93j3W4oeu3CK1UXQWeusjgy1uNk2i4nCo47GLGMZJ55JGB5LTaT3w(random);
                                if (8363b3U93j3W4oeu3CK1UXQWeusjgy1uNk2i4nCo47GLGMZJ55JGB5LTaT3w != null) {
                                    6enmE657iYVbTN0iMMWCsShLEv0Fb6935B88Ho7ge7tjl6HkmCv0ZNE9vqGuryooyrJpCie3DT8ZhU8TTBL60meAn91Zg8jo7j9fsbq.3X9ApEokKgiM9F560XcAj5R7N1nlRhI4G4E9O31Bh1SD247oOA0qX5ecWPdH(random.nextInt(6enmE657iYVbTN0iMMWCsShLEv0Fb6935B88Ho7ge7tjl6HkmCv0ZNE9vqGuryooyrJpCie3DT8ZhU8TTBL60meAn91Zg8jo7j9fsbq.82z4KDb9OZq9563k0KD4PRo6L2hS7GZeBAxa7oDwSLJg6kPr05p0MQ532ki7()), 8363b3U93j3W4oeu3CK1UXQWeusjgy1uNk2i4nCo47GLGMZJ55JGB5LTaT3w);
                                }
                            }
                            break;
                        }
                    }
                }
            }
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.0j88hQnG78a3fa48s11cxPgox69u31WE2S07Vf86o8RA5htD379LFQEd3w40.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            ((6rNnMce0Z9o9ZgEH1hCrjc470Py2d427dR01C0nFX01h79DjvS4w014cG16Le3OXp1H172g7Z4XXzCG2TIej5pd75M6Lu3BWg8)5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6hPp92kZVrpu289Er027gE6XGPzFeGBQ5pS5JM73GUT6dyg108A5z3pHTQtS(n, n2, n3)).02lHY6fi41k49D6xwX8YHFPbL4s6ZUh21RA6dmq0Y89xpcTld4ycUzwyal3o = this.7lv7EM8XhICoSZFsNRqdm5lEJT9EuCA18Yt05jS6tEsTkhErjGc35tk0i2d5(random);
            return true;
        }
        return false;
    }
    
    private 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex 8363b3U93j3W4oeu3CK1UXQWeusjgy1uNk2i4nCo47GLGMZJ55JGB5LTaT3w(final Random random) {
        final int nextInt = random.nextInt(11);
        return (nextInt == 0) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.6noflZ1gkjweEgzJ51jZAZD0rvVFPY0YubfkxzwYBAREg2KbroROtP6VG9if) : ((nextInt == 1) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.5FbH1YXTAh858ygBlR6AVt1t33tH2DJxw9v8Wjs4k5p4ejc7JZKv5o72Bu21, random.nextInt(4) + 1) : ((nextInt == 2) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.10zK6r99r8NgC10vK6a4iTpVCVaO8c5S3gUjWqP5at8j9X6jtz2f4hp39vUa) : ((nextInt == 3) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.298k5mF0Pc57SW3U5s1gOeXw99H6wFIz8y428TLu9utwD15qBNS2ql7tR48V, random.nextInt(4) + 1) : ((nextInt == 4) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.7ur4AD90TcI72D7QWPe6WJuU2v0TBS8YFNcSWG1gS4nVdfaVolbe4da3qD0m, random.nextInt(4) + 1) : ((nextInt == 5) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.9AjZJUrv8RA3EkVc9wXXKYOzVN4Rge0rY9Uw1sX50Ggbwg8it7mbty6022tP, random.nextInt(4) + 1) : ((nextInt == 6) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.9H7Iy3BTEJFt4WgjPuNen881DHgB487ae45Mu9y290O2lpH7cT59V7Gny3Y9) : ((nextInt == 7 && random.nextInt(100) == 0) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.1lKq5h20mTi8Qyx95287Z296tqIMg85o3HgoS6DRaZ1HTJBG7SK342a5Vbq6) : ((nextInt == 8 && random.nextInt(2) == 0) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.55NW8i54JpL3yz1J76pg3fYc9Td2PocF9wQ1v1brM226AHoc2HTlsD145WmV, random.nextInt(4) + 1) : ((nextInt == 9 && random.nextInt(10) == 0) ? new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.8520h7KAcsf6F9feiIOsmSaFng995n36Rbw1F2Fn1Nn8r6en822LOu567Z7z[9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.2VzIKFgUiCVSp7Upjs5ks19iixbH4PZ672By7Y5vFSKJId86B9P5w54CRksA.016D6B0WzYa1oAf8GVzuN3e04Nkxq5CzkT5YVZhj2l5H8LW20C9lkr0R7pc5 + random.nextInt(2)]) : null)))))))));
    }
    
    private String 7lv7EM8XhICoSZFsNRqdm5lEJT9EuCA18Yt05jS6tEsTkhErjGc35tk0i2d5(final Random random) {
        final int nextInt = random.nextInt(4);
        return (nextInt == 0) ? "Skeleton" : ((nextInt == 1) ? "Zombie" : ((nextInt == 2) ? "Zombie" : ((nextInt == 3) ? "Spider" : "")));
    }
}
