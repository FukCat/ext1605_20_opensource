import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 02Ok4wJjPXX4t0tf37acGm9C89LkXqZeYh5VGrnuQXVJHdavKu584xzsCuG14o6DdwF5wF0i2h99448Tl6ZDKZ5rwjP91205 extends 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl
{
    public final int 785AXtdFOhFXlosQ8xZ2sw8bZ29jM2mtdTSsO0C4Xzi6GtMPb6IYjy73g2C9;
    
    public 02Ok4wJjPXX4t0tf37acGm9C89LkXqZeYh5VGrnuQXVJHdavKu584xzsCuG14o6DdwF5wF0i2h99448Tl6ZDKZ5rwjP91205(final double n, final double n2, final Layer layer, final int 785AXtdFOhFXlosQ8xZ2sw8bZ29jM2mtdTSsO0C4Xzi6GtMPb6IYjy73g2C9) {
        super(n, n2, layer);
        this.785AXtdFOhFXlosQ8xZ2sw8bZ29jM2mtdTSsO0C4Xzi6GtMPb6IYjy73g2C9 = 785AXtdFOhFXlosQ8xZ2sw8bZ29jM2mtdTSsO0C4Xzi6GtMPb6IYjy73g2C9;
    }
    
    @Override
    public boolean 84EZjwmgfVpn5brk96GnU3Eit81Yc6Xxm4lTPdVKUWyphKxl38Uh4dg8VF3T(final Random random, final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2) {
        return true;
    }
    
    @Override
    public void 0C8cKMHZGkSA22DGYztFv5857z0O34nRumUNAm59CrgBrFnKV5bq3guXEYB5(final Random random) {
    }
    
    @Override
    public int 8WfOXonA2bRS7hUpHd7sbe7k20yqj7N6OH13GX3XXy71V13Eva115wQwe47C() {
        return this.785AXtdFOhFXlosQ8xZ2sw8bZ29jM2mtdTSsO0C4Xzi6GtMPb6IYjy73g2C9;
    }
}
