// 
// Decompiled by Procyon v0.6.0
// 

public class 3Xe5zb5e89nX00QQ5xsP2o5kxwh9bkix2So8x308O1AMTyiCLhZY1kni66wMlzvE0ocJ6331x03x95Qhk7h1dQo18c0u0E7TYaMyu extends RuntimeException
{
    public 3Xe5zb5e89nX00QQ5xsP2o5kxwh9bkix2So8x308O1AMTyiCLhZY1kni66wMlzvE0ocJ6331x03x95Qhk7h1dQo18c0u0E7TYaMyu(final String message) {
        super(message);
    }
}
