import java.io.DataInput;
import java.io.IOException;
import java.io.DataOutput;

// 
// Decompiled by Procyon v0.6.0
// 

public class 7eh6ri0t9ycCp8J7L2hLcpxyx60qg0pLnKkXo51739KRIBwUj6gXgu6C5veRwhFJ97P9a3Q85E2k1TnCo0ab2Y7ZdM1keD6 extends 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi
{
    public byte 0NYkuWw75sX68PMRr947nS18PIPw5004dqKm5dxrU87fONtExsYNS2n6rzyU;
    
    public 7eh6ri0t9ycCp8J7L2hLcpxyx60qg0pLnKkXo51739KRIBwUj6gXgu6C5veRwhFJ97P9a3Q85E2k1TnCo0ab2Y7ZdM1keD6() {
    }
    
    public 7eh6ri0t9ycCp8J7L2hLcpxyx60qg0pLnKkXo51739KRIBwUj6gXgu6C5veRwhFJ97P9a3Q85E2k1TnCo0ab2Y7ZdM1keD6(final byte 0nYkuWw75sX68PMRr947nS18PIPw5004dqKm5dxrU87fONtExsYNS2n6rzyU) {
        this.0NYkuWw75sX68PMRr947nS18PIPw5004dqKm5dxrU87fONtExsYNS2n6rzyU = 0nYkuWw75sX68PMRr947nS18PIPw5004dqKm5dxrU87fONtExsYNS2n6rzyU;
    }
    
    @Override
    void 7OU3N2lgEecd9p9DtAmaF5EwE4f0u28Oaa9zcxqnm3XW1bDsPewY15rIFs80(final DataOutput dataOutput) throws IOException {
        dataOutput.writeByte(this.0NYkuWw75sX68PMRr947nS18PIPw5004dqKm5dxrU87fONtExsYNS2n6rzyU);
    }
    
    @Override
    void 96fSDIRBY01vu6bNpWo4KQJG8fCN2WIew9WR04d4yvq9Lxko60PpMIEkyn00(final DataInput dataInput) throws IOException {
        this.0NYkuWw75sX68PMRr947nS18PIPw5004dqKm5dxrU87fONtExsYNS2n6rzyU = dataInput.readByte();
    }
    
    @Override
    public byte 3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr() {
        return 1;
    }
    
    @Override
    public String toString() {
        return "" + this.0NYkuWw75sX68PMRr947nS18PIPw5004dqKm5dxrU87fONtExsYNS2n6rzyU;
    }
}
