import java.util.Arrays;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 729wLc8hwl7tQSEXg3HsRG444K9D1o3Bi3exyPXRRdMjsGLGIyU3AQA2yY0rMpK979u8WUff3jJTFiOS9p5U9icBdQL2lm7JImBy51
{
    private float[] 9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ;
    private int[] 601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP;
    private int[] 9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2;
    private int[] 2GvS3046WAw180QE48uesiX8cEW6grY5kGu78N4y25Di8Shi8GywgLv7HdMC;
    private int[] 8jjfoE3x59c3a74BPpi52F3e1Nhns5KXhreJ8UogBr32t18tbh0796yG5fpy;
    private int[] 0lBxEs4458F1u5legmUj7vk9ZTKSkq1D0c4paSJ89ZBnGNezDX1ehQFe84Rg;
    private int[] 2567b26167RumFzdRuoCZ4Dw2Qpehv602UOpQ0M5clToWPdVu5HI4VgH9kTt;
    
    public 729wLc8hwl7tQSEXg3HsRG444K9D1o3Bi3exyPXRRdMjsGLGIyU3AQA2yY0rMpK979u8WUff3jJTFiOS9p5U9icBdQL2lm7JImBy51() {
        this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ = new float[768];
        this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP = new int[5120];
        this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2 = new int[5120];
        this.2GvS3046WAw180QE48uesiX8cEW6grY5kGu78N4y25Di8Shi8GywgLv7HdMC = new int[5120];
        this.8jjfoE3x59c3a74BPpi52F3e1Nhns5KXhreJ8UogBr32t18tbh0796yG5fpy = new int[5120];
        this.0lBxEs4458F1u5legmUj7vk9ZTKSkq1D0c4paSJ89ZBnGNezDX1ehQFe84Rg = new int[34];
        this.2567b26167RumFzdRuoCZ4Dw2Qpehv602UOpQ0M5clToWPdVu5HI4VgH9kTt = new int[768];
        try {
            final BufferedImage read = ImageIO.read(1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.9P3TY758VM8951Z7q70WD5qYdKqLdB22jUqQNi8u6rFBU4uZnFfpCw0XU82v(Minecraft.3A3F71eia4o7hinl32z3YhX5z1YU4tLl0Pa5fhF3On0AAcu71UaBBB87kO4L));
            final int[] rgbArray = new int[65536];
            read.getRGB(0, 0, 256, 256, rgbArray, 0, 256);
            for (int i = 0; i < 512; ++i) {
                int n = 0;
                int n2 = 0;
                int n3 = 0;
                final int n4 = i % 16 * 16;
                final int n5 = i / 16 * 32;
                int n6 = 0;
                for (int j = 0; j < 16; ++j) {
                    for (int k = 0; k < 16; ++k) {
                        final int n7 = rgbArray[k + n4 + (j + n5) * 256];
                        if ((n7 >> 24 & 0xFF) > 128) {
                            n += (n7 >> 16 & 0xFF);
                            n2 += (n7 >> 8 & 0xFF);
                            n3 += (n7 & 0xFF);
                            ++n6;
                        }
                    }
                    if (n6 == 0) {
                        ++n6;
                    }
                    this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[i * 3 + 0] = (float)(n / n6);
                    this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[i * 3 + 1] = (float)(n2 / n6);
                    this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[i * 3 + 2] = (float)(n3 / n6);
                }
            }
        }
        catch (final IOException ex) {
            ex.printStackTrace();
        }
        for (int l = 0; l < 256; ++l) {
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[l] != null) {
                this.2567b26167RumFzdRuoCZ4Dw2Qpehv602UOpQ0M5clToWPdVu5HI4VgH9kTt[l * 3 + 0] = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[l].8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(1);
                this.2567b26167RumFzdRuoCZ4Dw2Qpehv602UOpQ0M5clToWPdVu5HI4VgH9kTt[l * 3 + 1] = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[l].8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(2);
                this.2567b26167RumFzdRuoCZ4Dw2Qpehv602UOpQ0M5clToWPdVu5HI4VgH9kTt[l * 3 + 2] = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[l].8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(3);
            }
        }
    }
    
    public void 8DHJd27I7dEAinVNW1QMocs560JON070k26cNcs5j9fr6O3I853qcD326wmz(final 5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF 5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF) {
        final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR = 5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.7OZ7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR;
        if (7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR == null || !7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR.7eR9DSG8f5yl5ZjGCMk6TS2O067IQ0XB8SWMJB88YEiv3e1nz52X71J5974I.529kIgbItU22E3O3VE3qip6Qg03EgH4PNYZ29GuyhqQB304wIp4IGgc624cq(5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.1Ptq07ObeBn5cnc2Hvo5sxAmCyb89O4gW5f8asG4BJgu1683Xp5m687G8a41, 5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.70cH252WV3Ffw5dP5bgNN05P7K18GG75b6He6o6n0tc30d26t8ax5wfK8f09)) {
            5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.2fRon5m1N7aMOT87gKu4p0JI6CUWXpj4Bkt4446I1I1EGJK51WA3Q1ELoWCJ = true;
            5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.412nA6NkiGO6n7Cx8Ph8P5RUo8xoE50GQulkK7m445JG9wd413ygiw8y13B9 = true;
        }
        else {
            final int n = 5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.1Ptq07ObeBn5cnc2Hvo5sxAmCyb89O4gW5f8asG4BJgu1683Xp5m687G8a41 * 16;
            final int n2 = 5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.70cH252WV3Ffw5dP5bgNN05P7K18GG75b6He6o6n0tc30d26t8ax5wfK8f09 * 16;
            final int n3 = n + 16;
            final int n4 = n2 + 16;
            if (7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR.7c9x1zA6pt6wNR85ZLMaNksR9dgW3Ul967Y9IxCCm37kJyE185Iu6wF8e03Y(5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.1Ptq07ObeBn5cnc2Hvo5sxAmCyb89O4gW5f8asG4BJgu1683Xp5m687G8a41, 5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.70cH252WV3Ffw5dP5bgNN05P7K18GG75b6He6o6n0tc30d26t8ax5wfK8f09).0z4PO1p9Zw82wXn72PhosM6oqTRf45yjpZ9ESZ05DY9MVc5DKMC1plCFsy0a) {
                5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.2fRon5m1N7aMOT87gKu4p0JI6CUWXpj4Bkt4446I1I1EGJK51WA3Q1ELoWCJ = true;
                5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.412nA6NkiGO6n7Cx8Ph8P5RUo8xoE50GQulkK7m445JG9wd413ygiw8y13B9 = true;
            }
            else {
                5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.2fRon5m1N7aMOT87gKu4p0JI6CUWXpj4Bkt4446I1I1EGJK51WA3Q1ELoWCJ = false;
                Arrays.fill(this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2, 0);
                Arrays.fill(this.2GvS3046WAw180QE48uesiX8cEW6grY5kGu78N4y25Di8Shi8GywgLv7HdMC, 0);
                Arrays.fill(this.0lBxEs4458F1u5legmUj7vk9ZTKSkq1D0c4paSJ89ZBnGNezDX1ehQFe84Rg, 160);
                for (int i = n4 - 1; i >= n2; --i) {
                    for (int j = n3 - 1; j >= n; --j) {
                        final int n5 = j - n;
                        final int n6 = i - n2;
                        final int n7 = n5 + n6;
                        boolean b = true;
                        for (int k = 0; k < 128; ++k) {
                            final int n8 = n6 - n5 - k + 160 - 16;
                            if (n8 < this.0lBxEs4458F1u5legmUj7vk9ZTKSkq1D0c4paSJ89ZBnGNezDX1ehQFe84Rg[n7] || n8 < this.0lBxEs4458F1u5legmUj7vk9ZTKSkq1D0c4paSJ89ZBnGNezDX1ehQFe84Rg[n7 + 1]) {
                                final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(j, k, i)];
                                if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC == null) {
                                    b = false;
                                }
                                else if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF == 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.48vJoOIJt15P5mCD3szk3QoP21Ya9f5381N237U51K027s0J0H87b0ZD496P) {
                                    final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM = 7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(j, k + 1, i);
                                    if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM].5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF != 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.48vJoOIJt15P5mCD3szk3QoP21Ya9f5381N237U51K027s0J0H87b0ZD496P) {
                                        final float n9 = 7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR.601Q1cZyHo6i3ye002F165wmjZTccN0mi586WeLpWIZ3th5V852e3gwXjae7(j, k + 1, i) * (k / 127.0f * 0.6f + 0.4f);
                                        if (n8 >= 0 && n8 < 160) {
                                            final int n10 = n7 + n8 * 32;
                                            if (n7 >= 0 && n7 <= 32 && this.2GvS3046WAw180QE48uesiX8cEW6grY5kGu78N4y25Di8Shi8GywgLv7HdMC[n10] <= k) {
                                                this.2GvS3046WAw180QE48uesiX8cEW6grY5kGu78N4y25Di8Shi8GywgLv7HdMC[n10] = k;
                                                this.8jjfoE3x59c3a74BPpi52F3e1Nhns5KXhreJ8UogBr32t18tbh0796yG5fpy[n10] = (int)(n9 * 127.0f);
                                            }
                                            if (n7 >= -1 && n7 <= 31 && this.2GvS3046WAw180QE48uesiX8cEW6grY5kGu78N4y25Di8Shi8GywgLv7HdMC[n10 + 1] <= k) {
                                                this.2GvS3046WAw180QE48uesiX8cEW6grY5kGu78N4y25Di8Shi8GywgLv7HdMC[n10 + 1] = k;
                                                this.8jjfoE3x59c3a74BPpi52F3e1Nhns5KXhreJ8UogBr32t18tbh0796yG5fpy[n10 + 1] = (int)(n9 * 127.0f);
                                            }
                                            b = false;
                                        }
                                    }
                                }
                                else {
                                    if (b) {
                                        if (n8 < this.0lBxEs4458F1u5legmUj7vk9ZTKSkq1D0c4paSJ89ZBnGNezDX1ehQFe84Rg[n7]) {
                                            this.0lBxEs4458F1u5legmUj7vk9ZTKSkq1D0c4paSJ89ZBnGNezDX1ehQFe84Rg[n7] = n8;
                                        }
                                        if (n8 < this.0lBxEs4458F1u5legmUj7vk9ZTKSkq1D0c4paSJ89ZBnGNezDX1ehQFe84Rg[n7 + 1]) {
                                            this.0lBxEs4458F1u5legmUj7vk9ZTKSkq1D0c4paSJ89ZBnGNezDX1ehQFe84Rg[n7 + 1] = n8;
                                        }
                                    }
                                    final float n11 = k / 127.0f * 0.6f + 0.4f;
                                    if (n8 >= 0 && n8 < 160) {
                                        final int n12 = n7 + n8 * 32;
                                        final int n13 = this.2567b26167RumFzdRuoCZ4Dw2Qpehv602UOpQ0M5clToWPdVu5HI4VgH9kTt[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 * 3 + 0];
                                        final float n14 = (7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR.601Q1cZyHo6i3ye002F165wmjZTccN0mi586WeLpWIZ3th5V852e3gwXjae7(j, k + 1, i) * 0.8f + 0.2f) * n11;
                                        if (n7 >= 0 && this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n12] <= k) {
                                            this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n12] = k;
                                            this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n12] = (0xFF000000 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n13 * 3 + 0] * n14) << 16 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n13 * 3 + 1] * n14) << 8 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n13 * 3 + 2] * n14));
                                        }
                                        if (n7 < 31) {
                                            final float n15 = n14 * 0.9f;
                                            if (this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n12 + 1] <= k) {
                                                this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n12 + 1] = k;
                                                this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n12 + 1] = (0xFF000000 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n13 * 3 + 0] * n15) << 16 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n13 * 3 + 1] * n15) << 8 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n13 * 3 + 2] * n15));
                                            }
                                        }
                                    }
                                    if (n8 >= -1 && n8 < 159) {
                                        final int n16 = n7 + (n8 + 1) * 32;
                                        final int n17 = this.2567b26167RumFzdRuoCZ4Dw2Qpehv602UOpQ0M5clToWPdVu5HI4VgH9kTt[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 * 3 + 1];
                                        final float n18 = 7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR.601Q1cZyHo6i3ye002F165wmjZTccN0mi586WeLpWIZ3th5V852e3gwXjae7(j - 1, k, i) * 0.8f + 0.2f;
                                        final int n19 = this.2567b26167RumFzdRuoCZ4Dw2Qpehv602UOpQ0M5clToWPdVu5HI4VgH9kTt[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 * 3 + 2];
                                        final float n20 = 7oz7taAfVinHekYDAGlzh3Uz140r8kEzsd2tmdbE1ROP6nle3dRh1s5prdTR.601Q1cZyHo6i3ye002F165wmjZTccN0mi586WeLpWIZ3th5V852e3gwXjae7(j, k, i + 1) * 0.8f + 0.2f;
                                        if (n7 >= 0) {
                                            final float n21 = n18 * n11 * 0.6f;
                                            if (this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n16] <= k - 1) {
                                                this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n16] = k - 1;
                                                this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n16] = (0xFF000000 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n17 * 3 + 0] * n21) << 16 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n17 * 3 + 1] * n21) << 8 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n17 * 3 + 2] * n21));
                                            }
                                        }
                                        if (n7 < 31) {
                                            final float n22 = n20 * 0.9f * n11 * 0.4f;
                                            if (this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n16 + 1] <= k - 1) {
                                                this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n16 + 1] = k - 1;
                                                this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n16 + 1] = (0xFF000000 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n19 * 3 + 0] * n22) << 16 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n19 * 3 + 1] * n22) << 8 | (int)(this.9sdgFdL7J6iVa5Q8ScdOeGa14ksltJR91n7NDd0FVFBH20vSlYC4isdHZizQ[n19 * 3 + 2] * n22));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                this.5294Xxzn0lzbR7R50EcYwo35NOY06u9rP9fDwhKjW9Gv6Q0tP6lbFe9Ne4NK();
                if (5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.2gSiFJnTc4im5CUgc7OaR9dSUYWr4V68lA5e9Ni1S9uiy47SdOCB9V8kN0zN == null) {
                    5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.2gSiFJnTc4im5CUgc7OaR9dSUYWr4V68lA5e9Ni1S9uiy47SdOCB9V8kN0zN = new BufferedImage(32, 160, 2);
                }
                5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.2gSiFJnTc4im5CUgc7OaR9dSUYWr4V68lA5e9Ni1S9uiy47SdOCB9V8kN0zN.setRGB(0, 0, 32, 160, this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP, 0, 32);
                5b9av5ufoVer0hh5u77w3VG380f45cP2W6Bu1XDpImbFM4PIbLogd8eAtMZctK2q8eomUqysvstMm0T0Q0sYXdCZKU1pfCQM1IeL7tF.412nA6NkiGO6n7Cx8Ph8P5RUo8xoE50GQulkK7m445JG9wd413ygiw8y13B9 = true;
            }
        }
    }
    
    private void 5294Xxzn0lzbR7R50EcYwo35NOY06u9rP9fDwhKjW9Gv6Q0tP6lbFe9Ne4NK() {
        for (int i = 0; i < 32; ++i) {
            for (int j = 0; j < 160; ++j) {
                final int n = i + j * 32;
                if (this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n] == 0) {
                    this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n] = 0;
                }
                if (this.2GvS3046WAw180QE48uesiX8cEW6grY5kGu78N4y25Di8Shi8GywgLv7HdMC[n] > this.9GECAGv81yQD543UUlQV28zlKg1p2e3swkGvfQ6eyL1xxW4fimF79fZ52hb2[n]) {
                    final int n2 = this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n] >> 24 & 0xFF;
                    this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n] = ((this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n] & 0xFEFEFE) >> 1) + this.8jjfoE3x59c3a74BPpi52F3e1Nhns5KXhreJ8UogBr32t18tbh0796yG5fpy[n];
                    if (n2 < 128) {
                        this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n] = Integer.MIN_VALUE + this.8jjfoE3x59c3a74BPpi52F3e1Nhns5KXhreJ8UogBr32t18tbh0796yG5fpy[n] * 2;
                    }
                    else {
                        final int[] 601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP = this.601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP;
                        final int n3 = n;
                        601Lo7un7dy7LhVHI2R1434f9q2sjG7O6Q3w4Z7m32o3lAGQmNmT302ehOGP[n3] |= 0xFF000000;
                    }
                }
            }
        }
    }
}
