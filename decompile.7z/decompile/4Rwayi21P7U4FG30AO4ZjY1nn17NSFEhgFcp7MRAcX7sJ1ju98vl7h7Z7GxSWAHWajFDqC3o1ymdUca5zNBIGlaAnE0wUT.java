import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.ARBVertexBufferObject;
import org.lwjgl.opengl.GLContext;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ByteBuffer;

// 
// Decompiled by Procyon v0.6.0
// 

public class 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT
{
    private static boolean 08108hq6Y7h9f7GQ6W9Oys09fiT8P9SPmyAnu0Ftv5Oz25C7L9XZMWy08vm4;
    private static boolean 27w3bD08606gvLMBieKFhVaI53cR77q1z3q342Xth49O4B891KGP3Gm1VIHd;
    private ByteBuffer 8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS;
    private IntBuffer 5362r5v8xKUw09qdKmTTIN2zf6UU14i3On606C9qv9fij9Y0ril8z7Ni8Oe6;
    private FloatBuffer 36LjzW8U4735L1aKd9KY7BpZ013phF90yKpYq5mbUr9T3gRJ16xzTt6a9tC4;
    private int[] 7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s;
    private int 41K7EIHmtvWYaIF7y1yWH2v0VRgYPLSf5QkL5MV5tjd6Pn8N7W1iTJ0hf7VO;
    private double 965dA6q7a2cC0rhuHy4o1zD8csd2tOuF9o7Br9AZ9mqIwZQk5fLiqQ8n7wP3;
    private double 8o1IcH8y58HSw56uZO1Kc8WGA55E0prs7nC0VXobl429K1cn3CRyNwy2311Y;
    private int 81586Uhrr7MGq0vI129SXKq33Vs8vQl4PJd83ougnqatQ53Tw6k207785KV8;
    private boolean 30G40iRXXiCK1i17UV0Jo4EHm8sq0Nfwtjb1169AtgBPwYz7lf7a0L3plKGb;
    private boolean 9i97OpeL9Y07GRwMDGk1i1P9P3Q0i67Edx6sj12v7Ffn3HDpvOd22ta926v1;
    private boolean 6vdCgzA8rZ2YUwrKO1JwQVo4OVXZwzRKPG4IfK04Z5c8HRsXw5T7eCKelmA6;
    private int 5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7;
    private int 7lu77zBAC8UvdID9pmI5EDo0SYVT3WkddRktY4dOMQiE818Fe96aS8uBJxb4;
    private boolean 1JMM0S3fPxcvyUiwCmKeI57Ic0LmVQeB5gz0Oqj2358ebBnvyhZojYP0LS5s;
    private int 9rmS118mpcfaG57K7LEz1DT4CDt1SSdzovBEw21w1sJ4wE9F4gYkG9lOg03k;
    private double 6H15Et5q485s11tGRTWT8ZfLDSL4EW2bZGBGxc6zq7heam7iNk128kZAog0A;
    private double 0fx6Agi9mv24gWiudnw102TaV5Y85QJn1KBVhNfB082VCHL5z16q4QJ8JTs7;
    private double 7WbAPnE9B9Tazn40R7izK84Y11M3WBDr01a7hp52f1ZV6YPLDGcPd3pih29L;
    private int 7KaBAwl3W6436zj40A3d3mw3dtn9gz6dyuf46yc1c9Z9y62EL1iCOh111XRJ;
    public static final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
    private boolean 23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N;
    private boolean 19Z5OZ6vOK809lU12yWMZ0tMU5jsQf3upv2v8qfMWtK5z3G55ZvJ6QaAC8Wj;
    private IntBuffer 1W5xWSBKz2801SmVuOUC9nmTE3wuc52L1ekYR1874XFW26V196AGWB9wA4xp;
    private int 85mSNW00VTxM3HQkpM9jj4yWnDk6446JsXpI3ZkGLNT3n5HD4gtf6V9iJ09T;
    private int 91J5886OvxjvqD2nh35sLrQtGp7Ci47ewxZf5l17m1o0RZy9s0fzPAcnmten;
    private int 1Fc22qU22IMzC4yb770T4IRSUU3Xo27659D4mS3gsrqo22J34zP5br08083O;
    public int 0MROVDArlUltRNep2c82Yjn0c1YV0K6TX18zu3ch3eo466SKujDB70HFNvjW;
    public final int 3MB0Qm9645l05CgxH9Qp56vd457542UnkuBZPjHcpx7w5Fg2FpWDJ5149EH8 = 150;
    
    private 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT(final int 1Fc22qU22IMzC4yb770T4IRSUU3Xo27659D4mS3gsrqo22J34zP5br08083O) {
        this.41K7EIHmtvWYaIF7y1yWH2v0VRgYPLSf5QkL5MV5tjd6Pn8N7W1iTJ0hf7VO = 0;
        this.30G40iRXXiCK1i17UV0Jo4EHm8sq0Nfwtjb1169AtgBPwYz7lf7a0L3plKGb = false;
        this.9i97OpeL9Y07GRwMDGk1i1P9P3Q0i67Edx6sj12v7Ffn3HDpvOd22ta926v1 = false;
        this.6vdCgzA8rZ2YUwrKO1JwQVo4OVXZwzRKPG4IfK04Z5c8HRsXw5T7eCKelmA6 = false;
        this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 = 0;
        this.7lu77zBAC8UvdID9pmI5EDo0SYVT3WkddRktY4dOMQiE818Fe96aS8uBJxb4 = 0;
        this.1JMM0S3fPxcvyUiwCmKeI57Ic0LmVQeB5gz0Oqj2358ebBnvyhZojYP0LS5s = false;
        this.23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N = false;
        this.19Z5OZ6vOK809lU12yWMZ0tMU5jsQf3upv2v8qfMWtK5z3G55ZvJ6QaAC8Wj = false;
        this.85mSNW00VTxM3HQkpM9jj4yWnDk6446JsXpI3ZkGLNT3n5HD4gtf6V9iJ09T = 0;
        this.91J5886OvxjvqD2nh35sLrQtGp7Ci47ewxZf5l17m1o0RZy9s0fzPAcnmten = 10;
        this.0MROVDArlUltRNep2c82Yjn0c1YV0K6TX18zu3ch3eo466SKujDB70HFNvjW = 0;
        this.1Fc22qU22IMzC4yb770T4IRSUU3Xo27659D4mS3gsrqo22J34zP5br08083O = 1Fc22qU22IMzC4yb770T4IRSUU3Xo27659D4mS3gsrqo22J34zP5br08083O;
        this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS = 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.91EuTmkXm8xAIAY7j7v6912p5y1QFEu55cAH1a443YZgof0oct95U9qVT07h(1Fc22qU22IMzC4yb770T4IRSUU3Xo27659D4mS3gsrqo22J34zP5br08083O * 4);
        this.5362r5v8xKUw09qdKmTTIN2zf6UU14i3On606C9qv9fij9Y0ril8z7Ni8Oe6 = this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS.asIntBuffer();
        this.36LjzW8U4735L1aKd9KY7BpZ013phF90yKpYq5mbUr9T3gRJ16xzTt6a9tC4 = this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS.asFloatBuffer();
        this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s = new int[1Fc22qU22IMzC4yb770T4IRSUU3Xo27659D4mS3gsrqo22J34zP5br08083O];
        this.19Z5OZ6vOK809lU12yWMZ0tMU5jsQf3upv2v8qfMWtK5z3G55ZvJ6QaAC8Wj = (4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.27w3bD08606gvLMBieKFhVaI53cR77q1z3q342Xth49O4B891KGP3Gm1VIHd && GLContext.getCapabilities().GL_ARB_vertex_buffer_object);
        if (this.19Z5OZ6vOK809lU12yWMZ0tMU5jsQf3upv2v8qfMWtK5z3G55ZvJ6QaAC8Wj) {
            ARBVertexBufferObject.glGenBuffersARB(this.1W5xWSBKz2801SmVuOUC9nmTE3wuc52L1ekYR1874XFW26V196AGWB9wA4xp = 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1R0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2(this.91J5886OvxjvqD2nh35sLrQtGp7Ci47ewxZf5l17m1o0RZy9s0fzPAcnmten));
        }
    }
    
    public void 217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2() {
        if (this.23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N) {
            this.23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N = false;
            if (this.41K7EIHmtvWYaIF7y1yWH2v0VRgYPLSf5QkL5MV5tjd6Pn8N7W1iTJ0hf7VO > 0) {
                this.5362r5v8xKUw09qdKmTTIN2zf6UU14i3On606C9qv9fij9Y0ril8z7Ni8Oe6.clear();
                this.5362r5v8xKUw09qdKmTTIN2zf6UU14i3On606C9qv9fij9Y0ril8z7Ni8Oe6.put(this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s, 0, this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7);
                this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS.position(0);
                this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS.limit(this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 * 4);
                if (this.19Z5OZ6vOK809lU12yWMZ0tMU5jsQf3upv2v8qfMWtK5z3G55ZvJ6QaAC8Wj) {
                    this.85mSNW00VTxM3HQkpM9jj4yWnDk6446JsXpI3ZkGLNT3n5HD4gtf6V9iJ09T = (this.85mSNW00VTxM3HQkpM9jj4yWnDk6446JsXpI3ZkGLNT3n5HD4gtf6V9iJ09T + 1) % this.91J5886OvxjvqD2nh35sLrQtGp7Ci47ewxZf5l17m1o0RZy9s0fzPAcnmten;
                    ARBVertexBufferObject.glBindBufferARB(34962, this.1W5xWSBKz2801SmVuOUC9nmTE3wuc52L1ekYR1874XFW26V196AGWB9wA4xp.get(this.85mSNW00VTxM3HQkpM9jj4yWnDk6446JsXpI3ZkGLNT3n5HD4gtf6V9iJ09T));
                    ARBVertexBufferObject.glBufferDataARB(34962, this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS, 35040);
                }
                if (this.9i97OpeL9Y07GRwMDGk1i1P9P3Q0i67Edx6sj12v7Ffn3HDpvOd22ta926v1) {
                    if (this.19Z5OZ6vOK809lU12yWMZ0tMU5jsQf3upv2v8qfMWtK5z3G55ZvJ6QaAC8Wj) {
                        GL11.glTexCoordPointer(2, 5126, 32, 12L);
                    }
                    else {
                        this.36LjzW8U4735L1aKd9KY7BpZ013phF90yKpYq5mbUr9T3gRJ16xzTt6a9tC4.position(3);
                        GL11.glTexCoordPointer(2, 32, this.36LjzW8U4735L1aKd9KY7BpZ013phF90yKpYq5mbUr9T3gRJ16xzTt6a9tC4);
                    }
                    GL11.glEnableClientState(32888);
                }
                if (this.30G40iRXXiCK1i17UV0Jo4EHm8sq0Nfwtjb1169AtgBPwYz7lf7a0L3plKGb) {
                    if (this.19Z5OZ6vOK809lU12yWMZ0tMU5jsQf3upv2v8qfMWtK5z3G55ZvJ6QaAC8Wj) {
                        GL11.glColorPointer(4, 5121, 32, 20L);
                    }
                    else {
                        this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS.position(20);
                        GL11.glColorPointer(4, true, 32, this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS);
                    }
                    GL11.glEnableClientState(32886);
                }
                if (this.6vdCgzA8rZ2YUwrKO1JwQVo4OVXZwzRKPG4IfK04Z5c8HRsXw5T7eCKelmA6) {
                    if (this.19Z5OZ6vOK809lU12yWMZ0tMU5jsQf3upv2v8qfMWtK5z3G55ZvJ6QaAC8Wj) {
                        GL11.glNormalPointer(5120, 32, 24L);
                    }
                    else {
                        this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS.position(24);
                        GL11.glNormalPointer(32, this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS);
                    }
                    GL11.glEnableClientState(32885);
                }
                if (this.19Z5OZ6vOK809lU12yWMZ0tMU5jsQf3upv2v8qfMWtK5z3G55ZvJ6QaAC8Wj) {
                    GL11.glVertexPointer(3, 5126, 32, 0L);
                }
                else {
                    this.36LjzW8U4735L1aKd9KY7BpZ013phF90yKpYq5mbUr9T3gRJ16xzTt6a9tC4.position(0);
                    GL11.glVertexPointer(3, 32, this.36LjzW8U4735L1aKd9KY7BpZ013phF90yKpYq5mbUr9T3gRJ16xzTt6a9tC4);
                }
                GL11.glEnableClientState(32884);
                if (this.9rmS118mpcfaG57K7LEz1DT4CDt1SSdzovBEw21w1sJ4wE9F4gYkG9lOg03k == 7 && 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.08108hq6Y7h9f7GQ6W9Oys09fiT8P9SPmyAnu0Ftv5Oz25C7L9XZMWy08vm4) {
                    GL11.glDrawArrays(4, 0, this.41K7EIHmtvWYaIF7y1yWH2v0VRgYPLSf5QkL5MV5tjd6Pn8N7W1iTJ0hf7VO);
                }
                else {
                    GL11.glDrawArrays(this.9rmS118mpcfaG57K7LEz1DT4CDt1SSdzovBEw21w1sJ4wE9F4gYkG9lOg03k, 0, this.41K7EIHmtvWYaIF7y1yWH2v0VRgYPLSf5QkL5MV5tjd6Pn8N7W1iTJ0hf7VO);
                }
                GL11.glDisableClientState(32884);
                if (this.9i97OpeL9Y07GRwMDGk1i1P9P3Q0i67Edx6sj12v7Ffn3HDpvOd22ta926v1) {
                    GL11.glDisableClientState(32888);
                }
                if (this.30G40iRXXiCK1i17UV0Jo4EHm8sq0Nfwtjb1169AtgBPwYz7lf7a0L3plKGb) {
                    GL11.glDisableClientState(32886);
                }
                if (this.6vdCgzA8rZ2YUwrKO1JwQVo4OVXZwzRKPG4IfK04Z5c8HRsXw5T7eCKelmA6) {
                    GL11.glDisableClientState(32885);
                }
            }
            this.3j04Cz5s77elI7KGfBL2atJrE6h74Q7Kl1a1omh3aGUtNU8dooHOoKhR4UzL();
        }
    }
    
    private void 3j04Cz5s77elI7KGfBL2atJrE6h74Q7Kl1a1omh3aGUtNU8dooHOoKhR4UzL() {
        this.41K7EIHmtvWYaIF7y1yWH2v0VRgYPLSf5QkL5MV5tjd6Pn8N7W1iTJ0hf7VO = 0;
        this.8Y12RYr8Id3Pp51pp5nR9txCJ7qvbJVURXR53e7DszAARqj5j4F5mjLUw3hS.clear();
        this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 = 0;
        this.7lu77zBAC8UvdID9pmI5EDo0SYVT3WkddRktY4dOMQiE818Fe96aS8uBJxb4 = 0;
    }
    
    public void 0xlkp29IV3dqDsM1STBVfF0j99RiS6z898o5R0ZD1U10LYpJKhI0806gUiFW() {
        this.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(false);
    }
    
    public void 6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(final boolean b) {
        this.3G1to8O20W0e2IAxPtN5nia9CixxL69I1Ao9c5u7G19MPeSOCku1IA8g8iV3(7, b);
    }
    
    public void 31G3hr2WJI7y0m0G229iA1zFpQ2OVfNpAb4R1LE0bT9a78f39Q8YIn5T7Tj6(final int n) {
        this.3G1to8O20W0e2IAxPtN5nia9CixxL69I1Ao9c5u7G19MPeSOCku1IA8g8iV3(n, false);
    }
    
    public void 3G1to8O20W0e2IAxPtN5nia9CixxL69I1Ao9c5u7G19MPeSOCku1IA8g8iV3(final int 9rmS118mpcfaG57K7LEz1DT4CDt1SSdzovBEw21w1sJ4wE9F4gYkG9lOg03k, final boolean b) {
        ++this.0MROVDArlUltRNep2c82Yjn0c1YV0K6TX18zu3ch3eo466SKujDB70HFNvjW;
        if (b || 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb != 2 || this.0MROVDArlUltRNep2c82Yjn0c1YV0K6TX18zu3ch3eo466SKujDB70HFNvjW < 150) {
            if (this.23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N) {
                throw new IllegalStateException("Already tesselating!");
            }
            this.23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N = true;
            this.3j04Cz5s77elI7KGfBL2atJrE6h74Q7Kl1a1omh3aGUtNU8dooHOoKhR4UzL();
            this.9rmS118mpcfaG57K7LEz1DT4CDt1SSdzovBEw21w1sJ4wE9F4gYkG9lOg03k = 9rmS118mpcfaG57K7LEz1DT4CDt1SSdzovBEw21w1sJ4wE9F4gYkG9lOg03k;
            this.6vdCgzA8rZ2YUwrKO1JwQVo4OVXZwzRKPG4IfK04Z5c8HRsXw5T7eCKelmA6 = false;
            this.30G40iRXXiCK1i17UV0Jo4EHm8sq0Nfwtjb1169AtgBPwYz7lf7a0L3plKGb = false;
            this.9i97OpeL9Y07GRwMDGk1i1P9P3Q0i67Edx6sj12v7Ffn3HDpvOd22ta926v1 = false;
            this.1JMM0S3fPxcvyUiwCmKeI57Ic0LmVQeB5gz0Oqj2358ebBnvyhZojYP0LS5s = false;
        }
    }
    
    public void 7kNtOjZM19CPRkM929SHRlDo1BWtT89U54V0Xdk4Vkg85pxIlj0LKlNixpdW(final double 965dA6q7a2cC0rhuHy4o1zD8csd2tOuF9o7Br9AZ9mqIwZQk5fLiqQ8n7wP3, final double 8o1IcH8y58HSw56uZO1Kc8WGA55E0prs7nC0VXobl429K1cn3CRyNwy2311Y) {
        this.9i97OpeL9Y07GRwMDGk1i1P9P3Q0i67Edx6sj12v7Ffn3HDpvOd22ta926v1 = true;
        this.965dA6q7a2cC0rhuHy4o1zD8csd2tOuF9o7Br9AZ9mqIwZQk5fLiqQ8n7wP3 = 965dA6q7a2cC0rhuHy4o1zD8csd2tOuF9o7Br9AZ9mqIwZQk5fLiqQ8n7wP3;
        this.8o1IcH8y58HSw56uZO1Kc8WGA55E0prs7nC0VXobl429K1cn3CRyNwy2311Y = 8o1IcH8y58HSw56uZO1Kc8WGA55E0prs7nC0VXobl429K1cn3CRyNwy2311Y;
    }
    
    public void 5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(final float n, final float n2, final float n3) {
        this.8EGYkNCirjGnQ6E7PRS40dz0r5589u50JO7NuCVjzu22kdmWPgj2Stkh3zNl((int)(n * 255.0f), (int)(n2 * 255.0f), (int)(n3 * 255.0f));
    }
    
    public void 5o3NqiN89dd1lqO4U97EwCDWF6Z7M0u2x3alzse9wcJo7oGMyy47h61MTMSu(final float n, final float n2, final float n3, final float n4) {
        this.41i66Ar5P0BZOaedsSriGfKCW6H52J1wtNYvERq3zKn8B27Doygi095yidU1((int)(n * 255.0f), (int)(n2 * 255.0f), (int)(n3 * 255.0f), (int)(n4 * 255.0f));
    }
    
    public void 8EGYkNCirjGnQ6E7PRS40dz0r5589u50JO7NuCVjzu22kdmWPgj2Stkh3zNl(final int n, final int n2, final int n3) {
        this.41i66Ar5P0BZOaedsSriGfKCW6H52J1wtNYvERq3zKn8B27Doygi095yidU1(n, n2, n3, 255);
    }
    
    public void 41i66Ar5P0BZOaedsSriGfKCW6H52J1wtNYvERq3zKn8B27Doygi095yidU1(int n, int n2, int n3, int n4) {
        if (!this.1JMM0S3fPxcvyUiwCmKeI57Ic0LmVQeB5gz0Oqj2358ebBnvyhZojYP0LS5s) {
            if (n > 255) {
                n = 255;
            }
            if (n2 > 255) {
                n2 = 255;
            }
            if (n3 > 255) {
                n3 = 255;
            }
            if (n4 > 255) {
                n4 = 255;
            }
            if (n < 0) {
                n = 0;
            }
            if (n2 < 0) {
                n2 = 0;
            }
            if (n3 < 0) {
                n3 = 0;
            }
            if (n4 < 0) {
                n4 = 0;
            }
            this.30G40iRXXiCK1i17UV0Jo4EHm8sq0Nfwtjb1169AtgBPwYz7lf7a0L3plKGb = true;
            this.81586Uhrr7MGq0vI129SXKq33Vs8vQl4PJd83ougnqatQ53Tw6k207785KV8 = (n4 << 24 | n3 << 16 | n2 << 8 | n);
        }
    }
    
    public void 1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (!this.23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N) {
            return;
        }
        this.7kNtOjZM19CPRkM929SHRlDo1BWtT89U54V0Xdk4Vkg85pxIlj0LKlNixpdW(n4, n5);
        this.8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(n, n2, n3);
    }
    
    public void 8ksXSxMGiAnqOySa7lS2v4F63ZY797utQo8Nzf6TrpnZpViseje8RqTT3fg0(final double n, final double n2, final double n3) {
        if (!this.23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N) {
            return;
        }
        ++this.7lu77zBAC8UvdID9pmI5EDo0SYVT3WkddRktY4dOMQiE818Fe96aS8uBJxb4;
        if (this.9rmS118mpcfaG57K7LEz1DT4CDt1SSdzovBEw21w1sJ4wE9F4gYkG9lOg03k == 7 && 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.08108hq6Y7h9f7GQ6W9Oys09fiT8P9SPmyAnu0Ftv5Oz25C7L9XZMWy08vm4 && this.7lu77zBAC8UvdID9pmI5EDo0SYVT3WkddRktY4dOMQiE818Fe96aS8uBJxb4 % 4 == 0) {
            for (int i = 0; i < 2; ++i) {
                final int n4 = 8 * (3 - i);
                if (this.9i97OpeL9Y07GRwMDGk1i1P9P3Q0i67Edx6sj12v7Ffn3HDpvOd22ta926v1) {
                    this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 3] = this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 - n4 + 3];
                    this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 4] = this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 - n4 + 4];
                }
                if (this.30G40iRXXiCK1i17UV0Jo4EHm8sq0Nfwtjb1169AtgBPwYz7lf7a0L3plKGb) {
                    this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 5] = this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 - n4 + 5];
                }
                this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 0] = this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 - n4 + 0];
                this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 1] = this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 - n4 + 1];
                this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 2] = this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 - n4 + 2];
                ++this.41K7EIHmtvWYaIF7y1yWH2v0VRgYPLSf5QkL5MV5tjd6Pn8N7W1iTJ0hf7VO;
                this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 += 8;
            }
        }
        if (this.9i97OpeL9Y07GRwMDGk1i1P9P3Q0i67Edx6sj12v7Ffn3HDpvOd22ta926v1) {
            this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 3] = Float.floatToRawIntBits((float)this.965dA6q7a2cC0rhuHy4o1zD8csd2tOuF9o7Br9AZ9mqIwZQk5fLiqQ8n7wP3);
            this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 4] = Float.floatToRawIntBits((float)this.8o1IcH8y58HSw56uZO1Kc8WGA55E0prs7nC0VXobl429K1cn3CRyNwy2311Y);
        }
        if (this.30G40iRXXiCK1i17UV0Jo4EHm8sq0Nfwtjb1169AtgBPwYz7lf7a0L3plKGb) {
            this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 5] = this.81586Uhrr7MGq0vI129SXKq33Vs8vQl4PJd83ougnqatQ53Tw6k207785KV8;
        }
        if (this.6vdCgzA8rZ2YUwrKO1JwQVo4OVXZwzRKPG4IfK04Z5c8HRsXw5T7eCKelmA6) {
            this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 6] = this.7KaBAwl3W6436zj40A3d3mw3dtn9gz6dyuf46yc1c9Z9y62EL1iCOh111XRJ;
        }
        this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 0] = Float.floatToRawIntBits((float)(n + this.6H15Et5q485s11tGRTWT8ZfLDSL4EW2bZGBGxc6zq7heam7iNk128kZAog0A));
        this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 1] = Float.floatToRawIntBits((float)(n2 + this.0fx6Agi9mv24gWiudnw102TaV5Y85QJn1KBVhNfB082VCHL5z16q4QJ8JTs7));
        this.7ddrrHZ245UAIl1Mqq61OVTafWi50mP6fEAE4T7X2t3H6nk2ZB4WCp2rLJ9s[this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 + 2] = Float.floatToRawIntBits((float)(n3 + this.7WbAPnE9B9Tazn40R7izK84Y11M3WBDr01a7hp52f1ZV6YPLDGcPd3pih29L));
        this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 += 8;
        ++this.41K7EIHmtvWYaIF7y1yWH2v0VRgYPLSf5QkL5MV5tjd6Pn8N7W1iTJ0hf7VO;
        if (this.41K7EIHmtvWYaIF7y1yWH2v0VRgYPLSf5QkL5MV5tjd6Pn8N7W1iTJ0hf7VO % 4 == 0 && this.5o8a0shhVvr1iM5GC98s7y0YLHAPnx9X7p02NQeDSL9rnWGn34Kndbm3tVk7 >= this.1Fc22qU22IMzC4yb770T4IRSUU3Xo27659D4mS3gsrqo22J34zP5br08083O - 32) {
            this.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
            this.23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N = true;
        }
    }
    
    public void 8v7F8G8g1104wyQ7q86jd6WFsS0S8C9C5G6r53pazN5nIQt79hRlifP4WcDq(final int n) {
        this.8EGYkNCirjGnQ6E7PRS40dz0r5589u50JO7NuCVjzu22kdmWPgj2Stkh3zNl(n >> 16 & 0xFF, n >> 8 & 0xFF, n & 0xFF);
    }
    
    public void 9bHy7fL74IXD4UsqOd2Ex73M73ud0NIomc86hi8cp0K3zOYc25dWZ4o11NzU(final int n, final int n2) {
        this.41i66Ar5P0BZOaedsSriGfKCW6H52J1wtNYvERq3zKn8B27Doygi095yidU1(n >> 16 & 0xFF, n >> 8 & 0xFF, n & 0xFF, n2);
    }
    
    public void 6BQ2V5k5Ihtb1m4QVq2gGji10gT4C35Q55s5o765C0C5uU8U0PW4FfnTpd8c() {
        this.1JMM0S3fPxcvyUiwCmKeI57Ic0LmVQeB5gz0Oqj2358ebBnvyhZojYP0LS5s = true;
    }
    
    public void 2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(final float n, final float n2, final float n3) {
        if (!this.23I49S79ZR6uxuWkj96IC7RhRbF1dm66x8y2Qc4Qfmuyu6cSRZ8PFShC817N) {
            return;
        }
        this.6vdCgzA8rZ2YUwrKO1JwQVo4OVXZwzRKPG4IfK04Z5c8HRsXw5T7eCKelmA6 = true;
        this.7KaBAwl3W6436zj40A3d3mw3dtn9gz6dyuf46yc1c9Z9y62EL1iCOh111XRJ = ((byte)(n * 128.0f) | (byte)(n2 * 127.0f) << 8 | (byte)(n3 * 127.0f) << 16);
    }
    
    public void 1wd7CVzf99DqGVGhZc2NKI20P7o11jyAD2P71momVz0442bF92a1p910MH01(final double 6h15Et5q485s11tGRTWT8ZfLDSL4EW2bZGBGxc6zq7heam7iNk128kZAog0A, final double 0fx6Agi9mv24gWiudnw102TaV5Y85QJn1KBVhNfB082VCHL5z16q4QJ8JTs7, final double 7WbAPnE9B9Tazn40R7izK84Y11M3WBDr01a7hp52f1ZV6YPLDGcPd3pih29L) {
        this.6H15Et5q485s11tGRTWT8ZfLDSL4EW2bZGBGxc6zq7heam7iNk128kZAog0A = 6h15Et5q485s11tGRTWT8ZfLDSL4EW2bZGBGxc6zq7heam7iNk128kZAog0A;
        this.0fx6Agi9mv24gWiudnw102TaV5Y85QJn1KBVhNfB082VCHL5z16q4QJ8JTs7 = 0fx6Agi9mv24gWiudnw102TaV5Y85QJn1KBVhNfB082VCHL5z16q4QJ8JTs7;
        this.7WbAPnE9B9Tazn40R7izK84Y11M3WBDr01a7hp52f1ZV6YPLDGcPd3pih29L = 7WbAPnE9B9Tazn40R7izK84Y11M3WBDr01a7hp52f1ZV6YPLDGcPd3pih29L;
    }
    
    public void 61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(final float n, final float n2, final float n3) {
        this.6H15Et5q485s11tGRTWT8ZfLDSL4EW2bZGBGxc6zq7heam7iNk128kZAog0A += n;
        this.0fx6Agi9mv24gWiudnw102TaV5Y85QJn1KBVhNfB082VCHL5z16q4QJ8JTs7 += n2;
        this.7WbAPnE9B9Tazn40R7izK84Y11M3WBDr01a7hp52f1ZV6YPLDGcPd3pih29L += n3;
    }
    
    static {
        4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.08108hq6Y7h9f7GQ6W9Oys09fiT8P9SPmyAnu0Ftv5Oz25C7L9XZMWy08vm4 = true;
        4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.27w3bD08606gvLMBieKFhVaI53cR77q1z3q342Xth49O4B891KGP3Gm1VIHd = false;
        8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = new 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT(2097152);
    }
}
