// 
// Decompiled by Procyon v0.6.0
// 

public class 8sIzZZdtggOZy5a28bBzHt913EK4kzXMzF91CtP06jkFCC15bAO5RW18Xzeat0nG2V3XB8GgZkwkR1rpha6ct4G3veccWKMJ28HE extends 9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned
{
    public 8sIzZZdtggOZy5a28bBzHt913EK4kzXMzF91CtP06jkFCC15bAO5RW18Xzeat0nG2V3XB8GgZkwkR1rpha6ct4G3veccWKMJ28HE(final int n) {
        super(n);
    }
    
    @Override
    public boolean 0N8Tblq44D45hWE12nPmkuq9sOgtNeAo1rX80E96XFGn8QUj1F1vzKM511HQ(final 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex, final 4C3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4 4c3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4, final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, int n, int n2, int n3, final int n4) {
        if (n4 == 0) {
            --n2;
        }
        if (n4 == 1) {
            ++n2;
        }
        if (n4 == 2) {
            --n3;
        }
        if (n4 == 3) {
            ++n3;
        }
        if (n4 == 4) {
            --n;
        }
        if (n4 == 5) {
            ++n;
        }
        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3) != 0) {
            return false;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.7vfE1ZBd73eYQDtuiOF43q42Z16u3BkPsCcGOfu4RXswiX2wTNf07niBo9j8.26Sw8fe154f6YmvVZ7TYtX7TGoLNJ4WtS6WLf9Z0avd7SUy77UUQ2HeN8LJq(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3)) {
            --43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex.79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp;
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.7vfE1ZBd73eYQDtuiOF43q42Z16u3BkPsCcGOfu4RXswiX2wTNf07niBo9j8.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
        }
        return true;
    }
}
