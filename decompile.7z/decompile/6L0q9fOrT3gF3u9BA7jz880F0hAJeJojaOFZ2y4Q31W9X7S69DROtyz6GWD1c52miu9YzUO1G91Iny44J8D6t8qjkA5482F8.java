import java.util.ArrayList;
import java.nio.FloatBuffer;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.lwjgl.opengl.GL11;
import java.util.List;

// 
// Decompiled by Procyon v0.6.0
// 

public class 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8
{
    private static List<Integer> 270g5qvqO575mD67Au51C4d03251uXK2285BfWO5R49T0eTB85yJSMst3m9G;
    private static List<Integer> 1pIE2lrI0vV9q5qc3HCjiywZgmX3yhZVV9ik2wF08BP6s6xKh9s9SuV0R7GK;
    
    public static synchronized int 138K2t9YH4nAdJ6uDNr4xjMccU3H5E3JlRhhv9Vj028i2gtCBW9T2h1ZHTH4(final int i) {
        final int glGenLists = GL11.glGenLists(i);
        6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.270g5qvqO575mD67Au51C4d03251uXK2285BfWO5R49T0eTB85yJSMst3m9G.add(glGenLists);
        6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.270g5qvqO575mD67Au51C4d03251uXK2285BfWO5R49T0eTB85yJSMst3m9G.add(i);
        return glGenLists;
    }
    
    public static synchronized void 52DHX6qz0xD4W6xAaHcb3Y5lgdft9Ojb4P321YtSO802tDB5S0O0WW0iqaoO(final IntBuffer intBuffer) {
        GL11.glGenTextures(intBuffer);
        for (int i = intBuffer.position(); i < intBuffer.limit(); ++i) {
            6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1pIE2lrI0vV9q5qc3HCjiywZgmX3yhZVV9ik2wF08BP6s6xKh9s9SuV0R7GK.add(intBuffer.get(i));
        }
    }
    
    public static synchronized void 7JohDkGJux3P2XGaTywb0M9P0z06NFl6vkehak9CJ39ES63M8dP6LhM8d59Y() {
        for (int i = 0; i < 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.270g5qvqO575mD67Au51C4d03251uXK2285BfWO5R49T0eTB85yJSMst3m9G.size(); i += 2) {
            GL11.glDeleteLists((int)6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.270g5qvqO575mD67Au51C4d03251uXK2285BfWO5R49T0eTB85yJSMst3m9G.get(i), (int)6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.270g5qvqO575mD67Au51C4d03251uXK2285BfWO5R49T0eTB85yJSMst3m9G.get(i + 1));
        }
        final IntBuffer 1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2 = 1R0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2(6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1pIE2lrI0vV9q5qc3HCjiywZgmX3yhZVV9ik2wF08BP6s6xKh9s9SuV0R7GK.size());
        1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2.flip();
        GL11.glDeleteTextures(1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2);
        for (int j = 0; j < 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1pIE2lrI0vV9q5qc3HCjiywZgmX3yhZVV9ik2wF08BP6s6xKh9s9SuV0R7GK.size(); ++j) {
            1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2.put(6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1pIE2lrI0vV9q5qc3HCjiywZgmX3yhZVV9ik2wF08BP6s6xKh9s9SuV0R7GK.get(j));
        }
        1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2.flip();
        GL11.glDeleteTextures(1r0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2);
        6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.270g5qvqO575mD67Au51C4d03251uXK2285BfWO5R49T0eTB85yJSMst3m9G.clear();
        6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1pIE2lrI0vV9q5qc3HCjiywZgmX3yhZVV9ik2wF08BP6s6xKh9s9SuV0R7GK.clear();
    }
    
    public static synchronized ByteBuffer 91EuTmkXm8xAIAY7j7v6912p5y1QFEu55cAH1a443YZgof0oct95U9qVT07h(final int capacity) {
        return ByteBuffer.allocateDirect(capacity).order(ByteOrder.nativeOrder());
    }
    
    public static IntBuffer 1R0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2(final int n) {
        return 91EuTmkXm8xAIAY7j7v6912p5y1QFEu55cAH1a443YZgof0oct95U9qVT07h(n << 2).asIntBuffer();
    }
    
    public static FloatBuffer 010Npi02jcMInW39XFn5U3SXl11K8DIy9pBIJbF88C9f6zoBKV9MYNjg2p20(final int n) {
        return 91EuTmkXm8xAIAY7j7v6912p5y1QFEu55cAH1a443YZgof0oct95U9qVT07h(n << 2).asFloatBuffer();
    }
    
    static {
        6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.270g5qvqO575mD67Au51C4d03251uXK2285BfWO5R49T0eTB85yJSMst3m9G = new ArrayList<Integer>();
        6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1pIE2lrI0vV9q5qc3HCjiywZgmX3yhZVV9ik2wF08BP6s6xKh9s9SuV0R7GK = new ArrayList<Integer>();
    }
}
