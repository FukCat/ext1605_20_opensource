// 
// Decompiled by Procyon v0.6.0
// 

public class 1qFvFaJPQ2gA31wyzG1Yxe925B35Lom80cg857hRTux5p8Tn3616U67uO9fLna007Iu4yVgw8ImC5I3bhW8xn5S6O15G
{
    public float 6h838yup4LqBOQpO9693L6DsQFdnLTrC2doFIl439Cb5aUy0Epb4pkO0k6v2;
    
    public 1qFvFaJPQ2gA31wyzG1Yxe925B35Lom80cg857hRTux5p8Tn3616U67uO9fLna007Iu4yVgw8ImC5I3bhW8xn5S6O15G(final float 6h838yup4LqBOQpO9693L6DsQFdnLTrC2doFIl439Cb5aUy0Epb4pkO0k6v2) {
        this.6h838yup4LqBOQpO9693L6DsQFdnLTrC2doFIl439Cb5aUy0Epb4pkO0k6v2 = 6h838yup4LqBOQpO9693L6DsQFdnLTrC2doFIl439Cb5aUy0Epb4pkO0k6v2;
    }
}
