import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 33UcR0Vi73kFY3n07FJBn8ELrwADWuC7oef13t42JFl1p5q3E1H5LsBbwPu2jI4j10EqY469Dff53580gF9NBC6a0z4BT8e2ne9 extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 8Ifw08VLZvyK3e6Y8H8v080aJ39Fs9lI2rWc8NiRez8Crtx1oGkW5f1NEDLc;
    public 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex[] 9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ;
    
    public 33UcR0Vi73kFY3n07FJBn8ELrwADWuC7oef13t42JFl1p5q3E1H5LsBbwPu2jI4j10EqY469Dff53580gF9NBC6a0z4BT8e2ne9() {
    }
    
    public 33UcR0Vi73kFY3n07FJBn8ELrwADWuC7oef13t42JFl1p5q3E1H5LsBbwPu2jI4j10EqY469Dff53580gF9NBC6a0z4BT8e2ne9(final int 8Ifw08VLZvyK3e6Y8H8v080aJ39Fs9lI2rWc8NiRez8Crtx1oGkW5f1NEDLc, final 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex[] array) {
        this.8Ifw08VLZvyK3e6Y8H8v080aJ39Fs9lI2rWc8NiRez8Crtx1oGkW5f1NEDLc = 8Ifw08VLZvyK3e6Y8H8v080aJ39Fs9lI2rWc8NiRez8Crtx1oGkW5f1NEDLc;
        this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ = new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex[array.length];
        for (int i = 0; i < this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ.length; ++i) {
            this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ[i] = ((array[i] == null) ? null : array[i].1s6dBsLorAuY082X0atuicWh7fsSt35sTgoLDzo0J3Smd2qJPv75GcoaNP1h());
        }
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.8Ifw08VLZvyK3e6Y8H8v080aJ39Fs9lI2rWc8NiRez8Crtx1oGkW5f1NEDLc = dataInputStream.readInt();
        final short short1 = dataInputStream.readShort();
        this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ = new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex[short1];
        for (short n = 0; n < short1; ++n) {
            final int int1 = dataInputStream.readInt();
            if (int1 >= 0) {
                this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ[n] = new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(int1, dataInputStream.readByte(), dataInputStream.readShort());
            }
        }
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.8Ifw08VLZvyK3e6Y8H8v080aJ39Fs9lI2rWc8NiRez8Crtx1oGkW5f1NEDLc);
        dataOutputStream.writeShort(this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ.length);
        for (int i = 0; i < this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ.length; ++i) {
            if (this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ[i] == null) {
                dataOutputStream.writeInt(-1);
            }
            else {
                dataOutputStream.writeInt(this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ[i].5P1b49yjUtk40LxWp0cULx98QzgbH9k0zk5GX23wZQUAD5Z5i99U0u0h97L4);
                dataOutputStream.writeByte((byte)this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ[i].79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp);
                dataOutputStream.writeShort((short)this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ[i].5m97PZ4nQX8K45ZbdNs52zVsERp3LlEYIq0aSSyrFRYCXVItCeCQ44x988l8);
            }
        }
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.192O1578G29q01S7L6vmx6Ry2K7qYAVJSCd87heje82vgUo6H4iIOAN9s95K(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 6 + this.9w4fWBVaaIIHG1263Ted2k0w6n38A361qa67yhAutHD0k1LQVHAA1gQ0OswZ.length * 7;
    }
}
