import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.List;

// 
// Decompiled by Procyon v0.6.0
// 

public abstract class 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl
{
    public static final int 7nMyWcWuvyDrrL2K3w683NnXZ4R3413RLoh7xKe4GtYQ3RfS4Em5W0Vnp6dm = 20;
    public static final int 3wJsWrs47vvM7njdJxvcKAYAVN96D0S6RQVL85Tb51qa3Ec8rMKLwe9C09b3 = 46;
    public final Layer 68BA5YA20R63Jvx5mf2f0QY9F5CI712o6GIr96is6zFAg89BWvpL45J8n44Q;
    public final double 2Cj4T23zTjZ8P2pnru6eB2r3b229GaFgJC22W2tht5x24XTX4BiGdn4Y6xsC;
    public final double 2H7oEc5LBpn2wimwB5bXR08uskktpPvU1435c3fQ20uGKpkjHG1r9q5GXKU2;
    private static final List<5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl> 1gZRfAv6ZC2FpE1cZQrLBSUL7z3y4D60581LY6H69NcHdHE89jdxH2evUizQ;
    
    public 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl(final double 2Cj4T23zTjZ8P2pnru6eB2r3b229GaFgJC22W2tht5x24XTX4BiGdn4Y6xsC, final double 2h7oEc5LBpn2wimwB5bXR08uskktpPvU1435c3fQ20uGKpkjHG1r9q5GXKU2, final Layer 68BA5YA20R63Jvx5mf2f0QY9F5CI712o6GIr96is6zFAg89BWvpL45J8n44Q) {
        this.2Cj4T23zTjZ8P2pnru6eB2r3b229GaFgJC22W2tht5x24XTX4BiGdn4Y6xsC = 2Cj4T23zTjZ8P2pnru6eB2r3b229GaFgJC22W2tht5x24XTX4BiGdn4Y6xsC;
        this.2H7oEc5LBpn2wimwB5bXR08uskktpPvU1435c3fQ20uGKpkjHG1r9q5GXKU2 = 2h7oEc5LBpn2wimwB5bXR08uskktpPvU1435c3fQ20uGKpkjHG1r9q5GXKU2;
        this.68BA5YA20R63Jvx5mf2f0QY9F5CI712o6GIr96is6zFAg89BWvpL45J8n44Q = 68BA5YA20R63Jvx5mf2f0QY9F5CI712o6GIr96is6zFAg89BWvpL45J8n44Q;
    }
    
    public abstract boolean 84EZjwmgfVpn5brk96GnU3Eit81Yc6Xxm4lTPdVKUWyphKxl38Uh4dg8VF3T(final Random p0, final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY p1, final int p2, final int p3);
    
    public abstract void 0C8cKMHZGkSA22DGYztFv5857z0O34nRumUNAm59CrgBrFnKV5bq3guXEYB5(final Random p0);
    
    public int 8WfOXonA2bRS7hUpHd7sbe7k20yqj7N6OH13GX3XXy71V13Eva115wQwe47C() {
        return -1;
    }
    
    public static void 980N8050sF1v352476qOc8mfF92W7H1QatonEr6b738Sxi3vQSvf2K98637h(final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl) {
        5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.1gZRfAv6ZC2FpE1cZQrLBSUL7z3y4D60581LY6H69NcHdHE89jdxH2evUizQ.add(5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl);
    }
    
    public static 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 2dCM22Pc7rV0IQo46JM3ja84x9AHCGNPeSCDVFoTi3969B8hv2sM7nr6o61r(final double n, final double n2, final Layer layer) {
        double n3 = Double.MAX_VALUE;
        5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl = null;
        for (final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl2 : 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.1gZRfAv6ZC2FpE1cZQrLBSUL7z3y4D60581LY6H69NcHdHE89jdxH2evUizQ) {
            final double n4 = Math.abs(n - 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl2.2Cj4T23zTjZ8P2pnru6eB2r3b229GaFgJC22W2tht5x24XTX4BiGdn4Y6xsC) + Math.abs(n2 - 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl2.2H7oEc5LBpn2wimwB5bXR08uskktpPvU1435c3fQ20uGKpkjHG1r9q5GXKU2);
            if (n3 > n4) {
                n3 = n4;
                5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl = 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl2;
            }
        }
        return 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl;
    }
    
    public static void 9oD74IB2ktSl4rKYyq5be1pnGiKcijsDk38XO5US1yU1RgWUN9KZuVmeM2HO() {
        980N8050sF1v352476qOc8mfF92W7H1QatonEr6b738Sxi3vQSvf2K98637h(new 02Ok4wJjPXX4t0tf37acGm9C89LkXqZeYh5VGrnuQXVJHdavKu584xzsCuG14o6DdwF5wF0i2h99448Tl6ZDKZ5rwjP91205(0.2, 0.2, Layer.826lh5eslCWNLgtluhQvESvIz0u4cye5zctbuc7h93L41Q8yxBAB2u3EI3R7, 0));
        980N8050sF1v352476qOc8mfF92W7H1QatonEr6b738Sxi3vQSvf2K98637h(new 02Ok4wJjPXX4t0tf37acGm9C89LkXqZeYh5VGrnuQXVJHdavKu584xzsCuG14o6DdwF5wF0i2h99448Tl6ZDKZ5rwjP91205(0.3, 0.3, Layer.826lh5eslCWNLgtluhQvESvIz0u4cye5zctbuc7h93L41Q8yxBAB2u3EI3R7, 1));
        980N8050sF1v352476qOc8mfF92W7H1QatonEr6b738Sxi3vQSvf2K98637h(new 02Ok4wJjPXX4t0tf37acGm9C89LkXqZeYh5VGrnuQXVJHdavKu584xzsCuG14o6DdwF5wF0i2h99448Tl6ZDKZ5rwjP91205(0.4, 0.3, Layer.826lh5eslCWNLgtluhQvESvIz0u4cye5zctbuc7h93L41Q8yxBAB2u3EI3R7, 2));
        980N8050sF1v352476qOc8mfF92W7H1QatonEr6b738Sxi3vQSvf2K98637h(new 02Ok4wJjPXX4t0tf37acGm9C89LkXqZeYh5VGrnuQXVJHdavKu584xzsCuG14o6DdwF5wF0i2h99448Tl6ZDKZ5rwjP91205(0.2, 0.2, Layer.68k0FnC73Sz9s5z9rlrbupsw9QB4dKbktN8hyuk0W1u1Uzdgb8N09zhqZ4O7, 0));
        980N8050sF1v352476qOc8mfF92W7H1QatonEr6b738Sxi3vQSvf2K98637h(new 02Ok4wJjPXX4t0tf37acGm9C89LkXqZeYh5VGrnuQXVJHdavKu584xzsCuG14o6DdwF5wF0i2h99448Tl6ZDKZ5rwjP91205(0.1, 0.3, Layer.0Y2ZHLT6D3xX3327P6f983wP7du5jnFbwOYEA5Aq1T49UL6r6vy5SVm59459, 0));
        980N8050sF1v352476qOc8mfF92W7H1QatonEr6b738Sxi3vQSvf2K98637h(new 6OY4O5j6qZ1Bokx61wj3CUvRxSkmvkk5V3o0uw3d9330IfMzxsFtEaP487q85bnT2r239zO4l53xbYt2DF000A79v6hMM4175y4(0.15, 0.4, Layer.0Y2ZHLT6D3xX3327P6f983wP7du5jnFbwOYEA5Aq1T49UL6r6vy5SVm59459));
    }
    
    public static void 9JNUbhbk292KcCQ94Cqr7mT8uN1dJGymij9j6488Z69GSfe4353u9Nj2PWn2(final Random random) {
        final Iterator<5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl> iterator = 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.1gZRfAv6ZC2FpE1cZQrLBSUL7z3y4D60581LY6H69NcHdHE89jdxH2evUizQ.iterator();
        while (iterator.hasNext()) {
            iterator.next().0C8cKMHZGkSA22DGYztFv5857z0O34nRumUNAm59CrgBrFnKV5bq3guXEYB5(random);
        }
    }
    
    static {
        1gZRfAv6ZC2FpE1cZQrLBSUL7z3y4D60581LY6H69NcHdHE89jdxH2evUizQ = new ArrayList<5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl>();
    }
    
    public enum Layer
    {
        826lh5eslCWNLgtluhQvESvIz0u4cye5zctbuc7h93L41Q8yxBAB2u3EI3R7, 
        68k0FnC73Sz9s5z9rlrbupsw9QB4dKbktN8hyuk0W1u1Uzdgb8N09zhqZ4O7, 
        0Y2ZHLT6D3xX3327P6f983wP7du5jnFbwOYEA5Aq1T49UL6r6vy5SVm59459;
        
        private static final /* synthetic */ Layer[] 3QrIHxRx2jG15e9tuS5r0965HnOUaDkLsjOAqP48GPYU5wQjQ45qYyYp6i39;
        
        public static Layer[] 687pFhoaPBF6M4hBc653Q576K1D17054nP32W3591E5Q2aYGU1m5Kdc9N1JW() {
            return Layer.3QrIHxRx2jG15e9tuS5r0965HnOUaDkLsjOAqP48GPYU5wQjQ45qYyYp6i39.clone();
        }
        
        public static Layer 0ZK60yIEWC7x49spI4Px0g54M5La7Pn2X3qKvS4J166Fmb2htc02is7LQRlq(final String name) {
            return Enum.valueOf(Layer.class, name);
        }
        
        private static /* synthetic */ Layer[] 7w4698oPqL58Fjaf1uMTfEAgGG0uN10YP758eR09r2wx2dSrl77je7cUNid6() {
            return new Layer[] { Layer.826lh5eslCWNLgtluhQvESvIz0u4cye5zctbuc7h93L41Q8yxBAB2u3EI3R7, Layer.68k0FnC73Sz9s5z9rlrbupsw9QB4dKbktN8hyuk0W1u1Uzdgb8N09zhqZ4O7, Layer.0Y2ZHLT6D3xX3327P6f983wP7du5jnFbwOYEA5Aq1T49UL6r6vy5SVm59459 };
        }
        
        static {
            3QrIHxRx2jG15e9tuS5r0965HnOUaDkLsjOAqP48GPYU5wQjQ45qYyYp6i39 = 7w4698oPqL58Fjaf1uMTfEAgGG0uN10YP758eR09r2wx2dSrl77je7cUNid6();
        }
    }
}
