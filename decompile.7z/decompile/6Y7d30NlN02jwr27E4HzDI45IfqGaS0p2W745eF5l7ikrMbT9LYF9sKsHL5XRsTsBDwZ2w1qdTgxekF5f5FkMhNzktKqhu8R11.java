import java.util.Iterator;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Random;
import java.util.List;

// 
// Decompiled by Procyon v0.6.0
// 

public class 6Y7d30NlN02jwr27E4HzDI45IfqGaS0p2W745eF5l7ikrMbT9LYF9sKsHL5XRsTsBDwZ2w1qdTgxekF5f5FkMhNzktKqhu8R11
{
    public static final int 4w74pvYXa7sHUyUKm9RwA7R6dYS5l137T0iovPx6qXkyp4A654X9oYDIIiEs = 30;
    private final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 14Wpy36M5dtsKprEKf2Y4vtHO5KoBlcFwIcPD7Q7b2Z320Z530icn8P8OKm8;
    private final List<85o5i1pQ47Jgrr5fjYiAfhBQZR74WYjx5pS86q5W9i4R7iKOeL44hE4Is8H8I6WAFQU4ungwD04qtmtpEhBFpDwzZZ01q7xby25> 8j1Q760kpqsxwN9XC05XRk5NhDyNDLOEU5eR3ka6jY604e164oMNtSBfU03n;
    
    public static int 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65(final int n) {
        return (n >= 0) ? (n * 16) : (n * 16 + 15);
    }
    
    public static boolean 030X7YBFIyq838PzbbohW0DU604Ufm6fU5P2pk1l46RcvZNy7l32uebe2559(final int n, final int n2, final int n3, final int n4) {
        final int 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65 = 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65(n);
        final int 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg66 = 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65(n2);
        return n3 <= 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65 && n4 <= 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg66 && n3 > 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65 - 16 && n4 > 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg66 - 16;
    }
    
    public 6Y7d30NlN02jwr27E4HzDI45IfqGaS0p2W745eF5l7ikrMbT9LYF9sKsHL5XRsTsBDwZ2w1qdTgxekF5f5FkMhNzktKqhu8R11(final Random random, final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 14Wpy36M5dtsKprEKf2Y4vtHO5KoBlcFwIcPD7Q7b2Z320Z530icn8P8OKm8) {
        System.currentTimeMillis();
        this.8j1Q760kpqsxwN9XC05XRk5NhDyNDLOEU5eR3ka6jY604e164oMNtSBfU03n = new ArrayList<85o5i1pQ47Jgrr5fjYiAfhBQZR74WYjx5pS86q5W9i4R7iKOeL44hE4Is8H8I6WAFQU4ungwD04qtmtpEhBFpDwzZZ01q7xby25>();
        this.14Wpy36M5dtsKprEKf2Y4vtHO5KoBlcFwIcPD7Q7b2Z320Z530icn8P8OKm8 = 14Wpy36M5dtsKprEKf2Y4vtHO5KoBlcFwIcPD7Q7b2Z320Z530icn8P8OKm8;
        final int[] a = new int[900];
        Arrays.fill(a, 0);
        int n = 0;
        boolean b;
        do {
            b = false;
            for (int i = 0; i < a.length; ++i) {
                if (a[i] == 0) {
                    final int n2 = i % 30;
                    final int n3 = i / 30;
                    final 85o5i1pQ47Jgrr5fjYiAfhBQZR74WYjx5pS86q5W9i4R7iKOeL44hE4Is8H8I6WAFQU4ungwD04qtmtpEhBFpDwzZZ01q7xby25 510xxO0w79ZkBWq2cMUy7UUel9V7981Kqlz3lT2pU4RuFo2N2qx8G3dE8izE = 85o5i1pQ47Jgrr5fjYiAfhBQZR74WYjx5pS86q5W9i4R7iKOeL44hE4Is8H8I6WAFQU4ungwD04qtmtpEhBFpDwzZZ01q7xby25.510xxO0w79ZkBWq2cMUy7UUel9V7981Kqlz3lT2pU4RuFo2N2qx8G3dE8izE(random, new 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3(06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65(14Wpy36M5dtsKprEKf2Y4vtHO5KoBlcFwIcPD7Q7b2Z320Z530icn8P8OKm8.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM), 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65(14Wpy36M5dtsKprEKf2Y4vtHO5KoBlcFwIcPD7Q7b2Z320Z530icn8P8OKm8.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174)).43cW0BG7D6e15UgFxhYIhnbmvR9R0GKm0lZwapr276d869pJ379mWCc345jT((n2 - 15) * 14, (n3 - 15) * 14));
                    final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 1xd49rMZ7tPLtP0CWc3LgGLFv6JSjO4Q2B8uBaPHCRWAe6cbTx3935ua6FcY = 510xxO0w79ZkBWq2cMUy7UUel9V7981Kqlz3lT2pU4RuFo2N2qx8G3dE8izE.1XD49rMZ7tPLtP0CWc3LgGLFv6JSjO4Q2B8uBaPHCRWAe6cbTx3935ua6FcY();
                    boolean b2 = true;
                Label_0220:
                    for (int j = 0; j < 1xd49rMZ7tPLtP0CWc3LgGLFv6JSjO4Q2B8uBaPHCRWAe6cbTx3935ua6FcY.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM; ++j) {
                        for (int k = 0; k < 1xd49rMZ7tPLtP0CWc3LgGLFv6JSjO4Q2B8uBaPHCRWAe6cbTx3935ua6FcY.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174; ++k) {
                            if (n2 + j >= 30 || n3 + k >= 30 || a[n2 + j + (n3 + k) * 30] != 0) {
                                b2 = false;
                                break Label_0220;
                            }
                        }
                    }
                    if (!b2) {
                        b = true;
                    }
                    else {
                        ++n;
                        this.8j1Q760kpqsxwN9XC05XRk5NhDyNDLOEU5eR3ka6jY604e164oMNtSBfU03n.add(510xxO0w79ZkBWq2cMUy7UUel9V7981Kqlz3lT2pU4RuFo2N2qx8G3dE8izE);
                        for (int l = 0; l < 1xd49rMZ7tPLtP0CWc3LgGLFv6JSjO4Q2B8uBaPHCRWAe6cbTx3935ua6FcY.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM; ++l) {
                            for (int n4 = 0; n4 < 1xd49rMZ7tPLtP0CWc3LgGLFv6JSjO4Q2B8uBaPHCRWAe6cbTx3935ua6FcY.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174; ++n4) {
                                a[n2 + l + (n3 + n4) * 30] = n;
                            }
                        }
                    }
                }
            }
        } while (b);
    }
    
    public void 9T6PaAkH5j21yXgxCz0Ky7LkSL657x54i6JmNXG0p2PDYoP5H2HS678A5k0f(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2) {
        final ArrayList list = new ArrayList();
        for (final 85o5i1pQ47Jgrr5fjYiAfhBQZR74WYjx5pS86q5W9i4R7iKOeL44hE4Is8H8I6WAFQU4ungwD04qtmtpEhBFpDwzZZ01q7xby25 85o5i1pQ47Jgrr5fjYiAfhBQZR74WYjx5pS86q5W9i4R7iKOeL44hE4Is8H8I6WAFQU4ungwD04qtmtpEhBFpDwzZZ01q7xby25 : this.8j1Q760kpqsxwN9XC05XRk5NhDyNDLOEU5eR3ka6jY604e164oMNtSBfU03n) {
            final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 770WwnPt75L6J8UguFyXX1ITRtqTVRYMUSrCy1V0cX98wO01Qc5EpwKsvcM9 = 85o5i1pQ47Jgrr5fjYiAfhBQZR74WYjx5pS86q5W9i4R7iKOeL44hE4Is8H8I6WAFQU4ungwD04qtmtpEhBFpDwzZZ01q7xby25.770WwnPt75L6J8UguFyXX1ITRtqTVRYMUSrCy1V0cX98wO01Qc5EpwKsvcM9();
            final int n3 = 770WwnPt75L6J8UguFyXX1ITRtqTVRYMUSrCy1V0cX98wO01Qc5EpwKsvcM9.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM - 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65(n);
            final int n4 = 770WwnPt75L6J8UguFyXX1ITRtqTVRYMUSrCy1V0cX98wO01Qc5EpwKsvcM9.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174 - 06Gg7YSs1BbiPOukbWMG1FpX9uQjn5167srQmT4e4Tz1P27uh1V14O20Xg65(n2);
            if (n3 > 0) {
                continue;
            }
            if (n4 > 0) {
                continue;
            }
            if (n3 < -29) {
                continue;
            }
            if (n4 < -29) {
                continue;
            }
            if (!85o5i1pQ47Jgrr5fjYiAfhBQZR74WYjx5pS86q5W9i4R7iKOeL44hE4Is8H8I6WAFQU4ungwD04qtmtpEhBFpDwzZZ01q7xby25.5FEqwXoAtY7AI1e7tv5jsIS2I33Pxp03S2iKy3TijST5d36Zh4iU6YGR536H(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2)) {
                continue;
            }
            list.add(85o5i1pQ47Jgrr5fjYiAfhBQZR74WYjx5pS86q5W9i4R7iKOeL44hE4Is8H8I6WAFQU4ungwD04qtmtpEhBFpDwzZZ01q7xby25);
        }
        final Iterator iterator2 = list.iterator();
        while (iterator2.hasNext()) {
            this.8j1Q760kpqsxwN9XC05XRk5NhDyNDLOEU5eR3ka6jY604e164oMNtSBfU03n.remove(iterator2.next());
        }
    }
}
