import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 5p65E5EQxW2cHwwbF100KXleCeBty25uTxNqum4nmlh73rWmme20JB3J6M08W0v8g2U4IHTutG0I727LOi0S7Z0UpG6A571 extends 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC
{
    public 5p65E5EQxW2cHwwbF100KXleCeBty25uTxNqum4nmlh73rWmme20JB3J6M08W0v8g2U4IHTutG0I727LOi0S7Z0UpG6A571(final int n, final int n2) {
        super(n, n2, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.9dtjqFv0f956RuAw34mwNhJBUk0uapEph542x4Ja3850W3hAtmAD1DJ4tXJp);
    }
    
    @Override
    public int 9hFrB67UQ3xIdu153AXx7FYrppLysZW3gpO0hVR27pm9IQlKb2jF25i9DO3e(final int n, final Random random) {
        return 9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.3yHODVF5HKU8wK6DneurWvOi0dDio98dqaEFv6F9sj5aoN6MVUeY46xxWG6U.016D6B0WzYa1oAf8GVzuN3e04Nkxq5CzkT5YVZhj2l5H8LW20C9lkr0R7pc5;
    }
    
    @Override
    public int 6M14lZVXL6xs4lKY6vj11vAQ2E9U9ZDOF0Nh9aCHYAlz8F6Pfx930Z7gxmzf(final Random random) {
        return 4;
    }
}
