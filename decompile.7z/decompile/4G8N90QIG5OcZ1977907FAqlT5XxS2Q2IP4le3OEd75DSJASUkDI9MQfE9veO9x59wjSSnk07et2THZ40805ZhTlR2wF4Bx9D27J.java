// 
// Decompiled by Procyon v0.6.0
// 

public class 4G8N90QIG5OcZ1977907FAqlT5XxS2Q2IP4le3OEd75DSJASUkDI9MQfE9veO9x59wjSSnk07et2THZ40805ZhTlR2wF4Bx9D27J
{
    public final String 0prnTjMonFh7pQwe9f90uytUWw6L08okC0p6777lodkt01v84lGuC69c7DJ3;
    public final float 8mP76MNJSrqK6O90Et6rFsiQ7r8Szmt1r7A4wfyCuL9We1100v8M80q815ht;
    public final float 2wD52T0hI4BwK4K798E3VgS09lUWMWtkglzdLd8st8ns4J6f9IFYlRkImkAV;
    
    public 4G8N90QIG5OcZ1977907FAqlT5XxS2Q2IP4le3OEd75DSJASUkDI9MQfE9veO9x59wjSSnk07et2THZ40805ZhTlR2wF4Bx9D27J(final String 0prnTjMonFh7pQwe9f90uytUWw6L08okC0p6777lodkt01v84lGuC69c7DJ3, final float 8mP76MNJSrqK6O90Et6rFsiQ7r8Szmt1r7A4wfyCuL9We1100v8M80q815ht, final float 2wD52T0hI4BwK4K798E3VgS09lUWMWtkglzdLd8st8ns4J6f9IFYlRkImkAV) {
        this.0prnTjMonFh7pQwe9f90uytUWw6L08okC0p6777lodkt01v84lGuC69c7DJ3 = 0prnTjMonFh7pQwe9f90uytUWw6L08okC0p6777lodkt01v84lGuC69c7DJ3;
        this.8mP76MNJSrqK6O90Et6rFsiQ7r8Szmt1r7A4wfyCuL9We1100v8M80q815ht = 8mP76MNJSrqK6O90Et6rFsiQ7r8Szmt1r7A4wfyCuL9We1100v8M80q815ht;
        this.2wD52T0hI4BwK4K798E3VgS09lUWMWtkglzdLd8st8ns4J6f9IFYlRkImkAV = 2wD52T0hI4BwK4K798E3VgS09lUWMWtkglzdLd8st8ns4J6f9IFYlRkImkAV;
    }
    
    public float 56Cmh5usCj5YB8D3FGplJ3o1nu7R5K3H4Rr09d7ZMy8L44bRO51zDcMLA4a4() {
        return this.8mP76MNJSrqK6O90Et6rFsiQ7r8Szmt1r7A4wfyCuL9We1100v8M80q815ht;
    }
    
    public float 6P71o9AG4864rNxZ32OpZCHV1IIx0FuZt0gxcu2Pyji3O88k29S8CW1L9J74() {
        return this.2wD52T0hI4BwK4K798E3VgS09lUWMWtkglzdLd8st8ns4J6f9IFYlRkImkAV;
    }
    
    public String 4ysb026Q69QQ1Y451ML4JO19j79dea8A1yeC6Ff4otUgu8OmJfVTcf6gMhf7() {
        return "step." + this.0prnTjMonFh7pQwe9f90uytUWw6L08okC0p6777lodkt01v84lGuC69c7DJ3;
    }
    
    public String 45BNyY92JjZT86C7Qg34iuqt8O5k371uD6J4L0Y445697R9H7PQ0sePDz0LA() {
        return "step." + this.0prnTjMonFh7pQwe9f90uytUWw6L08okC0p6777lodkt01v84lGuC69c7DJ3;
    }
}
