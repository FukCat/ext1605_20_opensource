import java.io.IOException;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 186HcA0xfWyJHy51l8zNHH6Z733323ySlcudL6KQaI2PuY822Z8wrAd60k4Q36yjnwyT43sRHr6e63IXdYtsY4qZ5ydwmz80PE6 extends 2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38
{
    protected float[] 65GJsDsf35RDT23h2W40w9NZ31N99W5SByk8ZMfX963bLwbtDgGDh24dtI63;
    protected float[] 0NxcopemO70jL34we5M8hFBW433LB5MlfY6XqDrFKeV837wP8ukap9l7lj95;
    private Minecraft 96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w;
    private int[] 2p0Jsi09dNrDW5537eiaKf4N70NPgn3mvZ5B1779s5UQb7RdYMNHfxpv930E;
    private double 3XWs3nd7r9eNFEIpXUPF79HUJFE2U9ZX8mbxccz1v2cRh435E38y2X6dMBgM;
    private double 3Z98T131bQxUtTNFXAA51SWp4j5aQ9ERV1365GwXppgj7BVcdlC8T66q6CvC;
    
    public 186HcA0xfWyJHy51l8zNHH6Z733323ySlcudL6KQaI2PuY822Z8wrAd60k4Q36yjnwyT43sRHr6e63IXdYtsY4qZ5ydwmz80PE6(final Minecraft 96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w) {
        super(9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.6Wx8W2L6mpK9g41UETiDx4q5mz7PDn78ANw0zM569b4Q4E3Ze1rTc06SdEiX.7vBu6Dsy3np34d5koU2iMA04fL6X6hpRDN2LFQZTNtP80S2uVBbfOwmLZ6dV(null));
        this.65GJsDsf35RDT23h2W40w9NZ31N99W5SByk8ZMfX963bLwbtDgGDh24dtI63 = new float[320];
        this.0NxcopemO70jL34we5M8hFBW433LB5MlfY6XqDrFKeV837wP8ukap9l7lj95 = new float[320];
        this.2p0Jsi09dNrDW5537eiaKf4N70NPgn3mvZ5B1779s5UQb7RdYMNHfxpv930E = new int[256];
        this.96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w = 96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w;
        this.08vPf4y1fcDlGu3p83ZMwzDHz714NlB97oIRyuiN2vIzQg1EnVH33cVs8sKb = 1;
        try {
            ImageIO.read(1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.9P3TY758VM8951Z7q70WD5qYdKqLdB22jUqQNi8u6rFBU4uZnFfpCw0XU82v("/gui/items.png")).getRGB(this.5WM1LGW9GUgzeD24G7fCa6oIAGn7KuReXrb1632gE1jDa8S25J3Ulv2S0N6V % 16 * 16, this.5WM1LGW9GUgzeD24G7fCa6oIAGn7KuReXrb1632gE1jDa8S25J3Ulv2S0N6V / 16 * 16, 16, 16, this.2p0Jsi09dNrDW5537eiaKf4N70NPgn3mvZ5B1779s5UQb7RdYMNHfxpv930E, 0, 16);
        }
        catch (final IOException ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public void 88ejD45Q8LEgM39W23b9PS53H72qux6CoqBH3EmIU8XRRLm3446Q9e3d4IQv() {
        for (int i = 0; i < 256; ++i) {
            final int n = this.2p0Jsi09dNrDW5537eiaKf4N70NPgn3mvZ5B1779s5UQb7RdYMNHfxpv930E[i] >> 24 & 0xFF;
            int n2 = this.2p0Jsi09dNrDW5537eiaKf4N70NPgn3mvZ5B1779s5UQb7RdYMNHfxpv930E[i] >> 16 & 0xFF;
            int n3 = this.2p0Jsi09dNrDW5537eiaKf4N70NPgn3mvZ5B1779s5UQb7RdYMNHfxpv930E[i] >> 8 & 0xFF;
            int n4 = this.2p0Jsi09dNrDW5537eiaKf4N70NPgn3mvZ5B1779s5UQb7RdYMNHfxpv930E[i] >> 0 & 0xFF;
            if (this.06P3mXenpD5L0FS19r771z79X4G6ToUmlYYq950W8EH6ukeiX4WQd6Wqr2uA) {
                final int n5 = (n2 * 30 + n3 * 59 + n4 * 11) / 100;
                final int n6 = (n2 * 30 + n3 * 70) / 100;
                final int n7 = (n2 * 30 + n4 * 70) / 100;
                n2 = n5;
                n3 = n6;
                n4 = n7;
            }
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[i * 4 + 0] = (byte)n2;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[i * 4 + 1] = (byte)n3;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[i * 4 + 2] = (byte)n4;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[i * 4 + 3] = (byte)n;
        }
        double n8 = 0.0;
        if (this.96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w.8D1HRxTuOIR0Ym42loo9d0NS42Qp45kaXeR154x9Ri712QaegW563ZU96VM0 != null && this.96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w.8m10eD4o1nI4Yvt03uA2QMfUSGy4I2qp5qLsfQsDidFNBgCWTWjd2T5zayR5 != null) {
            n8 = (this.96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w.8m10eD4o1nI4Yvt03uA2QMfUSGy4I2qp5qLsfQsDidFNBgCWTWjd2T5zayR5.54gxMBF221TVjt0P0C9w3wC1bA39cSBLUECI0nEyW1pzgfvT49oZs1R0HUy8 - 90.0f) * 3.141592653589793 / 180.0 - Math.atan2(this.96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w.8D1HRxTuOIR0Ym42loo9d0NS42Qp45kaXeR154x9Ri712QaegW563ZU96VM0.454PK5YFHgg4V8nk6oaJ64rpp4Dh0q7eMb5wMYTYAHf3McQ84p854xN8i0y6 - this.96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w.8m10eD4o1nI4Yvt03uA2QMfUSGy4I2qp5qLsfQsDidFNBgCWTWjd2T5zayR5.68900A16KVY7SEiF2YQ3hM0ZG79rACr5q730w1yAkf6oUgPjo4rVq892edT0, this.96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w.8D1HRxTuOIR0Ym42loo9d0NS42Qp45kaXeR154x9Ri712QaegW563ZU96VM0.01d2ssfM8LK4kLnkL0u9ml4w6nuErqGh8449WV70OP842UK6VcDJe9tV4Grf - this.96OHMbO7v62ynEcSIPGUp44GdOP2l73Mn8DeAH2Rv67241yj2Wn6Uk86Xk0w.8m10eD4o1nI4Yvt03uA2QMfUSGy4I2qp5qLsfQsDidFNBgCWTWjd2T5zayR5.497Ny8ieOOsR16Sz600331Tse4JQLpB9t68N055JeLhS6p82x0V6dPP7m43N);
        }
        double n9;
        for (n9 = n8 - this.3XWs3nd7r9eNFEIpXUPF79HUJFE2U9ZX8mbxccz1v2cRh435E38y2X6dMBgM; n9 < -3.141592653589793; n9 += 6.283185307179586) {}
        while (n9 >= 3.141592653589793) {
            n9 -= 6.283185307179586;
        }
        if (n9 < -1.0) {
            n9 = -1.0;
        }
        if (n9 > 1.0) {
            n9 = 1.0;
        }
        this.3Z98T131bQxUtTNFXAA51SWp4j5aQ9ERV1365GwXppgj7BVcdlC8T66q6CvC += n9 * 0.1;
        this.3Z98T131bQxUtTNFXAA51SWp4j5aQ9ERV1365GwXppgj7BVcdlC8T66q6CvC *= 0.8;
        this.3XWs3nd7r9eNFEIpXUPF79HUJFE2U9ZX8mbxccz1v2cRh435E38y2X6dMBgM += this.3Z98T131bQxUtTNFXAA51SWp4j5aQ9ERV1365GwXppgj7BVcdlC8T66q6CvC;
        final double sin = Math.sin(this.3XWs3nd7r9eNFEIpXUPF79HUJFE2U9ZX8mbxccz1v2cRh435E38y2X6dMBgM);
        final double cos = Math.cos(this.3XWs3nd7r9eNFEIpXUPF79HUJFE2U9ZX8mbxccz1v2cRh435E38y2X6dMBgM);
        for (int j = -4; j <= 4; ++j) {
            final int n10 = (int)(7.5 - sin * j * 0.3 * 0.5) * 16 + (int)(8.5 + cos * j * 0.3);
            int n11 = 100;
            int n12 = 100;
            int n13 = 100;
            final int n14 = 255;
            if (this.06P3mXenpD5L0FS19r771z79X4G6ToUmlYYq950W8EH6ukeiX4WQd6Wqr2uA) {
                final int n15 = (n11 * 30 + n12 * 59 + n13 * 11) / 100;
                final int n16 = (n11 * 30 + n12 * 70) / 100;
                final int n17 = (n11 * 30 + n13 * 70) / 100;
                n11 = n15;
                n12 = n16;
                n13 = n17;
            }
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n10 * 4 + 0] = (byte)n11;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n10 * 4 + 1] = (byte)n12;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n10 * 4 + 2] = (byte)n13;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n10 * 4 + 3] = (byte)n14;
        }
        for (int k = -8; k <= 16; ++k) {
            final int n18 = (int)(7.5 + cos * k * 0.3 * 0.5) * 16 + (int)(8.5 + sin * k * 0.3);
            int n19 = (k >= 0) ? 255 : 100;
            int n20 = (k >= 0) ? 20 : 100;
            int n21 = (k >= 0) ? 20 : 100;
            final int n22 = 255;
            if (this.06P3mXenpD5L0FS19r771z79X4G6ToUmlYYq950W8EH6ukeiX4WQd6Wqr2uA) {
                final int n23 = (n19 * 30 + n20 * 59 + n21 * 11) / 100;
                final int n24 = (n19 * 30 + n20 * 70) / 100;
                final int n25 = (n19 * 30 + n21 * 70) / 100;
                n19 = n23;
                n20 = n24;
                n21 = n25;
            }
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n18 * 4 + 0] = (byte)n19;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n18 * 4 + 1] = (byte)n20;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n18 * 4 + 2] = (byte)n21;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n18 * 4 + 3] = (byte)n22;
        }
    }
}
