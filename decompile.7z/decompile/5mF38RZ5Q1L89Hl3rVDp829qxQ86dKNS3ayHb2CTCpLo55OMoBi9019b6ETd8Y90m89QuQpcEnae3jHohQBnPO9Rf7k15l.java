import java.io.DataInput;
import java.io.IOException;
import java.io.DataOutput;

// 
// Decompiled by Procyon v0.6.0
// 

public class 5mF38RZ5Q1L89Hl3rVDp829qxQ86dKNS3ayHb2CTCpLo55OMoBi9019b6ETd8Y90m89QuQpcEnae3jHohQBnPO9Rf7k15l extends 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi
{
    public long 7QWfAB1154Ks8W4Uq6u8z52lAd3Q6fDQs5yJb1PEoNcV8gJytBPtV1ycEZA0;
    
    public 5mF38RZ5Q1L89Hl3rVDp829qxQ86dKNS3ayHb2CTCpLo55OMoBi9019b6ETd8Y90m89QuQpcEnae3jHohQBnPO9Rf7k15l() {
    }
    
    public 5mF38RZ5Q1L89Hl3rVDp829qxQ86dKNS3ayHb2CTCpLo55OMoBi9019b6ETd8Y90m89QuQpcEnae3jHohQBnPO9Rf7k15l(final long 7qWfAB1154Ks8W4Uq6u8z52lAd3Q6fDQs5yJb1PEoNcV8gJytBPtV1ycEZA0) {
        this.7QWfAB1154Ks8W4Uq6u8z52lAd3Q6fDQs5yJb1PEoNcV8gJytBPtV1ycEZA0 = 7qWfAB1154Ks8W4Uq6u8z52lAd3Q6fDQs5yJb1PEoNcV8gJytBPtV1ycEZA0;
    }
    
    @Override
    void 7OU3N2lgEecd9p9DtAmaF5EwE4f0u28Oaa9zcxqnm3XW1bDsPewY15rIFs80(final DataOutput dataOutput) throws IOException {
        dataOutput.writeLong(this.7QWfAB1154Ks8W4Uq6u8z52lAd3Q6fDQs5yJb1PEoNcV8gJytBPtV1ycEZA0);
    }
    
    @Override
    void 96fSDIRBY01vu6bNpWo4KQJG8fCN2WIew9WR04d4yvq9Lxko60PpMIEkyn00(final DataInput dataInput) throws IOException {
        this.7QWfAB1154Ks8W4Uq6u8z52lAd3Q6fDQs5yJb1PEoNcV8gJytBPtV1ycEZA0 = dataInput.readLong();
    }
    
    @Override
    public byte 3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr() {
        return 4;
    }
    
    @Override
    public String toString() {
        return "" + this.7QWfAB1154Ks8W4Uq6u8z52lAd3Q6fDQs5yJb1PEoNcV8gJytBPtV1ycEZA0;
    }
}
