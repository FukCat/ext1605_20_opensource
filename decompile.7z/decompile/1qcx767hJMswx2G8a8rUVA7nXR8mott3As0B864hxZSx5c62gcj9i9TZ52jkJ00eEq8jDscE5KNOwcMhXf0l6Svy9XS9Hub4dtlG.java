import java.lang.reflect.InvocationTargetException;

// 
// Decompiled by Procyon v0.6.0
// 

public class 1qcx767hJMswx2G8a8rUVA7nXR8mott3As0B864hxZSx5c62gcj9i9TZ52jkJ00eEq8jDscE5KNOwcMhXf0l6Svy9XS9Hub4dtlG
{
    public static boolean 9LzmPa5dA62V89QZKR22H5VGgRTp0X11P2VLEFJw8tG0V8ig4m3CezjA515g(final String className) {
        try {
            Class.forName(className);
            return true;
        }
        catch (final ClassNotFoundException ex) {
            return false;
        }
    }
    
    public static Object 9Uru1FW89ta6z8a2n5ZS0zZels0ZLixz72YO2Rq9k20H9W7ISBGNQrOp5tUL(final Object o, final String name, final Class[] parameterTypes, final Object o2) {
        try {
            return ((o instanceof Class) ? ((Class)o) : o.getClass()).getMethod(name, (Class<?>[])parameterTypes).invoke((o instanceof Class) ? null : o, o2);
        }
        catch (final IllegalAccessException ex) {
            ex.printStackTrace();
        }
        catch (final IllegalArgumentException ex2) {
            ex2.printStackTrace();
        }
        catch (final InvocationTargetException ex3) {
            ex3.printStackTrace();
        }
        catch (final NoSuchMethodException ex4) {
            ex4.printStackTrace();
        }
        catch (final SecurityException ex5) {
            ex5.printStackTrace();
        }
        return null;
    }
    
    public static Object 2sP41C90YSw231vS4Sul8rx8y4GR4vNXfc1q37JKFf4KkR7Cq1r65e4xa8YC(final Object obj, final String name, final Class clazz) {
        try {
            return obj.getClass().getField(name).get(obj);
        }
        catch (final IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException ex) {
            ((Throwable)ex).printStackTrace();
            return null;
        }
    }
    
    public static Object 8MQ29480EaG6CorgpSaZf21csO2ec6Fx33YHpLEuXSz7265VcVqhVEck52XJ(final String className, final Class[] parameterTypes, final Object... initargs) {
        try {
            return Class.forName(className).getConstructor((Class<?>[])parameterTypes).newInstance(initargs);
        }
        catch (final ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            ((Throwable)ex).printStackTrace();
            return null;
        }
    }
    
    public static String 71s752so86DwU77rXlw1cHR51hpLewQ9ESrHcQon430rMgQXErcroRxA09ph(final Object o) {
        return o.getClass().getName();
    }
    
    public static Class 8Ehd0r9aAHEF32cGHok0smD4vA0B3N9Qx96zs8VmDa6dhPs1YF2JWfDn7x46(final String className) {
        try {
            return Class.forName(className);
        }
        catch (final ClassNotFoundException ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
