// 
// Decompiled by Procyon v0.6.0
// 

public class 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5
{
    public String 08YVi0miV0NCq8kgQVB3s086gcHnyy5wG3nCl3UVTdfLPyRbaq0dC2rfhcmD;
    public int 7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN;
    
    public 7Ex3Y0PhEloSzH2mCL20Eo2WWd2MO5JwWJC1RXanE9fpjFtFayN8O5J28yC51v4YjZ30cDqt3a3bFcbfG4B7uywbD0L5E5(final String 08YVi0miV0NCq8kgQVB3s086gcHnyy5wG3nCl3UVTdfLPyRbaq0dC2rfhcmD, final int 7m9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN) {
        this.08YVi0miV0NCq8kgQVB3s086gcHnyy5wG3nCl3UVTdfLPyRbaq0dC2rfhcmD = 08YVi0miV0NCq8kgQVB3s086gcHnyy5wG3nCl3UVTdfLPyRbaq0dC2rfhcmD;
        this.7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN = 7m9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN;
    }
}
