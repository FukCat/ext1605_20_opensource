import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 0yr0hSIR5cEyY6AyGGA31i8fV8PtBQm84L10t3651Doy8I8N41aS5pA7F0lOD9L7LAbK4g4Qs1RERi0X4115CFIP5M40ns7uM0mAja extends 04jG95z49Q0vzm7aDD4u7rv62B90mjfcT935e2Dzu8o9C0fd1Sk50n3k7fcwZrS9a3730pO5p6Gxj272Me3ugexz6x1jLF888XI4s2A55I
{
    protected 0yr0hSIR5cEyY6AyGGA31i8fV8PtBQm84L10t3651Doy8I8N41aS5pA7F0lOD9L7LAbK4g4Qs1RERi0X4115CFIP5M40ns7uM0mAja(final int n, final int n2) {
        super(n, n2, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.05M2lyfhkCWxFBaMQ4zXC4s76HnC5g08gem1NGa81EXm8lCOe51JljjWbII4);
    }
    
    @Override
    protected 2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex 6Qw6RCu9ZEo5HDblBh0CRT406s02009a656IV4nL0AKcEElJwejXE8chN4hm() {
        return new 6rNnMce0Z9o9ZgEH1hCrjc470Py2d427dR01C0nFX01h79DjvS4w014cG16Le3OXp1H172g7Z4XXzCG2TIej5pd75M6Lu3BWg8();
    }
    
    @Override
    public int 9hFrB67UQ3xIdu153AXx7FYrppLysZW3gpO0hVR27pm9IQlKb2jF25i9DO3e(final int n, final Random random) {
        return 0;
    }
    
    @Override
    public int 6M14lZVXL6xs4lKY6vj11vAQ2E9U9ZDOF0Nh9aCHYAlz8F6Pfx930Z7gxmzf(final Random random) {
        return 0;
    }
    
    @Override
    public boolean 11krARXg1dz3Cs9T1417zcu0h3o23b6X5J17X8JguWkYPA1xFa6hm48g23zA() {
        return false;
    }
}
