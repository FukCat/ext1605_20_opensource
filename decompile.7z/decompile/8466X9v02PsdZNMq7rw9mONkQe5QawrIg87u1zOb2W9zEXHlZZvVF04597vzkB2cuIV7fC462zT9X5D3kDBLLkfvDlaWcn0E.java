import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 8466X9v02PsdZNMq7rw9mONkQe5QawrIg87u1zOb2W9zEXHlZZvVF04597vzkB2cuIV7fC462zT9X5D3kDBLLkfvDlaWcn0E extends 71497xs2Sh1khzhYS572qd6F1J06d2EwFR1Y5G2Aa7TV0Blcy3yp1Dkw1O74pB66o1a0SG0J421Qys3eHXk1f9CJnwmh11498R
{
    public 8466X9v02PsdZNMq7rw9mONkQe5QawrIg87u1zOb2W9zEXHlZZvVF04597vzkB2cuIV7fC462zT9X5D3kDBLLkfvDlaWcn0E(final int n, final int n2) {
        super(n, n2);
    }
    
    @Override
    public int 6M14lZVXL6xs4lKY6vj11vAQ2E9U9ZDOF0Nh9aCHYAlz8F6Pfx930Z7gxmzf(final Random random) {
        return 1;
    }
    
    @Override
    public int 9hFrB67UQ3xIdu153AXx7FYrppLysZW3gpO0hVR27pm9IQlKb2jF25i9DO3e(final int n, final Random random) {
        return 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.9jnoy72im24QQ4J7wte9LiS0943oU2q3HgHGKZb8W9D478023ppVPxtTMDmC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
    }
}
