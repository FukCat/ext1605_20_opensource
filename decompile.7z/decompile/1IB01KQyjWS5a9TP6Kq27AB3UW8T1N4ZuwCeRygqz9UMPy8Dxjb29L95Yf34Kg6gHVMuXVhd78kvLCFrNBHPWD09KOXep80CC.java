// 
// Decompiled by Procyon v0.6.0
// 

public class 1IB01KQyjWS5a9TP6Kq27AB3UW8T1N4ZuwCeRygqz9UMPy8Dxjb29L95Yf34Kg6gHVMuXVhd78kvLCFrNBHPWD09KOXep80CC extends 2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38
{
    protected float[] 1svNgOD7VwC79ql8Ab9UzfF8D46rA021y0ms1p8xU9T5zY3xw9ZpMO1y5l2o;
    protected float[] 9DRBfXVt5K7W37u6Ajl7cm67r78YQjAQ195BIs46746AC6b61UCABL0oy6eh;
    
    public 1IB01KQyjWS5a9TP6Kq27AB3UW8T1N4ZuwCeRygqz9UMPy8Dxjb29L95Yf34Kg6gHVMuXVhd78kvLCFrNBHPWD09KOXep80CC(final int n) {
        super(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5P0gbq1QR95V381vsU1YW37ky63wbm4kYI9hdNi97J2K2578j94T1ly7HaX4.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41 + n * 16);
        this.1svNgOD7VwC79ql8Ab9UzfF8D46rA021y0ms1p8xU9T5zY3xw9ZpMO1y5l2o = new float[320];
        this.9DRBfXVt5K7W37u6Ajl7cm67r78YQjAQ195BIs46746AC6b61UCABL0oy6eh = new float[320];
    }
    
    @Override
    public void 88ejD45Q8LEgM39W23b9PS53H72qux6CoqBH3EmIU8XRRLm3446Q9e3d4IQv() {
        if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb == 2 && !this.88024hG6da4f4kcVfOqR8cTJ36RtCs13wB6V30Rs17vqAj14F4Cqz3neFg20) {
            return;
        }
        this.88024hG6da4f4kcVfOqR8cTJ36RtCs13wB6V30Rs17vqAj14F4Cqz3neFg20 = false;
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 20; ++j) {
                int n = 18;
                float n2 = this.1svNgOD7VwC79ql8Ab9UzfF8D46rA021y0ms1p8xU9T5zY3xw9ZpMO1y5l2o[i + (j + 1) % 20 * 16] * n;
                for (int k = i - 1; k <= i + 1; ++k) {
                    for (int l = j; l <= j + 1; ++l) {
                        if (k >= 0 && l >= 0 && k < 16 && l < 20) {
                            n2 += this.1svNgOD7VwC79ql8Ab9UzfF8D46rA021y0ms1p8xU9T5zY3xw9ZpMO1y5l2o[k + l * 16];
                        }
                        ++n;
                    }
                }
                this.9DRBfXVt5K7W37u6Ajl7cm67r78YQjAQ195BIs46746AC6b61UCABL0oy6eh[i + j * 16] = n2 / (n * 1.06f);
                if (j >= 19) {
                    this.9DRBfXVt5K7W37u6Ajl7cm67r78YQjAQ195BIs46746AC6b61UCABL0oy6eh[i + j * 16] = (float)(Math.random() * Math.random() * Math.random() * 4.0 + Math.random() * 0.10000000149011612 + 0.20000000298023224);
                }
            }
        }
        final float[] 9drBfXVt5K7W37u6Ajl7cm67r78YQjAQ195BIs46746AC6b61UCABL0oy6eh = this.9DRBfXVt5K7W37u6Ajl7cm67r78YQjAQ195BIs46746AC6b61UCABL0oy6eh;
        this.9DRBfXVt5K7W37u6Ajl7cm67r78YQjAQ195BIs46746AC6b61UCABL0oy6eh = this.1svNgOD7VwC79ql8Ab9UzfF8D46rA021y0ms1p8xU9T5zY3xw9ZpMO1y5l2o;
        this.1svNgOD7VwC79ql8Ab9UzfF8D46rA021y0ms1p8xU9T5zY3xw9ZpMO1y5l2o = 9drBfXVt5K7W37u6Ajl7cm67r78YQjAQ195BIs46746AC6b61UCABL0oy6eh;
        for (int n3 = 0; n3 < 256; ++n3) {
            float n4 = this.1svNgOD7VwC79ql8Ab9UzfF8D46rA021y0ms1p8xU9T5zY3xw9ZpMO1y5l2o[n3] * 1.8f;
            if (n4 > 1.0f) {
                n4 = 1.0f;
            }
            if (n4 < 0.0f) {
                n4 = 0.0f;
            }
            int n5 = (int)(10.0f * n4 + 75.0f);
            int n6 = (int)(5.0f * n4 * 225.0f);
            int n7 = (int)(n4 * n4 * n4 * n4 * n4 * n4 * n4 * n4 * n4 * n4 * 255.0f);
            int n8 = 255;
            if (n4 < 0.5f) {
                n8 = 0;
            }
            if (this.06P3mXenpD5L0FS19r771z79X4G6ToUmlYYq950W8EH6ukeiX4WQd6Wqr2uA) {
                final int n9 = (n5 * 30 + n6 * 59 + n7 * 11) / 100;
                final int n10 = (n5 * 30 + n6 * 70) / 100;
                final int n11 = (n5 * 30 + n7 * 70) / 100;
                n5 = n9;
                n6 = n10;
                n7 = n11;
            }
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n3 * 4 + 0] = (byte)n5;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n3 * 4 + 1] = (byte)n6;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n3 * 4 + 2] = (byte)n7;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n3 * 4 + 3] = (byte)n8;
        }
    }
}
