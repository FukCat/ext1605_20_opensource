import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.6.0
// 

public class 6pMRlhtTuQKaXgRar23xZFcM7Z02S0PVf9qZK2t8i1HiX572okJ83gKE1b2MG7RZmiTh2fN85cl1StmZ2UDGn7y5Itdkr5 extends 7mjBY5hjtYhFxmol0bJe7iaSdAco8DYgEtKD0APEX18xD7OnTVA4NKvZ4y233k8K0H1w5BQ7woiDHXTI5YccsWhxw1RJ
{
    private 740NlC1gREr6WKvZ6Bl5EP5AG2TVk7pfO7dAglxiwI4Jqd56bB0pSr7A844Ml6Dr50QtEE2YbZ6U0uzf04jQ0od44IYV92jKbD 85JEBmQ1Jl9H7Ir6ranJgwep25oznl00a61iflDdceBsJl8c6K0P7Z8Q3JzG;
    
    public 6pMRlhtTuQKaXgRar23xZFcM7Z02S0PVf9qZK2t8i1HiX572okJ83gKE1b2MG7RZmiTh2fN85cl1StmZ2UDGn7y5Itdkr5() {
        this.85JEBmQ1Jl9H7Ir6ranJgwep25oznl00a61iflDdceBsJl8c6K0P7Z8Q3JzG = new 740NlC1gREr6WKvZ6Bl5EP5AG2TVk7pfO7dAglxiwI4Jqd56bB0pSr7A844Ml6Dr50QtEE2YbZ6U0uzf04jQ0od44IYV92jKbD();
    }
    
    public void 1zK4FFVI9Pfr1JsIYdad0udVS3jX9zoVy5a6KyIjb49q2MA6wbcvd8Gn9nLV(final 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7, final double n, final double n2, final double n3, final float n4) {
        final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 7LfK4m7Nkevw8KLtBGOhC343i0Yn59U0N4WJ4qF0be3j8XIZ4m6Q1lUf04Jm = 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7.7LfK4m7Nkevw8KLtBGOhC343i0Yn59U0N4WJ4qF0be3j8XIZ4m6Q1lUf04Jm();
        GL11.glPushMatrix();
        final float n5 = 0.6666667f;
        if (7LfK4m7Nkevw8KLtBGOhC343i0Yn59U0N4WJ4qF0be3j8XIZ4m6Q1lUf04Jm == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3FJOncK0A81yjqFj2MiftTDhO3Ew09Y8Bs91GNA685U4LNH1Cfn2uDr9B31I) {
            GL11.glTranslatef((float)n + 0.5f, (float)n2 + 0.75f * n5, (float)n3 + 0.5f);
            GL11.glRotatef(-(32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7.8P1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh() * 360 / 16.0f), 0.0f, 1.0f, 0.0f);
            this.85JEBmQ1Jl9H7Ir6ranJgwep25oznl00a61iflDdceBsJl8c6K0P7Z8Q3JzG.37r6LH72naJbeTB4EtXV2KMMdJc415570n2Da5w4Rk0TYzhuZUXP68kncRoR.1jlbih5i5f8xexppOFn4050Xq05qb9JO1ky4kc4UVdU98Dfv35JLDnIJ555D = true;
        }
        else {
            final int 8p1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh = 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7.8P1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh();
            float n6 = 0.0f;
            if (8p1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh == 2) {
                n6 = 180.0f;
            }
            if (8p1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh == 4) {
                n6 = 90.0f;
            }
            if (8p1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh == 5) {
                n6 = -90.0f;
            }
            GL11.glTranslatef((float)n + 0.5f, (float)n2 + 0.75f * n5, (float)n3 + 0.5f);
            GL11.glRotatef(-n6, 0.0f, 1.0f, 0.0f);
            GL11.glTranslatef(0.0f, -0.3125f, -0.4375f);
            this.85JEBmQ1Jl9H7Ir6ranJgwep25oznl00a61iflDdceBsJl8c6K0P7Z8Q3JzG.37r6LH72naJbeTB4EtXV2KMMdJc415570n2Da5w4Rk0TYzhuZUXP68kncRoR.1jlbih5i5f8xexppOFn4050Xq05qb9JO1ky4kc4UVdU98Dfv35JLDnIJ555D = false;
        }
        this.9BHJSwbon1ahg5uM5SnN7cdDH0Pb92P1W3BY1CQFdA52m6n1Z3aWV5Eo8Nd2("/item/sign.png");
        GL11.glPushMatrix();
        GL11.glScalef(n5, -n5, -n5);
        this.85JEBmQ1Jl9H7Ir6ranJgwep25oznl00a61iflDdceBsJl8c6K0P7Z8Q3JzG.6mesG3kAI5P3TH3pUx5x1TPpUtc3eXF43wi6S9E3Cs84w6EA6hWwz13WT3wD();
        GL11.glPopMatrix();
        final 87k6gZdUF64lRd2414n3C9YY0RqdbbURZjg76Q3wg8n1vyhOeSdCGqtgKyQUo9TtGm8AxXBADPj6456Y0svQ4I3QmXX6S4J0 17z3voISJyZM3vHlc7Nd9M4IID57NATJsFSI0mBgmGdEJ4y4IY01CmJknf3U = this.17z3voISJyZM3vHlc7Nd9M4IID57NATJsFSI0mBgmGdEJ4y4IY01CmJknf3U();
        final float n7 = 0.016666668f * n5;
        GL11.glTranslatef(0.0f, 0.5f * n5, 0.07f * n5);
        GL11.glScalef(n7, -n7, n7);
        GL11.glNormal3f(0.0f, 0.0f, -1.0f * n7);
        GL11.glDepthMask(false);
        final int n8 = 0;
        for (int i = 0; i < 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b.length; ++i) {
            final String str = 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b[i];
            if (i == 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7.85V30gaDG6Xj02sL1WMJ6m7N3gebUU2eCs1PGgQQD6Xtde9DRR7P1cfb37XE) {
                final String string = "> " + str + " <";
                17z3voISJyZM3vHlc7Nd9M4IID57NATJsFSI0mBgmGdEJ4y4IY01CmJknf3U.9WH7LUf546x263V85v8o87x6d2Y7ZY7fPYyzVR9F61aJ7PnY1EAuj01xIk30(string, -17z3voISJyZM3vHlc7Nd9M4IID57NATJsFSI0mBgmGdEJ4y4IY01CmJknf3U.513yBz0z1e0Xp8J9hG9YLezT8TFgNrrND64rO10vxk37SjfO36iSUM8NmZ6j(string) / 2, i * 10 - 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b.length * 5, n8);
            }
            else {
                17z3voISJyZM3vHlc7Nd9M4IID57NATJsFSI0mBgmGdEJ4y4IY01CmJknf3U.9WH7LUf546x263V85v8o87x6d2Y7ZY7fPYyzVR9F61aJ7PnY1EAuj01xIk30(str, -17z3voISJyZM3vHlc7Nd9M4IID57NATJsFSI0mBgmGdEJ4y4IY01CmJknf3U.513yBz0z1e0Xp8J9hG9YLezT8TFgNrrND64rO10vxk37SjfO36iSUM8NmZ6j(str) / 2, i * 10 - 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b.length * 5, n8);
            }
        }
        GL11.glDepthMask(true);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    @Override
    public void 4yHlC88q82A91J4KaRZ2JwSFEgkU9iAYOAUx2OY5jx2UP2R0vtR4eFldWM2C(final 2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex 2ch1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex, final double n, final double n2, final double n3, final float n4) {
        this.1zK4FFVI9Pfr1JsIYdad0udVS3jX9zoVy5a6KyIjb49q2MA6wbcvd8Gn9nLV((32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7)2ch1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex, n, n2, n3, n4);
    }
}
