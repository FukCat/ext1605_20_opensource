// 
// Decompiled by Procyon v0.6.0
// 

public class 0gJ30uR8544WlDM95JfI7T0ZBN28kH5u7wl066bl2Ofw75k911QHplpc4U9rIOI6EU91bkyQ4RCYljPHBkb7ek7ehc3G3mh7
{
    public 0gJ30uR8544WlDM95JfI7T0ZBN28kH5u7wl066bl2Ofw75k911QHplpc4U9rIOI6EU91bkyQ4RCYljPHBkb7ek7ehc3G3mh7(final String s, final String s2) {
    }
}
