import java.util.HashMap;
import java.util.ArrayList;
import java.util.Collections;
import java.nio.IntBuffer;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.io.InputStream;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.util.LinkedList;
import java.util.Iterator;
import java.io.File;
import java.util.AbstractMap;
import java.util.Map;
import java.util.List;

// 
// Decompiled by Procyon v0.6.0
// 

public class 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX
{
    private static boolean 72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP;
    private static int 5dr5St90Oh58IImZ2u1Qa9TnH57Fm9Z3mbw7d66Rpr7pwLfzm8WwZfRXqEYa;
    private static int 0UiBN5RSC9RfxrH197Fw49353XPtq7AIQ10zv76TZjJ1mdETP7B4p4Gv6u8R;
    private static List<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> 9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG;
    private static Map<String, List<AbstractMap.SimpleEntry<String, Integer>>> 5I3lj0DX8KZT0aZ20ID7L4lD3zwq90XX7U57i62V2t1LV4Z8YV1pRDO391cO;
    private static int 79m4hO5D8sponYeuxHP8Ckcd4bo96538B2984S7mH4U7mBxBEZ4fx5yL5z0I;
    public static boolean 3gRA1DPeME7dX0o79x6vYtmX9E56Rk4BzqeEhKyuCUjM4Jy9i689uHvsp0L5;
    private static boolean[] 5y7b5152Md8Z9EHuZ025UoG0H2lRYR8C1mpjYv8TA90hyjieQphvjJJzsdg2;
    private static boolean[] 2ru92zlbWTMFil0V7u2Nqg2Cih9NEtsYQroaun656e7toIJhbs35ykvwio5C;
    private static List<2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38> 4Xu0V1F9kFc3WCP266SoSNwfcHhPI1la15vPfzXuH916i4b6avt2I5NwQxQ4;
    public static final String 36Ty520QfO20Ax3rMshqVfvF7n1CuphU809iDI7awL2ld87Yr6P6DK3kFH46 = "ExtensionLoader 16.05_20#";
    
    private static void 90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP() {
        final String s = "1111111111111011111111111111001111111111111110011111111111110001111111111111110011111001111000001111100110000000111110000000000011111001100000000000000100000000000000010000000000000000000000000000000000000000000000000000000000000000000000001100000000000000";
        final String s2 = "1111111111111111111111111111110111111111111111011111111111111100111111111111000011111111111111111111111111000000100100111000000010000000000000000000000000000000000000000000000000000000000000000000000000000111000000000000001100000000000001111111111111000011";
        for (int i = 0; i < 256; ++i) {
            00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5y7b5152Md8Z9EHuZ025UoG0H2lRYR8C1mpjYv8TA90hyjieQphvjJJzsdg2[i] = (s.charAt(i) == '1');
            00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.2ru92zlbWTMFil0V7u2Nqg2Cih9NEtsYQroaun656e7toIJhbs35ykvwio5C[i] = (s2.charAt(i) == '1');
        }
        try {
            74K2aL3fM9tPc23003GGOn5IX38EkdrnO8EKoTCZ7nINa7sxKMt7oav6TMz4(new File(00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.class.getProtectionDomain().getCodeSource().getLocation().toURI()));
            for (int j = 0; j < 32767; ++j) {
                if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[j] != null && 9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.8520h7KAcsf6F9feiIOsmSaFng995n36Rbw1F2Fn1Nn8r6en822LOu567Z7z[j] == null) {
                    9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.8520h7KAcsf6F9feiIOsmSaFng995n36Rbw1F2Fn1Nn8r6en822LOu567Z7z[j] = new 0k754nZk611N9r3A4VmIWweIGe20QKHutNj7cQo6p8hUM5N10Akkkyt0OhJDMmG6mp8Ex9P7w5n9B489li4ackKhn0n5B9m(j - 32767);
                }
            }
        }
        catch (final Exception cause) {
            cause.printStackTrace();
            throw new RuntimeException("ModLoader has failed to initialize. ", cause);
        }
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP = true;
    }
    
    public static void 1zA8dG4qpPf0EuPQHO8C1m3EUO479EwCMU9VHNBg24ct5Yf07DmMa5onsYBx() {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        final Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator();
        while (iterator.hasNext()) {
            iterator.next().2eZtZ8JV4VFwZrVeN3w4Yrg6L2rY7dp63a7lMTV19mq79WO6W21h60q6d4WS();
        }
    }
    
    public static int 311m5IZ1B4CRa9Rd318g8v14mkj05vBGEJ1RLFzJSfW9L8gnW2tB8CPz25H5(final int n) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        int 5hLg6hm1t3Z2E17z30LjP7Z5oZ195gKg36Z5026ri3B6A1dFnN6Nz5f49CWJ = 0;
        for (int n2 = 0; n2 < 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.size() && 5hLg6hm1t3Z2E17z30LjP7Z5oZ195gKg36Z5026ri3B6A1dFnN6Nz5f49CWJ == 0; 5hLg6hm1t3Z2E17z30LjP7Z5oZ195gKg36Z5026ri3B6A1dFnN6Nz5f49CWJ = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.get(n2).5HLg6hm1t3Z2E17z30LjP7Z5oZ195gKg36Z5026ri3B6A1dFnN6Nz5f49CWJ(n), ++n2) {}
        return 5hLg6hm1t3Z2E17z30LjP7Z5oZ195gKg36Z5026ri3B6A1dFnN6Nz5f49CWJ;
    }
    
    public static void 4QyF1nuedmVM18Y9FbnF0b3gf7IoG2J1dvkciuRvG4KthVh4nkasPv2tVWSo(final 67v4VfoC7ZGIWm5DlM418eZsYtc11QOolEyXR6AmZWIXvM1zk8zC5AbUzL1ox3x6i0ro65mGi0lGcc18R44qj0IN1v3oFucxb 67v4VfoC7ZGIWm5DlM418eZsYtc11QOolEyXR6AmZWIXvM1zk8zC5AbUzL1ox3x6i0ro65mGi0lGcc18R44qj0IN1v3oFucxb) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        final Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator();
        while (iterator.hasNext()) {
            iterator.next().466TsZ39Dt0IR55iI3vjNtseY8DruGHf7A343s3Uu6fWWfmkLpp5bt33nDVK(67v4VfoC7ZGIWm5DlM418eZsYtc11QOolEyXR6AmZWIXvM1zk8zC5AbUzL1ox3x6i0ro65mGi0lGcc18R44qj0IN1v3oFucxb);
        }
    }
    
    public static void 6WEf01uG0vOkrDW3AeDVkT4WTty8iX42F00PC4mIjnR9g9N887t6M967l933(final Map<Class<? extends 4GWFbOIMR3rg69M1Tw7AsIuO5A54yNk6ixz2D7h14bcq6qKB3v03aoGd8614DGBeJF7H1Bel756g1YCxyfkR0pQsk5P6wYjVNy>, 5l565Bhd57o0w6WsbV8e0692MOw67c9yUD3TKzzsrZNvrx4R8Ale5B5YCj8ocX8b36j793Ue2v3210qRvsvBW81zq809P34> map) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        final Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator();
        while (iterator.hasNext()) {
            iterator.next().5b0zagnX85oVC7LRFhOJ88RsIfI519v16u26Jbcwr9S33s1P06N0zG52Xitb(map);
        }
    }
    
    public static int 4jhB0G8F51zA9A72ejrhjmF5fQAsAi63knJb88ZvFWHfkRhLFJ06y6m40uYH(final int n) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        int 812pvAqF80y4d8Ieaj000vP1fao61t3W2WgdT60kdy45QrkWEXO51n3i6966 = -1;
        for (int n2 = 0; n2 < 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.size() && 812pvAqF80y4d8Ieaj000vP1fao61t3W2WgdT60kdy45QrkWEXO51n3i6966 == -1; 812pvAqF80y4d8Ieaj000vP1fao61t3W2WgdT60kdy45QrkWEXO51n3i6966 = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.get(n2).812pvAqF80y4d8Ieaj000vP1fao61t3W2WgdT60kdy45QrkWEXO51n3i6966(n), ++n2) {}
        return 812pvAqF80y4d8Ieaj000vP1fao61t3W2WgdT60kdy45QrkWEXO51n3i6966;
    }
    
    private static void 7PEIaVDp4NvSo8rPl8X60hq2SFIN10Hyul2lfkpQJHECM457hBsoMtMrJSR3(final ClassLoader classLoader, final String s) {
        try {
            final String replace = s.substring(0, s.length() - 6).replace('/', '.');
            final Class<?> loadClass = classLoader.loadClass(replace);
            if (loadClass.getSuperclass() != 3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU.class) {
                return;
            }
            if (00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.add((3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU)loadClass.newInstance())) {
                System.out.println("Mod Loaded: " + replace);
            }
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static void 9dLwAl76YvcE8uaxk317kBdM98GuIkb9M0ObzJxad4YP6nPU6R2sxMr9WSQY(final String s, final String key, final int i) {
        List list = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5I3lj0DX8KZT0aZ20ID7L4lD3zwq90XX7U57i62V2t1LV4Z8YV1pRDO391cO.get(s);
        if (list == null) {
            list = new LinkedList();
            00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5I3lj0DX8KZT0aZ20ID7L4lD3zwq90XX7U57i62V2t1LV4Z8YV1pRDO391cO.put(s, list);
        }
        list.add(new AbstractMap.SimpleEntry(key, i));
    }
    
    public static void 7amIWaRwMFh34FW4JoMnK1nnfTz2Gg50SP1aC1RCaH3BqxiQcEA1E6vOiiYl(final 2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38 2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38) {
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.4Xu0V1F9kFc3WCP266SoSNwfcHhPI1la15vPfzXuH916i4b6avt2I5NwQxQ4.add(2uqbjp5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38);
    }
    
    public static int 7183oegZY0lx68gnspUjz5TeDj5U0T8UL5vU2k4YyMvSv62XRV1v4hfB0rrX() {
        return 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5dr5St90Oh58IImZ2u1Qa9TnH57Fm9Z3mbw7d66Rpr7pwLfzm8WwZfRXqEYa++;
    }
    
    private static int 5020H9Cb0GHW3nf9O6o9GQEcLC103b9nseE49E6mmmjitPfI0GvyEmni5zQ2() {
        while (00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.0UiBN5RSC9RfxrH197Fw49353XPtq7AIQ10zv76TZjJ1mdETP7B4p4Gv6u8R < 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5y7b5152Md8Z9EHuZ025UoG0H2lRYR8C1mpjYv8TA90hyjieQphvjJJzsdg2.length) {
            if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5y7b5152Md8Z9EHuZ025UoG0H2lRYR8C1mpjYv8TA90hyjieQphvjJJzsdg2[00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.0UiBN5RSC9RfxrH197Fw49353XPtq7AIQ10zv76TZjJ1mdETP7B4p4Gv6u8R]) {
                00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5y7b5152Md8Z9EHuZ025UoG0H2lRYR8C1mpjYv8TA90hyjieQphvjJJzsdg2[00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.0UiBN5RSC9RfxrH197Fw49353XPtq7AIQ10zv76TZjJ1mdETP7B4p4Gv6u8R] = true;
                return 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.0UiBN5RSC9RfxrH197Fw49353XPtq7AIQ10zv76TZjJ1mdETP7B4p4Gv6u8R++;
            }
            ++00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.0UiBN5RSC9RfxrH197Fw49353XPtq7AIQ10zv76TZjJ1mdETP7B4p4Gv6u8R;
        }
        throw new RuntimeException("No more empty item sprite indices left!");
    }
    
    public static int 99a4FRq83H8nAc7cAuNx7Dawz1rb78K0ca3a4yTWJ5HsAhqvM3Ut257qHk20(final String str) {
        if (str.equals("/gui/items.png")) {
            return 5020H9Cb0GHW3nf9O6o9GQEcLC103b9nseE49E6mmmjitPfI0GvyEmni5zQ2();
        }
        if (str.equals("/terrain.png")) {
            return 98pBf1OMqP55wbs7m74Pxp3Sh4kbF9710wu6x4z5BSiyTZRWcla768rBTP1L();
        }
        throw new RuntimeException("No registry for this texture: " + str);
    }
    
    private static int 98pBf1OMqP55wbs7m74Pxp3Sh4kbF9710wu6x4z5BSiyTZRWcla768rBTP1L() {
        while (00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.79m4hO5D8sponYeuxHP8Ckcd4bo96538B2984S7mH4U7mBxBEZ4fx5yL5z0I < 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.2ru92zlbWTMFil0V7u2Nqg2Cih9NEtsYQroaun656e7toIJhbs35ykvwio5C.length) {
            if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.2ru92zlbWTMFil0V7u2Nqg2Cih9NEtsYQroaun656e7toIJhbs35ykvwio5C[00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.79m4hO5D8sponYeuxHP8Ckcd4bo96538B2984S7mH4U7mBxBEZ4fx5yL5z0I]) {
                00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.2ru92zlbWTMFil0V7u2Nqg2Cih9NEtsYQroaun656e7toIJhbs35ykvwio5C[00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.79m4hO5D8sponYeuxHP8Ckcd4bo96538B2984S7mH4U7mBxBEZ4fx5yL5z0I] = true;
                return 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.79m4hO5D8sponYeuxHP8Ckcd4bo96538B2984S7mH4U7mBxBEZ4fx5yL5z0I++;
            }
            ++00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.79m4hO5D8sponYeuxHP8Ckcd4bo96538B2984S7mH4U7mBxBEZ4fx5yL5z0I;
        }
        throw new RuntimeException("No more empty terrain sprite indices left!");
    }
    
    public static boolean 9XN4KHl6PcbIvg873W8xh7eo0Y8F7m78b3qNkHP9fGWl0j5UO55s6vCqFT7D(final String className) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        Class<?> forName;
        try {
            forName = Class.forName(className);
        }
        catch (final ClassNotFoundException ex) {
            return false;
        }
        if (forName != null) {
            final Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator();
            while (iterator.hasNext()) {
                if (forName.isInstance(iterator.next())) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private static BufferedImage 46A50K97ovzn670U84943wNWdB80IJXX68N729Yxd8M8BJ3o6EnUrlyLX28c(final 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u, final String str) {
        try {
            final InputStream 35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0 = 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.8nB09v2wL31LD7473aXNMbJrX47AX71iPMP6yPX544heeDvxj78y5qTJYk68.1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0.35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0(str);
            if (35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0 != null) {
                return ImageIO.read(35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0);
            }
            throw new RuntimeException("Image not found: " + str);
        }
        catch (final Exception cause) {
            throw new RuntimeException(cause);
        }
    }
    
    public static 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D 15q5nHaDm3z7iw3d661PfoH597ablE52QxXWXhA2acdGaMK8nfXY3k0CDfN1(final 799HmGi6Zuy2VT1N48Y2QeMvKB1kN289S0Wi1ZI6k06AYWM1KH5P5G3B0ENil5eN9S04g8Smf14y9GkpkeoGdCZza90SL14j 799HmGi6Zuy2VT1N48Y2QeMvKB1kN289S0Wi1ZI6k06AYWM1KH5P5G3B0ENil5eN9S04g8Smf14y9GkpkeoGdCZza90SL14j, final Object o) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D 6vDjyvt90B3A53eVhIye02TE5UPi4K8b3V7RO5Mz036n1j4a15Sj95h93ptY = null;
        for (int n = 0; n < 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.size() && 6vDjyvt90B3A53eVhIye02TE5UPi4K8b3V7RO5Mz036n1j4a15Sj95h93ptY == null; 6vDjyvt90B3A53eVhIye02TE5UPi4K8b3V7RO5Mz036n1j4a15Sj95h93ptY = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.get(n).6vDjyvt90B3A53eVhIye02TE5UPi4K8b3V7RO5Mz036n1j4a15Sj95h93ptY(799HmGi6Zuy2VT1N48Y2QeMvKB1kN289S0Wi1ZI6k06AYWM1KH5P5G3B0ENil5eN9S04g8Smf14y9GkpkeoGdCZza90SL14j, o), ++n) {}
        return 6vDjyvt90B3A53eVhIye02TE5UPi4K8b3V7RO5Mz036n1j4a15Sj95h93ptY;
    }
    
    public static void 3JcBnXK0NLGB1T644pEz7D76TXKSh2Uyjaa68711aHHN1jk1SN3Cr2d8mLjw(final 9w01LW7i1o0vXYp00Bl2S04v40DMez7W4759J3B7rfcZlQFVzYu9tp8T2pP1654iFNkVSafl1rNS262Luzk60c82j1fD12F19 9w01LW7i1o0vXYp00Bl2S04v40DMez7W4759J3B7rfcZlQFVzYu9tp8T2pP1654iFNkVSafl1rNS262Luzk60c82j1fD12F19, final int n, final int n2, final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        for (final 3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU 3qHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU : 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG) {
            if (9w01LW7i1o0vXYp00Bl2S04v40DMez7W4759J3B7rfcZlQFVzYu9tp8T2pP1654iFNkVSafl1rNS262Luzk60c82j1fD12F19 instanceof 558q23gk66Cx1OdBJBWC7VTXR0LmuO3t8y8980L1Xqn06l37dSTnn7ZXdEvDtHSEYFq2z0668ZufwKgh6MR6psGso4MRVO4i2p) {
                3qHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU.06E0h7pfToqW9jubxYakg4609C207COWJHin8Miz3Mnafv779G3V5X6iwFZp(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6e2b2Q0bozeRSkKP7uT1ZulyTqO1Z95PKHnUf4RqJNCrz5DW87P9QB88us18, n, n2);
            }
            else {
                3qHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU.20fGD696E1rrnKO3zQ6ej3jllKU462gK6r1jhOj9DZ6R475673aN5KvNgDSo(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6e2b2Q0bozeRSkKP7uT1ZulyTqO1Z95PKHnUf4RqJNCrz5DW87P9QB88us18, n, n2);
            }
        }
    }
    
    private static void 74K2aL3fM9tPc23003GGOn5IX38EkdrnO8EKoTCZ7nINa7sxKMt7oav6TMz4(final File file) throws IOException {
        final ClassLoader classLoader = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.class.getClassLoader();
        if (file.isFile() && (file.getName().endsWith(".jar") || file.getName().endsWith(".zip"))) {
            final ZipInputStream zipInputStream = new ZipInputStream(Files.newInputStream(file.toPath(), new OpenOption[0]));
            while (true) {
                final ZipEntry nextEntry = zipInputStream.getNextEntry();
                if (nextEntry == null) {
                    break;
                }
                final String name = nextEntry.getName();
                if (nextEntry.isDirectory() || !name.contains("mod_") || !name.endsWith(".class")) {
                    continue;
                }
                7PEIaVDp4NvSo8rPl8X60hq2SFIN10Hyul2lfkpQJHECM457hBsoMtMrJSR3(classLoader, name);
            }
        }
        else if (file.isDirectory()) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (final File file2 : listFiles) {
                    final String name2 = file2.getName();
                    if (file2.isFile() && name2.contains("mod_") && name2.endsWith(".class")) {
                        7PEIaVDp4NvSo8rPl8X60hq2SFIN10Hyul2lfkpQJHECM457hBsoMtMrJSR3(classLoader, name2);
                    }
                }
            }
        }
    }
    
    public static void 9gV9mY45OBWw3kXxytZ8X3DM342337Bs6562p8qX81uWz9A7Q93ZFs4Qf9dh(final List<1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC> list) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        final Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator();
        while (iterator.hasNext()) {
            iterator.next().5X1cltfSVH6sx9fdX8FdgBUCiHe1gR9R77Wk1ZIIAtuMHHWkK1Lif13AZ93Q(list);
        }
    }
    
    public static void 9V98K4dP8l9wBiOKecrVO8000djz8eeV534KchJg7PdcLjb1V0p7Im99IdB7(final 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        final Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator();
        while (iterator.hasNext()) {
            iterator.next().8ylvh6Bkf5gx3O4h0u9X0aya0I0fV245sUOG4M8NhL03LRC1gC7i8PxaGaJ2();
        }
        final Minecraft 2shGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242 = 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.78OxWKhpSoq2g2GiUNej2aKIJrP7X69zer9a141qoQdboWo1BnWwfu6q2Xhc.2SHGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242;
        if (2shGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242 != null) {
            for (int i = 0; i < 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.size(); ++i) {
                00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.get(i).1aDo2hz1gTEYV7a8NNfBDpoqP7GwAH0JV6oz40Bo5C1I5eN8a0I2ok1Gj7YH(2shGlLXMgM3LkYu59L1i9U42BIjP5v1sLw98ez1s80429W0ZVh10BWc3E242);
            }
        }
        for (int j = 0; j < 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.4Xu0V1F9kFc3WCP266SoSNwfcHhPI1la15vPfzXuH916i4b6avt2I5NwQxQ4.size(); ++j) {
            5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.28Z4uM6w2C9HBIK0Je3x0ZTd15BEr7HSCMfM76jj6Ncia2M0shMqtHRVj7cg(00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.4Xu0V1F9kFc3WCP266SoSNwfcHhPI1la15vPfzXuH916i4b6avt2I5NwQxQ4.get(j));
        }
        for (final Map.Entry entry : 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5I3lj0DX8KZT0aZ20ID7L4lD3zwq90XX7U57i62V2t1LV4Z8YV1pRDO391cO.entrySet()) {
            final String str = (String)entry.getKey();
            final int 7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8 = 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8(str);
            final IntBuffer intBuffer = ByteBuffer.allocateDirect(16).order(ByteOrder.nativeOrder()).asIntBuffer();
            GL11.glBindTexture(3553, 7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8);
            GL11.glGetTexLevelParameter(3553, 0, 4097, intBuffer);
            final int n = intBuffer.get(0) / 16;
            for (final AbstractMap.SimpleEntry simpleEntry : (List)entry.getValue()) {
                final String str2 = (String)simpleEntry.getKey();
                final int intValue = (int)simpleEntry.getValue();
                System.out.println("Overriding " + str + " with " + str2 + " @ " + intValue);
                final BufferedImage 46A50K97ovzn670U84943wNWdB80IJXX68N729Yxd8M8BJ3o6EnUrlyLX28c = 46A50K97ovzn670U84943wNWdB80IJXX68N729Yxd8M8BJ3o6EnUrlyLX28c(5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u, str2);
                final int height = 46A50K97ovzn670U84943wNWdB80IJXX68N729Yxd8M8BJ3o6EnUrlyLX28c.getHeight();
                final ByteBuffer order = ByteBuffer.allocateDirect(4 * n * n).order(ByteOrder.nativeOrder());
                final int n2 = n / height;
                final int[] rgbArray = new int[height * height];
                46A50K97ovzn670U84943wNWdB80IJXX68N729Yxd8M8BJ3o6EnUrlyLX28c.getRGB(0, 0, height, height, rgbArray, 0, height);
                final int n3 = intValue / 16;
                final int n4 = intValue % 16;
                final int k = n * n3;
                final int l = n * n4;
                for (int n5 = 0; n5 < n; ++n5) {
                    for (int n6 = 0; n6 < n; ++n6) {
                        final int n7 = rgbArray[(n2 != 0) ? (height * (n5 / n2) + n6 / n2) : (height * n5 * (height / n) + n6 * (height / n))];
                        final byte b = (byte)(n7 >> 24 & 0xFF);
                        final byte b2 = (byte)(n7 >> 16 & 0xFF);
                        final byte b3 = (byte)(n7 >> 8 & 0xFF);
                        final byte b4 = (byte)(n7 & 0xFF);
                        order.put(b2);
                        order.put(b3);
                        order.put(b4);
                        order.put(b);
                    }
                }
                order.position(0);
                try {
                    GL11.class.getMethod("glTexSubImage2D", Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, ByteBuffer.class).invoke(null, 3553, 0, l, k, n, n, 6408, 5121, order);
                }
                catch (final Exception cause) {
                    cause.printStackTrace();
                    throw new RuntimeException("Error calling glTexSubImage2D (blame xau)", cause);
                }
            }
            00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.3gRA1DPeME7dX0o79x6vYtmX9E56Rk4BzqeEhKyuCUjM4Jy9i689uHvsp0L5 = true;
        }
    }
    
    public static void 5DV4s925KfPwW7lOnppC2dWI2O982zWtD86jrq145Axc1uOSn1lY382GtmhK() {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        final Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator();
        while (iterator.hasNext()) {
            iterator.next().6J2c50sO2r0utzh1fv7M51XYY4zYX2J524uKx6kj77tYi1yn8888O3Xr2U4z();
        }
    }
    
    public static void 9536dYBvF3Zj5I47C7Co2LY5B3T2nqx5F3ohU512CQWFQ6FQOzrlO7aIAfUY(final Minecraft minecraft) {
        if (!00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP) {
            90Z4359g5Q99Y192qds9w1x1X02iR8VpHm34IxzI4qHFP3OHBa1pTf964VDP();
        }
        final Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator();
        while (iterator.hasNext()) {
            iterator.next().8Qoy3Z0g210X0E3BR229hbl5KKdL16AJmG5KBUu3l3854OJ58gdO0T397qez(minecraft);
        }
    }
    
    public static int 7FVgHb825Vh87dj7a9W610VePPyEK11H4311BN3gSLe6J6831pq3l6tzy2RP(final int n) {
        int 54pM8s64ZMnaU952nGEh82Q57WO2N6jhc3lwdq8i55LCTqh9Z6CBI7mTN1xJ = -1;
        for (Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator(); iterator.hasNext() && 54pM8s64ZMnaU952nGEh82Q57WO2N6jhc3lwdq8i55LCTqh9Z6CBI7mTN1xJ == -1; 54pM8s64ZMnaU952nGEh82Q57WO2N6jhc3lwdq8i55LCTqh9Z6CBI7mTN1xJ = iterator.next().54pM8s64ZMnaU952nGEh82Q57WO2N6jhc3lwdq8i55LCTqh9Z6CBI7mTN1xJ(n)) {}
        return 54pM8s64ZMnaU952nGEh82Q57WO2N6jhc3lwdq8i55LCTqh9Z6CBI7mTN1xJ;
    }
    
    public static int 52C0KnY47qid74yQYI1zgrLooP36NM650B3JgHP47o3Od0glFmCykL7fJoj8(final int n) {
        int 7m6m13dn8LrG10h8c2Og50FZ5BadQ06sFis8fvT5TqNZ2cpOxQ56X340JqVC = 0;
        for (Iterator<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> iterator = 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG.iterator(); iterator.hasNext() && 7m6m13dn8LrG10h8c2Og50FZ5BadQ06sFis8fvT5TqNZ2cpOxQ56X340JqVC == 0; 7m6m13dn8LrG10h8c2Og50FZ5BadQ06sFis8fvT5TqNZ2cpOxQ56X340JqVC = iterator.next().7m6m13dn8LrG10h8c2Og50FZ5BadQ06sFis8fvT5TqNZ2cpOxQ56X340JqVC(n)) {}
        return 7m6m13dn8LrG10h8c2Og50FZ5BadQ06sFis8fvT5TqNZ2cpOxQ56X340JqVC;
    }
    
    public static List<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU> 7AT2q764kBM4UAhX20130C3Jh6LT7Y5snv3wxjh9e5VP43467B37csjDd1NC() {
        return Collections.unmodifiableList((List<? extends 3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU>)00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG);
    }
    
    static {
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.72Ap8D2a33D5G3C3xliX77A0g79pdP886Jma57uw8sLcEZWSETL9965GlrFP = false;
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5dr5St90Oh58IImZ2u1Qa9TnH57Fm9Z3mbw7d66Rpr7pwLfzm8WwZfRXqEYa = 3000;
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.0UiBN5RSC9RfxrH197Fw49353XPtq7AIQ10zv76TZjJ1mdETP7B4p4Gv6u8R = 0;
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.9M3Y3MMjsbAfP046dpOiSD6wo1h12o4djZ6WU86xQNZoZd0Udq9V39L05qCG = new ArrayList<3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU>();
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5I3lj0DX8KZT0aZ20ID7L4lD3zwq90XX7U57i62V2t1LV4Z8YV1pRDO391cO = new HashMap<String, List<AbstractMap.SimpleEntry<String, Integer>>>();
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.79m4hO5D8sponYeuxHP8Ckcd4bo96538B2984S7mH4U7mBxBEZ4fx5yL5z0I = 0;
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.3gRA1DPeME7dX0o79x6vYtmX9E56Rk4BzqeEhKyuCUjM4Jy9i689uHvsp0L5 = false;
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.5y7b5152Md8Z9EHuZ025UoG0H2lRYR8C1mpjYv8TA90hyjieQphvjJJzsdg2 = new boolean[256];
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.2ru92zlbWTMFil0V7u2Nqg2Cih9NEtsYQroaun656e7toIJhbs35ykvwio5C = new boolean[256];
        00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.4Xu0V1F9kFc3WCP266SoSNwfcHhPI1la15vPfzXuH916i4b6avt2I5NwQxQ4 = new ArrayList<2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38>();
    }
}
