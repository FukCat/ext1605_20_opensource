import java.io.DataInput;
import java.io.IOException;
import java.io.DataOutput;

// 
// Decompiled by Procyon v0.6.0
// 

public abstract class 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi
{
    private String 2uueGmCeZDqab76Xk514Mf20S313Em33W4I41W65UY7eeMXjkyqG08SOKpfG;
    
    public 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi() {
        this.2uueGmCeZDqab76Xk514Mf20S313Em33W4I41W65UY7eeMXjkyqG08SOKpfG = null;
    }
    
    abstract void 7OU3N2lgEecd9p9DtAmaF5EwE4f0u28Oaa9zcxqnm3XW1bDsPewY15rIFs80(final DataOutput p0) throws IOException;
    
    abstract void 96fSDIRBY01vu6bNpWo4KQJG8fCN2WIew9WR04d4yvq9Lxko60PpMIEkyn00(final DataInput p0) throws IOException;
    
    public abstract byte 3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr();
    
    public String 1bXdxI1r44PJ8H3Al9yKRQUvLOdXu12zCf91TjxP6d3yYuCbub216zk5B9xc() {
        return (this.2uueGmCeZDqab76Xk514Mf20S313Em33W4I41W65UY7eeMXjkyqG08SOKpfG == null) ? "" : this.2uueGmCeZDqab76Xk514Mf20S313Em33W4I41W65UY7eeMXjkyqG08SOKpfG;
    }
    
    public 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi 6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(final String 2uueGmCeZDqab76Xk514Mf20S313Em33W4I41W65UY7eeMXjkyqG08SOKpfG) {
        this.2uueGmCeZDqab76Xk514Mf20S313Em33W4I41W65UY7eeMXjkyqG08SOKpfG = 2uueGmCeZDqab76Xk514Mf20S313Em33W4I41W65UY7eeMXjkyqG08SOKpfG;
        return this;
    }
    
    public static 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi 5LDNVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814(final DataInput dataInput) throws IOException {
        final byte byte1 = dataInput.readByte();
        if (byte1 == 0) {
            return new 248m06R8iz5CGp1qVwqUND31oZbp600Q4HU9TLK6aW684RZM21aJ8YJv0f9qF73P9zVTCp8z6e415QzF8SOmI65IJEn123J();
        }
        final 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi 7q2m6CHT71cLIL2ML3Y1B6IXFRJ3i9P881DK9N6VS9TN5kpTvd5e8x4TRFDM = 7q2m6CHT71cLIL2ML3Y1B6IXFRJ3i9P881DK9N6VS9TN5kpTvd5e8x4TRFDM(byte1);
        7q2m6CHT71cLIL2ML3Y1B6IXFRJ3i9P881DK9N6VS9TN5kpTvd5e8x4TRFDM.2uueGmCeZDqab76Xk514Mf20S313Em33W4I41W65UY7eeMXjkyqG08SOKpfG = dataInput.readUTF();
        7q2m6CHT71cLIL2ML3Y1B6IXFRJ3i9P881DK9N6VS9TN5kpTvd5e8x4TRFDM.96fSDIRBY01vu6bNpWo4KQJG8fCN2WIew9WR04d4yvq9Lxko60PpMIEkyn00(dataInput);
        return 7q2m6CHT71cLIL2ML3Y1B6IXFRJ3i9P881DK9N6VS9TN5kpTvd5e8x4TRFDM;
    }
    
    public static void 78J371L0tO529ZkE8c9oYbZ1V4VtvwmXY8SqyrOhkx0OrNxa9X2sjgw70byi(final 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi, final DataOutput dataOutput) throws IOException {
        dataOutput.writeByte(03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi.3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr());
        if (03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi.3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr() != 0) {
            dataOutput.writeUTF(03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi.1bXdxI1r44PJ8H3Al9yKRQUvLOdXu12zCf91TjxP6d3yYuCbub216zk5B9xc());
            03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi.7OU3N2lgEecd9p9DtAmaF5EwE4f0u28Oaa9zcxqnm3XW1bDsPewY15rIFs80(dataOutput);
        }
    }
    
    public static 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi 7q2m6CHT71cLIL2ML3Y1B6IXFRJ3i9P881DK9N6VS9TN5kpTvd5e8x4TRFDM(final byte b) {
        switch (b) {
            case 0: {
                return new 248m06R8iz5CGp1qVwqUND31oZbp600Q4HU9TLK6aW684RZM21aJ8YJv0f9qF73P9zVTCp8z6e415QzF8SOmI65IJEn123J();
            }
            case 1: {
                return new 7eh6ri0t9ycCp8J7L2hLcpxyx60qg0pLnKkXo51739KRIBwUj6gXgu6C5veRwhFJ97P9a3Q85E2k1TnCo0ab2Y7ZdM1keD6();
            }
            case 2: {
                return new 71JZdqce1m9979i3cSBBlOj3ETTvHGDPSWO291hY4ds9z4R7UJ0T2V1rNWb7twoV1Tf9MH0frb0MPpjV7R84FayCU8r3366qF3FCbom1H();
            }
            case 3: {
                return new 5vLi42tz24A1bKSOsig3qqCTWQJ6JU22J1RtQm2UWWOXkk3bkZ24aN8A7pIf8W41hLW8pdXSEswAGTbMo4Suk6TmvHH9dV4OhrU();
            }
            case 4: {
                return new 5mF38RZ5Q1L89Hl3rVDp829qxQ86dKNS3ayHb2CTCpLo55OMoBi9019b6ETd8Y90m89QuQpcEnae3jHohQBnPO9Rf7k15l();
            }
            case 5: {
                return new 09Khv82el60zcD4X75muqO07J4UCSBbGjrciEn701oHQ424aXL3f7qy41XSva67YQCnM46P1kh2a0wsS92Pe05yy3Rpk0572n();
            }
            case 6: {
                return new 20vQdcXWP2tdq36Nqw3EFGw0qUYN96832lkzEzf8gd2S1DkJpqVeZI1k9XL0Swqa7r1ny7P9tX47F8H11ycA4I066jGQ5TW8Ab();
            }
            case 7: {
                return new 3k7fks2663LUy0ues29Fx7SaYSSvMXM4l89hG8z0T5vi9m60Qmi1Az50Gvoe8014U15R85MFw0sp4kiyAnFPv3XCdb9j();
            }
            case 8: {
                return new 5320B5B2PAe1Msr7UU0iIN551u42U9hRsa5VP260D729PAz32nhTE5lhHX7upTAB1P7wW6jq7894K4ABR3SNw45C3si50Ldou5Ux12();
            }
            case 9: {
                return new 4d42WC8IOlF5b2geal4NQk6ibJke2bs4240Y3lhJnxK7i21K1Pf54b98jw84dTo8q6xfwV0T2segbUDIqe6bax9oDWcwB();
            }
            case 10: {
                return new 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419();
            }
            default: {
                return null;
            }
        }
    }
    
    public static String 1mogjF2YI89vJHkMC2hSNiyxIkcIByYW72f1F4y8VqaeINT7Y1A2BlIe9hUk(final byte b) {
        switch (b) {
            case 0: {
                return "TAG_End";
            }
            case 1: {
                return "TAG_Byte";
            }
            case 2: {
                return "TAG_Short";
            }
            case 3: {
                return "TAG_Int";
            }
            case 4: {
                return "TAG_Long";
            }
            case 5: {
                return "TAG_Float";
            }
            case 6: {
                return "TAG_Double";
            }
            case 7: {
                return "TAG_Byte_Array";
            }
            case 8: {
                return "TAG_String";
            }
            case 9: {
                return "TAG_List";
            }
            case 10: {
                return "TAG_Compound";
            }
            default: {
                return "UNKNOWN";
            }
        }
    }
}
