import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

// 
// Decompiled by Procyon v0.6.0
// 

public class 74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX
{
    public static HashMap<String, 74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX> 293hUSlrDZ5KqkEIUf42HQ0MuQ29P6gQ9O1UJw7cYH753B92dP6B3tqaKFpf;
    public String 600hk0484Bn99Fky1ijfMZJ92xjRzP8y47YibYblG9VJ499gj97F5t5mhikx;
    public byte[] 8u4H8s1OU3Y6C3EtLsf7U008wY0JFo6lT55WW90fs2awsRCSuIlxzgDspTR6;
    public int 70hCX89P48xycSCGipE9fkNj2AJp9MON2YDKZFT48oK89XF09W8r2cVWcl9M;
    public int 53QH2KJ5zo6OXKxAjRXunVewAx6WgXnO6GbCJeQ37yWnPe5yY0xRDbl631L4;
    public int 4xupnEk7SDlQE5P1MiI6resUDlR1VD77i587eKJotSM16x63HKAv2K174dbE;
    public List<Integer> 69qbve9pc68k2c6E45GS5hSEq3SXSsJ379FTUd440fovNX0WhV10IGFqj9Nz;
    
    public 74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX(final String 600hk0484Bn99Fky1ijfMZJ92xjRzP8y47YibYblG9VJ499gj97F5t5mhikx, final int 53QH2KJ5zo6OXKxAjRXunVewAx6WgXnO6GbCJeQ37yWnPe5yY0xRDbl631L4) {
        this.70hCX89P48xycSCGipE9fkNj2AJp9MON2YDKZFT48oK89XF09W8r2cVWcl9M = 1024;
        this.4xupnEk7SDlQE5P1MiI6resUDlR1VD77i587eKJotSM16x63HKAv2K174dbE = 0;
        this.69qbve9pc68k2c6E45GS5hSEq3SXSsJ379FTUd440fovNX0WhV10IGFqj9Nz = new ArrayList<Integer>();
        this.600hk0484Bn99Fky1ijfMZJ92xjRzP8y47YibYblG9VJ499gj97F5t5mhikx = 600hk0484Bn99Fky1ijfMZJ92xjRzP8y47YibYblG9VJ499gj97F5t5mhikx;
        this.8u4H8s1OU3Y6C3EtLsf7U008wY0JFo6lT55WW90fs2awsRCSuIlxzgDspTR6 = new byte[53QH2KJ5zo6OXKxAjRXunVewAx6WgXnO6GbCJeQ37yWnPe5yY0xRDbl631L4];
        this.53QH2KJ5zo6OXKxAjRXunVewAx6WgXnO6GbCJeQ37yWnPe5yY0xRDbl631L4 = 53QH2KJ5zo6OXKxAjRXunVewAx6WgXnO6GbCJeQ37yWnPe5yY0xRDbl631L4;
    }
    
    public static 74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX 186bsEdE0L8avI1T6188HOBkw74Rv2C84f9rbbXELJN9UVCSqDM617l7y7BO(final String key, final int n) {
        if (!74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX.293hUSlrDZ5KqkEIUf42HQ0MuQ29P6gQ9O1UJw7cYH753B92dP6B3tqaKFpf.containsKey(key)) {
            74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX.293hUSlrDZ5KqkEIUf42HQ0MuQ29P6gQ9O1UJw7cYH753B92dP6B3tqaKFpf.put(key, new 74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX(key, n));
        }
        return 74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX.293hUSlrDZ5KqkEIUf42HQ0MuQ29P6gQ9O1UJw7cYH753B92dP6B3tqaKFpf.get(key);
    }
    
    public void 9cz7Vn98gE08Y4N68LMaUZqR034r0KI31q3sL1hSrAF18DrcnKIY245062Yk(final byte[] array, final int i) {
        if (i < 0 || i > this.53QH2KJ5zo6OXKxAjRXunVewAx6WgXnO6GbCJeQ37yWnPe5yY0xRDbl631L4 / this.70hCX89P48xycSCGipE9fkNj2AJp9MON2YDKZFT48oK89XF09W8r2cVWcl9M) {
            7l2e0fYR96rf6dpREUY30xWh65d1rOc3abJQrqtvYEW6GNMN9qeJW237wlzS37y9Xt8xV209FRDRzpsI4HOsGN7skzB8a0.100zpjGx871CfQ97LIlXB4L1a18kKl6sZ3OLerqmn87iT5wYRd5Zq70vJ0m3("Received invalid data chunk n" + i);
            return;
        }
        if (this.69qbve9pc68k2c6E45GS5hSEq3SXSsJ379FTUd440fovNX0WhV10IGFqj9Nz.contains(i)) {
            return;
        }
        7l2e0fYR96rf6dpREUY30xWh65d1rOc3abJQrqtvYEW6GNMN9qeJW237wlzS37y9Xt8xV209FRDRzpsI4HOsGN7skzB8a0.4TOtWqH41d7jD9655kwO3Cg5UDFI8gwADO0lrcf8Wo27yqT11iUXxA20819F("Received data chunk n" + i);
        final int n = i * this.70hCX89P48xycSCGipE9fkNj2AJp9MON2YDKZFT48oK89XF09W8r2cVWcl9M;
        int n2 = 1024;
        if (n + this.70hCX89P48xycSCGipE9fkNj2AJp9MON2YDKZFT48oK89XF09W8r2cVWcl9M > this.53QH2KJ5zo6OXKxAjRXunVewAx6WgXnO6GbCJeQ37yWnPe5yY0xRDbl631L4) {
            n2 = this.53QH2KJ5zo6OXKxAjRXunVewAx6WgXnO6GbCJeQ37yWnPe5yY0xRDbl631L4 - n;
        }
        System.arraycopy(array, 0, this.8u4H8s1OU3Y6C3EtLsf7U008wY0JFo6lT55WW90fs2awsRCSuIlxzgDspTR6, i * this.70hCX89P48xycSCGipE9fkNj2AJp9MON2YDKZFT48oK89XF09W8r2cVWcl9M, n2);
        this.4xupnEk7SDlQE5P1MiI6resUDlR1VD77i587eKJotSM16x63HKAv2K174dbE += array.length;
    }
    
    public boolean 9O1NrmW1QwxhgB5D7Vd06gSDyvy5p9L7ScBn1nCcKehSekZg3ig5102xlUI3() {
        return this.4xupnEk7SDlQE5P1MiI6resUDlR1VD77i587eKJotSM16x63HKAv2K174dbE >= this.53QH2KJ5zo6OXKxAjRXunVewAx6WgXnO6GbCJeQ37yWnPe5yY0xRDbl631L4;
    }
    
    static {
        74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX.293hUSlrDZ5KqkEIUf42HQ0MuQ29P6gQ9O1UJw7cYH753B92dP6B3tqaKFpf = new HashMap<String, 74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX>();
    }
}
