import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 4h8d8D1sxxuo126NLHObu8tx9H5tTrLWgQIQBL7I0l4IkV8n9JR51ozmJNqMI1kxU950tUgSibebd54rR11u7UBIe49RF2AgOQ98 extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 6; ++i) {
            final int n4 = n + random.nextInt(8) - random.nextInt(8);
            final int n5 = n2 + random.nextInt(4) - random.nextInt(4);
            final int n6 = n3 + random.nextInt(8) - random.nextInt(8);
            if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n4, n5 - 1, n6) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.950Cje4Cfg220sn9jKZs75F3vi3FLOw4iI1LIhe5y729KT7wW7F3wWvQOBtI.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n4, n5 - 1, n6) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.1Qp0JaZY8j08gNvixC9lTVmYuhPF31BB7EM4Stx7l040d2ADn4eGQuWyK2M5.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                for (int j = 0; j != 5; ++j) {
                    if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n4, n5 + j, n6) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.950Cje4Cfg220sn9jKZs75F3vi3FLOw4iI1LIhe5y729KT7wW7F3wWvQOBtI.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                        break;
                    }
                    if (j == 4) {
                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n4, n5, n6, (random.nextInt(20) > 16) ? 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.81uZUSi4y7jQ4so2Y7YP3Ez7ftqgg9fGqPSsmJMj3MpePRUoT0sQeZXd0QVX.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 : 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.9C2KbpWgwouOhHKOhFQj7I67U7Q95W0rZrEvX59OgCOi3nTgvd9gx8ic68x5.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    }
                }
            }
        }
        return true;
    }
}
