import org.lwjgl.opengl.GL11;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.DataFlavor;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D extends 38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu
{
    public Minecraft 9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr;
    public int 7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s;
    public int 1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b;
    protected List<5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03> 1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX;
    public boolean 93QovqXI4cvpj6v35Vl2mv99720FtE34fwg6Gx681vytU322t104F82pxa90;
    protected 87k6gZdUF64lRd2414n3C9YY0RqdbbURZjg76Q3wg8n1vyhOeSdCGqtgKyQUo9TtGm8AxXBADPj6456Y0svQ4I3QmXX6S4J0 56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ;
    private 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03 7OKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U;
    
    public 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D() {
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX = new ArrayList<5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03>();
        this.93QovqXI4cvpj6v35Vl2mv99720FtE34fwg6Gx681vytU322t104F82pxa90 = false;
        this.7OKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U = null;
    }
    
    public void 9zr0Ft7ATwYEg4elWEB8ucyDaj2700KJgZB3Cc51d8vF03zOM52iOvWHcrR5(final int n, final int n2, final float n3) {
        for (int i = 0; i < this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.size(); ++i) {
            this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(i).43LE10z1ing0357Eco2t24BdeC8Vv9mc8UDcim4TqxbrjvWsF22F2da8709Q(this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr, n, n2);
        }
    }
    
    protected void 27HH93i69891UR8scaUy8Wa381SrOHnrgz1395TWPN543Aw65UPU60a9U5op(final char c, final int n) {
        if (n == 1) {
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(null);
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.3AhGMp6608Ha88cP0AKp402fgrMuur6v37TLnyN944DeKr5Y6m227AaMmY1Y();
        }
    }
    
    public static String 1Ae3liQi6CP5qmL7Ss8k8igZ0509h976JQWj05V83wBG2K1xU29qgQkdc9sT() {
        try {
            final Transferable contents = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
            if (contents != null && contents.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                return (String)contents.getTransferData(DataFlavor.stringFlavor);
            }
        }
        catch (final Exception ex) {}
        return null;
    }
    
    protected void 1Nwq9X5O6zB3l5Q6jlp7vRyJCy003716XQtYd21t186l1xHxa83OF67TpS6Q(final int n, final int n2, final int n3) {
        if (n3 == 0) {
            for (int i = 0; i < this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.size(); ++i) {
                final 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03 7oKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U = this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(i);
                if (7oKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U.0LeWaef80ASn5OrS2pI64995rlF9h6C5L691dcbo1e1SRFnknWGyKa766ET9(this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr, n, n2)) {
                    this.7OKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U = 7oKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U;
                    this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.1FtenBjtbWTQMx7w9NQ2pQqFxhc78G5Djz3ghM24o7Tc21uHI6Cx8s0PaRpG.7m3q7293wukp8hfc9p1yVGT9prA08GR67jGbvL76CEKjlH63f80S8OzHk6Qq("random.click", 1.0f, 1.0f);
                    this.7OD0HqHbYI4579sDX4xzee60N9g9V78YwSmgkc1Y6fyN6rF6JwUqBEU5m77M(7oKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U);
                }
            }
        }
    }
    
    protected void 6RH3eK34C89o4wuSKfpBXYxs6ty2Tyj7NF3iBKo00WBO5X5prrSV2O0UNE7n(final int n, final int n2, final int n3) {
        if (this.7OKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U != null && n3 == 0) {
            this.7OKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U.01U778BzOYfrS183c6jJ9lPiuQUphAZUO397N8V9957A5Dg0Q06bfD8CaXEd(n, n2);
            this.7OKd8BYE3ONDQDjKVpNQ85KYdHKflY952aa901Pv1kIQe91NF4QNE42t4G2U = null;
        }
    }
    
    protected void 7OD0HqHbYI4579sDX4xzee60N9g9V78YwSmgkc1Y6fyN6rF6JwUqBEU5m77M(final 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03 5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03) {
    }
    
    public void 851JTpOHxqz7G83fp0d8u3576qY9jTtr0hkY0J2WJQ8E0xlOpEm857I6xIAl(final Minecraft 9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr, final int 7d1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s, final int 1zgu6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b) {
        this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr = 9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr;
        this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ = 9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.4gTIxYqR91GOe6nJ3qln6t9eH31Cng1A7QRR4E59Vhz8La6hfSFZ0nzE6aF2;
        this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s = 7d1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s;
        this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b = 1zgu6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b;
        this.4An20JYjYn5ahp07NQmWFCuC33T53X6s4pd5325t5MV2inUXBh7is28o5l1C();
    }
    
    public void 4An20JYjYn5ahp07NQmWFCuC33T53X6s4pd5325t5MV2inUXBh7is28o5l1C() {
    }
    
    public void 4yTDY7xv1zcvgnL57Xh4lG3yAot4T912AG58eujB7N8roYLw4ov61evcpcQV() {
        while (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.9a9o5w8761299aY0803nZqT2qfw99G8V4j1mrW5LcuU3ZY53L7hC8tHylrk5()) {
            this.57ZVc0dbIa439OBoT5LigRMatK3S7FXjA5e9ZH67A9ZcXFAe937I3NCTa1mc();
        }
        while (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.9944Y14BKZcYTNPE5RBi0Oa210Zw6zkR0fXN4RSo0p4GLqn28dqcnNjzJa0E()) {
            this.6oau5Z4Zg4P10W079SMCjWVQ441vx3INljL78592Y02r7QgT7s0vT0x0ct60();
        }
    }
    
    public void 57ZVc0dbIa439OBoT5LigRMatK3S7FXjA5e9ZH67A9ZcXFAe937I3NCTa1mc() {
        if (Mouse.getEventButtonState()) {
            this.1Nwq9X5O6zB3l5Q6jlp7vRyJCy003716XQtYd21t186l1xHxa83OF67TpS6Q(Mouse.getEventX() * this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b - Mouse.getEventY() * this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw - 1, Mouse.getEventButton());
        }
        else {
            this.6RH3eK34C89o4wuSKfpBXYxs6ty2Tyj7NF3iBKo00WBO5X5prrSV2O0UNE7n(Mouse.getEventX() * this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b - Mouse.getEventY() * this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw - 1, Mouse.getEventButton());
        }
    }
    
    public void 6oau5Z4Zg4P10W079SMCjWVQ441vx3INljL78592Y02r7QgT7s0vT0x0ct60() {
        if (Keyboard.getEventKeyState()) {
            if (Keyboard.getEventKey() == 87) {
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.5ih4xMEE4EbaRT6o4CA5T809hopo44q7bG9hq5pAZ6GT6gvqHx8F8kw2TFi4();
                return;
            }
            this.27HH93i69891UR8scaUy8Wa381SrOHnrgz1395TWPN543Aw65UPU60a9U5op(Keyboard.getEventCharacter(), Keyboard.getEventKey());
        }
    }
    
    public void 79dcDBX8wOiJ7P492Y177gZw78gOSlsV8lxmDRioLVlEh14o5HL6Utyo3Gfq() {
    }
    
    public void 8QjqiHCzrK6gKACEe1CMZny00Rq3aNdEJ2fZf2Q8T53ugvuH3wUj0meqGRCg() {
    }
    
    public void 43zN406CnnMvKt50m1T5x9TK6olZW559Ze5Um8SL6U0pyu07041JesDT1Mts() {
    }
    
    public void 5S1K79XLhK48s404AETji776rN10k5t6zymKy3FSC71grsr64j85ILV6pJWZ() {
        this.61CwpSt5O3Z0vv7Uru9KS5GE2CXsg8RO9Y642Z255VH8Xhk1g7u8j397N7A4((System.currentTimeMillis() - this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.9A23in1uqW3pg13kj4pOda0YD2W2B8toO2Xk31j7y1F2q5nDP0ompj85iXQC) / 10000.0f);
    }
    
    public void 61CwpSt5O3Z0vv7Uru9KS5GE2CXsg8RO9Y642Z255VH8Xhk1g7u8j397N7A4(final float n) {
        if (this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.8D1HRxTuOIR0Ym42loo9d0NS42Qp45kaXeR154x9Ri712QaegW563ZU96VM0 != null) {
            38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.2423D44YwU0rxXCBAYNu49Ev2WpxKRw67DiwCB63xVXr80FDU91BWvgU90x8(0, 0, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b, -1072689136, -804253680);
        }
        else {
            this.9543IU093L4FN7h2fxI01fXuGLxJN1V9a4Z8Yqj9nu6LIV43eN2P2DZT5Z2F(n);
        }
    }
    
    public void 9543IU093L4FN7h2fxI01fXuGLxJN1V9a4Z8Yqj9nu6LIV43eN2P2DZT5Z2F(final float n) {
        GL11.glDisable(2896);
        GL11.glDisable(2912);
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        GL11.glBindTexture(3553, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8("/dirt.png"));
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        final float n2 = 32.0f;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8v7F8G8g1104wyQ7q86jd6WFsS0S8C9C5G6r53pazN5nIQt79hRlifP4WcDq(3815994);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(0.0, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b, 0.0, 0.0, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / n2 + n);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b, 0.0, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / n2, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / n2 + n);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s, 0.0, 0.0, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / n2, 0.0f + n);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(0.0, 0.0, 0.0, 0.0, 0.0f + n);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
    }
    
    public boolean 7NN3K02F9E90B5R25956d9U4WDVnWznsQl0kmp95I5Lx3ID1gG7QFp81LhMo() {
        return true;
    }
    
    public void 6DYjjJ3ufV0T59OFd18d0IpO0m8PfQ8zDEOBtF3KV6SOjUs3GcCdU9pqOK7i(final boolean b, final int n) {
    }
    
    public void 12PWG4K0hz30euf3TjasOTPOlQHoMn9R6JC1uygYCl5TVnsfQ4haLWrZXH4O() {
    }
}
