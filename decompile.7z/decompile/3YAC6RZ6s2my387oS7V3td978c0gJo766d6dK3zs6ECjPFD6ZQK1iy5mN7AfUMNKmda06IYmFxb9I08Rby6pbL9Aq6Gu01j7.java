import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 3YAC6RZ6s2my387oS7V3td978c0gJo766d6dK3zs6ECjPFD6ZQK1iy5mN7AfUMNKmda06IYmFxb9I08Rby6pbL9Aq6Gu01j7 extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public double 8k8fOf10zE5wV426PW513LOn9XFZ1fW1KN47mham0Q1T1sC2365M6Dmfv50R;
    public double 978sLV88WnWtzqjW7Kxf5652l71IDb0hi79eh44BM0dp8OkX226m1F1932X1;
    public double 0c92r8Qs8QI56bbtotz212jZ1zv438xGfs6d98zejI4990LeJ3v83KBzM8HW;
    public double 11jvlckYUeM123Wigt8l2UK3HC2VeduD17j51f1dGo17bP2oFOPCYYv0323p;
    public float 5LdwW5nHxgifk2K7iGlkzRhrf9gZ81GXEQZ3eVk4G6qor0iyg1k0sn02N6Kp;
    public float 02ig4QYKgL5c7nWgPiD644jsh79AVSZIXB4U7y3gVN8Kjw1nLKK0jonY81GX;
    public boolean 2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e;
    public boolean 29g8SsPmU7TOWROl8YhJNmZ6gRdy8c1X38Dj923Pb9U6366k9qHLOTDay6e1;
    public boolean 04vuai650le37skOuuaCuD1g981wurNsQXbo3O23oV4l4yeKb37061SoTosj;
    
    public 3YAC6RZ6s2my387oS7V3td978c0gJo766d6dK3zs6ECjPFD6ZQK1iy5mN7AfUMNKmda06IYmFxb9I08Rby6pbL9Aq6Gu01j7() {
    }
    
    public 3YAC6RZ6s2my387oS7V3td978c0gJo766d6dK3zs6ECjPFD6ZQK1iy5mN7AfUMNKmda06IYmFxb9I08Rby6pbL9Aq6Gu01j7(final boolean 2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e) {
        this.2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e = 2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e;
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.40n6742Sux72k6283EcTBdX4ZTlK1nwjR2zCucVijOE1L4LC0x2nSbByjm96(this);
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e = (dataInputStream.read() != 0);
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.write(this.2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e ? 1 : 0);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 1;
    }
}
