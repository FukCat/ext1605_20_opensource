import java.util.Iterator;
import java.awt.Component;
import java.awt.Font;
import java.awt.TextArea;
import org.lwjgl.opengl.GL11;
import org.lwjgl.Sys;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Panel;

// 
// Decompiled by Procyon v0.6.0
// 

public class 9hij01kqN0o2FAl605673v1pp8S0nAJrGx5uTq0s4oT5AuH04JalTntqp8W2BLgvFYrfjrp7SDxn9tKBX3Ma4B9LW5Ah0T extends Panel
{
    public 9hij01kqN0o2FAl605673v1pp8S0nAJrGx5uTq0s4oT5AuH04JalTntqp8W2BLgvFYrfjrp7SDxn9tKBX3Ma4B9LW5Ah0T(final 8O94wV86zi53NUGjB4bjuz07OdZ5AQMFj36j262U4havnb1rT68h61Uu6kluKGu3Zt2A50x51X06Z0VPHPWJM7ZjgEn0n32nr 8o94wV86zi53NUGjB4bjuz07OdZ5AQMFj36j262U4havnb1rT68h61Uu6kluKGu3Zt2A50x51X06Z0VPHPWJM7ZjgEn0n32nr) {
        this.setBackground(new Color(3028036));
        this.setLayout(new BorderLayout());
        final StringWriter out = new StringWriter();
        8o94wV86zi53NUGjB4bjuz07OdZ5AQMFj36j262U4havnb1rT68h61Uu6kluKGu3Zt2A50x51X06Z0VPHPWJM7ZjgEn0n32nr.474KbVg8Q6n59T6BN1h3sDex5ZdjJxXHekmysQA0YtNJDBF08Y35WXpYWGQf.printStackTrace(new PrintWriter(out));
        final String string = out.toString();
        String glGetString = "";
        String s = "";
        try {
            s = s + "Generated " + new SimpleDateFormat().format(new Date()) + "\n";
            s += "\n";
            s += "Minecraft: Minecraft Alpha v1.1.2_01\n";
            s = s + "OS: " + System.getProperty("os.name") + " (" + System.getProperty("os.arch") + ") version " + System.getProperty("os.version") + "\n";
            s = s + "Java: " + System.getProperty("java.version") + ", " + System.getProperty("java.vendor") + "\n";
            s = s + "VM: " + System.getProperty("java.vm.name") + " (" + System.getProperty("java.vm.info") + "), " + System.getProperty("java.vm.vendor") + "\n";
            s = s + "LWJGL: " + Sys.getVersion() + "\n";
            glGetString = GL11.glGetString(7936);
            s = s + "OpenGL: " + GL11.glGetString(7937) + " version " + GL11.glGetString(7938) + ", " + GL11.glGetString(7936) + "\n";
        }
        catch (final Throwable obj) {
            s = s + "[failed to get system properties (" + obj + ")]\n";
        }
        final String string2 = s + "\n" + string;
        String s2 = "" + "Mods loaded: " + (00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.7AT2q764kBM4UAhX20130C3Jh6LT7Y5snv3wxjh9e5VP43467B37csjDd1NC().size() + 1) + "\n" + "ModLoader 0.0.1";
        for (final 3QHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU 3qHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU : 00WnnD122947mw77zO8v6GkftyDXlW022S03sNi2s1df1ymf47X38Tbly70ZDQ2L67SqPbKa7lWwttJZoXue45ifeOeCdX.7AT2q764kBM4UAhX20130C3Jh6LT7Y5snv3wxjh9e5VP43467B37csjDd1NC()) {
            s2 = s2 + 3qHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU.getClass().getName() + " " + 3qHo5aINy9U816K39rX6Or2189b9nk1cLg9347wUQ1rJXAjf1bDNx6hG52382D8hkG4GUni0o7O64CgbOben9YsmqUX52qMU.3HY3RzRSYKLKz5s8KcxtYisVs4uBElA3DqDZnYdNY83DB8D1zr0q86pz405R() + "\n";
        }
        final String string3 = s2 + "\n" + "\n";
        String str;
        if (string.contains("Pixel format not accelerated")) {
            str = string3 + "      Bad video card drivers!      \n" + "      -----------------------      \n" + "\n" + "Minecraft was unable to start because it failed to find an accelerated OpenGL mode.\n" + "This can usually be fixed by updating the video card drivers.\n" + "If you're running the experimental Direct3D development branch and you're sure the drivers are installed, please report this to the bug tracker.\n";
            if (glGetString.toLowerCase().contains("nvidia")) {
                str = str + "\n" + "You might be able to find drivers for your video card here:\n" + "  https://www.nvidia.com/Download/index.aspx\n";
            }
            else if (glGetString.toLowerCase().contains("ati") || glGetString.toLowerCase().contains("amd")) {
                str = str + "\n" + "You might be able to find drivers for your video card here:\n" + "  https://www.amd.com/en/support\n";
            }
            else if (glGetString.toLowerCase().contains("4 series express")) {
                str = str + "\n" + "This graphics card does not support OpenGL 2 and will not run the game.\n" + "\n";
            }
            else if (glGetString.toLowerCase().contains("intel")) {
                str = str + "\n" + "You might be able to find drivers for your video card here:\n" + "  https://www.intel.com/content/www/us/en/download-center/home.html\n" + "Do not expect the game to run well on your hardware.\n";
            }
            else if (glGetString.toLowerCase().contains("svga") || glGetString.toLowerCase().contains("llvm") || glGetString.toLowerCase().contains("virtualbox")) {
                str = str + "\n" + "Install the guest OS extensions for your virtual machine.\n" + "  (VMWare Tools, VirtualBox Guest Additions, etc.)\n";
            }
            else if (glGetString.toLowerCase().contains("microsoft basic")) {
                str = str + "\n" + "Failed to detect your video card manufacturer.\n" + "  *If you're using a laptop, search for drivers for your exact model number.\n" + "  *If this is a virtual computer, please install the guest OS extensions for your VM software.\n";
            }
        }
        else {
            str = string3 + "      Minecraft has crashed!      \n" + "      ----------------------      \n" + "\n" + "Minecraft has stopped running because it encountered a problem.\n" + "\n" + "If you wish to report this, please copy this entire text and email it to support@mojang.com.\n" + "Please include a description of what you did when the error occured.\n";
        }
        final String string4 = str + "\n" + "\n" + "\n";
        final String string5 = string4 + "--- BEGIN ERROR REPORT " + Integer.toHexString(string4.hashCode()) + " --------\n" + string2;
        final TextArea comp = new TextArea(string5 + "--- END ERROR REPORT " + Integer.toHexString(string5.hashCode()) + " ----------\n" + "\n" + "\n", 0, 0, 1);
        comp.setFont(new Font("Monospaced", 0, 12));
        this.add(new 3Wk7aObA35sf3WzVJ8L53qX79g2lq5x4B15Wgd88oyCZ0IR5TVPpR1Qnhfdlz0kBtno3pcNSO9P8Fz380ySOdbd35NRz54DUX4ZEb(), "North");
        this.add(new 3jQq9U1tTe2T2c8OcNwuEOcR8juvJ4LOil9PWDLZ3whfD3DjWBRi3lIARRRx5p5y4R9w0Ptgdslrz0r2FaT4xBS32XfmDV4Q7fvKX5(80), "East");
        this.add(new 3jQq9U1tTe2T2c8OcNwuEOcR8juvJ4LOil9PWDLZ3whfD3DjWBRi3lIARRRx5p5y4R9w0Ptgdslrz0r2FaT4xBS32XfmDV4Q7fvKX5(80), "West");
        this.add(new 3jQq9U1tTe2T2c8OcNwuEOcR8juvJ4LOil9PWDLZ3whfD3DjWBRi3lIARRRx5p5y4R9w0Ptgdslrz0r2FaT4xBS32XfmDV4Q7fvKX5(100), "South");
        this.add(comp, "Center");
    }
}
