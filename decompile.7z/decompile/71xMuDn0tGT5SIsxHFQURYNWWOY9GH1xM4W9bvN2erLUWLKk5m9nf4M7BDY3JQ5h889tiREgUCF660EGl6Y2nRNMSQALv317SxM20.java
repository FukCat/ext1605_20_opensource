import java.io.DataInputStream;
import java.io.IOException;
import java.io.DataOutputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 71xMuDn0tGT5SIsxHFQURYNWWOY9GH1xM4W9bvN2erLUWLKk5m9nf4M7BDY3JQ5h889tiREgUCF660EGl6Y2nRNMSQALv317SxM20 implements 7oYzM8i6AvFU5A2Q9o06FwWA68w3Dp2ArdLj15snf6NN0E35Zh0AOuf8ng43ing0w36d96tbAwF90VWODNYhVQUGYNdmdo
{
    @Override
    public byte 178NaXUB1Mz0iKS7p0rb5MLEFW81jOd3BN6381aI9KPCkdKkIoXwIM4720qw() {
        return -96;
    }
    
    @Override
    public void 7oie1kbCv97Ig3BCX7TZjJIg1AUh80OTYa111V0tWp27J3Yv0m4sM0cDA73M(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeByte(17);
    }
    
    @Override
    public void 00qpuBbCmjhi6Voo00BP7Vz6u2bNjtIp8VX76GI1cjCx8C53CK8JhksRhC0t(final DataInputStream dataInputStream) throws IOException {
        System.out.println("Ping request received: " + dataInputStream.readByte());
    }
    
    @Override
    public void 9McPi6cn7jk1268yz5ws1jM9Ej6zIqU0PUg1w25ve46pjZQA5AhEH9c6mX8g(final DataOutputStream dataOutputStream) throws IOException {
    }
    
    @Override
    public int 56te9EBbePs77oy6WX3V8S1Q2019XuigQDcRcK9DT3L43zAusk9Zh8L48wM6() {
        return 1;
    }
}
