// 
// Decompiled by Procyon v0.6.0
// 

public class 9Z1vqCCDX6bh6JskOY97yX0TC3qNS4W2oEyaZVUY88ToPlnl216V042852Ke9IxhJIc0de7B5MP3Bya2BdCRpHETU1WBf5XwUK extends 2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38
{
    protected float[] 19L6j85I73KzggtC263Bm2CLuj118gx0J1Jj6oF1D3KPbIK37GQhswk20O6b;
    protected float[] 6qgb7htBxV9iS4206CTG7j68bT0N24yETfd4C71jd8oD7JZ2HtE9l7wuk7h2;
    protected float[] 5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI;
    protected float[] 4Y5ZdO7QpEG7Rj8REzDkKyf0j6qxPqEx8567lgGKX1CA1J79nROL9gtHBoUQ;
    int 4T3ya0t21yOfl9039V56TS95E9XK7oDopb82th7OVj175rXwli8Mv0lf57NC;
    
    public 9Z1vqCCDX6bh6JskOY97yX0TC3qNS4W2oEyaZVUY88ToPlnl216V042852Ke9IxhJIc0de7B5MP3Bya2BdCRpHETU1WBf5XwUK() {
        super(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.49xZBeNWe5R177er90mO1v746gG1855YFe7aX9c09ydxcA9lB34O4S3qsXqT.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41 + 1);
        this.19L6j85I73KzggtC263Bm2CLuj118gx0J1Jj6oF1D3KPbIK37GQhswk20O6b = new float[256];
        this.6qgb7htBxV9iS4206CTG7j68bT0N24yETfd4C71jd8oD7JZ2HtE9l7wuk7h2 = new float[256];
        this.5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI = new float[256];
        this.4Y5ZdO7QpEG7Rj8REzDkKyf0j6qxPqEx8567lgGKX1CA1J79nROL9gtHBoUQ = new float[256];
        this.4T3ya0t21yOfl9039V56TS95E9XK7oDopb82th7OVj175rXwli8Mv0lf57NC = 0;
        this.2r4qC4o6Ex5Qa6j5s9Q44419BRuE90j03wh4yL3yFS46YmB5u0nSpx5Z6wvl = 2;
    }
    
    @Override
    public void 88ejD45Q8LEgM39W23b9PS53H72qux6CoqBH3EmIU8XRRLm3446Q9e3d4IQv() {
        ++this.4T3ya0t21yOfl9039V56TS95E9XK7oDopb82th7OVj175rXwli8Mv0lf57NC;
        if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb == 2 && !this.88024hG6da4f4kcVfOqR8cTJ36RtCs13wB6V30Rs17vqAj14F4Cqz3neFg20) {
            return;
        }
        this.88024hG6da4f4kcVfOqR8cTJ36RtCs13wB6V30Rs17vqAj14F4Cqz3neFg20 = false;
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 16; ++j) {
                float n = 0.0f;
                final int n2 = (int)(5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(j * 3.1415927f * 2.0f / 16.0f) * 1.2f);
                final int n3 = (int)(5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(i * 3.1415927f * 2.0f / 16.0f) * 1.2f);
                for (int k = i - 1; k <= i + 1; ++k) {
                    for (int l = j - 1; l <= j + 1; ++l) {
                        n += this.19L6j85I73KzggtC263Bm2CLuj118gx0J1Jj6oF1D3KPbIK37GQhswk20O6b[(k + n2 & 0xF) + (l + n3 & 0xF) * 16];
                    }
                }
                this.6qgb7htBxV9iS4206CTG7j68bT0N24yETfd4C71jd8oD7JZ2HtE9l7wuk7h2[i + j * 16] = n / 10.0f + (this.5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI[(i + 0 & 0xF) + (j + 0 & 0xF) * 16] + this.5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI[(i + 1 & 0xF) + (j + 0 & 0xF) * 16] + this.5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI[(i + 1 & 0xF) + (j + 1 & 0xF) * 16] + this.5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI[(i + 0 & 0xF) + (j + 1 & 0xF) * 16]) / 4.0f * 0.8f;
                final float[] 5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI = this.5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI;
                final int n4 = i + j * 16;
                5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI[n4] += this.4Y5ZdO7QpEG7Rj8REzDkKyf0j6qxPqEx8567lgGKX1CA1J79nROL9gtHBoUQ[i + j * 16] * 0.01f;
                if (this.5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI[i + j * 16] < 0.0f) {
                    this.5mH6uQ30sbBYw379GC4b2J65gYFtDl98kzQ2qqwDSX414Ota56UkdtJ3NHOI[i + j * 16] = 0.0f;
                }
                final float[] 4y5ZdO7QpEG7Rj8REzDkKyf0j6qxPqEx8567lgGKX1CA1J79nROL9gtHBoUQ = this.4Y5ZdO7QpEG7Rj8REzDkKyf0j6qxPqEx8567lgGKX1CA1J79nROL9gtHBoUQ;
                final int n5 = i + j * 16;
                4y5ZdO7QpEG7Rj8REzDkKyf0j6qxPqEx8567lgGKX1CA1J79nROL9gtHBoUQ[n5] -= 0.06f;
                if (Math.random() < 0.005) {
                    this.4Y5ZdO7QpEG7Rj8REzDkKyf0j6qxPqEx8567lgGKX1CA1J79nROL9gtHBoUQ[i + j * 16] = 1.5f;
                }
            }
        }
        final float[] 6qgb7htBxV9iS4206CTG7j68bT0N24yETfd4C71jd8oD7JZ2HtE9l7wuk7h2 = this.6qgb7htBxV9iS4206CTG7j68bT0N24yETfd4C71jd8oD7JZ2HtE9l7wuk7h2;
        this.6qgb7htBxV9iS4206CTG7j68bT0N24yETfd4C71jd8oD7JZ2HtE9l7wuk7h2 = this.19L6j85I73KzggtC263Bm2CLuj118gx0J1Jj6oF1D3KPbIK37GQhswk20O6b;
        this.19L6j85I73KzggtC263Bm2CLuj118gx0J1Jj6oF1D3KPbIK37GQhswk20O6b = 6qgb7htBxV9iS4206CTG7j68bT0N24yETfd4C71jd8oD7JZ2HtE9l7wuk7h2;
        for (int n6 = 0; n6 < 256; ++n6) {
            float n7 = this.19L6j85I73KzggtC263Bm2CLuj118gx0J1Jj6oF1D3KPbIK37GQhswk20O6b[n6 - this.4T3ya0t21yOfl9039V56TS95E9XK7oDopb82th7OVj175rXwli8Mv0lf57NC / 3 * 16 & 0xFF] * 2.0f;
            if (n7 > 1.0f) {
                n7 = 1.0f;
            }
            if (n7 < 0.0f) {
                n7 = 0.0f;
            }
            int n8 = (int)(n7 * 100.0f + 155.0f);
            int n9 = (int)(n7 * n7 * 255.0f);
            int n10 = (int)(n7 * n7 * n7 * n7 * 128.0f);
            if (this.06P3mXenpD5L0FS19r771z79X4G6ToUmlYYq950W8EH6ukeiX4WQd6Wqr2uA) {
                final int n11 = (n8 * 30 + n9 * 59 + n10 * 11) / 100;
                final int n12 = (n8 * 30 + n9 * 70) / 100;
                final int n13 = (n8 * 30 + n10 * 70) / 100;
                n8 = n11;
                n9 = n12;
                n10 = n13;
            }
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n6 * 4 + 0] = (byte)n8;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n6 * 4 + 1] = (byte)n9;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n6 * 4 + 2] = (byte)n10;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n6 * 4 + 3] = -1;
        }
    }
}
