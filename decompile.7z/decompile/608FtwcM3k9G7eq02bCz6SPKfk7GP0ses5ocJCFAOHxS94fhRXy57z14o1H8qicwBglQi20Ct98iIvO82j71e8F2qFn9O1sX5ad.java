import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.HashMap;
import java.util.Map;

// 
// Decompiled by Procyon v0.6.0
// 

public class 608FtwcM3k9G7eq02bCz6SPKfk7GP0ses5ocJCFAOHxS94fhRXy57z14o1H8qicwBglQi20Ct98iIvO82j71e8F2qFn9O1sX5ad extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    public static int 9HHBzQ2wG84LFbc45tMzL7mAlvvdO1k855mGGSfk3FfJP80LupQs710X4K6J;
    private final Map<61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, BuiltTowerData> 9IWUn864qx5IO5om711HK5Sftm12yv0GK3QrtVY84g747HU1IztC3G1RDFZ6;
    private final HashMap<61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, 6Y7d30NlN02jwr27E4HzDI45IfqGaS0p2W745eF5l7ikrMbT9LYF9sKsHL5XRsTsBDwZ2w1qdTgxekF5f5FkMhNzktKqhu8R11> 6A95w6TCKMljjJy1nntH1rW395Pix9TTxJ3jQYOCs5ip238cYFQFYZLOL6xM;
    
    private BuiltTowerData 4bSggIjY4Y8PdaaH85z1zIqMCNm5aG4TqjidsQP1lxcesP15aXOIcvtKAyC8(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3, final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, final int n4) {
        return this.9pTy4yiDSYYiMgi1p82kZR862lr5vjJNqdi8KePH7dH2wrISOg522L69fb4R(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random, n, n2, n3, 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, n4, new 5rSInBXm7HKSAmGQ1u2CafkxN5Mt2s99G2r7c09ngDn3u88Y0yfnXT1RZjYo8SCiOp4X0sMJ27brEGIPm6BnC6uqev14i4F1<Integer>(0));
    }
    
    private BuiltTowerData 9pTy4yiDSYYiMgi1p82kZR862lr5vjJNqdi8KePH7dH2wrISOg522L69fb4R(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, int n2, final int n3, final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, final int n4, final 5rSInBXm7HKSAmGQ1u2CafkxN5Mt2s99G2r7c09ngDn3u88Y0yfnXT1RZjYo8SCiOp4X0sMJ27brEGIPm6BnC6uqev14i4F1<Integer> 5rSInBXm7HKSAmGQ1u2CafkxN5Mt2s99G2r7c09ngDn3u88Y0yfnXT1RZjYo8SCiOp4X0sMJ27brEGIPm6BnC6uqev14i4F1) {
        if (this.9IWUn864qx5IO5om711HK5Sftm12yv0GK3QrtVY84g747HU1IztC3G1RDFZ6.containsKey(61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3)) {
            return null;
        }
        this.9IWUn864qx5IO5om711HK5Sftm12yv0GK3QrtVY84g747HU1IztC3G1RDFZ6.put(61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, null);
        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3) != 0) {
            return null;
        }
        while (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3) == 0) {
            if (--n2 <= 0) {
                return null;
            }
        }
        if (n2 > 104) {
            return null;
        }
        n2 /= 4;
        n2 = ++n2 * 4;
        final int n5 = 3 + random.nextInt(3);
        final int bound = (116 - n2) / 4 - 2;
        if (bound <= 0) {
            return null;
        }
        final int n6 = 2 + random.nextInt(bound);
        final BuiltTowerData builtTowerData = new BuiltTowerData(n5, n6, n, n2, n3);
        for (int i = -n5 + 1; i <= n5 - 1; ++i) {
            for (int j = 1; j <= 3; ++j) {
                for (int k = 0; k <= n6; ++k) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(i + n, n2 + 4 * k + j, -n5 + 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(i + n, n2 + 4 * k + j, n5 - 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + 1 + n, n2 + 4 * k + j, i + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 - 1 + n, n2 + 4 * k + j, i + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                }
            }
        }
        for (int l = -n5; l <= n5; ++l) {
            for (int n7 = -n5; n7 <= n5; ++n7) {
                for (int n8 = 0; n8 <= n6 + 1; ++n8) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(l + n, n2 + 4 * n8, n7 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5b870FXjZe31QTVxGhJM6x7TBSM55LgXdJyW1W74JmVdE6F4lqoX11wb0HS9.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                }
            }
        }
        for (int n9 = 1; n9 <= 3; ++n9) {
            for (int n10 = 0; n10 <= n6; ++n10) {
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 + n, n2 + 4 * n10 + n9, -n5 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + n, n2 + 4 * n10 + n9, n5 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + n, n2 + 4 * n10 + n9, -n5 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 + n, n2 + 4 * n10 + n9, n5 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            }
        }
        for (int n11 = -n5 + 1; n11 <= n5 - 1; ++n11) {
            for (int n12 = -n5 + 1; n12 <= n5 - 1; ++n12) {
                for (int n13 = n2 - 1; n13 > 0 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n11 + n, n13, n12 + n3) == 0; --n13) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n11 + n, n13, n12 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                }
            }
        }
        for (int n14 = 0; n14 < n6; ++n14) {
            final int n15 = n2 + 1 + 4 * n14;
            final BuiltWallKind[] array = new BuiltWallKind[4];
            builtTowerData.7EQ6jd3x88fSv4M9BHi7s57Y778Lr34WSc98fXK3YndnTY5T4cO73NCZv1zn.add(array);
            for (int n16 = 0; n16 < 4; ++n16) {
                array[n16] = BuiltWallKind.8RxQ5xG7RufIZZxNcu3zdoGMwr9yZujizBq84i9R2h9BM8rEB4741BO6z3Mu;
            }
            for (int n17 = 0; n17 < 4; ++n17) {
                int n18 = 0;
                int n19 = (n17 & 0x2) - 1;
                if (n17 % 2 == 1) {
                    n18 = n19;
                    n19 = 0;
                }
                int n20 = n18 * (n5 - 1) + n;
                int n21 = n19 * (n5 - 1) + n3;
                switch (random.nextInt(5)) {
                    case 1: {
                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n20, n15 + 1, n21, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.8OGjS32UzjFHn823L2QOCQDofpd96BPBmI3xdJ74g75C5Wx1UNE4f2575Yhd.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                        array[n17] = BuiltWallKind.7a0YItcP7wbYYOx65GpAq37ptJ925PDlKC8mnOe1ll9DkdKke0P58IkjakSx;
                        break;
                    }
                    case 2: {
                        final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot4 = new 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3(61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3.5ZR6ielH0gxIT8YmA1m4F65rkWUs4cP2723lV4Hy6tl6rO7opLrvOyTWthww() + n18, 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3.47IAru15P2DzBMMdHFDJNZXRKMMGzW0ZSLEGX87l25z9CdPzg63Pq5T04vvr() + n19);
                        if (this.9IWUn864qx5IO5om711HK5Sftm12yv0GK3QrtVY84g747HU1IztC3G1RDFZ6.containsKey(61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot4)) {
                            break;
                        }
                        array[n17] = BuiltWallKind.7Bel03OLB1X02Eu48ke9LrabzepVgQ8bDY7W9XD0ri16OrQn06w4qSE13Hz3;
                        int n22 = 0;
                        while (n22 <= n4 / 2 + 1) {
                            if (random.nextInt(n4 + 1) == 0 && 5rSInBXm7HKSAmGQ1u2CafkxN5Mt2s99G2r7c09ngDn3u88Y0yfnXT1RZjYo8SCiOp4X0sMJ27brEGIPm6BnC6uqev14i4F1.0yKQEI9scMQYs2U79FTz0taKE8d93C90G8erLBZDQ88O3Q6XJ3zC1l0lXK1q < 608FtwcM3k9G7eq02bCz6SPKfk7GP0ses5ocJCFAOHxS94fhRXy57z14o1H8qicwBglQi20Ct98iIvO82j71e8F2qFn9O1sX5ad.9HHBzQ2wG84LFbc45tMzL7mAlvvdO1k855mGGSfk3FfJP80LupQs710X4K6J) {
                                final Integer n23 = 5rSInBXm7HKSAmGQ1u2CafkxN5Mt2s99G2r7c09ngDn3u88Y0yfnXT1RZjYo8SCiOp4X0sMJ27brEGIPm6BnC6uqev14i4F1.0yKQEI9scMQYs2U79FTz0taKE8d93C90G8erLBZDQ88O3Q6XJ3zC1l0lXK1q;
                                ++5rSInBXm7HKSAmGQ1u2CafkxN5Mt2s99G2r7c09ngDn3u88Y0yfnXT1RZjYo8SCiOp4X0sMJ27brEGIPm6BnC6uqev14i4F1.0yKQEI9scMQYs2U79FTz0taKE8d93C90G8erLBZDQ88O3Q6XJ3zC1l0lXK1q;
                                final int n24 = n5 + 8 + random.nextInt(3);
                                final BuiltTowerData 9pTy4yiDSYYiMgi1p82kZR862lr5vjJNqdi8KePH7dH2wrISOg522L69fb4R = this.9pTy4yiDSYYiMgi1p82kZR862lr5vjJNqdi8KePH7dH2wrISOg522L69fb4R(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random, n + n18 * n24, 128, n3 + n19 * n24, 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot4, n4 + 1, 5rSInBXm7HKSAmGQ1u2CafkxN5Mt2s99G2r7c09ngDn3u88Y0yfnXT1RZjYo8SCiOp4X0sMJ27brEGIPm6BnC6uqev14i4F1);
                                if (9pTy4yiDSYYiMgi1p82kZR862lr5vjJNqdi8KePH7dH2wrISOg522L69fb4R == null) {
                                    break;
                                }
                                if (9pTy4yiDSYYiMgi1p82kZR862lr5vjJNqdi8KePH7dH2wrISOg522L69fb4R.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + (9pTy4yiDSYYiMgi1p82kZR862lr5vjJNqdi8KePH7dH2wrISOg522L69fb4R.7fAKjHW1LE847OSwtPxt16L6WGEi68u7u6fWOmkZTpO3ZbiE0TR39wTva1vJ + 1) * 4 < n15) {
                                    break;
                                }
                                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n20, n15, n21, 0);
                                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n20, n15 + 1, n21, 0);
                                for (int n25 = n5; n25 < n24 - 9pTy4yiDSYYiMgi1p82kZR862lr5vjJNqdi8KePH7dH2wrISOg522L69fb4R.5UJO83Sal8307YLDFyzIt779v5qD6812ur6y32x891iN95OgW8FOAZDB1pNG + 1; ++n25) {
                                    n20 += n18;
                                    n21 += n19;
                                    for (int n26 = -1; n26 <= 1; ++n26) {
                                        for (int n27 = -1; n27 <= 1; ++n27) {
                                            if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n20 + n26, n15 - 1, n21 + n27) == 0) {
                                                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n20 + n26, n15 - 1, n21 + n27, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.06BTam40bi3j67w6q8lm047ICOMDdGWW4Ap366op029l0DK75g9lM9V1URF7.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                                            }
                                        }
                                    }
                                }
                                final int n28 = n20 + n18;
                                final int n29 = n21 + n19;
                                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n28, n15, n29, 0);
                                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n28, n15 + 1, n29, 0);
                                break;
                            }
                            else {
                                ++n22;
                            }
                        }
                        break;
                    }
                }
            }
        }
        final int n30 = n2 + (n6 + 1) * 4 + 1;
        for (int n31 = 0; n31 <= 1; ++n31) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 + n, n30 + n31, -n5 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + n, n30 + n31, n5 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + n, n30 + n31, -n5 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 + n, n30 + n31, n5 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
        }
        if (random.nextInt(10) == 0) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, n30 + n5, n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.879S0d0sDlpb57n4lgD5WLQ2b15v75xf43HGO03X6vZGc51i112X58Aw9Rre.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, n30 + n5 - 1, n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4s490iSB84a1ak91zjamWQ0U46B6upao0X554xpJr36089k30bfGDBc4ljNA.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            for (int n32 = 0; n32 < n5 - 1; ++n32) {
                for (int n33 = -n5 + 1 + n32; n33 <= n5 - 1 - n32; ++n33) {
                    for (int n34 = -n5 + 1 + n32; n34 <= n5 - 1 - n32; ++n34) {
                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n + n33, n30 + n32, n3 + n34, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.80DRb9NBFx40sOj7ivT3h54UGJ6wOg3Ch87TYwGN65040bs78131evVc1Ps8.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    }
                }
            }
        }
        else {
            for (int n35 = 0; n35 <= 1; ++n35) {
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 - 1 + n, n30 + n35, -n5 + 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + 1 + n, n30 + n35, n5 - 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + 1 + n, n30 + n35, -n5 + 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 - 1 + n, n30 + n35, n5 - 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            }
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 - 2 + n, n30, -n5 + 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + 2 + n, n30, n5 - 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + 2 + n, n30, -n5 + 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 - 2 + n, n30, n5 - 1 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 - 1 + n, n30, -n5 + 2 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + 1 + n, n30, n5 - 2 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(-n5 + 1 + n, n30, -n5 + 2 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5 - 1 + n, n30, n5 - 2 + n3, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5u3luNCa31aF933S5jC3EFxU5kEwWbZhG354222X0R6RS473RG803xHNA79a.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
        }
        for (int n36 = 0; n36 <= n6; ++n36) {
            if (n6 != n36) {
                final int nextInt = random.nextInt(4);
                final int n37 = (1 + random.nextInt(n5 - 2)) * (random.nextInt(2) * 2 - 1);
                int n38 = 0;
                int n39 = 0;
                switch (nextInt) {
                    case 0: {
                        n38 = n + n37;
                        n39 = n3 + n5 - 2;
                        break;
                    }
                    case 1: {
                        n38 = n + n37;
                        n39 = n3 - n5 + 2;
                        break;
                    }
                    case 2: {
                        n38 = n + n5 - 2;
                        n39 = n3 + n37;
                        break;
                    }
                    case 3: {
                        n38 = n - n5 + 2;
                        n39 = n3 + n37;
                        break;
                    }
                }
                for (int n40 = 1; n40 <= 4; ++n40) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n38, n2 + n40 + n36 * 4, n39, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.83p1oFLEIQ01IqRqdN94n0DV302qCg887Vks8zcCCwc93cnJn4j8Vb2I1IDY.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6wp59FCGZy0ODNzS0pC7TuicUh1KtawD0iSOIwB0w904q95SD9Ydn8rC7X3H(n38, n2 + n40 + n36 * 4, n39, nextInt + 2);
                }
            }
        }
        this.9IWUn864qx5IO5om711HK5Sftm12yv0GK3QrtVY84g747HU1IztC3G1RDFZ6.put(61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, builtTowerData);
        return builtTowerData;
    }
    
    private void 00EILg3OmCfJhYO3i3J4ybeenZj4OZ0JmTbQvREppfrHT8BnI9Z3yfR0OsE4(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random) {
        for (final Map.Entry entry : this.9IWUn864qx5IO5om711HK5Sftm12yv0GK3QrtVY84g747HU1IztC3G1RDFZ6.entrySet()) {
            if (entry.getValue() == null) {
                continue;
            }
            if (((BuiltTowerData)entry.getValue()).7fAKjHW1LE847OSwtPxt16L6WGEi68u7u6fWOmkZTpO3ZbiE0TR39wTva1vJ < 8) {
                continue;
            }
            final BuiltTowerData builtTowerData = (BuiltTowerData)entry.getValue();
        Label_0956:
            for (int i = 4; i < builtTowerData.7fAKjHW1LE847OSwtPxt16L6WGEi68u7u6fWOmkZTpO3ZbiE0TR39wTva1vJ - 3; ++i) {
                int j = 0;
            Label_0099:
                while (j < 4) {
                    int n;
                    int n2;
                    while (true) {
                        for (int k = 0; k < 3; ++k) {
                            if (builtTowerData.7EQ6jd3x88fSv4M9BHi7s57Y778Lr34WSc98fXK3YndnTY5T4cO73NCZv1zn.get(i + k)[j] != BuiltWallKind.8RxQ5xG7RufIZZxNcu3zdoGMwr9yZujizBq84i9R2h9BM8rEB4741BO6z3Mu) {
                                ++j;
                                continue Label_0099;
                            }
                        }
                        n = 0;
                        n2 = (j & 0x2) - 1;
                        if (j % 2 == 1) {
                            n = n2;
                            n2 = 0;
                        }
                        final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 = new 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3((61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3)entry.getKey());
                        61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3.0t72uE0X6e9X1lk504mMn0Usl2040LLyJIqoCM5A8QY4qQ7Bui0LPvUn4qLg(n, n2);
                        final BuiltTowerData builtTowerData2 = this.9IWUn864qx5IO5om711HK5Sftm12yv0GK3QrtVY84g747HU1IztC3G1RDFZ6.get(61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3);
                        if (builtTowerData2 != null && Math.max(Math.abs(builtTowerData2.8ceUXPOD34dVCWOlpGT5Do01b84rla5c3oO5uc195z07QUJ9oHb4k9hRdKb9 - builtTowerData.8ceUXPOD34dVCWOlpGT5Do01b84rla5c3oO5uc195z07QUJ9oHb4k9hRdKb9), Math.abs(builtTowerData2.8ceUXPOD34dVCWOlpGT5Do01b84rla5c3oO5uc195z07QUJ9oHb4k9hRdKb9 - builtTowerData.8ceUXPOD34dVCWOlpGT5Do01b84rla5c3oO5uc195z07QUJ9oHb4k9hRdKb9)) - builtTowerData2.5UJO83Sal8307YLDFyzIt779v5qD6812ur6y32x891iN95OgW8FOAZDB1pNG - builtTowerData.5UJO83Sal8307YLDFyzIt779v5qD6812ur6y32x891iN95OgW8FOAZDB1pNG < 5) {
                            continue;
                        }
                        if (random.nextInt(10) != 0) {
                            continue;
                        }
                        break;
                    }
                    final int n3 = n * builtTowerData.5UJO83Sal8307YLDFyzIt779v5qD6812ur6y32x891iN95OgW8FOAZDB1pNG + builtTowerData.8ceUXPOD34dVCWOlpGT5Do01b84rla5c3oO5uc195z07QUJ9oHb4k9hRdKb9;
                    final int n4 = n2 * builtTowerData.5UJO83Sal8307YLDFyzIt779v5qD6812ur6y32x891iN95OgW8FOAZDB1pNG + builtTowerData.2QgdUt39i2D2kz0DVgEK57x7SbqDO3VF01u5FKjDkJE4E2TM9g1sTnjxdetP;
                    int n5 = n2;
                    int n6 = n;
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n3, builtTowerData.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + i * 4 + 2, n4, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.9ss0X6v3Nx9y1WzivQAPz91Gy6i9a700E28q5i26942nIbD2Qt6f9H69yeCl.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n3, builtTowerData.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + i * 4 + 8, n4, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.9ss0X6v3Nx9y1WzivQAPz91Gy6i9a700E28q5i26942nIbD2Qt6f9H69yeCl.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n3 + n, builtTowerData.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + i * 4 + 2, n4 + n2, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.9ss0X6v3Nx9y1WzivQAPz91Gy6i9a700E28q5i26942nIbD2Qt6f9H69yeCl.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n3 + n, builtTowerData.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + i * 4 + 8, n4 + n2, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.9ss0X6v3Nx9y1WzivQAPz91Gy6i9a700E28q5i26942nIbD2Qt6f9H69yeCl.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    final int[] array = { random.nextInt(5) + 1, random.nextInt(5) + 1, random.nextInt(5) + 1, random.nextInt(5) + 1 };
                    while (Math.abs(array[0] - array[2]) == 1) {
                        array[0] = random.nextInt(5) + 1;
                        array[2] = random.nextInt(5) + 1;
                    }
                    while (Math.abs(array[1] - array[3]) == 1) {
                        array[1] = random.nextInt(5) + 1;
                        array[3] = random.nextInt(5) + 1;
                    }
                    for (int l = builtTowerData.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + i * 4 + 1; l <= builtTowerData.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + i * 4 + 9; ++l) {
                        for (int n7 = 0; n7 < 3; ++n7) {
                            final boolean b = n7 == 1 && l != builtTowerData.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + i * 4 + 1 && l != builtTowerData.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + i * 4 + 9;
                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n3 + n * (2 + n7), l, n4 + n2 * (2 + n7), b ? 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.6AN0LupYtF4omLes2y3hwBk9WjEQv204WZBoW5kFkWrLC91GarF3zYYI4R64.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 : 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4Nx15FPmG5qva6iT9ZT03jNGp0AWU7hx7Wim64378IwGuo4zm48SK91Q5xp2.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                            if (b) {
                                for (int n8 = -1; n8 <= 1; n8 += 2) {
                                    int n9 = 0;
                                    final int n10 = n5 * n8;
                                    final int n11 = n6 * n8;
                                    if (n10 == 1) {
                                        n9 = 5;
                                    }
                                    else if (n10 == -1) {
                                        n9 = 4;
                                    }
                                    else if (n11 == 1) {
                                        n9 = 3;
                                    }
                                    else if (n11 == -1) {
                                        n9 = 2;
                                    }
                                    n5 = n10 * n8;
                                    n6 = n11 * n8;
                                    final int n12 = l - (builtTowerData.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 + i * 4 + 1);
                                    if (n12 != array[n8 + 1]) {
                                        if (n12 != array[n8 + 2]) {
                                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.662aRVUQNq17a2fcf2tjXq7e5kKBxqcO9kwyyO7e48nn4jEdQ5N1h8976S8H(n3 + n * (2 + n7) + n5 * n8, l, n4 + n2 * (2 + n7) + n6 * n8, (random.nextBoolean() ? 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.01IuIZMmb29pk17tNAC6RI1E4Nc22U45HjA8b75Ocu99w4YP8zdedACN0z63.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 : 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.9GO6moZwP6lZ0cPwE68d4vq2f51o2m7jecpo125MAaZnSEMC93VstTR33803.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) + random.nextInt(5), n9);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break Label_0956;
                }
            }
        }
    }
    
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int a, final int n, final int a2) {
        if (Math.abs(a) < 64 && Math.abs(a2) < 64) {
            return false;
        }
        this.4bSggIjY4Y8PdaaH85z1zIqMCNm5aG4TqjidsQP1lxcesP15aXOIcvtKAyC8(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random, a, n, a2, new 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3(1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.8Hz7yQrbpttYl62r56lFe782dI9GJEm7d3W4768d4S2Iay7QH2DbzVf66DGe(a, 196), 1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.8Hz7yQrbpttYl62r56lFe782dI9GJEm7d3W4768d4S2Iay7QH2DbzVf66DGe(a2, 196)), 0);
        this.00EILg3OmCfJhYO3i3J4ybeenZj4OZ0JmTbQvREppfrHT8BnI9Z3yfR0OsE4(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random);
        return true;
    }
    
    private 6Y7d30NlN02jwr27E4HzDI45IfqGaS0p2W745eF5l7ikrMbT9LYF9sKsHL5XRsTsBDwZ2w1qdTgxekF5f5FkMhNzktKqhu8R11 6dKE8W4m3r1pcJ4AkaSl4NNeJjf9Xu15ce9m1bEB2krev7jJONoh6b6cnMkv(final int n, final int n2, final Random random) {
        final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 key = new 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3(n / 1000, n2 / 1000);
        if (this.6A95w6TCKMljjJy1nntH1rW395Pix9TTxJ3jQYOCs5ip238cYFQFYZLOL6xM.containsKey(key)) {
            return this.6A95w6TCKMljjJy1nntH1rW395Pix9TTxJ3jQYOCs5ip238cYFQFYZLOL6xM.get(key);
        }
        final 6Y7d30NlN02jwr27E4HzDI45IfqGaS0p2W745eF5l7ikrMbT9LYF9sKsHL5XRsTsBDwZ2w1qdTgxekF5f5FkMhNzktKqhu8R11 value = new 6Y7d30NlN02jwr27E4HzDI45IfqGaS0p2W745eF5l7ikrMbT9LYF9sKsHL5XRsTsBDwZ2w1qdTgxekF5f5FkMhNzktKqhu8R11(random, key);
        this.6A95w6TCKMljjJy1nntH1rW395Pix9TTxJ3jQYOCs5ip238cYFQFYZLOL6xM.put(key, value);
        return value;
    }
    
    public 608FtwcM3k9G7eq02bCz6SPKfk7GP0ses5ocJCFAOHxS94fhRXy57z14o1H8qicwBglQi20Ct98iIvO82j71e8F2qFn9O1sX5ad(final Random random) {
        this.9IWUn864qx5IO5om711HK5Sftm12yv0GK3QrtVY84g747HU1IztC3G1RDFZ6 = new HashMap<61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, BuiltTowerData>();
        this.6A95w6TCKMljjJy1nntH1rW395Pix9TTxJ3jQYOCs5ip238cYFQFYZLOL6xM = new HashMap<61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3, 6Y7d30NlN02jwr27E4HzDI45IfqGaS0p2W745eF5l7ikrMbT9LYF9sKsHL5XRsTsBDwZ2w1qdTgxekF5f5FkMhNzktKqhu8R11>();
    }
    
    static {
        608FtwcM3k9G7eq02bCz6SPKfk7GP0ses5ocJCFAOHxS94fhRXy57z14o1H8qicwBglQi20Ct98iIvO82j71e8F2qFn9O1sX5ad.9HHBzQ2wG84LFbc45tMzL7mAlvvdO1k855mGGSfk3FfJP80LupQs710X4K6J = 25;
    }
    
    private enum BuiltWallKind
    {
        8RxQ5xG7RufIZZxNcu3zdoGMwr9yZujizBq84i9R2h9BM8rEB4741BO6z3Mu, 
        7a0YItcP7wbYYOx65GpAq37ptJ925PDlKC8mnOe1ll9DkdKke0P58IkjakSx, 
        7Bel03OLB1X02Eu48ke9LrabzepVgQ8bDY7W9XD0ri16OrQn06w4qSE13Hz3;
        
        private static final /* synthetic */ BuiltWallKind[] 5DU1q74wG2K77T0ZlI5W44FAm2Aqv24mz96pa1X88RzMmFVm14Nd108r12n7;
        
        public static BuiltWallKind[] 4tXyU6RR6cO5Zi9fhjc1I7QG04yEjq6wDM4jfxZmi73mP7096R32YLzn7IGX() {
            return BuiltWallKind.5DU1q74wG2K77T0ZlI5W44FAm2Aqv24mz96pa1X88RzMmFVm14Nd108r12n7.clone();
        }
        
        public static BuiltWallKind 3bJVQ5UBqfon6Z5wNWq1ljNFCUy7Nd7D5ry055OWEwBqFQL3zv4n846H20r2(final String name) {
            return Enum.valueOf(BuiltWallKind.class, name);
        }
        
        private static /* synthetic */ BuiltWallKind[] 3rJo3AK4ECqk7FlHfgl5vc5v87WG6Az39tfJ21SGO8a04eMpmI46iJ91MZm6() {
            return new BuiltWallKind[] { BuiltWallKind.8RxQ5xG7RufIZZxNcu3zdoGMwr9yZujizBq84i9R2h9BM8rEB4741BO6z3Mu, BuiltWallKind.7a0YItcP7wbYYOx65GpAq37ptJ925PDlKC8mnOe1ll9DkdKke0P58IkjakSx, BuiltWallKind.7Bel03OLB1X02Eu48ke9LrabzepVgQ8bDY7W9XD0ri16OrQn06w4qSE13Hz3 };
        }
        
        static {
            5DU1q74wG2K77T0ZlI5W44FAm2Aqv24mz96pa1X88RzMmFVm14Nd108r12n7 = 3rJo3AK4ECqk7FlHfgl5vc5v87WG6Az39tfJ21SGO8a04eMpmI46iJ91MZm6();
        }
    }
    
    private static class BuiltTowerData
    {
        public int 5UJO83Sal8307YLDFyzIt779v5qD6812ur6y32x891iN95OgW8FOAZDB1pNG;
        public int 7fAKjHW1LE847OSwtPxt16L6WGEi68u7u6fWOmkZTpO3ZbiE0TR39wTva1vJ;
        public int 8ceUXPOD34dVCWOlpGT5Do01b84rla5c3oO5uc195z07QUJ9oHb4k9hRdKb9;
        public int 2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3;
        public int 2QgdUt39i2D2kz0DVgEK57x7SbqDO3VF01u5FKjDkJE4E2TM9g1sTnjxdetP;
        public List<BuiltWallKind[]> 7EQ6jd3x88fSv4M9BHi7s57Y778Lr34WSc98fXK3YndnTY5T4cO73NCZv1zn;
        
        public BuiltTowerData(final int 5ujo83Sal8307YLDFyzIt779v5qD6812ur6y32x891iN95OgW8FOAZDB1pNG, final int 7fAKjHW1LE847OSwtPxt16L6WGEi68u7u6fWOmkZTpO3ZbiE0TR39wTva1vJ, final int 8ceUXPOD34dVCWOlpGT5Do01b84rla5c3oO5uc195z07QUJ9oHb4k9hRdKb9, final int 2h1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3, final int 2QgdUt39i2D2kz0DVgEK57x7SbqDO3VF01u5FKjDkJE4E2TM9g1sTnjxdetP) {
            this.7EQ6jd3x88fSv4M9BHi7s57Y778Lr34WSc98fXK3YndnTY5T4cO73NCZv1zn = new ArrayList<BuiltWallKind[]>();
            this.5UJO83Sal8307YLDFyzIt779v5qD6812ur6y32x891iN95OgW8FOAZDB1pNG = 5ujo83Sal8307YLDFyzIt779v5qD6812ur6y32x891iN95OgW8FOAZDB1pNG;
            this.7fAKjHW1LE847OSwtPxt16L6WGEi68u7u6fWOmkZTpO3ZbiE0TR39wTva1vJ = 7fAKjHW1LE847OSwtPxt16L6WGEi68u7u6fWOmkZTpO3ZbiE0TR39wTva1vJ;
            this.8ceUXPOD34dVCWOlpGT5Do01b84rla5c3oO5uc195z07QUJ9oHb4k9hRdKb9 = 8ceUXPOD34dVCWOlpGT5Do01b84rla5c3oO5uc195z07QUJ9oHb4k9hRdKb9;
            this.2H1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3 = 2h1YgXg1iR1kd9fC2ubGim1KGwSPUAnw9qg68y5mGH12kgO6dN8w61caMKO3;
            this.2QgdUt39i2D2kz0DVgEK57x7SbqDO3VF01u5FKjDkJE4E2TM9g1sTnjxdetP = 2QgdUt39i2D2kz0DVgEK57x7SbqDO3VF01u5FKjDkJE4E2TM9g1sTnjxdetP;
        }
    }
}
