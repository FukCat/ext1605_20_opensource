// 
// Decompiled by Procyon v0.6.0
// 

public class 21SqcgIh6jIrIV37Tdzb4Kt6u10ojf2PIv99e373w7Piu3K19xW9D2xy9f2XIO1hV7ukheyd6F6t6K218x1h7nafxm9r5j4MPk
{
    public static final int[] 32d3x0Xf86cpfgOOi98YK5ZkoMlNOjT5Qy0s2IdlmWB1E6L1z9291maTfUiI;
    
    static {
        32d3x0Xf86cpfgOOi98YK5ZkoMlNOjT5Qy0s2IdlmWB1E6L1z9291maTfUiI = new int[753jUtk5BLkRD9448WzlKTE5h08v6dkLD07oH31vIW43AJn71riIlj7l5B4qvTZ1zf71Poafe4Y2yIgZ57aTxd7xR061vsnlW.16FA9q1KKa5b458goToK2WS017HxHX4Cg55jdyq8BWmsTG4k63nE48YNn7Ls().length];
        try {
            21SqcgIh6jIrIV37Tdzb4Kt6u10ojf2PIv99e373w7Piu3K19xW9D2xy9f2XIO1hV7ukheyd6F6t6K218x1h7nafxm9r5j4MPk.32d3x0Xf86cpfgOOi98YK5ZkoMlNOjT5Qy0s2IdlmWB1E6L1z9291maTfUiI[753jUtk5BLkRD9448WzlKTE5h08v6dkLD07oH31vIW43AJn71riIlj7l5B4qvTZ1zf71Poafe4Y2yIgZ57aTxd7xR061vsnlW.4r9hY4dYfmaQ44N1Q7417z7VjAf638F22F8PhnULufIp71k63OJ4SuFE6N2I.ordinal()] = 1;
        }
        catch (final NoSuchFieldError noSuchFieldError) {}
        try {
            21SqcgIh6jIrIV37Tdzb4Kt6u10ojf2PIv99e373w7Piu3K19xW9D2xy9f2XIO1hV7ukheyd6F6t6K218x1h7nafxm9r5j4MPk.32d3x0Xf86cpfgOOi98YK5ZkoMlNOjT5Qy0s2IdlmWB1E6L1z9291maTfUiI[753jUtk5BLkRD9448WzlKTE5h08v6dkLD07oH31vIW43AJn71riIlj7l5B4qvTZ1zf71Poafe4Y2yIgZ57aTxd7xR061vsnlW.1ZS30A1M6mj6J0n3H0ztDVCahJVSEmJBuJ4YTR2w27lhzo0Xt5E6AKDiWdG7.ordinal()] = 2;
        }
        catch (final NoSuchFieldError noSuchFieldError2) {}
        try {
            21SqcgIh6jIrIV37Tdzb4Kt6u10ojf2PIv99e373w7Piu3K19xW9D2xy9f2XIO1hV7ukheyd6F6t6K218x1h7nafxm9r5j4MPk.32d3x0Xf86cpfgOOi98YK5ZkoMlNOjT5Qy0s2IdlmWB1E6L1z9291maTfUiI[753jUtk5BLkRD9448WzlKTE5h08v6dkLD07oH31vIW43AJn71riIlj7l5B4qvTZ1zf71Poafe4Y2yIgZ57aTxd7xR061vsnlW.9tcAOMfISXDxIU6BKEuvtwcx4ww0B14Mm4b6Y7M74KOE6PpizYJ75d9BT7T2.ordinal()] = 3;
        }
        catch (final NoSuchFieldError noSuchFieldError3) {}
        try {
            21SqcgIh6jIrIV37Tdzb4Kt6u10ojf2PIv99e373w7Piu3K19xW9D2xy9f2XIO1hV7ukheyd6F6t6K218x1h7nafxm9r5j4MPk.32d3x0Xf86cpfgOOi98YK5ZkoMlNOjT5Qy0s2IdlmWB1E6L1z9291maTfUiI[753jUtk5BLkRD9448WzlKTE5h08v6dkLD07oH31vIW43AJn71riIlj7l5B4qvTZ1zf71Poafe4Y2yIgZ57aTxd7xR061vsnlW.0YCS3Lf0Mnn3Tqh40koCBE19x5QperDvUY8WEyHcufynA4tO3whl4MOq7855.ordinal()] = 4;
        }
        catch (final NoSuchFieldError noSuchFieldError4) {}
    }
}
