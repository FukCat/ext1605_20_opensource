import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 6ZGY0hm2P0sD92bf7T8yv1D36X41rVU4hlY82hg6d1U2ok16nY3A850VSXJ4v085e9X0Dv0tzjug922OX8c44Qd1y266g0dDhOrs48Tq extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 5qv3g9V1k5Lv2XkDw44ChI9c15755ce24rZC175X7cAaSf2IL82gk9J1xpf6;
    public String 1Dk0hi8L2tBf9YgOmhV9GcCbmGH8NO00Zc8X9NqTw5Gwfy773PfZ1FMlCN28;
    public String 359f3QkH8v35LZ3kqrz24KevRTr05PqPG8E6Nyx6pz210jZGz0qtHY510N5X;
    public int 0O1lZJsuYwM4VneruFjZTSquW8Nb17FtPzYYL9ju1U2Himk5RXe4dTyn0FtW;
    
    public 6ZGY0hm2P0sD92bf7T8yv1D36X41rVU4hlY82hg6d1U2ok16nY3A850VSXJ4v085e9X0Dv0tzjug922OX8c44Qd1y266g0dDhOrs48Tq() {
        this.0O1lZJsuYwM4VneruFjZTSquW8Nb17FtPzYYL9ju1U2Himk5RXe4dTyn0FtW = -1;
    }
    
    public 6ZGY0hm2P0sD92bf7T8yv1D36X41rVU4hlY82hg6d1U2ok16nY3A850VSXJ4v085e9X0Dv0tzjug922OX8c44Qd1y266g0dDhOrs48Tq(final String 1Dk0hi8L2tBf9YgOmhV9GcCbmGH8NO00Zc8X9NqTw5Gwfy773PfZ1FMlCN28, final String 359f3QkH8v35LZ3kqrz24KevRTr05PqPG8E6Nyx6pz210jZGz0qtHY510N5X, final int 5qv3g9V1k5Lv2XkDw44ChI9c15755ce24rZC175X7cAaSf2IL82gk9J1xpf6) {
        this.0O1lZJsuYwM4VneruFjZTSquW8Nb17FtPzYYL9ju1U2Himk5RXe4dTyn0FtW = -1;
        this.1Dk0hi8L2tBf9YgOmhV9GcCbmGH8NO00Zc8X9NqTw5Gwfy773PfZ1FMlCN28 = 1Dk0hi8L2tBf9YgOmhV9GcCbmGH8NO00Zc8X9NqTw5Gwfy773PfZ1FMlCN28;
        this.359f3QkH8v35LZ3kqrz24KevRTr05PqPG8E6Nyx6pz210jZGz0qtHY510N5X = 359f3QkH8v35LZ3kqrz24KevRTr05PqPG8E6Nyx6pz210jZGz0qtHY510N5X;
        this.5qv3g9V1k5Lv2XkDw44ChI9c15755ce24rZC175X7cAaSf2IL82gk9J1xpf6 = 5qv3g9V1k5Lv2XkDw44ChI9c15755ce24rZC175X7cAaSf2IL82gk9J1xpf6;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.5qv3g9V1k5Lv2XkDw44ChI9c15755ce24rZC175X7cAaSf2IL82gk9J1xpf6 = dataInputStream.readInt();
        this.1Dk0hi8L2tBf9YgOmhV9GcCbmGH8NO00Zc8X9NqTw5Gwfy773PfZ1FMlCN28 = dataInputStream.readUTF();
        this.359f3QkH8v35LZ3kqrz24KevRTr05PqPG8E6Nyx6pz210jZGz0qtHY510N5X = dataInputStream.readUTF();
        if (3TRs4A75rS0TtcUL36iKx34E6k4NB1XXM6i8cs9Khd3OUdqLNT1q99wqrgwtn53Nk1LerxKV5f8Dlt8MOX4uKK6df8l.5lX8X5yivf7DSGr0s2G13Eu4UeF1813nrrHhGM1pL8m1fFm44I8s6apKHz60 != null) {
            this.0O1lZJsuYwM4VneruFjZTSquW8Nb17FtPzYYL9ju1U2Himk5RXe4dTyn0FtW = Integer.parseInt(this.359f3QkH8v35LZ3kqrz24KevRTr05PqPG8E6Nyx6pz210jZGz0qtHY510N5X);
        }
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.5qv3g9V1k5Lv2XkDw44ChI9c15755ce24rZC175X7cAaSf2IL82gk9J1xpf6);
        dataOutputStream.writeUTF(this.1Dk0hi8L2tBf9YgOmhV9GcCbmGH8NO00Zc8X9NqTw5Gwfy773PfZ1FMlCN28);
        dataOutputStream.writeUTF(this.359f3QkH8v35LZ3kqrz24KevRTr05PqPG8E6Nyx6pz210jZGz0qtHY510N5X);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.5j5vxiwi54h1B7LRq4CgcEDNjuCSaPkS7erSFn4n81TKMI6286nlo9ArnN9a(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 4 + this.1Dk0hi8L2tBf9YgOmhV9GcCbmGH8NO00Zc8X9NqTw5Gwfy773PfZ1FMlCN28.length() + this.359f3QkH8v35LZ3kqrz24KevRTr05PqPG8E6Nyx6pz210jZGz0qtHY510N5X.length() + 4;
    }
}
