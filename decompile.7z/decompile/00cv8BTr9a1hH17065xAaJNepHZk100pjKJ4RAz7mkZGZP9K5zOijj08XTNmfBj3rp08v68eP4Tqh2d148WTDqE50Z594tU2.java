// 
// Decompiled by Procyon v0.6.0
// 

public class 00cv8BTr9a1hH17065xAaJNepHZk100pjKJ4RAz7mkZGZP9K5zOijj08XTNmfBj3rp08v68eP4Tqh2d148WTDqE50Z594tU2 extends 8XF8bu9911GE62hU3rrpS474yx4XMaT4craVcGzl6Lkz6I000591Sgx5Y4e6jmv0qn737rOaHvtqAZ2eYIE6S876Wd35MNrWiNWF4
{
    int 9xg75975dD6A4d9T5oI8tGF0oWpQ42zz2ef0y7RQs41s83hqjse1ISW95Na6;
    
    public 00cv8BTr9a1hH17065xAaJNepHZk100pjKJ4RAz7mkZGZP9K5zOijj08XTNmfBj3rp08v68eP4Tqh2d148WTDqE50Z594tU2(final int n, final int n2, final int 9xg75975dD6A4d9T5oI8tGF0oWpQ42zz2ef0y7RQs41s83hqjse1ISW95Na6) {
        super(n, n2);
        this.9xg75975dD6A4d9T5oI8tGF0oWpQ42zz2ef0y7RQs41s83hqjse1ISW95Na6 = 9xg75975dD6A4d9T5oI8tGF0oWpQ42zz2ef0y7RQs41s83hqjse1ISW95Na6;
    }
    
    @Override
    public int 562a2lhwZKvA2q1SYRkk6a3ib277RkRI785Nc3EOo7NAF01ZLdp6C8534NoH(final 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa, final int n, final int n2, final double n3, final double n4, final double n5) {
        if (3p9u95CB1CP0y3UiTUZMGY05o15X75Oi03v43rZTG0wGCHvXqU15Kt1Q8k8Op87au5qr4U1GCvu00LTfk2w3YhwqE0it1tw2g11k.8G80Kimsj2t150ZuEHxk97V3fSV455qzurOOVWgX8oTDDCEH9YV34z9vRAoC) {
            return this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41;
        }
        if (91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa == null) {
            return this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41;
        }
        final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8 = 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa.9805301CWs03An9555qIw883P54dcq9802DkM5DuquNweM1NH26RH6oP02mr().7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8((int)n3, (int)n5, 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer.826lh5eslCWNLgtluhQvESvIz0u4cye5zctbuc7h93L41Q8yxBAB2u3EI3R7);
        if (7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8 == null) {
            return this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41;
        }
        switch (7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8.8WfOXonA2bRS7hUpHd7sbe7k20yqj7N6OH13GX3XXy71V13Eva115wQwe47C()) {
            case 1:
            case 2: {
                return this.9xg75975dD6A4d9T5oI8tGF0oWpQ42zz2ef0y7RQs41s83hqjse1ISW95Na6;
            }
            default: {
                return this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41;
            }
        }
    }
}
