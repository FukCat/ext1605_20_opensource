import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 8uACSkTjhpdTZEEVlCQD3e2P7LMwrvZt3XW8wBqc49N7c6j21epOteeddA2WM57vzK79sToq34AnHs6vDxzLVP0AZ2s4Dz073 extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    private int 16Ks9Xt85O6Fy2j82SXr8iH2kLFs59xa1c2LA5PIuL6sNdGM48janU2hHA5P;
    private int 72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r;
    
    public 8uACSkTjhpdTZEEVlCQD3e2P7LMwrvZt3XW8wBqc49N7c6j21epOteeddA2WM57vzK79sToq34AnHs6vDxzLVP0AZ2s4Dz073(final int 72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r) {
        this.16Ks9Xt85O6Fy2j82SXr8iH2kLFs59xa1c2LA5PIuL6sNdGM48janU2hHA5P = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6Zj01154X4I1OqtD51p013Be7Sw285vke1Q8nRX9PB7GL2D56UJ1A8ycRJTS.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r = 72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r;
    }
    
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n, n2, n3) != 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.48vJoOIJt15P5mCD3szk3QoP21Ya9f5381N237U51K027s0J0H87b0ZD496P) {
            return false;
        }
        final float n4 = random.nextFloat() * 3.1415927f;
        final double n5 = n + 8 + 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(n4) * this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r / 8.0f;
        final double n6 = n + 8 - 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(n4) * this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r / 8.0f;
        final double n7 = n3 + 8 + 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.1724kYgc5e55Yw1mK1EZTYO084n57BWWaYUE7iquVDiu4hFo5J70Cori9WLs(n4) * this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r / 8.0f;
        final double n8 = n3 + 8 - 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.1724kYgc5e55Yw1mK1EZTYO084n57BWWaYUE7iquVDiu4hFo5J70Cori9WLs(n4) * this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r / 8.0f;
        final double n9 = n2 + random.nextInt(3) + 2;
        final double n10 = n2 + random.nextInt(3) + 2;
        for (int i = 0; i <= this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r; ++i) {
            final double n11 = n5 + (n6 - n5) * i / this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r;
            final double n12 = n9 + (n10 - n9) * i / this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r;
            final double n13 = n7 + (n8 - n7) * i / this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r;
            final double n14 = random.nextDouble() * this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r / 16.0;
            final double n15 = (5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(i * 3.1415927f / this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r) + 1.0f) * n14 + 1.0;
            final double n16 = (5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(i * 3.1415927f / this.72bgjEtOq5Rq5OTL21JziRBU6xOtjpQ289k0KQCpkZg4591q1iO95VlS5m9r) + 1.0f) * n14 + 1.0;
            for (int j = (int)(n11 - n15 / 2.0); j <= (int)(n11 + n15 / 2.0); ++j) {
                for (int k = (int)(n12 - n16 / 2.0); k <= (int)(n12 + n16 / 2.0); ++k) {
                    for (int l = (int)(n13 - n15 / 2.0); l <= (int)(n13 + n15 / 2.0); ++l) {
                        final double n17 = (j + 0.5 - n11) / (n15 / 2.0);
                        final double n18 = (k + 0.5 - n12) / (n16 / 2.0);
                        final double n19 = (l + 0.5 - n13) / (n15 / 2.0);
                        if (n17 * n17 + n18 * n18 + n19 * n19 < 1.0 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(j, k, l) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8Oc1R0m7Q45IV28h9CrA3XY3p9daokx84Vb2EiQjjRHA812692WF5o1hQDgT.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(j, k, l, this.16Ks9Xt85O6Fy2j82SXr8iH2kLFs59xa1c2LA5PIuL6sNdGM48janU2hHA5P);
                        }
                    }
                }
            }
        }
        return true;
    }
}
