import java.awt.event.WindowEvent;
import net.minecraft.client.Minecraft;
import java.awt.event.WindowAdapter;

// 
// Decompiled by Procyon v0.6.0
// 

public final class 442LEmhrls9a84s3v9gTRS3OqzlDxb3is8NLX17JSRAz5cM4D3oeCy5879vw887L5soC3X4d1CG0Hzlx355Fqdedq9UujYy extends WindowAdapter
{
    final Minecraft 9NgSpzsjJc504h7QpF9vV5hgA10D5D7T2g9004TZ8M89PTwkt11hk8069KSd;
    final Thread 02K5E1PpErsPATdx69lc2QDfs0n2jII8R69Vl18GwMjjeFQH6WRv3HY93066;
    
    public 442LEmhrls9a84s3v9gTRS3OqzlDxb3is8NLX17JSRAz5cM4D3oeCy5879vw887L5soC3X4d1CG0Hzlx355Fqdedq9UujYy(final Minecraft 9NgSpzsjJc504h7QpF9vV5hgA10D5D7T2g9004TZ8M89PTwkt11hk8069KSd, final Thread 02K5E1PpErsPATdx69lc2QDfs0n2jII8R69Vl18GwMjjeFQH6WRv3HY93066) {
        this.9NgSpzsjJc504h7QpF9vV5hgA10D5D7T2g9004TZ8M89PTwkt11hk8069KSd = 9NgSpzsjJc504h7QpF9vV5hgA10D5D7T2g9004TZ8M89PTwkt11hk8069KSd;
        this.02K5E1PpErsPATdx69lc2QDfs0n2jII8R69Vl18GwMjjeFQH6WRv3HY93066 = 02K5E1PpErsPATdx69lc2QDfs0n2jII8R69Vl18GwMjjeFQH6WRv3HY93066;
    }
    
    @Override
    public void windowClosing(final WindowEvent windowEvent) {
        this.9NgSpzsjJc504h7QpF9vV5hgA10D5D7T2g9004TZ8M89PTwkt11hk8069KSd.2F487nXtBcZHUniC3RAaQkjPat9E0C39FL3iEiaGPs2TNnr16TXWREX5Y48f();
        try {
            this.02K5E1PpErsPATdx69lc2QDfs0n2jII8R69Vl18GwMjjeFQH6WRv3HY93066.join();
        }
        catch (final InterruptedException ex) {
            ex.printStackTrace();
        }
        System.exit(0);
    }
}
