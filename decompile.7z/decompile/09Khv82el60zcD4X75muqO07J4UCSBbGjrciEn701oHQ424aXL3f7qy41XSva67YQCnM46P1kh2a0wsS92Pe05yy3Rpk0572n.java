import java.io.DataInput;
import java.io.IOException;
import java.io.DataOutput;

// 
// Decompiled by Procyon v0.6.0
// 

public class 09Khv82el60zcD4X75muqO07J4UCSBbGjrciEn701oHQ424aXL3f7qy41XSva67YQCnM46P1kh2a0wsS92Pe05yy3Rpk0572n extends 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi
{
    public float 7bCSu2L647xiTT55nI6i5g0D9ZDV6k3prxL74xPkt7nC1B9isrC06UhM0I05;
    
    public 09Khv82el60zcD4X75muqO07J4UCSBbGjrciEn701oHQ424aXL3f7qy41XSva67YQCnM46P1kh2a0wsS92Pe05yy3Rpk0572n() {
    }
    
    public 09Khv82el60zcD4X75muqO07J4UCSBbGjrciEn701oHQ424aXL3f7qy41XSva67YQCnM46P1kh2a0wsS92Pe05yy3Rpk0572n(final float 7bCSu2L647xiTT55nI6i5g0D9ZDV6k3prxL74xPkt7nC1B9isrC06UhM0I05) {
        this.7bCSu2L647xiTT55nI6i5g0D9ZDV6k3prxL74xPkt7nC1B9isrC06UhM0I05 = 7bCSu2L647xiTT55nI6i5g0D9ZDV6k3prxL74xPkt7nC1B9isrC06UhM0I05;
    }
    
    @Override
    void 7OU3N2lgEecd9p9DtAmaF5EwE4f0u28Oaa9zcxqnm3XW1bDsPewY15rIFs80(final DataOutput dataOutput) throws IOException {
        dataOutput.writeFloat(this.7bCSu2L647xiTT55nI6i5g0D9ZDV6k3prxL74xPkt7nC1B9isrC06UhM0I05);
    }
    
    @Override
    void 96fSDIRBY01vu6bNpWo4KQJG8fCN2WIew9WR04d4yvq9Lxko60PpMIEkyn00(final DataInput dataInput) throws IOException {
        this.7bCSu2L647xiTT55nI6i5g0D9ZDV6k3prxL74xPkt7nC1B9isrC06UhM0I05 = dataInput.readFloat();
    }
    
    @Override
    public byte 3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr() {
        return 5;
    }
    
    @Override
    public String toString() {
        return "" + this.7bCSu2L647xiTT55nI6i5g0D9ZDV6k3prxL74xPkt7nC1B9isrC06UhM0I05;
    }
}
