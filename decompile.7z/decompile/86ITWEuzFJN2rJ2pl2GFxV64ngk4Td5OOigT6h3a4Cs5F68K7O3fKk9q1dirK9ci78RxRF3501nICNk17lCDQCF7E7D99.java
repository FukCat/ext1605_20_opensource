import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99 implements 8W1WSL13Q4ln33n7y62avj4L856TJi97cz688GPkUp1w7RteH2Xmt1Sz81L5765Ka5FhopL16lf9xj7Suw2rH92Al868XGr7
{
    private final 1ICVnGhfs4cDkq364iDD6irgW0QCEUrMwN4q9cEO5BW67u5q10M6lLi1L7Qmvh0zf2Ai3hcP0zit7M8eR0SWk9wgNQusHQ 8Z0gt9AA75q8CM88X89mbX3Dz5aB2z41i0d99Yt647gvdI24EnEdelrhUcYk;
    
    public 86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99(final Random random) {
        this.8Z0gt9AA75q8CM88X89mbX3Dz5aB2z41i0d99Yt647gvdI24EnEdelrhUcYk = new 1ICVnGhfs4cDkq364iDD6irgW0QCEUrMwN4q9cEO5BW67u5q10M6lLi1L7Qmvh0zf2Ai3hcP0zit7M8eR0SWk9wgNQusHQ(random);
    }
    
    @Override
    public float 913vTZx6no47397W6wG95Q5uB254nJBZ27osnW242XcA9M93Alb1ry5oPyVe() {
        return 1.1f;
    }
    
    private boolean 4U50uH23DKVbS4kT87Vx337cToyT7Yl2565CFwbWiX722T2c06GWkwRh9w0p(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3);
        return 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.63nirDT0ysU52yrV7NrOFP3w5y6GfnHtl75Rxpz4tsleaNpwg02R6ida6v9c.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8Oc1R0m7Q45IV28h9CrA3XY3p9daokx84Vb2EiQjjRHA812692WF5o1hQDgT.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
    }
    
    private void 0v3vQbv70s7YdkWhB90cyD0W15xlZnAZbEe99E98x929tVR1C60D5w9fMoh3(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2) {
        for (int i = 128; i > 40; --i) {
            if (this.4U50uH23DKVbS4kT87Vx337cToyT7Yl2565CFwbWiX722T2c06GWkwRh9w0p(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, i, n2)) {
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, i, n2, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, i + 1, n2) == 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.35n8I544igDd31e8F9S5eH4vzN4Ot7X39d37sI8eV5GtLsHraAQR0MYE7PLN.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, i + 1, n2, 0);
                }
                return;
            }
        }
    }
    
    @Override
    public void 61qP7q8deV5ospnX8sW5XUMxMcV5ssOU68863452kQ9H403L5ScR3DEa98qO(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final 1B94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588) {
        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.8sSo6R56dp4iBRcZYEsyqGvairy6hA3iSie40WLK34B7262TDpz1Mm0uLRn1) {
            return;
        }
        final int[] array = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n + 1, n2)) {
            for (int i = 9; i <= 15; ++i) {
                for (int j = 4; j <= 11; ++j) {
                    array[i + j * 16] = 1;
                }
            }
        }
        if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n - 1, n2)) {
            for (int k = 0; k <= 6; ++k) {
                for (int l = 4; l <= 11; ++l) {
                    array[k + l * 16] = 1;
                }
            }
        }
        if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 + 1)) {
            for (int n3 = 4; n3 <= 11; ++n3) {
                for (int n4 = 9; n4 <= 15; ++n4) {
                    array[n3 + n4 * 16] = 1;
                }
            }
        }
        if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 - 1)) {
            for (int n5 = 4; n5 <= 11; ++n5) {
                for (int n6 = 0; n6 <= 6; ++n6) {
                    array[n5 + n6 * 16] = 1;
                }
            }
        }
        if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n + 1, n2) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n + 1, n2 + 1) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 + 1)) {
            for (int n7 = 12; n7 <= 15; ++n7) {
                for (int n8 = 12; n8 <= 15; ++n8) {
                    array[n7 + n8 * 16] = 1;
                }
            }
        }
        else if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n + 1, n2) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 + 1)) {
            array[204] = 1;
            for (int n9 = 1; n9 <= 2; ++n9) {
                array[12 + (12 + n9) * 16] = (array[12 + n9 + 192] = 1);
            }
        }
        if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n - 1, n2) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n - 1, n2 - 1) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 - 1)) {
            for (int n10 = 0; n10 <= 3; ++n10) {
                for (int n11 = 0; n11 <= 3; ++n11) {
                    array[n10 + n11 * 16] = 1;
                }
            }
        }
        else if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n - 1, n2) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 - 1)) {
            array[51] = 1;
            for (int n12 = 1; n12 <= 2; ++n12) {
                array[3 + (3 - n12) * 16] = (array[3 - n12 + 48] = 1);
            }
        }
        if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n - 1, n2) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n - 1, n2 + 1) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 + 1)) {
            for (int n13 = 0; n13 <= 3; ++n13) {
                for (int n14 = 12; n14 <= 15; ++n14) {
                    array[n13 + n14 * 16] = 1;
                }
            }
        }
        else if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n - 1, n2) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 + 1)) {
            array[195] = 1;
            for (int n15 = 1; n15 <= 2; ++n15) {
                array[3 + (12 + n15) * 16] = (array[3 - n15 + 192] = 1);
            }
        }
        if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n + 1, n2) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n + 1, n2 - 1) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 - 1)) {
            for (int n16 = 12; n16 <= 15; ++n16) {
                for (int n17 = 0; n17 <= 3; ++n17) {
                    array[n16 + n17 * 16] = 1;
                }
            }
        }
        else if (1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n + 1, n2) && 1b94lIhqOD1rM3kFmwzDicAW4EzKNVglbB7m5gsqueU55wc70wy368Y3zDI1Fw2F0Hfa72bI2ZOJeqJ38l4P8VgOzAU5iVS588.1lauh9bG6pSmwZgFm5Y1FVXU7kmZ47i860Qhf5XR6gXkIbUPfjJbjs82g9pF(86ITWEuzFJN2rJ2pl2GFxV64ngk4Td5OOigT6h3a4Cs5F68K7O3fKk9q1dirK9ci78RxRF3501nICNk17lCDQCF7E7D99.class, n, n2 - 1)) {
            array[60] = 1;
            for (int n18 = 1; n18 <= 2; ++n18) {
                array[12 + (3 - n18) * 16] = (array[12 + n18 + 48] = 1);
            }
        }
        for (int n19 = 0; n19 < 16; ++n19) {
            for (int n20 = 0; n20 < 16; ++n20) {
                if (array[n19 + n20 * 16] == 1) {
                    this.0v3vQbv70s7YdkWhB90cyD0W15xlZnAZbEe99E98x929tVR1C60D5w9fMoh3(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.83H73ksIvJrMc2NeZfFS9RKWMZ119cw00ovP878PIJ7vm7j1o8FoKors0HXq, n * 16 + n19, n2 * 16 + n20);
                }
            }
        }
    }
}
