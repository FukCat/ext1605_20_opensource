// 
// Decompiled by Procyon v0.6.0
// 

public class 8Q5rXsMrRRFgdCH76Gkdit1Cb654Aew0Ob4M32l7S3FC8XT1nT96Gzi8r1urDRbw3nJlc52P8nv9a7mIHKo4j9f7ZglrwtdRGb extends 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D
{
    private 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D 8srMDc3bwFs8w9nVpcdDw1t0x8n1F7luIiky2i02kSBod6nZXhPZtrn1W7TD;
    private int 0W8ob727Ied0mM3a9kga7Z4V3Bj3VP9rO3g4r7cX3q7xl4s0A7ee1xf8Ok94;
    private String 88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q;
    public static int 02qfiP2Lg4LqXw6cx116l6TbKRb67MqCY7BH1429SbB154FYd4UhjFU1cbU0;
    
    public 8Q5rXsMrRRFgdCH76Gkdit1Cb654Aew0Ob4M32l7S3FC8XT1nT96Gzi8r1urDRbw3nJlc52P8nv9a7mIHKo4j9f7ZglrwtdRGb(final 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D 8srMDc3bwFs8w9nVpcdDw1t0x8n1F7luIiky2i02kSBod6nZXhPZtrn1W7TD) {
        this.0W8ob727Ied0mM3a9kga7Z4V3Bj3VP9rO3g4r7cX3q7xl4s0A7ee1xf8Ok94 = 0;
        this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q = "";
        this.8srMDc3bwFs8w9nVpcdDw1t0x8n1F7luIiky2i02kSBod6nZXhPZtrn1W7TD = 8srMDc3bwFs8w9nVpcdDw1t0x8n1F7luIiky2i02kSBod6nZXhPZtrn1W7TD;
    }
    
    @Override
    public void 79dcDBX8wOiJ7P492Y177gZw78gOSlsV8lxmDRioLVlEh14o5HL6Utyo3Gfq() {
        ++this.0W8ob727Ied0mM3a9kga7Z4V3Bj3VP9rO3g4r7cX3q7xl4s0A7ee1xf8Ok94;
    }
    
    @Override
    public void 4An20JYjYn5ahp07NQmWFCuC33T53X6s4pd5325t5MV2inUXBh7is28o5l1C() {
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.clear();
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03(0, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 - 100, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 96 + 12, "Connect"));
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03(1, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 - 100, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 120 + 12, "Cancel"));
        if (3TRs4A75rS0TtcUL36iKx34E6k4NB1XXM6i8cs9Khd3OUdqLNT1q99wqrgwtn53Nk1LerxKV5f8Dlt8MOX4uKK6df8l.5lX8X5yivf7DSGr0s2G13Eu4UeF1813nrrHhGM1pL8m1fFm44I8s6apKHz60 != null) {
            this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03(2, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 - 100, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 96 - 24, 8Q5rXsMrRRFgdCH76Gkdit1Cb654Aew0Ob4M32l7S3FC8XT1nT96Gzi8r1urDRbw3nJlc52P8nv9a7mIHKo4j9f7ZglrwtdRGb.02qfiP2Lg4LqXw6cx116l6TbKRb67MqCY7BH1429SbB154FYd4UhjFU1cbU0 + ""));
        }
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(0).0Dn9XYbwOI0cTzjIRHga5tL990b9oummb9Q64SZBh9LU4M0I395Wln2t9pnG = false;
    }
    
    @Override
    protected void 7OD0HqHbYI4579sDX4xzee60N9g9V78YwSmgkc1Y6fyN6rF6JwUqBEU5m77M(final 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03 5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03) {
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.0Dn9XYbwOI0cTzjIRHga5tL990b9oummb9Q64SZBh9LU4M0I395Wln2t9pnG) {
            if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 1) {
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(this.8srMDc3bwFs8w9nVpcdDw1t0x8n1F7luIiky2i02kSBod6nZXhPZtrn1W7TD);
            }
            else if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 0) {
                final String[] split = this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q.split(":");
                74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX.293hUSlrDZ5KqkEIUf42HQ0MuQ29P6gQ9O1UJw7cYH753B92dP6B3tqaKFpf.clear();
                try {
                    this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 9W4jPlrL8r95eKy06X9S6I6BNH1JHglQrX3bI6n9TF9C4oLS12OBhiUbwh7Q913f3f8PcvsgQ114Qs1qraV7aY4V011(this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr, split[0], (split.length > 1) ? Integer.parseInt(split[1]) : 25565));
                }
                catch (final NumberFormatException ex) {
                    this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 4iPxfE9NobLgCV7E18vEHT1cJ6lluXA02YrGIhCL2SlE5e6tfoFs52b4cqQ2AyS509L8nqdO9h4jR24EM6huGz76JTn8Gb("Connection failed", "Invalid port: " + split[1]));
                }
            }
            else if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 2) {
                ++8Q5rXsMrRRFgdCH76Gkdit1Cb654Aew0Ob4M32l7S3FC8XT1nT96Gzi8r1urDRbw3nJlc52P8nv9a7mIHKo4j9f7ZglrwtdRGb.02qfiP2Lg4LqXw6cx116l6TbKRb67MqCY7BH1429SbB154FYd4UhjFU1cbU0;
                8Q5rXsMrRRFgdCH76Gkdit1Cb654Aew0Ob4M32l7S3FC8XT1nT96Gzi8r1urDRbw3nJlc52P8nv9a7mIHKo4j9f7ZglrwtdRGb.02qfiP2Lg4LqXw6cx116l6TbKRb67MqCY7BH1429SbB154FYd4UhjFU1cbU0 %= 3;
                this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(2).341FqR7gR9Z89F779fLfXdcwKO6ZA54xm6oS9N8sLphh7p10BkALs3o76F57 = 8Q5rXsMrRRFgdCH76Gkdit1Cb654Aew0Ob4M32l7S3FC8XT1nT96Gzi8r1urDRbw3nJlc52P8nv9a7mIHKo4j9f7ZglrwtdRGb.02qfiP2Lg4LqXw6cx116l6TbKRb67MqCY7BH1429SbB154FYd4UhjFU1cbU0 + "";
            }
        }
    }
    
    @Override
    protected void 27HH93i69891UR8scaUy8Wa381SrOHnrgz1395TWPN543Aw65UPU60a9U5op(final char c, final int n) {
        if (c == '\u0016') {
            String 1Ae3liQi6CP5qmL7Ss8k8igZ0509h976JQWj05V83wBG2K1xU29qgQkdc9sT = 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D.1Ae3liQi6CP5qmL7Ss8k8igZ0509h976JQWj05V83wBG2K1xU29qgQkdc9sT();
            if (1Ae3liQi6CP5qmL7Ss8k8igZ0509h976JQWj05V83wBG2K1xU29qgQkdc9sT == null) {
                1Ae3liQi6CP5qmL7Ss8k8igZ0509h976JQWj05V83wBG2K1xU29qgQkdc9sT = "";
            }
            int length = 32 - this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q.length();
            if (length > 1Ae3liQi6CP5qmL7Ss8k8igZ0509h976JQWj05V83wBG2K1xU29qgQkdc9sT.length()) {
                length = 1Ae3liQi6CP5qmL7Ss8k8igZ0509h976JQWj05V83wBG2K1xU29qgQkdc9sT.length();
            }
            if (length > 0) {
                this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q += 1Ae3liQi6CP5qmL7Ss8k8igZ0509h976JQWj05V83wBG2K1xU29qgQkdc9sT.substring(0, length);
            }
        }
        if (c == '\r') {
            this.7OD0HqHbYI4579sDX4xzee60N9g9V78YwSmgkc1Y6fyN6rF6JwUqBEU5m77M(this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(0));
        }
        if (n == 14 && this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q.length() > 0) {
            this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q = this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q.substring(0, this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q.length() - 1);
        }
        if (" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~\u2302\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8?\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1??????????".indexOf(c) >= 0 && this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q.length() < 32) {
            this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q += c;
        }
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(0).0Dn9XYbwOI0cTzjIRHga5tL990b9oummb9Q64SZBh9LU4M0I395Wln2t9pnG = (this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q.length() > 0);
    }
    
    @Override
    public void 9zr0Ft7ATwYEg4elWEB8ucyDaj2700KJgZB3Cc51d8vF03zOM52iOvWHcrR5(final int n, final int n2, final float n3) {
        this.5S1K79XLhK48s404AETji776rN10k5t6zymKy3FSC71grsr64j85ILV6pJWZ();
        this.7hd18JPAm30YnhcZ8R4BhADB3iRynT8aWz54M1xf1qSS3I4uWxIHQH2B64Sx(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, "Play Multiplayer", this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 - 60 + 20, 16777215);
        if (3TRs4A75rS0TtcUL36iKx34E6k4NB1XXM6i8cs9Khd3OUdqLNT1q99wqrgwtn53Nk1LerxKV5f8Dlt8MOX4uKK6df8l.5lX8X5yivf7DSGr0s2G13Eu4UeF1813nrrHhGM1pL8m1fFm44I8s6apKHz60 != null) {
            38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, "-- WARNING --   JOINING IN SECURE MODE", this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 - 140, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 - 60 + 60 + 0, 10526880);
        }
        else {
            38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, "Minecraft Multiplayer is currently not finished, but there", this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 - 140, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 - 60 + 60 + 0, 10526880);
            38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, "is some buggy early testing going on.", this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 - 140, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 - 60 + 60 + 9, 10526880);
            38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, "Enter the IP of a server to connect to it:", this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 - 140, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 - 60 + 60 + 36, 10526880);
        }
        final int n4 = this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 - 100;
        final int n5 = this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 - 10 + 50 + 18;
        final int n6 = 200;
        final int n7 = 20;
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.0zEK7Ya35KrGoBUefz5kDC2FtMvEeQ0VZd705ddMg5qu7RhW9J01B4TC6J6C(n4 - 1, n5 - 1, n4 + n6 + 1, n5 + n7 + 1, -6250336);
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.0zEK7Ya35KrGoBUefz5kDC2FtMvEeQ0VZd705ddMg5qu7RhW9J01B4TC6J6C(n4, n5, n4 + n6, n5 + n7, -16777216);
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, this.88hcpBG42P0hmc3b5Og7SHeK588WLXjmO0132bB8Lm96zn5VT6QcTb9hdw1Q + ((this.0W8ob727Ied0mM3a9kga7Z4V3Bj3VP9rO3g4r7cX3q7xl4s0A7ee1xf8Ok94 / 6 % 2 == 0) ? "_" : ""), n4 + 4, n5 + (n7 - 8) / 2, 14737632);
        super.9zr0Ft7ATwYEg4elWEB8ucyDaj2700KJgZB3Cc51d8vF03zOM52iOvWHcrR5(n, n2, n3);
    }
    
    static {
        8Q5rXsMrRRFgdCH76Gkdit1Cb654Aew0Ob4M32l7S3FC8XT1nT96Gzi8r1urDRbw3nJlc52P8nv9a7mIHKo4j9f7ZglrwtdRGb.02qfiP2Lg4LqXw6cx116l6TbKRb67MqCY7BH1429SbB154FYd4UhjFU1cbU0 = 0;
    }
}
