import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 6kEcps0fHg3BS3ugGDa764P7ZHl5HIpv2rmZSsg3ZV46aJB9b97oVjqBQ36EgHubG8Rf7K795jlNB90wUK5U503Vzdv55 extends 55XXM28b6p84b4G2l6B1InnTc701h21NG7n6pZPb2RkqeSGMf12ZMp058OFNNJP04Q3WjX0S3IEUdu0p0YkM1TMGm5WXG2Nme6
{
    protected 6kEcps0fHg3BS3ugGDa764P7ZHl5HIpv2rmZSsg3ZV46aJB9b97oVjqBQ36EgHubG8Rf7K795jlNB90wUK5U503Vzdv55(final int n) {
        super(n, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.0e51g5n7QQ2bM6IT7Q28hAbJkebnbMOVd3lRo7XioWLAkvTHV9DQxASpl4S7);
        this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H = 20;
    }
    
    @Override
    public int 45k0se28RPK2IN33WJfb5g4oDd7zeQlWp0LvSfJeHBZ0aVU090Eh0r7XB665(final Random random) {
        return 1;
    }
    
    @Override
    public int 8LTZgqX2KHwGhNpQ1gUZz1WaWt0W2TrjgClq35mEWEh8l45qEVZXQ21Rh3g0(final int n, final Random random) {
        return 55XXM28b6p84b4G2l6B1InnTc701h21NG7n6pZPb2RkqeSGMf12ZMp058OFNNJP04Q3WjX0S3IEUdu0p0YkM1TMGm5WXG2Nme6.6goL295Sxp484OGP6jl0a6Bc6B6GO4b2u07MvUufs9zE25zpss2S8Lsp2t68.01lgF9B869y98971xM904ArErwAmKW0135S3qc6W8Vi3wsv260KyANkXWhDN;
    }
    
    @Override
    public int 2b1pbetRmJyaMfSXs7k02a96ZB84GA6lI6KnMBwqDWfFcMKEifg20ytG350E(final int n) {
        if (n == 1) {
            return 21;
        }
        if (n == 0) {
            return 21;
        }
        return 20;
    }
}
