import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 91543Y75GMHiVnSbT31fM34BZ3l0N414Zjt2CBOgy7XdCSsEI0GXK14DAgO46OX0g7WfmzXAIw9V7hq440T333meOhs1Z1 extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 346WvU83SqW7P6IBuh53TzK0s2XC28qJ5CJ113agV55y1zbt14oAquq1C142;
    public int 54e8257630z9OU4FuX3YMTXIDeDns1xzEauv494574H6K98yJ2sIOvEeCcok;
    public int 0j2pJfKBH8I8nqZWMJ0wdxVD5E9Gwzsy3Z9ti3RtLIrslQbw34Sed2yz2Z2r;
    public long 2BF6SJeykA355Ycp3mlpze6RWA8r7ov3Zl36VF9IN37v710u6vZU00fOZ6cf;
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.346WvU83SqW7P6IBuh53TzK0s2XC28qJ5CJ113agV55y1zbt14oAquq1C142 = dataInputStream.readInt();
        this.54e8257630z9OU4FuX3YMTXIDeDns1xzEauv494574H6K98yJ2sIOvEeCcok = dataInputStream.readInt();
        this.0j2pJfKBH8I8nqZWMJ0wdxVD5E9Gwzsy3Z9ti3RtLIrslQbw34Sed2yz2Z2r = dataInputStream.readInt();
        this.2BF6SJeykA355Ycp3mlpze6RWA8r7ov3Zl36VF9IN37v710u6vZU00fOZ6cf = dataInputStream.readLong();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.346WvU83SqW7P6IBuh53TzK0s2XC28qJ5CJ113agV55y1zbt14oAquq1C142);
        dataOutputStream.writeInt(this.54e8257630z9OU4FuX3YMTXIDeDns1xzEauv494574H6K98yJ2sIOvEeCcok);
        dataOutputStream.writeInt(this.0j2pJfKBH8I8nqZWMJ0wdxVD5E9Gwzsy3Z9ti3RtLIrslQbw34Sed2yz2Z2r);
        dataOutputStream.writeLong(this.2BF6SJeykA355Ycp3mlpze6RWA8r7ov3Zl36VF9IN37v710u6vZU00fOZ6cf);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.357ppjZ0thhMR5WgAJ1R7144r47oPVaU447IavriH4PTZR9mDh8hwz45Rjg1(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 20;
    }
}
