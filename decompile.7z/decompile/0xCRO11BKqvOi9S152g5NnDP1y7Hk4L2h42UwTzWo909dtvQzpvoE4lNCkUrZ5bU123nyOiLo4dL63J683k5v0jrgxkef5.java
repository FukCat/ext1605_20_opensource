import java.util.ArrayList;

// 
// Decompiled by Procyon v0.6.0
// 

public class 0xCRO11BKqvOi9S152g5NnDP1y7Hk4L2h42UwTzWo909dtvQzpvoE4lNCkUrZ5bU123nyOiLo4dL63J683k5v0jrgxkef5 extends 5h9aW7iFtT7oClcDT10FiIe1AdNwsJ2Y7h7oUz1h6103B1XDQlOpaO7TFsEh5c2NX5bu3syv6OW7ubLP8kJu5WVb0ON64o7427yE89
{
    public 0xCRO11BKqvOi9S152g5NnDP1y7Hk4L2h42UwTzWo909dtvQzpvoE4lNCkUrZ5bU123nyOiLo4dL63J683k5v0jrgxkef5(final int n, final int n2, final int[] array, final 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex) {
        super(n, n2, array, 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex);
    }
    
    @Override
    public boolean 8zDvxlifg2v7M5mTzZ01U8Hp5GK4vFsG10Itf2n8bAGupn8K0EATYPc9Gv8n(final int[] array) {
        final ArrayList list = new ArrayList();
        for (final int j : this.4bJH090TU6D4pW1r0aTNZ8EtLu5uO3Nx9mVoi9mh84hkOOlS5aO07wsp6al1) {
            if (j != -1) {
                list.add(j);
            }
        }
        for (final int n : array) {
            if (n != -1) {
                if (list.size() == 0) {
                    return false;
                }
                if (list.contains(n)) {
                    list.remove((Object)n);
                }
            }
        }
        return list.size() == 0;
    }
}
