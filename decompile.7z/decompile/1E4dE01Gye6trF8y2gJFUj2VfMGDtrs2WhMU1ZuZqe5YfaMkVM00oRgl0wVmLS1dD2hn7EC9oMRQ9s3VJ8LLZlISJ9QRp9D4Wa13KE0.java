import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 1E4dE01Gye6trF8y2gJFUj2VfMGDtrs2WhMU1ZuZqe5YfaMkVM00oRgl0wVmLS1dD2hn7EC9oMRQ9s3VJ8LLZlISJ9QRp9D4Wa13KE0 extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    private int 2v382L80n9GNB413XYzW8IJdfv3iSJyZK33o9rrYaet70giMVGcp5AG2WCRW;
    int 0GQi1TjM2FmICF11q3Sx0038M6wiH9jYx9fHyy340uF6ob7mVkEZxdiesD3T;
    int 6a448amLrpaLag8CA1fD4Nj99P6wmKt33K6Z3P7eQuaWg1SMJZnc845JwTX4;
    int 2nP6g52ZzinTcY4Mo5K9nnqt5l6Yg0KfQm9f49rHkqt7P88zW08DnUWeiOd8;
    int 7Ymqm3NHTxuZ728R81C8ga5x4uACLAAT4q7v3kuUiQ4lE5mrQi1aHg43D410;
    Random 2IjLCct7sIi53Vk1Xd145C6Iy8f13D0Rp9TrzqbS5u96ni70726U1h6a1tyF;
    
    public 1E4dE01Gye6trF8y2gJFUj2VfMGDtrs2WhMU1ZuZqe5YfaMkVM00oRgl0wVmLS1dD2hn7EC9oMRQ9s3VJ8LLZlISJ9QRp9D4Wa13KE0(final int 2v382L80n9GNB413XYzW8IJdfv3iSJyZK33o9rrYaet70giMVGcp5AG2WCRW, final int 0gQi1TjM2FmICF11q3Sx0038M6wiH9jYx9fHyy340uF6ob7mVkEZxdiesD3T, final int 6a448amLrpaLag8CA1fD4Nj99P6wmKt33K6Z3P7eQuaWg1SMJZnc845JwTX4) {
        this.2v382L80n9GNB413XYzW8IJdfv3iSJyZK33o9rrYaet70giMVGcp5AG2WCRW = 2v382L80n9GNB413XYzW8IJdfv3iSJyZK33o9rrYaet70giMVGcp5AG2WCRW;
        this.0GQi1TjM2FmICF11q3Sx0038M6wiH9jYx9fHyy340uF6ob7mVkEZxdiesD3T = 0gQi1TjM2FmICF11q3Sx0038M6wiH9jYx9fHyy340uF6ob7mVkEZxdiesD3T;
        this.6a448amLrpaLag8CA1fD4Nj99P6wmKt33K6Z3P7eQuaWg1SMJZnc845JwTX4 = 6a448amLrpaLag8CA1fD4Nj99P6wmKt33K6Z3P7eQuaWg1SMJZnc845JwTX4;
        this.2nP6g52ZzinTcY4Mo5K9nnqt5l6Yg0KfQm9f49rHkqt7P88zW08DnUWeiOd8 = 0gQi1TjM2FmICF11q3Sx0038M6wiH9jYx9fHyy340uF6ob7mVkEZxdiesD3T / 16;
        this.7Ymqm3NHTxuZ728R81C8ga5x4uACLAAT4q7v3kuUiQ4lE5mrQi1aHg43D410 = 6a448amLrpaLag8CA1fD4Nj99P6wmKt33K6Z3P7eQuaWg1SMJZnc845JwTX4 / 16;
    }
    
    public void 7gzkGZ6s69O5A0n0N5BG5QUHxAvE6E0C8iCLF1iR0tvlzyhYWlk421467F3T(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final int n4) {
        if (n4 == 0) {
            return;
        }
        for (int i = -n4; i <= n4; ++i) {
            for (int j = -n4; j <= n4; ++j) {
                for (int k = -n4; k <= n4; ++k) {
                    if (i * i + j * j + k * k <= n4 * n4) {
                        if ((n + i) / 16 - ((this.2nP6g52ZzinTcY4Mo5K9nnqt5l6Yg0KfQm9f49rHkqt7P88zW08DnUWeiOd8 < 0) ? 1 : 0) == this.2nP6g52ZzinTcY4Mo5K9nnqt5l6Yg0KfQm9f49rHkqt7P88zW08DnUWeiOd8 && (n3 + k) / 16 - ((this.7Ymqm3NHTxuZ728R81C8ga5x4uACLAAT4q7v3kuUiQ4lE5mrQi1aHg43D410 < 0) ? 1 : 0) == this.7Ymqm3NHTxuZ728R81C8ga5x4uACLAAT4q7v3kuUiQ4lE5mrQi1aHg43D410 && n2 + j >= 1) {
                            if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n + i, n2 + j, n3 + k) != 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.9455yfDY3L7R1n5G9W02hs7Do71W4pAVo7EH0F7K6DuPSZ1FU55BX5Oc39jF.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                                final boolean b = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n + i, n2 + j, n3 + k) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.9DwuHv1rF8tHn9hxQ74YH2a9UDMG087j4Z8NJ6X7ly1OaZNeZrC5MTA51CA7.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
                                if (n2 + j > 3 || b || (!b && this.2IjLCct7sIi53Vk1Xd145C6Iy8f13D0Rp9TrzqbS5u96ni70726U1h6a1tyF.nextInt(4) < 3)) {
                                    if (n2 + j <= 3) {
                                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n + i, n2 + j, n3 + k, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.950Cje4Cfg220sn9jKZs75F3vi3FLOw4iI1LIhe5y729KT7wW7F3wWvQOBtI.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                                        for (int l = -1; l <= 1; ++l) {
                                            for (int n5 = -1; n5 <= 1; ++n5) {
                                                for (int n6 = -1; n6 <= 1; ++n6) {
                                                    if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n + i + l, n2 + j + n6, n3 + k + n5) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.26V475EeKyTVt6B142Z2Jgcs6tr37z2in7wZlqoDyiUykn30S0vQ2evr9SGO.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                                                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n + i + l, n2 + j + n6, n3 + k + n5, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.86uF1FC9xUOGU0CrPUjNTBJys3fz1G75Br41gpC581m292G272WfaN5I6fea.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                                                    }
                                                    else if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n + i + l, n2 + j + n6, n3 + k + n5) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.35wK7RXXc4Uu2oc9JBTTNWs6ng4la5dQ6N3KM9ii276gF3OhPeoRtqJ1k8qk.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                                                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n + i + l, n2 + j + n6, n3 + k + n5, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.0f9HrKY257p2W1jO3NV2CMI9WVHT6K63qb0B0397V1rL281TUC2qrph09WeO.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                                                    }
                                                }
                                            }
                                        }
                                        if (n2 + j == 3 && this.2IjLCct7sIi53Vk1Xd145C6Iy8f13D0Rp9TrzqbS5u96ni70726U1h6a1tyF.nextInt(80) == 0) {
                                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n + i, n2 + j + 1, n3 + k, 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.9455yfDY3L7R1n5G9W02hs7Do71W4pAVo7EH0F7K6DuPSZ1FU55BX5Oc39jF.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                                        }
                                    }
                                    else {
                                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n + i, n2 + j, n3 + k, 0);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random 2IjLCct7sIi53Vk1Xd145C6Iy8f13D0Rp9TrzqbS5u96ni70726U1h6a1tyF, final int i, final int j, final int k) {
        this.2IjLCct7sIi53Vk1Xd145C6Iy8f13D0Rp9TrzqbS5u96ni70726U1h6a1tyF = 2IjLCct7sIi53Vk1Xd145C6Iy8f13D0Rp9TrzqbS5u96ni70726U1h6a1tyF;
        if (j < 10) {
            try {
                this.7gzkGZ6s69O5A0n0N5BG5QUHxAvE6E0C8iCLF1iR0tvlzyhYWlk421467F3T(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, i, j, k, this.2v382L80n9GNB413XYzW8IJdfv3iSJyZK33o9rrYaet70giMVGcp5AG2WCRW);
            }
            catch (final StackOverflowError stackOverflowError) {
                System.out.println("StackOverflowError at " + i + " " + j + " " + k + ", " + this.2v382L80n9GNB413XYzW8IJdfv3iSJyZK33o9rrYaet70giMVGcp5AG2WCRW);
            }
        }
        return true;
    }
}
