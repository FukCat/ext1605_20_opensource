import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 1A6ny00d874VnMnNbR38yJ6642BoDMnDKQIW0H9gkZ13WXSQO7i38t9ykv619w5q1R26xZD1tN13Ix20C7WjEwD032Ha9o4qn3U extends 3cicE9OcuQ29K8r10U2uUfKpu0noKEafUbw2915vFW0G88uOIN59T7E98VW968gI3dTP30nDL5DW6jg934fj60jaW3v0Q3xi3
{
    private Class 7kVz97275WKBi70o0C0D1SM7zbqNyT7A4vCjLD1iz0q4f0Zzi56UsymC9rbX;
    private boolean 7W7BI1TIpmSW9fATiPHHU120gD6vdUe7L7HEgvKwe8HsUs53ZmN6pY1Q1Gm4;
    
    protected 1A6ny00d874VnMnNbR38yJ6642BoDMnDKQIW0H9gkZ13WXSQO7i38t9ykv619w5q1R26xZD1tN13Ix20C7WjEwD032Ha9o4qn3U(final int n, final Class 7kVz97275WKBi70o0C0D1SM7zbqNyT7A4vCjLD1iz0q4f0Zzi56UsymC9rbX, final boolean 7w7BI1TIpmSW9fATiPHHU120gD6vdUe7L7HEgvKwe8HsUs53ZmN6pY1Q1Gm4) {
        super(n, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.0e51g5n7QQ2bM6IT7Q28hAbJkebnbMOVd3lRo7XioWLAkvTHV9DQxASpl4S7);
        this.7W7BI1TIpmSW9fATiPHHU120gD6vdUe7L7HEgvKwe8HsUs53ZmN6pY1Q1Gm4 = 7w7BI1TIpmSW9fATiPHHU120gD6vdUe7L7HEgvKwe8HsUs53ZmN6pY1Q1Gm4;
        this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H = 4;
        this.7kVz97275WKBi70o0C0D1SM7zbqNyT7A4vCjLD1iz0q4f0Zzi56UsymC9rbX = 7kVz97275WKBi70o0C0D1SM7zbqNyT7A4vCjLD1iz0q4f0Zzi56UsymC9rbX;
        final float n2 = 0.25f;
        this.9w0IOmY12qK4JKGsra5FT9k7v1rYm1s17GIX95bQJo39LwptHS50f5Ajuj4v(0.5f - n2, 0.0f, 0.5f - n2, 0.5f + n2, 1.0f, 0.5f + n2);
    }
    
    @Override
    public 85H57P2H4D6cj141sW70sW6k1pGNK4K4k78ms060bS9Wz8ktuElnkcl5YQCE3305VB1e75Xq1DQYF44ZEikQn64iKmEU62Tu9R5qy07u 6J37zOcIWT16DI1Y2mKTk13ZRQHrJfElzOfvvxDh5yf4fvn0N7dmFCKx1va5(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public 85H57P2H4D6cj141sW70sW6k1pGNK4K4k78ms060bS9Wz8ktuElnkcl5YQCE3305VB1e75Xq1DQYF44ZEikQn64iKmEU62Tu9R5qy07u 6qp1VQmY2L1KiOgfTp0h6d9fskSg58bT05JatwkGVzv0R9p60DOKiX2kNGq2(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        this.2kYL0QL7Y3Ro3Y1yNzOj7vPRxbJHjr7p7WfE46K7gPWnaMtKV793Q14sVRkA(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3);
        return super.6qp1VQmY2L1KiOgfTp0h6d9fskSg58bT05JatwkGVzv0R9p60DOKiX2kNGq2(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3);
    }
    
    @Override
    public void 2kYL0QL7Y3Ro3Y1yNzOj7vPRxbJHjr7p7WfE46K7gPWnaMtKV793Q14sVRkA(final 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa, final int n, final int n2, final int n3) {
        if (this.7W7BI1TIpmSW9fATiPHHU120gD6vdUe7L7HEgvKwe8HsUs53ZmN6pY1Q1Gm4) {
            return;
        }
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        final float n4 = 0.28125f;
        final float n5 = 0.78125f;
        final float n6 = 0.0f;
        final float n7 = 1.0f;
        final float n8 = 0.125f;
        this.9w0IOmY12qK4JKGsra5FT9k7v1rYm1s17GIX95bQJo39LwptHS50f5Ajuj4v(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 2) {
            this.9w0IOmY12qK4JKGsra5FT9k7v1rYm1s17GIX95bQJo39LwptHS50f5Ajuj4v(n6, n4, 1.0f - n8, n7, n5, 1.0f);
        }
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 3) {
            this.9w0IOmY12qK4JKGsra5FT9k7v1rYm1s17GIX95bQJo39LwptHS50f5Ajuj4v(n6, n4, 0.0f, n7, n5, n8);
        }
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 4) {
            this.9w0IOmY12qK4JKGsra5FT9k7v1rYm1s17GIX95bQJo39LwptHS50f5Ajuj4v(1.0f - n8, n4, n6, 1.0f, n5, n7);
        }
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 5) {
            this.9w0IOmY12qK4JKGsra5FT9k7v1rYm1s17GIX95bQJo39LwptHS50f5Ajuj4v(0.0f, n4, n6, n8, n5, n7);
        }
    }
    
    @Override
    public int 0u4ekfGDm86890j6n5AZfgN3QIDRX4H6yneJUsRUQ4VO62cekiq5jz1Kvh2O() {
        return -1;
    }
    
    @Override
    public boolean 31N9l23iv8Yym635LvdOS67pYmji01td0Ady0mmv8002jWWzg2Puqhev5sQN() {
        return false;
    }
    
    @Override
    public boolean 0h7ja7JP1RVvR1k3BkHI25xIPjD0Mt7VMr7R1eHBtT1qev9PQb01Fzly06mZ() {
        return false;
    }
    
    @Override
    protected 2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex 8cW5T5YlOAxd2blGPDHwxROAJxAZ44YaVVZgMOsT8936vX6dFUzUTFYe648j() {
        try {
            return this.7kVz97275WKBi70o0C0D1SM7zbqNyT7A4vCjLD1iz0q4f0Zzi56UsymC9rbX.newInstance();
        }
        catch (final Exception cause) {
            throw new RuntimeException(cause);
        }
    }
    
    @Override
    public int 8LTZgqX2KHwGhNpQ1gUZz1WaWt0W2TrjgClq35mEWEh8l45qEVZXQ21Rh3g0(final int n, final Random random) {
        return 9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.1kh95G9G2xoVXwfeXfq2zw2YVJqR8FOW931667oNkT1sLxs58kMQ1HU1x31N.016D6B0WzYa1oAf8GVzuN3e04Nkxq5CzkT5YVZhj2l5H8LW20C9lkr0R7pc5;
    }
    
    @Override
    public void 6h3l210oGEo49l82x77rDdyZUKun1F8QNLnnDCf3tv8b50V1jN65C00KJNcU(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final int n4) {
        boolean b = false;
        if (this.7W7BI1TIpmSW9fATiPHHU120gD6vdUe7L7HEgvKwe8HsUs53ZmN6pY1Q1Gm4) {
            if (!5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n, n2 - 1, n3).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = true;
            }
        }
        else {
            final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
            b = true;
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 2 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n, n2, n3 + 1).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = false;
            }
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 3 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n, n2, n3 - 1).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = false;
            }
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 4 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n + 1, n2, n3).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = false;
            }
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 5 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n - 1, n2, n3).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = false;
            }
        }
        if (b) {
            this.6Cnl2PaKjrc6k6wE8o73ZBVio1M3awh3XYqVc5Ng3Cl598nAkhj6ML5CS62i(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3, 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3));
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(n, n2, n3, 0);
        }
        super.6h3l210oGEo49l82x77rDdyZUKun1F8QNLnnDCf3tv8b50V1jN65C00KJNcU(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3, n4);
    }
}
