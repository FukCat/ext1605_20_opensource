import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 0Zx2l0Q3a3u30a2SxU4IitiV5xWQ5UPxVF5R8T5eTby308L5bi6c52XW7PQZBzLbPiUk38fLf06AHG1q5Y1b6523qQZy175wB3u extends 3YAC6RZ6s2my387oS7V3td978c0gJo766d6dK3zs6ECjPFD6ZQK1iy5mN7AfUMNKmda06IYmFxb9I08Rby6pbL9Aq6Gu01j7
{
    public 0Zx2l0Q3a3u30a2SxU4IitiV5xWQ5UPxVF5R8T5eTby308L5bi6c52XW7PQZBzLbPiUk38fLf06AHG1q5Y1b6523qQZy175wB3u() {
        this.29g8SsPmU7TOWROl8YhJNmZ6gRdy8c1X38Dj923Pb9U6366k9qHLOTDay6e1 = true;
    }
    
    public 0Zx2l0Q3a3u30a2SxU4IitiV5xWQ5UPxVF5R8T5eTby308L5bi6c52XW7PQZBzLbPiUk38fLf06AHG1q5Y1b6523qQZy175wB3u(final double 8k8fOf10zE5wV426PW513LOn9XFZ1fW1KN47mham0Q1T1sC2365M6Dmfv50R, final double 978sLV88WnWtzqjW7Kxf5652l71IDb0hi79eh44BM0dp8OkX226m1F1932X1, final double 11jvlckYUeM123Wigt8l2UK3HC2VeduD17j51f1dGo17bP2oFOPCYYv0323p, final double 0c92r8Qs8QI56bbtotz212jZ1zv438xGfs6d98zejI4990LeJ3v83KBzM8HW, final boolean 2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e) {
        this.8k8fOf10zE5wV426PW513LOn9XFZ1fW1KN47mham0Q1T1sC2365M6Dmfv50R = 8k8fOf10zE5wV426PW513LOn9XFZ1fW1KN47mham0Q1T1sC2365M6Dmfv50R;
        this.978sLV88WnWtzqjW7Kxf5652l71IDb0hi79eh44BM0dp8OkX226m1F1932X1 = 978sLV88WnWtzqjW7Kxf5652l71IDb0hi79eh44BM0dp8OkX226m1F1932X1;
        this.11jvlckYUeM123Wigt8l2UK3HC2VeduD17j51f1dGo17bP2oFOPCYYv0323p = 11jvlckYUeM123Wigt8l2UK3HC2VeduD17j51f1dGo17bP2oFOPCYYv0323p;
        this.0c92r8Qs8QI56bbtotz212jZ1zv438xGfs6d98zejI4990LeJ3v83KBzM8HW = 0c92r8Qs8QI56bbtotz212jZ1zv438xGfs6d98zejI4990LeJ3v83KBzM8HW;
        this.2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e = 2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e;
        this.29g8SsPmU7TOWROl8YhJNmZ6gRdy8c1X38Dj923Pb9U6366k9qHLOTDay6e1 = true;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.8k8fOf10zE5wV426PW513LOn9XFZ1fW1KN47mham0Q1T1sC2365M6Dmfv50R = dataInputStream.readDouble();
        this.978sLV88WnWtzqjW7Kxf5652l71IDb0hi79eh44BM0dp8OkX226m1F1932X1 = dataInputStream.readDouble();
        this.11jvlckYUeM123Wigt8l2UK3HC2VeduD17j51f1dGo17bP2oFOPCYYv0323p = dataInputStream.readDouble();
        this.0c92r8Qs8QI56bbtotz212jZ1zv438xGfs6d98zejI4990LeJ3v83KBzM8HW = dataInputStream.readDouble();
        super.5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(dataInputStream);
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeDouble(this.8k8fOf10zE5wV426PW513LOn9XFZ1fW1KN47mham0Q1T1sC2365M6Dmfv50R);
        dataOutputStream.writeDouble(this.978sLV88WnWtzqjW7Kxf5652l71IDb0hi79eh44BM0dp8OkX226m1F1932X1);
        dataOutputStream.writeDouble(this.11jvlckYUeM123Wigt8l2UK3HC2VeduD17j51f1dGo17bP2oFOPCYYv0323p);
        dataOutputStream.writeDouble(this.0c92r8Qs8QI56bbtotz212jZ1zv438xGfs6d98zejI4990LeJ3v83KBzM8HW);
        super.45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(dataOutputStream);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 33;
    }
}
