import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 4325k26DmdDV5j1IjV8vrJo24qmGuT5bdNIPVFSKq79WjWX76Kvn9Ka2FTG9Oj8mEV9YUvbCa8k19y8M5Yv3alQH98valwFA6x4 extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 5bbd56zO5pr09SC03724TA8d6G95GE08W04VdXteG3abdW83292DHfYH6jtV;
    public byte 32IePI70ogeJpKwlw99WMbygHnX7iquc00HHszN008hEOF6C06fbvoR7bxIV;
    public byte 55K97y551O34c270aFA8fuBwB9Z3h3M5T4u9shhaW8Vi7vH5ePeFf295bXno;
    public byte 4bfk3jX8Cka91MqwpVL5YCz1YQF0Rd1X8d1ddI9yu2962ygg3rWzwN17l792;
    public byte 89ZMZvJM7P89t2LhuJh0usV9Uit50q5j2m1dxl4FjBLFaw60MIkfnVo0r60U;
    public byte 2v3jgPEGWF4g1HyZ16l4fH9sH1dXuzDIP65jk5oorm14J4XWYI2pu4L125sQ;
    public boolean 27MZR7Vsau5qN5V155085PngR83EV19wcMsl9W3YLJDrMggvdkWAu5tAS4Hf;
    
    public 4325k26DmdDV5j1IjV8vrJo24qmGuT5bdNIPVFSKq79WjWX76Kvn9Ka2FTG9Oj8mEV9YUvbCa8k19y8M5Yv3alQH98valwFA6x4() {
        this.27MZR7Vsau5qN5V155085PngR83EV19wcMsl9W3YLJDrMggvdkWAu5tAS4Hf = false;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.5bbd56zO5pr09SC03724TA8d6G95GE08W04VdXteG3abdW83292DHfYH6jtV = dataInputStream.readInt();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.5bbd56zO5pr09SC03724TA8d6G95GE08W04VdXteG3abdW83292DHfYH6jtV);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.0Bx6vJ95hHsHLh13K3IjNtPbXAJE3YJ4sHGDes03XT721eBeFyJ8tU427Fn9(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 4;
    }
}
