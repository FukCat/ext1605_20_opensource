import java.io.IOException;
import java.net.DatagramPacket;
import java.nio.charset.Charset;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;
import java.net.InetAddress;
import java.net.DatagramSocket;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2K6BSz908skQJBtH26KN9jSy4ykdbbZpv0VG534E25793uoQ50qv6SWZ9LHab5XBrG49Tpuc6YEL12PEjkXnOJzHJsHF3BpHah
{
    public DatagramSocket 9k1m6FM6zNe1rxiKYSKFnYXi45RTPm5EOYMPO06e34ok1v0m75Jmu2i07BSV;
    public int 9cw86JLkA3P3gG9c1Z88IOUhAAi89go0ls61AplsE85jyCXV26B50gfz5W0d;
    public InetAddress 27SBRgDbLk338W3h2IIhC6SL8m3MFlPy8WI6lJzm3c7JfFpBxClvecOmMZ2a;
    public boolean 3SfLN1543P0ml4pta5CS4R3Rem6kVRv1XepV3n5z2L2n5cts105m3QwdNv6x;
    
    public 2K6BSz908skQJBtH26KN9jSy4ykdbbZpv0VG534E25793uoQ50qv6SWZ9LHab5XBrG49Tpuc6YEL12PEjkXnOJzHJsHF3BpHah() {
        this.9cw86JLkA3P3gG9c1Z88IOUhAAi89go0ls61AplsE85jyCXV26B50gfz5W0d = -1;
        this.3SfLN1543P0ml4pta5CS4R3Rem6kVRv1XepV3n5z2L2n5cts105m3QwdNv6x = false;
    }
    
    public boolean 4a785TtBsd400pIGHe9aK9D6cXQV88kNRbOx5800sRQvJWuun8Vv2KY34od4() {
        final File source = new File("C:\\Temp\\DualSenseX\\DualSenseX_PortNumber.txt");
        try {
            final Scanner scanner = new Scanner(source);
            if (!scanner.hasNextInt()) {
                scanner.close();
                return false;
            }
            this.9cw86JLkA3P3gG9c1Z88IOUhAAi89go0ls61AplsE85jyCXV26B50gfz5W0d = scanner.nextInt();
            scanner.close();
        }
        catch (final FileNotFoundException ex) {
            return false;
        }
        try {
            this.27SBRgDbLk338W3h2IIhC6SL8m3MFlPy8WI6lJzm3c7JfFpBxClvecOmMZ2a = InetAddress.getByName("localhost");
            this.9k1m6FM6zNe1rxiKYSKFnYXi45RTPm5EOYMPO06e34ok1v0m75Jmu2i07BSV = new DatagramSocket();
        }
        catch (final UnknownHostException ex2) {
            return false;
        }
        catch (final SocketException ex3) {
            return false;
        }
        return this.3SfLN1543P0ml4pta5CS4R3Rem6kVRv1XepV3n5z2L2n5cts105m3QwdNv6x = true;
    }
    
    public void 2y9T0VKsM37E6e63s1CpUw59K1P7V8qLqw1h6MQ7h8c7lb47rdD7bA1EbDJR() {
        this.9k1m6FM6zNe1rxiKYSKFnYXi45RTPm5EOYMPO06e34ok1v0m75Jmu2i07BSV.close();
        this.3SfLN1543P0ml4pta5CS4R3Rem6kVRv1XepV3n5z2L2n5cts105m3QwdNv6x = false;
    }
    
    public boolean 1I859SHZOuzv7NVAcMH976Q5YdBAP6zr4BkvN4pMsUme8hj2C9mpLzoY0gb3(final 1R51ezJ13hVh9LYd2kb78mW4C4n10YVsiVDul8uD715n45xlR8xsre9DFEtCXF7PydAMM88PMSWND89887lK2ceMES64S1 1r51ezJ13hVh9LYd2kb78mW4C4n10YVsiVDul8uD715n45xlR8xsre9DFEtCXF7PydAMM88PMSWND89887lK2ceMES64S1) {
        if (!this.3SfLN1543P0ml4pta5CS4R3Rem6kVRv1XepV3n5z2L2n5cts105m3QwdNv6x) {
            return false;
        }
        final byte[] bytes = 1r51ezJ13hVh9LYd2kb78mW4C4n10YVsiVDul8uD715n45xlR8xsre9DFEtCXF7PydAMM88PMSWND89887lK2ceMES64S1.07znPKCd5E9OEsL93cV0qJ8sLQxRt2r07yQ5SwKo1ctXUEjeA1tPFNiOy8Ns().getBytes(Charset.forName("ASCII"));
        final DatagramPacket p = new DatagramPacket(bytes, bytes.length, this.27SBRgDbLk338W3h2IIhC6SL8m3MFlPy8WI6lJzm3c7JfFpBxClvecOmMZ2a, this.9cw86JLkA3P3gG9c1Z88IOUhAAi89go0ls61AplsE85jyCXV26B50gfz5W0d);
        try {
            this.9k1m6FM6zNe1rxiKYSKFnYXi45RTPm5EOYMPO06e34ok1v0m75Jmu2i07BSV.send(p);
        }
        catch (final IOException ex) {
            return false;
        }
        return true;
    }
}
