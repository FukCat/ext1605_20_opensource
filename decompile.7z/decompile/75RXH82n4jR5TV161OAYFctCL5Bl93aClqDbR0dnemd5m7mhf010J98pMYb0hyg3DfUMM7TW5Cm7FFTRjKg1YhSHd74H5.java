import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 75RXH82n4jR5TV161OAYFctCL5Bl93aClqDbR0dnemd5m7mhf010J98pMYb0hyg3DfUMM7TW5Cm7FFTRjKg1YhSHd74H5 extends 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC
{
    protected 75RXH82n4jR5TV161OAYFctCL5Bl93aClqDbR0dnemd5m7mhf010J98pMYb0hyg3DfUMM7TW5Cm7FFTRjKg1YhSHd74H5(final int n) {
        super(n, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.0e51g5n7QQ2bM6IT7Q28hAbJkebnbMOVd3lRo7XioWLAkvTHV9DQxASpl4S7);
        this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41 = 20;
    }
    
    @Override
    public int 6M14lZVXL6xs4lKY6vj11vAQ2E9U9ZDOF0Nh9aCHYAlz8F6Pfx930Z7gxmzf(final Random random) {
        return 1;
    }
    
    @Override
    public int 9hFrB67UQ3xIdu153AXx7FYrppLysZW3gpO0hVR27pm9IQlKb2jF25i9DO3e(final int n, final Random random) {
        return 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.449GA8f0N005Fb6O5d4HBSxHZV01PAz6Qhko184YtIQxNvf7E8e8756HRemv.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
    }
    
    @Override
    public int 8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(final int n) {
        return (n == 1) ? 21 : ((n == 0) ? 21 : 20);
    }
}
