import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

// 
// Decompiled by Procyon v0.6.0
// 

public class 020lGmSPEHXe89p40VZigrfoo2PR0v7NbUq1qJXJT2slfJ81J2tA1VcL8R5jGXS72R1xrrOCtW1VHG23J3EJ5fSSVPb839a87 extends 57wxscSM69a2zrUjxq8bMyg1h94Tc28sM8bT8N09Pcd30hQvNGTeaI9n7lM5v4vB92233pJJ82QI68DDvu30Wi21QviQHu
{
    private List<06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4> 3n3877cAL198QgMDPGv8AXYIec0mHr5ObtZma81Yl5nX8ugCz86y6XL9Pi5O;
    
    public 020lGmSPEHXe89p40VZigrfoo2PR0v7NbUq1qJXJT2slfJ81J2tA1VcL8R5jGXS72R1xrrOCtW1VHG23J3EJ5fSSVPb839a87() {
        this.3n3877cAL198QgMDPGv8AXYIec0mHr5ObtZma81Yl5nX8ugCz86y6XL9Pi5O = new ArrayList<06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4>();
    }
    
    private boolean 5uod1iu6Dlqg52iO0v6qFBPdixFGfm6LmbnW4Rx3Ep7C4LSh0InO8QKqkeJk() {
        final Iterator<06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4> iterator = this.3n3877cAL198QgMDPGv8AXYIec0mHr5ObtZma81Yl5nX8ugCz86y6XL9Pi5O.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().5204axQba8r4yKOmf635c4mf99bQl70mm0X8b96R3NY7EX2N636dc3j5E7Jq()) {
                return true;
            }
        }
        return false;
    }
    
    private 06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4 8OSUykYWUR3a2r3PPU9aWX0djkEYBjTtmmkhtMY0762Vl2FaAN2L4j7JvJpd(final int n, final int n2, final int n3) {
        if (!this.5uod1iu6Dlqg52iO0v6qFBPdixFGfm6LmbnW4Rx3Ep7C4LSh0InO8QKqkeJk()) {
            return null;
        }
        final int n4 = (n == 0 && n2 == 1 && n3 == 0) ? 0 : this.1O0R784ChH0Na1Ko396gF5k7c80ww6xh7TZvBIG5LmcX1WdkyMYaD0dL9PKd.nextInt(5);
        return null;
    }
}
