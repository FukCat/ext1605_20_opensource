import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2moT8juVihvba3tApU9cyOLU2bScpMbtSx55rr9L1JTp234FzHZkFhfLCq4jWMqcwl80gi56KKNA634lv1m9h3tJzyCFTGC6 extends Thread
{
    final Minecraft 5qOa6idsmKS7661hxge9Fq1hO6Bj56Af53SQjm327S4dol3930ABGpZExtdk;
    
    public 2moT8juVihvba3tApU9cyOLU2bScpMbtSx55rr9L1JTp234FzHZkFhfLCq4jWMqcwl80gi56KKNA634lv1m9h3tJzyCFTGC6(final Minecraft 5qOa6idsmKS7661hxge9Fq1hO6Bj56Af53SQjm327S4dol3930ABGpZExtdk, final String name) {
        super(name);
        this.5qOa6idsmKS7661hxge9Fq1hO6Bj56Af53SQjm327S4dol3930ABGpZExtdk = 5qOa6idsmKS7661hxge9Fq1hO6Bj56Af53SQjm327S4dol3930ABGpZExtdk;
        this.setDaemon(true);
        this.start();
    }
    
    @Override
    public void run() {
        while (this.5qOa6idsmKS7661hxge9Fq1hO6Bj56Af53SQjm327S4dol3930ABGpZExtdk.1z4ObCPpG0p71XzmKI5pA52oCuNeQd7W52IDk8415gt4kK2zAQcGob4V39RR) {
            try {
                Thread.sleep(2147483647L);
            }
            catch (final InterruptedException ex) {}
        }
    }
}
