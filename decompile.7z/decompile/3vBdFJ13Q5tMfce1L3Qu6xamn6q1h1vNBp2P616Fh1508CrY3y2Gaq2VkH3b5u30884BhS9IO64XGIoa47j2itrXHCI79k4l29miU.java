import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 3vBdFJ13Q5tMfce1L3Qu6xamn6q1h1vNBp2P616Fh1508CrY3y2Gaq2VkH3b5u30884BhS9IO64XGIoa47j2itrXHCI79k4l29miU extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    private int 7A7YG57y3kFS29peJ5aO9t819c85Teix9g7C1RWOn5Q4J20p76I2YuY9p5b0;
    
    public 3vBdFJ13Q5tMfce1L3Qu6xamn6q1h1vNBp2P616Fh1508CrY3y2Gaq2VkH3b5u30884BhS9IO64XGIoa47j2itrXHCI79k4l29miU() {
        this.7A7YG57y3kFS29peJ5aO9t819c85Teix9g7C1RWOn5Q4J20p76I2YuY9p5b0 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.4oL60E1ssJ08C8nW9fyx8u1898vvu5nF2SwNJB5U7n0uNywP6r37x5ED8j0L.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
    }
    
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 64; ++i) {
            final int n4 = n + random.nextInt(8) - random.nextInt(8);
            final int n5 = n2 + random.nextInt(4) - random.nextInt(4);
            final int n6 = n3 + random.nextInt(8) - random.nextInt(8);
            if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n4, n5, n6) == 0) {
                if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[this.7A7YG57y3kFS29peJ5aO9t819c85Teix9g7C1RWOn5Q4J20p76I2YuY9p5b0].8RS28Xf0FuA8Ecl1T85B1mB0rQ585WxI8MN6PnD57WSn3kXaXF968F4kI5x1(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n4, n5, n6)) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n4, n5, n6, this.7A7YG57y3kFS29peJ5aO9t819c85Teix9g7C1RWOn5Q4J20p76I2YuY9p5b0);
                }
            }
        }
        return true;
    }
}
