import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 9nS6bmCLrE89PK9sq2C1E94rytwgYi8fW4BRL53jojALFRXsSko6efCM240sH2PLLO03nez5uc2f1iRR25o58BZiw5pgYEa401TU2 extends 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC
{
    protected 9nS6bmCLrE89PK9sq2C1E94rytwgYi8fW4BRL53jojALFRXsSko6efCM240sH2PLLO03nez5uc2f1iRR25o58BZiw5pgYEa401TU2(final int n, final int n2) {
        super(n, n2, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.3lE3v2U178mJeky6160HyMWuqr0Un4P7phvN7sTLwpg14mR6kInDYdcjJd30);
        this.8KA5yJRt7pv9ZbpZI39s4nb12a25m0cl84QCU39blwneh2sFf2Vm5km8DcV9(true);
    }
    
    @Override
    public int 9hFrB67UQ3xIdu153AXx7FYrppLysZW3gpO0hVR27pm9IQlKb2jF25i9DO3e(final int n, final Random random) {
        return 9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.07q3i5uyM63RQChLsPkeOz5gM1y4JlhDZ6C83HtsrACiEeSO6fI61G5d15pl.016D6B0WzYa1oAf8GVzuN3e04Nkxq5CzkT5YVZhj2l5H8LW20C9lkr0R7pc5;
    }
    
    @Override
    public int 6M14lZVXL6xs4lKY6vj11vAQ2E9U9ZDOF0Nh9aCHYAlz8F6Pfx930Z7gxmzf(final Random random) {
        return 4;
    }
    
    @Override
    public void 4078HMR7qcMBAz3w7Wq6QiAdGBCLCJ7o6qt9rjDU11jPE3M066o5hv9stTs0(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final Random random) {
        if (random.nextBoolean()) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6z0LyHt8cjp6K2a66C88t2L84s2JTd7v23E75aN3LSm3zx61W8xn9Pz0FaO0("snow1", n, n2, n3, (random.nextDouble() - 0.5) * 0.1, 0.8, (random.nextDouble() - 0.5) * 0.1);
        }
        if (random.nextBoolean()) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6z0LyHt8cjp6K2a66C88t2L84s2JTd7v23E75aN3LSm3zx61W8xn9Pz0FaO0("snow2", n, n2, n3, (random.nextDouble() - 0.5) * 0.2, 0.95, (random.nextDouble() - 0.5) * 0.2);
        }
        if (random.nextBoolean()) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6z0LyHt8cjp6K2a66C88t2L84s2JTd7v23E75aN3LSm3zx61W8xn9Pz0FaO0("snow3", n, n2, n3, (random.nextDouble() + 0.5) * 0.2, 0.45, (random.nextDouble() - 0.5) * 0.1);
        }
        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.90sO6ErOdJr7717xc1d6WJVok7xIFQV1iQ7WJ71dBrCrOn70xF2g62G2O349(82XfAxsgRmgGjtK1Xcd5FB9acvlsZILQV11715f83X9SIk9s6HocDyHF717WC3gSjN48D3bsph2Q3u8i04gkKUE0w3W5dKuwe.68SfSnxP5FU6u2BZvxqwy6py30332wYQQqHk4EEaTo4isnMHXV27H46k3QEu, n, n2, n3) > 11) {
            this.34c2i0BTc9ESKRlH8o24MFx27N7S3sQf54gg2xV6ZbZrdGZ1JlWKc3u2Dk65(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3, 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3));
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(n, n2, n3, 0);
        }
    }
}
