// 
// Decompiled by Procyon v0.6.0
// 

public class 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT extends 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03
{
    public boolean 88RPpNfetf0C362yVBUQMTpRl0s54b6HMb02n1qnBrRIAWhWB1oo7eYgvXfq;
    
    public 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT(final int n, final int n2, final int n3, final int n4, final int n5, final String s, final boolean 88RPpNfetf0C362yVBUQMTpRl0s54b6HMb02n1qnBrRIAWhWB1oo7eYgvXfq) {
        super(n, n2, n3, n4, n5, s);
        this.88RPpNfetf0C362yVBUQMTpRl0s54b6HMb02n1qnBrRIAWhWB1oo7eYgvXfq = false;
        this.88RPpNfetf0C362yVBUQMTpRl0s54b6HMb02n1qnBrRIAWhWB1oo7eYgvXfq = 88RPpNfetf0C362yVBUQMTpRl0s54b6HMb02n1qnBrRIAWhWB1oo7eYgvXfq;
    }
    
    public 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT(final int n, final int n2, final int n3, final String s) {
        super(n, n2, n3, 50, 20, s);
        this.88RPpNfetf0C362yVBUQMTpRl0s54b6HMb02n1qnBrRIAWhWB1oo7eYgvXfq = false;
    }
    
    @Override
    public boolean 6nn76xn75jkNpKB9Sh129Q32vm9N0lG68zRy7yDWq13FtymI5qk8UIhvhIPd() {
        return this.88RPpNfetf0C362yVBUQMTpRl0s54b6HMb02n1qnBrRIAWhWB1oo7eYgvXfq;
    }
}
