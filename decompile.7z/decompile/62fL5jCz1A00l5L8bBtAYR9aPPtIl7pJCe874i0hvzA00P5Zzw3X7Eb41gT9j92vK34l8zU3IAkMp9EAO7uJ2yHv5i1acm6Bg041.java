import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL11;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.lwjgl.opengl.ARBShaderObjects;
import net.minecraft.client.Minecraft;
import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 62fL5jCz1A00l5L8bBtAYR9aPPtIl7pJCe874i0hvzA00P5Zzw3X7Eb41gT9j92vK34l8zU3IAkMp9EAO7uJ2yHv5i1acm6Bg041
{
    public int 6hrv4v954Okb7obaj0yHtV3G5Pxi4HLBshp8pHZ6gBKLb8z38aC0Wl5J781Q;
    public int 6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni;
    private int 2fk6kdaE94v3T9513Sk23R46mYaA5nqbbaE37TC85q0I8bC3Rul64T4PeL7t;
    private int 91wim1EVvh3KkuC0VI77xjt4EvJUg5K9i65b5GTg1PsB8Vv00h1Sje3KX91p;
    public int 5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C;
    private int 0Jliadq6MiR90YwBX2EcyoC4q777p4ThxDrqTIN9pjcRGK23VU3JY7xA9v39;
    private int 8q3NnYF395aMwM6JsGAH1dqDyCG6rgY7QK44W9yx8CEBc2hSTW4rcLdNgth0;
    private int 0SSC84N8JG6dE09gQ6910N5N78f81K4E4ovsfRt5iRjZCSVdok9vRwTZuh1k;
    private int 385X644BXT9qBn6EF1gIbS63mT0B092Z2lynp6yudR6UJeSv1MPf63o296yR;
    private int 99QURSTWyu6T75EQj21pgtAS627wxwQ52Z8b7F8U3R81i613FC3SJLY2aTbs;
    private int 9441y1Y9T40FDCF9uuwkU1lmehM65hg8761b2m6X1BgG7auF90lDMvklrCeq;
    private int 6lfU3mNn3UomWZH8MfUGPg4LX59b1U18fabPV53p2u7ludbeYE1196g5rWX6;
    private int 20GQz7zR34Tp693G3DSupFXBE66x7RUvn9JBul8RyCo5s50123NSbmOaYt5u;
    private int 2i7O7iJDFtoO2YSWX2e96Df4ACzXIrBwc2Khi70y062n1HJaqNA1njxwdt6o;
    private int 5OVC2g2d9zq6dP14qJsUlMx8ghzyNOS2n5hh0gcYmL4BF9KuER7SqHiYE809;
    private int 3W20rY0C5sq1crIFTGspopkir94xT6ZbCJ2HfG0YdtAolGW79iW5ue93k9gj;
    public Random 2SsePNiNxSOe8T43T3RkxQkXltd0oPOKg7w710gmT1w1fVdSSd15fP0M69aI;
    private Minecraft 6kPc5bsQEopw306pUZPVI78jGyAvqN5EXMDClw6q2Hy6z4n2X8f6EJIXw0Zs;
    
    public 62fL5jCz1A00l5L8bBtAYR9aPPtIl7pJCe874i0hvzA00P5Zzw3X7Eb41gT9j92vK34l8zU3IAkMp9EAO7uJ2yHv5i1acm6Bg041(final Minecraft 6kPc5bsQEopw306pUZPVI78jGyAvqN5EXMDClw6q2Hy6z4n2X8f6EJIXw0Zs) {
        this.6hrv4v954Okb7obaj0yHtV3G5Pxi4HLBshp8pHZ6gBKLb8z38aC0Wl5J781Q = 0;
        this.6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni = 0;
        this.2fk6kdaE94v3T9513Sk23R46mYaA5nqbbaE37TC85q0I8bC3Rul64T4PeL7t = 0;
        this.91wim1EVvh3KkuC0VI77xjt4EvJUg5K9i65b5GTg1PsB8Vv00h1Sje3KX91p = 0;
        this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C = 0;
        this.0Jliadq6MiR90YwBX2EcyoC4q777p4ThxDrqTIN9pjcRGK23VU3JY7xA9v39 = 0;
        this.8q3NnYF395aMwM6JsGAH1dqDyCG6rgY7QK44W9yx8CEBc2hSTW4rcLdNgth0 = 0;
        this.0SSC84N8JG6dE09gQ6910N5N78f81K4E4ovsfRt5iRjZCSVdok9vRwTZuh1k = 0;
        this.385X644BXT9qBn6EF1gIbS63mT0B092Z2lynp6yudR6UJeSv1MPf63o296yR = 0;
        this.99QURSTWyu6T75EQj21pgtAS627wxwQ52Z8b7F8U3R81i613FC3SJLY2aTbs = 0;
        this.9441y1Y9T40FDCF9uuwkU1lmehM65hg8761b2m6X1BgG7auF90lDMvklrCeq = 0;
        this.6lfU3mNn3UomWZH8MfUGPg4LX59b1U18fabPV53p2u7ludbeYE1196g5rWX6 = 0;
        this.20GQz7zR34Tp693G3DSupFXBE66x7RUvn9JBul8RyCo5s50123NSbmOaYt5u = 0;
        this.2i7O7iJDFtoO2YSWX2e96Df4ACzXIrBwc2Khi70y062n1HJaqNA1njxwdt6o = 0;
        this.5OVC2g2d9zq6dP14qJsUlMx8ghzyNOS2n5hh0gcYmL4BF9KuER7SqHiYE809 = 0;
        this.3W20rY0C5sq1crIFTGspopkir94xT6ZbCJ2HfG0YdtAolGW79iW5ue93k9gj = 0;
        this.2SsePNiNxSOe8T43T3RkxQkXltd0oPOKg7w710gmT1w1fVdSSd15fP0M69aI = new Random();
        this.6kPc5bsQEopw306pUZPVI78jGyAvqN5EXMDClw6q2Hy6z4n2X8f6EJIXw0Zs = 6kPc5bsQEopw306pUZPVI78jGyAvqN5EXMDClw6q2Hy6z4n2X8f6EJIXw0Zs;
        this.9r1511Jp0jE144f4MQc4NK82XBZn9UtKQ9T0m3371572UnC4jS4YM9eJUhB9();
    }
    
    public void 9r1511Jp0jE144f4MQc4NK82XBZn9UtKQ9T0m3371572UnC4jS4YM9eJUhB9() {
        this.6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni = ARBShaderObjects.glCreateProgramObjectARB();
        if (this.6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni != 0) {
            this.2fk6kdaE94v3T9513Sk23R46mYaA5nqbbaE37TC85q0I8bC3Rul64T4PeL7t = this.0u1i79tq0P37AEqTW68P5h1i60IaZ9B5ZJcVyUU5cxE4ZBy70htlWd17uQle("/ext1605/shaders/default/base.vsh");
            this.91wim1EVvh3KkuC0VI77xjt4EvJUg5K9i65b5GTg1PsB8Vv00h1Sje3KX91p = this.1z5mnRcFcRlTWBe1jp2xD0rCP4M4Y54xinN7y78Gku4p1Fs79CtzhXaAM43P("/ext1605/shaders/default/base.fsh");
        }
        if (this.2fk6kdaE94v3T9513Sk23R46mYaA5nqbbaE37TC85q0I8bC3Rul64T4PeL7t != 0 && this.91wim1EVvh3KkuC0VI77xjt4EvJUg5K9i65b5GTg1PsB8Vv00h1Sje3KX91p != 0) {
            ARBShaderObjects.glAttachObjectARB(this.6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni, this.2fk6kdaE94v3T9513Sk23R46mYaA5nqbbaE37TC85q0I8bC3Rul64T4PeL7t);
            ARBShaderObjects.glAttachObjectARB(this.6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni, this.91wim1EVvh3KkuC0VI77xjt4EvJUg5K9i65b5GTg1PsB8Vv00h1Sje3KX91p);
            ARBShaderObjects.glLinkProgramARB(this.6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni);
            ARBShaderObjects.glValidateProgramARB(this.6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni);
            if (!0Xl1zrDDJ6B7f1Ga59F3PLk9v9hZR3c4d9CJ6uv71JQVj2ByH42wT0OY43XH(this.6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni)) {
                this.6G238hzdz174ui01Kn7hC7aXG4OFtxgSTqd88RZTU29K01h2S9Ewl85O71ni = 0;
            }
        }
        this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C = ARBShaderObjects.glCreateProgramObjectARB();
        if (this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C != 0) {
            this.0Jliadq6MiR90YwBX2EcyoC4q777p4ThxDrqTIN9pjcRGK23VU3JY7xA9v39 = this.0u1i79tq0P37AEqTW68P5h1i60IaZ9B5ZJcVyUU5cxE4ZBy70htlWd17uQle("/ext1605/shaders/default/final.vsh");
            this.8q3NnYF395aMwM6JsGAH1dqDyCG6rgY7QK44W9yx8CEBc2hSTW4rcLdNgth0 = this.1z5mnRcFcRlTWBe1jp2xD0rCP4M4Y54xinN7y78Gku4p1Fs79CtzhXaAM43P("/ext1605/shaders/custom/final.fsh");
        }
        if (this.0Jliadq6MiR90YwBX2EcyoC4q777p4ThxDrqTIN9pjcRGK23VU3JY7xA9v39 != 0 && this.8q3NnYF395aMwM6JsGAH1dqDyCG6rgY7QK44W9yx8CEBc2hSTW4rcLdNgth0 != 0) {
            ARBShaderObjects.glAttachObjectARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, this.0Jliadq6MiR90YwBX2EcyoC4q777p4ThxDrqTIN9pjcRGK23VU3JY7xA9v39);
            ARBShaderObjects.glAttachObjectARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, this.8q3NnYF395aMwM6JsGAH1dqDyCG6rgY7QK44W9yx8CEBc2hSTW4rcLdNgth0);
            ARBShaderObjects.glLinkProgramARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C);
            ARBShaderObjects.glValidateProgramARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C);
            if (!0Xl1zrDDJ6B7f1Ga59F3PLk9v9hZR3c4d9CJ6uv71JQVj2ByH42wT0OY43XH(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C)) {
                this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C = 0;
            }
        }
    }
    
    public void 2aBrqFndfkzC8w9LabN9jT6nygQa1G113SE0F3xs21Ehzq80X8oVOnixaKXP(final int 6hrv4v954Okb7obaj0yHtV3G5Pxi4HLBshp8pHZ6gBKLb8z38aC0Wl5J781Q) {
        ARBShaderObjects.glUseProgramObjectARB(6hrv4v954Okb7obaj0yHtV3G5Pxi4HLBshp8pHZ6gBKLb8z38aC0Wl5J781Q);
        this.6hrv4v954Okb7obaj0yHtV3G5Pxi4HLBshp8pHZ6gBKLb8z38aC0Wl5J781Q = 6hrv4v954Okb7obaj0yHtV3G5Pxi4HLBshp8pHZ6gBKLb8z38aC0Wl5J781Q;
        if (6hrv4v954Okb7obaj0yHtV3G5Pxi4HLBshp8pHZ6gBKLb8z38aC0Wl5J781Q != 0) {
            ARBShaderObjects.glUniform1iARB(ARBShaderObjects.glGetUniformLocationARB(6hrv4v954Okb7obaj0yHtV3G5Pxi4HLBshp8pHZ6gBKLb8z38aC0Wl5J781Q, (CharSequence)"sampler0"), 0);
        }
    }
    
    private int 0u1i79tq0P37AEqTW68P5h1i60IaZ9B5ZJcVyUU5cxE4ZBy70htlWd17uQle(final String s) {
        int glCreateShaderObjectARB = ARBShaderObjects.glCreateShaderObjectARB(35633);
        if (glCreateShaderObjectARB == 0) {
            return 0;
        }
        String string = "";
        try {
            String line;
            while ((line = new BufferedReader(new InputStreamReader(1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.5v4Cs6sI06e6Hjpg3rSI82gG008x14C2jag2OM7ADaW5U8a3DYSrf570CJm6(s))).readLine()) != null) {
                string = string + line + "\n";
            }
        }
        catch (final Exception ex) {
            System.out.println("Failed reading vertex shading code.");
            return 0;
        }
        ARBShaderObjects.glShaderSourceARB(glCreateShaderObjectARB, (CharSequence)string);
        ARBShaderObjects.glCompileShaderARB(glCreateShaderObjectARB);
        if (!0Xl1zrDDJ6B7f1Ga59F3PLk9v9hZR3c4d9CJ6uv71JQVj2ByH42wT0OY43XH(glCreateShaderObjectARB)) {
            glCreateShaderObjectARB = 0;
        }
        return glCreateShaderObjectARB;
    }
    
    private int 1z5mnRcFcRlTWBe1jp2xD0rCP4M4Y54xinN7y78Gku4p1Fs79CtzhXaAM43P(final String s) {
        int glCreateShaderObjectARB = ARBShaderObjects.glCreateShaderObjectARB(35632);
        if (glCreateShaderObjectARB == 0) {
            return 0;
        }
        String str = "#version 120\n" + this.6kPc5bsQEopw306pUZPVI78jGyAvqN5EXMDClw6q2Hy6z4n2X8f6EJIXw0Zs.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.4ZBw6818NpyygSj15g0tevwT2VRNee9iyV3HNltCy7o20mr67D74Di6czF41();
        try {
            String line;
            while ((line = new BufferedReader(new InputStreamReader(1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.5v4Cs6sI06e6Hjpg3rSI82gG008x14C2jag2OM7ADaW5U8a3DYSrf570CJm6(s))).readLine()) != null) {
                str = str + line + "\n";
            }
        }
        catch (final Exception ex) {
            System.out.println("Failed reading fragment shading code.");
            return 0;
        }
        ARBShaderObjects.glShaderSourceARB(glCreateShaderObjectARB, (CharSequence)str);
        ARBShaderObjects.glCompileShaderARB(glCreateShaderObjectARB);
        if (!0Xl1zrDDJ6B7f1Ga59F3PLk9v9hZR3c4d9CJ6uv71JQVj2ByH42wT0OY43XH(glCreateShaderObjectARB)) {
            glCreateShaderObjectARB = 0;
        }
        return glCreateShaderObjectARB;
    }
    
    private static boolean 0Xl1zrDDJ6B7f1Ga59F3PLk9v9hZR3c4d9CJ6uv71JQVj2ByH42wT0OY43XH(final int n) {
        final IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
        ARBShaderObjects.glGetObjectParameterARB(n, 35716, intBuffer);
        final int value = intBuffer.get();
        if (value > 1) {
            final ByteBuffer byteBuffer = BufferUtils.createByteBuffer(value);
            intBuffer.flip();
            ARBShaderObjects.glGetInfoLogARB(n, intBuffer, byteBuffer);
            final byte[] array = new byte[value];
            byteBuffer.get(array);
            System.out.println("Info log:\n" + new String(array));
            return false;
        }
        return true;
    }
    
    private int 6N3mcf0BGqjNK53qh26x8VQ4E61x3o39KsFng4ST42q2tOJc811a7A37Zu88(final int n, final int n2, final boolean b) {
        final int glGenTextures = GL11.glGenTextures();
        GL11.glBindTexture(3553, glGenTextures);
        if (b) {
            GL11.glTexImage2D(3553, 0, 6402, n, n2, 0, 6402, 5126, ByteBuffer.allocateDirect(n * n2 * 4 * 4));
        }
        else {
            GL11.glTexImage2D(3553, 0, 6408, n, n2, 0, 6408, 5121, ByteBuffer.allocateDirect(n * n2 * 4));
        }
        GL11.glTexParameteri(3553, 10240, 9729);
        GL11.glTexParameteri(3553, 10241, 9729);
        return glGenTextures;
    }
    
    private void 70Z3u02f1Kr9285gO782wwmyAI50j816Mb433849317G7yhuZTqic1PYtnPe(final int n) {
        GL11.glDeleteTextures(n);
    }
    
    public int 8HzFSuQdA8hV11L03HqdJf3J6QnwTI3IL1K751k618F0KmXstFu981F5bdPq(final Minecraft minecraft) {
        if (this.0SSC84N8JG6dE09gQ6910N5N78f81K4E4ovsfRt5iRjZCSVdok9vRwTZuh1k == 0 || this.385X644BXT9qBn6EF1gIbS63mT0B092Z2lynp6yudR6UJeSv1MPf63o296yR != minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA || this.99QURSTWyu6T75EQj21pgtAS627wxwQ52Z8b7F8U3R81i613FC3SJLY2aTbs != minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw) {
            this.0SSC84N8JG6dE09gQ6910N5N78f81K4E4ovsfRt5iRjZCSVdok9vRwTZuh1k = this.6N3mcf0BGqjNK53qh26x8VQ4E61x3o39KsFng4ST42q2tOJc811a7A37Zu88(minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw, false);
            this.385X644BXT9qBn6EF1gIbS63mT0B092Z2lynp6yudR6UJeSv1MPf63o296yR = minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA;
            this.99QURSTWyu6T75EQj21pgtAS627wxwQ52Z8b7F8U3R81i613FC3SJLY2aTbs = minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw;
        }
        return this.0SSC84N8JG6dE09gQ6910N5N78f81K4E4ovsfRt5iRjZCSVdok9vRwTZuh1k;
    }
    
    public int 35vk4IIhd8hao4F5HSR9jWpH6tem7rh9B886Pq7RYkf415WQC9hm6vShCua6(final Minecraft minecraft) {
        if (this.9441y1Y9T40FDCF9uuwkU1lmehM65hg8761b2m6X1BgG7auF90lDMvklrCeq == 0 || this.6lfU3mNn3UomWZH8MfUGPg4LX59b1U18fabPV53p2u7ludbeYE1196g5rWX6 != minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA || this.20GQz7zR34Tp693G3DSupFXBE66x7RUvn9JBul8RyCo5s50123NSbmOaYt5u != minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw) {
            this.9441y1Y9T40FDCF9uuwkU1lmehM65hg8761b2m6X1BgG7auF90lDMvklrCeq = this.6N3mcf0BGqjNK53qh26x8VQ4E61x3o39KsFng4ST42q2tOJc811a7A37Zu88(minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw, true);
            this.6lfU3mNn3UomWZH8MfUGPg4LX59b1U18fabPV53p2u7ludbeYE1196g5rWX6 = minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA;
            this.20GQz7zR34Tp693G3DSupFXBE66x7RUvn9JBul8RyCo5s50123NSbmOaYt5u = minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw;
        }
        return this.9441y1Y9T40FDCF9uuwkU1lmehM65hg8761b2m6X1BgG7auF90lDMvklrCeq;
    }
    
    public int 6L4tKeSFB9JuB4C21yfU9Wexrw7VE17dZURA0uDEgh0622ButpwPgn1H7yV8(final Minecraft minecraft) {
        if (this.2i7O7iJDFtoO2YSWX2e96Df4ACzXIrBwc2Khi70y062n1HJaqNA1njxwdt6o == 0 || this.5OVC2g2d9zq6dP14qJsUlMx8ghzyNOS2n5hh0gcYmL4BF9KuER7SqHiYE809 != minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA || this.3W20rY0C5sq1crIFTGspopkir94xT6ZbCJ2HfG0YdtAolGW79iW5ue93k9gj != minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw) {
            this.2i7O7iJDFtoO2YSWX2e96Df4ACzXIrBwc2Khi70y062n1HJaqNA1njxwdt6o = this.6N3mcf0BGqjNK53qh26x8VQ4E61x3o39KsFng4ST42q2tOJc811a7A37Zu88(minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw, true);
            this.5OVC2g2d9zq6dP14qJsUlMx8ghzyNOS2n5hh0gcYmL4BF9KuER7SqHiYE809 = minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA;
            this.3W20rY0C5sq1crIFTGspopkir94xT6ZbCJ2HfG0YdtAolGW79iW5ue93k9gj = minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw;
        }
        return this.2i7O7iJDFtoO2YSWX2e96Df4ACzXIrBwc2Khi70y062n1HJaqNA1njxwdt6o;
    }
    
    public void 3Ox6ELkjL7tS0M11M9Ec3mtp515ihaUVz6k07257y4J6E9IJVRiQKoD3Ym6J(final Minecraft minecraft, final float n, final float n2, final float n3, final float n4) {
        if (!minecraft.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8 && this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C != 0) {
            GL11.glBindTexture(3553, this.8HzFSuQdA8hV11L03HqdJf3J6QnwTI3IL1K751k618F0KmXstFu981F5bdPq(minecraft));
            GL11.glCopyTexImage2D(3553, 0, 6408, 0, 0, minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw, 0);
            GL13.glActiveTexture(33985);
            GL11.glBindTexture(3553, this.35vk4IIhd8hao4F5HSR9jWpH6tem7rh9B886Pq7RYkf415WQC9hm6vShCua6(minecraft));
            GL13.glActiveTexture(33986);
            GL11.glBindTexture(3553, this.6L4tKeSFB9JuB4C21yfU9Wexrw7VE17dZURA0uDEgh0622ButpwPgn1H7yV8(minecraft));
            GL13.glActiveTexture(33984);
            this.2aBrqFndfkzC8w9LabN9jT6nygQa1G113SE0F3xs21Ehzq80X8oVOnixaKXP(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C);
            ARBShaderObjects.glUniform1iARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"sampler0"), 0);
            ARBShaderObjects.glUniform1iARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"sampler1"), 1);
            ARBShaderObjects.glUniform1iARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"sampler2"), 2);
            ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"aspectRatio"), (float)(minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA / minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw));
            ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"near"), 0.05f);
            ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"far"), n);
            ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"rand"), this.2SsePNiNxSOe8T43T3RkxQkXltd0oPOKg7w710gmT1w1fVdSSd15fP0M69aI.nextFloat());
            ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"lastMouseDist"), (minecraft.5qb40IUHA9HwkHE9H6Pw5jQkWgRm689t02eg1oWLR2M3x8586n3eGW1x87rb != null) ? 0.0f : ((float)Math.abs(Math.sqrt(Math.pow(1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.707jU4qzhFX6mGQ1ZpfwhqquvvDf0Qa3HrgGCQWLv9INJ93Ut22XPAd9uj5R, 2.0) + Math.pow(1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.0y3INMpYVFu2C7IwEbg5nJo1l7oB6657C9L2jQsq1z1M4Z1uOS3yDZ67o1sR, 2.0)))));
            ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"lastMouseX"), (float)1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.707jU4qzhFX6mGQ1ZpfwhqquvvDf0Qa3HrgGCQWLv9INJ93Ut22XPAd9uj5R);
            ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"lastMouseY"), (float)1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.0y3INMpYVFu2C7IwEbg5nJo1l7oB6657C9L2jQsq1z1M4Z1uOS3yDZ67o1sR);
            ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"playerPitchRot"), minecraft.8m10eD4o1nI4Yvt03uA2QMfUSGy4I2qp5qLsfQsDidFNBgCWTWjd2T5zayR5.938V1I5CwF14ryNLJ9uSgWA5Rf5006saW2va7lj6Mn672871w9S2xlWi0v4C);
            ARBShaderObjects.glUniform1fARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"fovMod"), minecraft.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.0C4EtBfBCuT3y3UEjMQa70c4g8B7aHSysEqc87yvqIaoA7Vw61YIpz5Fe8dR);
            ARBShaderObjects.glUniform1iARB(ARBShaderObjects.glGetUniformLocationARB(this.5njmf4RMUMok22e26216PC1AQHrm3cuOQ244o6dsQIZ7mMyYI2OdfKFqUw9C, (CharSequence)"fogMode"), GL11.glGetInteger(2917));
            GL11.glClearColor(n2, n3, n4, 0.0f);
            GL11.glClear(16384);
            GL11.glDisable(2929);
            GL11.glDisable(3042);
            GL11.glMatrixMode(5889);
            GL11.glLoadIdentity();
            GL11.glOrtho(0.0, (double)minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, (double)minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw, 0.0, -1.0, 1.0);
            GL11.glMatrixMode(5888);
            GL11.glLoadIdentity();
            GL11.glBegin(7);
            GL11.glTexCoord2f(0.0f, 1.0f);
            GL11.glVertex3f(0.0f, 0.0f, 0.0f);
            GL11.glTexCoord2f(0.0f, 0.0f);
            GL11.glVertex3f(0.0f, (float)minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw, 0.0f);
            GL11.glTexCoord2f(1.0f, 0.0f);
            GL11.glVertex3f((float)minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, (float)minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw, 0.0f);
            GL11.glTexCoord2f(1.0f, 1.0f);
            GL11.glVertex3f((float)minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, 0.0f, 0.0f);
            GL11.glEnd();
            GL11.glEnable(2929);
            this.2aBrqFndfkzC8w9LabN9jT6nygQa1G113SE0F3xs21Ehzq80X8oVOnixaKXP(0);
        }
    }
    
    public static void 9k8UYIQjyl8A669E4479n7ZN6ovKzu0Py7mZLt8QHMg0jDqVsW8F6L6Ycg15(final int n, final Minecraft minecraft) {
        GL11.glBindTexture(3553, n);
        GL11.glCopyTexImage2D(3553, 0, 6402, 0, 0, minecraft.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, minecraft.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw, 0);
    }
}
