import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;

// 
// Decompiled by Procyon v0.6.0
// 

public abstract class 06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4
{
    public int 9Psx0tZC91cMh7ZAzUJ658Kzvt14VXdr7EZ2i1DLVD9g4MlOJonxzd0TGHB9;
    protected 7XdlAOp7XckOje04de7ABA9F884wwnr6If64CVJj628g43i49363cBhRp98803WX78LMz1Brfwq184d66GuuJHlEN9KGq7m 9di5kTyQJSVIL4e04LHO4k6zJ1R6dE2XFd7U87CVdoCE497R8cfT70Idl59f;
    public Map<Integer, 7uWI82NGR90qSdLSKHCn87S220XJI71IRF4S66oHQ0Ffy6AUDK2b0cvR2Y92TktyJn861l0K0Q7ZU1W2X42JFY47UVaxAOU3bwv> 402Fu54l8TN2Bk80iCfxL13eV1alTV2m2yuc0ENbnJKb9yho3t8yoy6p2U16;
    private int 49YKQ9H4rrqumwJ440g4Mih74Nh25b3khR0956wdddVjq9A278gi4nUXDmg5;
    private int 7C4VOY68RA8Zy4TwusOsh6A2t4L4uXD7kPKxs6Dy2d35t3Ziv1aw4I0uQ6o8;
    private int 11fE8Ox7P73E077oD4aH1xmldckIt3kdPUm7WME2kV9Rpk2Ky85479aFl1oG;
    public int 3X8uS9Os0Ro4y2OE9xS3l95Rn75LDno8OkmTSU4PUHOIRmXt6887Qc80QbJp;
    public int 4xQ8UJa1zzwd5Ak02TtA45g8muig5017CnUqTI595caW1tt0I0n2G8Fq86z7;
    public int 04229h383DiAbTtznv60GRjak8V5dt3yQ79a0e8ICDtjs9toY69Ld05AykI1;
    protected 1g9c5c64er1Be7481671w4l8713i0q3v6Ltd8C00Ga4ee0tD4lxHX27l9oSknv514rpN2bpn8Jb130XJ5rQ4Ph8lI62OShchMVQ 5CixT11auYqthm59bz65N7pR6c1kFc4PgWOJTyMES6c8JRFtTc8y4fu4by3m;
    protected 1g9c5c64er1Be7481671w4l8713i0q3v6Ltd8C00Ga4ee0tD4lxHX27l9oSknv514rpN2bpn8Jb130XJ5rQ4Ph8lI62OShchMVQ 1ZuLBTbJCb68R6q2Pu8z16VwdmUU78La4DGYSspy8oZ48Z2dLDn7EaVJQ5s6;
    
    public 06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4(final 7XdlAOp7XckOje04de7ABA9F884wwnr6If64CVJj628g43i49363cBhRp98803WX78LMz1Brfwq184d66GuuJHlEN9KGq7m 7XdlAOp7XckOje04de7ABA9F884wwnr6If64CVJj628g43i49363cBhRp98803WX78LMz1Brfwq184d66GuuJHlEN9KGq7m, final int n, final int n2, final int n3) {
        this(7XdlAOp7XckOje04de7ABA9F884wwnr6If64CVJj628g43i49363cBhRp98803WX78LMz1Brfwq184d66GuuJHlEN9KGq7m, n, n2, n3, 16, 16, 5);
    }
    
    public 06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4(final 7XdlAOp7XckOje04de7ABA9F884wwnr6If64CVJj628g43i49363cBhRp98803WX78LMz1Brfwq184d66GuuJHlEN9KGq7m 9di5kTyQJSVIL4e04LHO4k6zJ1R6dE2XFd7U87CVdoCE497R8cfT70Idl59f, final int 49YKQ9H4rrqumwJ440g4Mih74Nh25b3khR0956wdddVjq9A278gi4nUXDmg5, final int 7c4VOY68RA8Zy4TwusOsh6A2t4L4uXD7kPKxs6Dy2d35t3Ziv1aw4I0uQ6o8, final int 11fE8Ox7P73E077oD4aH1xmldckIt3kdPUm7WME2kV9Rpk2Ky85479aFl1oG, final int 3x8uS9Os0Ro4y2OE9xS3l95Rn75LDno8OkmTSU4PUHOIRmXt6887Qc80QbJp, final int 4xQ8UJa1zzwd5Ak02TtA45g8muig5017CnUqTI595caW1tt0I0n2G8Fq86z7, final int 04229h383DiAbTtznv60GRjak8V5dt3yQ79a0e8ICDtjs9toY69Ld05AykI1) {
        this.9di5kTyQJSVIL4e04LHO4k6zJ1R6dE2XFd7U87CVdoCE497R8cfT70Idl59f = 9di5kTyQJSVIL4e04LHO4k6zJ1R6dE2XFd7U87CVdoCE497R8cfT70Idl59f;
        this.49YKQ9H4rrqumwJ440g4Mih74Nh25b3khR0956wdddVjq9A278gi4nUXDmg5 = 49YKQ9H4rrqumwJ440g4Mih74Nh25b3khR0956wdddVjq9A278gi4nUXDmg5;
        this.7C4VOY68RA8Zy4TwusOsh6A2t4L4uXD7kPKxs6Dy2d35t3Ziv1aw4I0uQ6o8 = 7c4VOY68RA8Zy4TwusOsh6A2t4L4uXD7kPKxs6Dy2d35t3Ziv1aw4I0uQ6o8;
        this.11fE8Ox7P73E077oD4aH1xmldckIt3kdPUm7WME2kV9Rpk2Ky85479aFl1oG = 11fE8Ox7P73E077oD4aH1xmldckIt3kdPUm7WME2kV9Rpk2Ky85479aFl1oG;
        this.3X8uS9Os0Ro4y2OE9xS3l95Rn75LDno8OkmTSU4PUHOIRmXt6887Qc80QbJp = 3x8uS9Os0Ro4y2OE9xS3l95Rn75LDno8OkmTSU4PUHOIRmXt6887Qc80QbJp;
        this.4xQ8UJa1zzwd5Ak02TtA45g8muig5017CnUqTI595caW1tt0I0n2G8Fq86z7 = 4xQ8UJa1zzwd5Ak02TtA45g8muig5017CnUqTI595caW1tt0I0n2G8Fq86z7;
        this.04229h383DiAbTtznv60GRjak8V5dt3yQ79a0e8ICDtjs9toY69Ld05AykI1 = 04229h383DiAbTtznv60GRjak8V5dt3yQ79a0e8ICDtjs9toY69Ld05AykI1;
        this.9Psx0tZC91cMh7ZAzUJ658Kzvt14VXdr7EZ2i1DLVD9g4MlOJonxzd0TGHB9 = 0;
        this.5CixT11auYqthm59bz65N7pR6c1kFc4PgWOJTyMES6c8JRFtTc8y4fu4by3m = new 1g9c5c64er1Be7481671w4l8713i0q3v6Ltd8C00Ga4ee0tD4lxHX27l9oSknv514rpN2bpn8Jb130XJ5rQ4Ph8lI62OShchMVQ(32768);
        this.1ZuLBTbJCb68R6q2Pu8z16VwdmUU78La4DGYSspy8oZ48Z2dLDn7EaVJQ5s6 = new 1g9c5c64er1Be7481671w4l8713i0q3v6Ltd8C00Ga4ee0tD4lxHX27l9oSknv514rpN2bpn8Jb130XJ5rQ4Ph8lI62OShchMVQ(this.5CixT11auYqthm59bz65N7pR6c1kFc4PgWOJTyMES6c8JRFtTc8y4fu4by3m.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU.length);
        this.402Fu54l8TN2Bk80iCfxL13eV1alTV2m2yuc0ENbnJKb9yho3t8yoy6p2U16 = new HashMap<Integer, 7uWI82NGR90qSdLSKHCn87S220XJI71IRF4S66oHQ0Ffy6AUDK2b0cvR2Y92TktyJn861l0K0Q7ZU1W2X42JFY47UVaxAOU3bwv>();
    }
    
    protected boolean 0ir18WW2Er00vPEwk4ysWYEf3jBf0oDxYSVBcO27LQ7O9UiZXGtduk6tgrab(final int n, final int n2, final int n3, final int n4) {
        if (this.9di5kTyQJSVIL4e04LHO4k6zJ1R6dE2XFd7U87CVdoCE497R8cfT70Idl59f.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(this.49YKQ9H4rrqumwJ440g4Mih74Nh25b3khR0956wdddVjq9A278gi4nUXDmg5 + n, this.7C4VOY68RA8Zy4TwusOsh6A2t4L4uXD7kPKxs6Dy2d35t3Ziv1aw4I0uQ6o8 + n2, this.11fE8Ox7P73E077oD4aH1xmldckIt3kdPUm7WME2kV9Rpk2Ky85479aFl1oG + n3, n4)) {
            this.5CixT11auYqthm59bz65N7pR6c1kFc4PgWOJTyMES6c8JRFtTc8y4fu4by3m.493RggokAg7F1PytzXg4zR6GOSCVMIUkS3WxpJR06xKZqxKJUkSz5vrKMjKQ(n, n2, n3, n4);
            return true;
        }
        return false;
    }
    
    protected boolean 68E6w9t9bw9Zp6jmEk8M417RMoDQ5rpWim85pcpWr4b1H5bY93ND9Ret3lM0(final int n, final int n2, final int n3, final int n4, final int n5) {
        if (this.0ir18WW2Er00vPEwk4ysWYEf3jBf0oDxYSVBcO27LQ7O9UiZXGtduk6tgrab(n, n2, n3, n4) && this.9di5kTyQJSVIL4e04LHO4k6zJ1R6dE2XFd7U87CVdoCE497R8cfT70Idl59f.6wp59FCGZy0ODNzS0pC7TuicUh1KtawD0iSOIwB0w904q95SD9Ydn8rC7X3H(this.49YKQ9H4rrqumwJ440g4Mih74Nh25b3khR0956wdddVjq9A278gi4nUXDmg5 + n, this.7C4VOY68RA8Zy4TwusOsh6A2t4L4uXD7kPKxs6Dy2d35t3Ziv1aw4I0uQ6o8 + n2, this.11fE8Ox7P73E077oD4aH1xmldckIt3kdPUm7WME2kV9Rpk2Ky85479aFl1oG + n3, n5)) {
            this.1ZuLBTbJCb68R6q2Pu8z16VwdmUU78La4DGYSspy8oZ48Z2dLDn7EaVJQ5s6.493RggokAg7F1PytzXg4zR6GOSCVMIUkS3WxpJR06xKZqxKJUkSz5vrKMjKQ(n, n2, n3, n5);
            return true;
        }
        return false;
    }
    
    protected void 4OnwgF5x0BQ3sp7En29qVPi3wP2F99dRcg44iCY75OWivoZ4x7hHLld3O5x3(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int n7) {
        for (int i = n; i <= n4; ++i) {
            for (int j = n2; j <= n5; ++j) {
                for (int k = n3; k <= n6; ++k) {
                    this.0ir18WW2Er00vPEwk4ysWYEf3jBf0oDxYSVBcO27LQ7O9UiZXGtduk6tgrab(i, j, k, n7);
                }
            }
        }
    }
    
    public void 7ZpHFjuGvcJ051cOz9PE89x1h4vDq16V2LJ76i4OBAOemXk2l5J09hlg30Vh(final int 9Psx0tZC91cMh7ZAzUJ658Kzvt14VXdr7EZ2i1DLVD9g4MlOJonxzd0TGHB9) {
        if (this.9Psx0tZC91cMh7ZAzUJ658Kzvt14VXdr7EZ2i1DLVD9g4MlOJonxzd0TGHB9 != 9Psx0tZC91cMh7ZAzUJ658Kzvt14VXdr7EZ2i1DLVD9g4MlOJonxzd0TGHB9) {
            final 1g9c5c64er1Be7481671w4l8713i0q3v6Ltd8C00Ga4ee0tD4lxHX27l9oSknv514rpN2bpn8Jb130XJ5rQ4Ph8lI62OShchMVQ 5CixT11auYqthm59bz65N7pR6c1kFc4PgWOJTyMES6c8JRFtTc8y4fu4by3m = this.5CixT11auYqthm59bz65N7pR6c1kFc4PgWOJTyMES6c8JRFtTc8y4fu4by3m;
            int n = 0;
            int n2 = 0;
            switch (Math.abs(9Psx0tZC91cMh7ZAzUJ658Kzvt14VXdr7EZ2i1DLVD9g4MlOJonxzd0TGHB9 - this.9Psx0tZC91cMh7ZAzUJ658Kzvt14VXdr7EZ2i1DLVD9g4MlOJonxzd0TGHB9)) {
                case 1: {
                    n = 1;
                    n2 = 0;
                    break;
                }
                case 2: {
                    n = 0;
                    n2 = -1;
                    break;
                }
                case 3: {
                    n = -1;
                    n2 = 0;
                    break;
                }
                default: {
                    n = 0;
                    n2 = 1;
                    break;
                }
            }
            for (int i = 0; i < this.3X8uS9Os0Ro4y2OE9xS3l95Rn75LDno8OkmTSU4PUHOIRmXt6887Qc80QbJp; ++i) {
                for (int j = 0; j < this.04229h383DiAbTtznv60GRjak8V5dt3yQ79a0e8ICDtjs9toY69Ld05AykI1; ++j) {
                    for (int k = 0; k < this.4xQ8UJa1zzwd5Ak02TtA45g8muig5017CnUqTI595caW1tt0I0n2G8Fq86z7; ++k) {
                        this.9di5kTyQJSVIL4e04LHO4k6zJ1R6dE2XFd7U87CVdoCE497R8cfT70Idl59f.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(i * n2 - k * n, j, i * n + k * n2, 5CixT11auYqthm59bz65N7pR6c1kFc4PgWOJTyMES6c8JRFtTc8y4fu4by3m.6NDQZ279aA35RAAcvrwNf551m5uCxuz3nLoAE4R5O5C7SFSYIJ283EnjEL0m(i, j, k));
                    }
                }
            }
            this.9Psx0tZC91cMh7ZAzUJ658Kzvt14VXdr7EZ2i1DLVD9g4MlOJonxzd0TGHB9 = 9Psx0tZC91cMh7ZAzUJ658Kzvt14VXdr7EZ2i1DLVD9g4MlOJonxzd0TGHB9;
        }
    }
    
    public boolean 5204axQba8r4yKOmf635c4mf99bQl70mm0X8b96R3NY7EX2N636dc3j5E7Jq() {
        final Iterator<7uWI82NGR90qSdLSKHCn87S220XJI71IRF4S66oHQ0Ffy6AUDK2b0cvR2Y92TktyJn861l0K0Q7ZU1W2X42JFY47UVaxAOU3bwv> iterator = this.402Fu54l8TN2Bk80iCfxL13eV1alTV2m2yuc0ENbnJKb9yho3t8yoy6p2U16.values().iterator();
        while (iterator.hasNext()) {
            if (iterator.next().50HlF50aFoB7NiHFoTOH3x80rsY8B1b3Kth2O196sr37CQNqM7QEDA5Lg1xv()) {
                return false;
            }
        }
        return true;
    }
    
    public void 7R35CGL5Z6S8q1KH37CB0kTCR4Y7Ufr7F0QHR1bV4Ftooj95dS8B04mVvpb3(final 06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4 06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4, final int n) {
        if (!this.5204axQba8r4yKOmf635c4mf99bQl70mm0X8b96R3NY7EX2N636dc3j5E7Jq() || !06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4.5204axQba8r4yKOmf635c4mf99bQl70mm0X8b96R3NY7EX2N636dc3j5E7Jq()) {
            return;
        }
        if (06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4.402Fu54l8TN2Bk80iCfxL13eV1alTV2m2yuc0ENbnJKb9yho3t8yoy6p2U16.get(8suuoyAmK77iaFQ5gqG532Zz1Nv6r737qh0KwPWU6hZ2XAqPKKq2VBh1bljt8U5054nka5A758kGL0XoH2zY29jd9365Gog9UY.4dD10Vjg8EXQlPqLn1740KeipDH3q81QpEc7eJ1kIDKnDkDuh78Z6nVgtW23(n)) == null) {
            return;
        }
        this.402Fu54l8TN2Bk80iCfxL13eV1alTV2m2yuc0ENbnJKb9yho3t8yoy6p2U16.get(n).0J562Mkp8zd7uXcLK816mU9467m831KM7RpX06f6clIam7Juk383188UJI1W = 06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4.402Fu54l8TN2Bk80iCfxL13eV1alTV2m2yuc0ENbnJKb9yho3t8yoy6p2U16.get(8suuoyAmK77iaFQ5gqG532Zz1Nv6r737qh0KwPWU6hZ2XAqPKKq2VBh1bljt8U5054nka5A758kGL0XoH2zY29jd9365Gog9UY.4dD10Vjg8EXQlPqLn1740KeipDH3q81QpEc7eJ1kIDKnDkDuh78Z6nVgtW23(n));
        06Cnw7njmAdTm7pcwgxWTVOo3fXNY453ms9m9280Mj810641vE27Rk090ZPC0XB3602xe57oi68rQxRJPaX7y0W1V3oDYzX0rzu4.402Fu54l8TN2Bk80iCfxL13eV1alTV2m2yuc0ENbnJKb9yho3t8yoy6p2U16.get(8suuoyAmK77iaFQ5gqG532Zz1Nv6r737qh0KwPWU6hZ2XAqPKKq2VBh1bljt8U5054nka5A758kGL0XoH2zY29jd9365Gog9UY.4dD10Vjg8EXQlPqLn1740KeipDH3q81QpEc7eJ1kIDKnDkDuh78Z6nVgtW23(n)).0J562Mkp8zd7uXcLK816mU9467m831KM7RpX06f6clIam7Juk383188UJI1W = this.402Fu54l8TN2Bk80iCfxL13eV1alTV2m2yuc0ENbnJKb9yho3t8yoy6p2U16.get(n);
    }
    
    public abstract void 96pkMbVA643Z1Y78zU1zOHbm0WbR47PCGp9q1ZyTK64G0pr0ViUREK2TCos1();
}
