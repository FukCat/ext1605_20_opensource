// 
// Decompiled by Procyon v0.6.0
// 

public class 58QNZTTsU9MoNCN45O03qVA0975ZxNUqwm2rd84py2xlP87nuI018eWGW28tpiQX6Y78XDuZfw1Gf45oDk0hl0Ygju0rn62qyq4X extends RuntimeException
{
    public 58QNZTTsU9MoNCN45O03qVA0975ZxNUqwm2rd84py2xlP87nuI018eWGW28tpiQX6Y78XDuZfw1Gf45oDk0hl0Ygju0rn62qyq4X(final String message) {
        super(message);
    }
}
