import net.minecraft.client.Minecraft;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2064w9c30d1kXPgNi6GX308Bsu3daqFRgvQsJ5MN6wkc88EPTCniCA107126o26K1674HMm2b1p9uZI2kIB8GquGLHD5xMm1DwT extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    private Boolean 14W2tr76fRFVwxt8UMKtXBST5QgZfZd76Kd60D0ecLT6rj2651p1OIw3Okl7;
    
    public 2064w9c30d1kXPgNi6GX308Bsu3daqFRgvQsJ5MN6wkc88EPTCniCA107126o26K1674HMm2b1p9uZI2kIB8GquGLHD5xMm1DwT() {
        this.14W2tr76fRFVwxt8UMKtXBST5QgZfZd76Kd60D0ecLT6rj2651p1OIw3Okl7 = null;
    }
    
    public 2064w9c30d1kXPgNi6GX308Bsu3daqFRgvQsJ5MN6wkc88EPTCniCA107126o26K1674HMm2b1p9uZI2kIB8GquGLHD5xMm1DwT 6t2D748Z7amgg6374qlf449x2Q0OB9B0wDPgUi1O77x30fiK30LU69tit5K7(final boolean b) {
        this.14W2tr76fRFVwxt8UMKtXBST5QgZfZd76Kd60D0ecLT6rj2651p1OIw3Okl7 = b;
        return this;
    }
    
    private boolean 8ybc3aO2T6MgY1TYT8ss066o6JU57Xmb5te89rUZiY5oFY9rdx2bLb5U8vu3(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.5k6O7kzX0QxZxv9DfI5FlLir9tP0ouS0KI1un0FBvq87Gz2yWmwGqINFKRyq.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.1196YuYuMAYVg24GE1V23E0ARiyEyxHa3VTDj6Dp5cK3oy5bRSW6mX1Tj3TR.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        final int n4 = random.nextInt(4) + 4;
        int n5 = 1;
        if (n2 < 1 || n2 + n4 + 1 > 128) {
            return false;
        }
        for (int i = n2; i <= n2 + 1 + n4; ++i) {
            int n6 = 1;
            if (i == n2) {
                n6 = 0;
            }
            if (i >= n2 + 1 + n4 - 2) {
                n6 = 2;
            }
            for (int n7 = n - n6; n7 <= n + n6 && n5 != 0; ++n7) {
                for (int n8 = n3 - n6; n8 <= n3 + n6 && n5 != 0; ++n8) {
                    if (i >= 0 && i < 128) {
                        final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n7, i, n8);
                        if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != 0 && 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2) {
                            n5 = 0;
                        }
                    }
                    else {
                        n5 = 0;
                    }
                }
            }
        }
        if (n5 == 0) {
            return false;
        }
        final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM2 = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 - 1, n3);
        if ((1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM2 == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.55p7e2KM7lJg6B2uW7aU042Ab5YRpS56F1Ut596J372iOA170081qInfiVwy.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM2 == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.55p7e2KM7lJg6B2uW7aU042Ab5YRpS56F1Ut596J372iOA170081qInfiVwy.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) && n2 < 128 - n4 - 1) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, n2 - 1, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.55p7e2KM7lJg6B2uW7aU042Ab5YRpS56F1Ut596J372iOA170081qInfiVwy.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            for (int j = n2 - 1 + n4; j <= n2 + n4; ++j) {
                for (int n9 = 1, k = n - n9; k <= n - n9; ++k) {
                    for (int l = n3 - n9; l <= n3 - n9; ++l) {
                        if (!1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.25cFll7Xn2l3P9qpDfjmhENMHI2oz6lJ7OtyqhgIOq9u29Xr920bbMcIH1f0[5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(k, j, l)]) {
                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(k + 1, j, l + 1, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2);
                        }
                    }
                }
            }
            for (int n10 = 0; n10 < n4; ++n10) {
                final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM3 = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 + n10, n3);
                if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM3 == 0 || 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM3 == 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, n2 + n10, n3, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                }
            }
            return true;
        }
        return false;
    }
    
    private void 8Q6sVEAF0181r05kCUEta3Mj47k1jnf88657Pv2Q38U9H8M6EAlf2G7PEzYb(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, int n, int round, int n2) {
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.73oWiFV9jc7E7Iv0djCWc7LSxsG7obhlJk814D0R1gXrf2A25o96ql6o9Z73.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.14Ks8Z3BJ852fcCm6iIDNKaHsvjx718uf048Oijp3690dG0HVc8yZ9T8Uf3l.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        float n3 = 0.0f;
        float n4 = random.nextFloat() * 3.1415927f * 2.0f;
        final int n5 = random.nextInt(8) + 7;
        float a = (float)round;
        for (int i = 0; i < n5; ++i) {
            n4 += (float)((random.nextFloat() - 0.5) * 0.1);
            ++n3;
            final float n6 = n3 / n5;
            n += (int)(5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.1724kYgc5e55Yw1mK1EZTYO084n57BWWaYUE7iquVDiu4hFo5J70Cori9WLs(n4) * (1.0f - n6));
            a += n6;
            n2 += (int)(5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(n4) * (1.0f - n6));
            round = Math.round(a);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, round, n2, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
        }
        round += random.nextInt(2) + 1;
        for (int n7 = random.nextInt(2) + 2, j = 0; j < n7; ++j) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, round, n2, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2);
            for (float n8 = 0.0f; n8 < 6.283185307179586; n8 += (float)0.6283185307179586) {
                final int n9 = random.nextInt(j + 2) + j + 2;
                float n10 = (float)n;
                float n11 = (float)n2;
                for (int k = 0; k < n9; ++k) {
                    n11 += 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(n8);
                    n10 += 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.1724kYgc5e55Yw1mK1EZTYO084n57BWWaYUE7iquVDiu4hFo5J70Cori9WLs(n8);
                    if (!5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(Math.round(n10), round - j, Math.round(n11)).7xm2Jx0S8rI7617Ovpb5DFTezpfWmqzIiE2WYq1jc8o1SRpvc713WJ5tkWdP()) {
                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(Math.round(n10), round - j, Math.round(n11), 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2);
                    }
                }
            }
        }
    }
    
    private void 57JnQz29BeV8zgzsGl3J1kp08qjYLG4ixDPE5NIopzS8Rx361W9D19x2164N(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.3We17EJvdsmHvL4uwZMIs6gOd30GS262z1LH4mOFeS5pG9XD6js5Zu56PANz.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        for (int nextInt = random.nextInt(3), i = 0; i < nextInt; ++i) {
            final int n4 = random.nextInt(4) + 2;
            int n5 = n;
            int n6 = n2;
            int n7 = n3;
            for (int j = 0; j < n4; ++j) {
                n5 += random.nextInt(3) - 1;
                --n6;
                n7 += random.nextInt(3) - 1;
                if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n5, n6, n7) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.9DwuHv1rF8tHn9hxQ74YH2a9UDMG087j4Z8NJ6X7ly1OaZNeZrC5MTA51CA7.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5, n6, n7, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                }
            }
        }
    }
    
    private boolean 207WU7S6UShx2dKMu834lJM1ofWd2fa8azp67F0oht39izalOwX18EZ268Y8(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.73oWiFV9jc7E7Iv0djCWc7LSxsG7obhlJk814D0R1gXrf2A25o96ql6o9Z73.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.14Ks8Z3BJ852fcCm6iIDNKaHsvjx718uf048Oijp3690dG0HVc8yZ9T8Uf3l.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 - 1, n3) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.63nirDT0ysU52yrV7NrOFP3w5y6GfnHtl75Rxpz4tsleaNpwg02R6ida6v9c.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 - 1, n3) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.35wK7RXXc4Uu2oc9JBTTNWs6ng4la5dQ6N3KM9ii276gF3OhPeoRtqJ1k8qk.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
            return true;
        }
        final Random random2 = new Random(random.nextLong() + n + n2 + n3 + 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1FawBBFYvHD6RwlXAU5K97Vdl06vvbW1l7jIv9UTLqhT80S0VL74wGs85AKR);
        final ArrayList c = new ArrayList();
        c.add(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(n, n2 + (7 + random2.nextInt(10)), n3));
        int n4 = 0;
        while (c.size() > 0) {
            for (final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 : new ArrayList(c)) {
                final int n5 = (int)Math.round(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.2eY43A926V72BOu2G531aa2ZhODT8w5mCxf6jNpHYkd0HHxvk9yRC9Ix62k9);
                final int n6 = (int)Math.round(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.5wRQ3f09mhVbrkWp9ni13w5Ss0dIm9OImDlyjLJaXBrUy1xUXCzWTfQJow9c);
                final int n7 = (int)Math.round(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF);
                if ((5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n5, n6, n7).7xm2Jx0S8rI7617Ovpb5DFTezpfWmqzIiE2WYq1jc8o1SRpvc713WJ5tkWdP() && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n5, n6, n7) == 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2) || n6 < 0 || (random2.nextInt(3) == 0 && c.size() > 3)) {
                    c.remove(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457);
                    if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n5, n6, n7) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.55p7e2KM7lJg6B2uW7aU042Ab5YRpS56F1Ut596J372iOA170081qInfiVwy.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n5, n6, n7) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.55p7e2KM7lJg6B2uW7aU042Ab5YRpS56F1Ut596J372iOA170081qInfiVwy.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                        continue;
                    }
                    this.57JnQz29BeV8zgzsGl3J1kp08qjYLG4ixDPE5NIopzS8Rx361W9D19x2164N(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random2, n5, n6, n7);
                }
                else {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5, n6, n7, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    int n8 = 0;
                    while (random2.nextInt(c.size() / 30 + 2) <= 1) {
                        if (c.size() > 10000) {
                            break;
                        }
                        if (++n8 >= 4) {
                            break;
                        }
                        c.add(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.8wLY5gyzx357NR05a1m1Q7cyQ5cP7To9781nF4W25WMgL6r0iK9XkS2j5OD2(random2.nextInt(3) - 1, -1.0, random2.nextInt(3) - 1));
                    }
                    if (n4 > 2 && random2.nextInt(Math.max(40, 78 - n4)) == 3) {
                        this.8Q6sVEAF0181r05kCUEta3Mj47k1jnf88657Pv2Q38U9H8M6EAlf2G7PEzYb(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random, n5, n6, n7);
                    }
                    c.remove(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457);
                    c.add(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.8wLY5gyzx357NR05a1m1Q7cyQ5cP7To9781nF4W25WMgL6r0iK9XkS2j5OD2(0.0, -1.0, 0.0));
                }
            }
            ++n4;
        }
        return true;
    }
    
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        final Random random2 = new Random(random.nextLong() + n + n2 + n3 + 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1FawBBFYvHD6RwlXAU5K97Vdl06vvbW1l7jIv9UTLqhT80S0VL74wGs85AKR);
        if (!Minecraft.4vZ36FKx2I9PxzXyWH4290I55Q6yd6FI668q2Ylv62ISy2u1yh710qJ4Q0Yo && this.14W2tr76fRFVwxt8UMKtXBST5QgZfZd76Kd60D0ecLT6rj2651p1OIw3Okl7 != null && (random2.nextInt(150) == 0 || this.14W2tr76fRFVwxt8UMKtXBST5QgZfZd76Kd60D0ecLT6rj2651p1OIw3Okl7)) {
            return this.207WU7S6UShx2dKMu834lJM1ofWd2fa8azp67F0oht39izalOwX18EZ268Y8(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random, n, n2, n3);
        }
        return this.8ybc3aO2T6MgY1TYT8ss066o6JU57Xmb5te89rUZiY5oFY9rdx2bLb5U8vu3(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random, n, n2, n3);
    }
}
