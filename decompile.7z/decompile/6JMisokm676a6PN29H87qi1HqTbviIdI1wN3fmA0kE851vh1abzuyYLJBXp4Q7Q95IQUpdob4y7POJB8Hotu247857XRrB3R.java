import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 6JMisokm676a6PN29H87qi1HqTbviIdI1wN3fmA0kE851vh1abzuyYLJBXp4Q7Q95IQUpdob4y7POJB8Hotu247857XRrB3R extends 005H4t5riGVmaG6Yk11O6x7RHdsA8G9pu7V1UDQH2UpSkub8hRwC96z12IYi666KesQuogtYKvHh2OYRqkqNGRAK61fwfx497V9
{
    public 6JMisokm676a6PN29H87qi1HqTbviIdI1wN3fmA0kE851vh1abzuyYLJBXp4Q7Q95IQUpdob4y7POJB8Hotu247857XRrB3R(final int n, final int n2) {
        super(n, n2);
    }
    
    @Override
    public int 8LTZgqX2KHwGhNpQ1gUZz1WaWt0W2TrjgClq35mEWEh8l45qEVZXQ21Rh3g0(final int n, final Random random) {
        if (random.nextInt(10) == 0) {
            return 9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.672kXvfHLsy3clOht013QyUvZ2Lf3065JoUD0CfFUOy1l6f9d6Ap25Xnl6R2.016D6B0WzYa1oAf8GVzuN3e04Nkxq5CzkT5YVZhj2l5H8LW20C9lkr0R7pc5;
        }
        return this.01lgF9B869y98971xM904ArErwAmKW0135S3qc6W8Vi3wsv260KyANkXWhDN;
    }
}
