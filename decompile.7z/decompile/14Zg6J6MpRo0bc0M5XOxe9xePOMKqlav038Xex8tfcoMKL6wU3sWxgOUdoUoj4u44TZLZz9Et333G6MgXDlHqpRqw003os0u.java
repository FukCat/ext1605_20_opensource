import org.lwjgl.opengl.GL11;
import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 14Zg6J6MpRo0bc0M5XOxe9xePOMKqlav038Xex8tfcoMKL6wU3sWxgOUdoUoj4u44TZLZz9Et333G6MgXDlHqpRqw003os0u extends 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03
{
    public float 6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6;
    public boolean 3qd96ngIW1AHTSnzZ7PS3ICtm2H3n2a8P7j66w05R71cS42cCCSFpDR5804i;
    private int 3jZQUlEaPrc55lhLO60REL644b0Q2Hl67NV2RNAroMtD4zaxTi6GVtY6h1y1;
    
    public 14Zg6J6MpRo0bc0M5XOxe9xePOMKqlav038Xex8tfcoMKL6wU3sWxgOUdoUoj4u44TZLZz9Et333G6MgXDlHqpRqw003os0u(final int n, final int n2, final int n3, final int 3jZQUlEaPrc55lhLO60REL644b0Q2Hl67NV2RNAroMtD4zaxTi6GVtY6h1y1, final String s, final float 6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6) {
        super(n, n2, n3, 150, 20, s);
        this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 = 1.0f;
        this.3qd96ngIW1AHTSnzZ7PS3ICtm2H3n2a8P7j66w05R71cS42cCCSFpDR5804i = false;
        this.3jZQUlEaPrc55lhLO60REL644b0Q2Hl67NV2RNAroMtD4zaxTi6GVtY6h1y1 = 0;
        this.3jZQUlEaPrc55lhLO60REL644b0Q2Hl67NV2RNAroMtD4zaxTi6GVtY6h1y1 = 3jZQUlEaPrc55lhLO60REL644b0Q2Hl67NV2RNAroMtD4zaxTi6GVtY6h1y1;
        this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 = 6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6;
    }
    
    @Override
    protected int 7onHHc11Xv27v0qu5Gep1q7EW95jBlA09cj2LhRQvxlaPd6TkmkF9tGnN64u(final boolean b) {
        return 0;
    }
    
    @Override
    protected void 8X8Br1428K6PQ31O892x1pp5v90sZQf9v3269N56R326VkrR72K2c0welnbu(final Minecraft minecraft, final int n, final int n2) {
        if (this.49mge70At31d4nug9dLRDDTEl4xGT7hSMvD95g19sFShA9WaCuYzD25q70W7) {
            if (this.3qd96ngIW1AHTSnzZ7PS3ICtm2H3n2a8P7j66w05R71cS42cCCSFpDR5804i) {
                this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 = (n - (this.6G4e5GVolj2st66ECJ9KX18GrLrq5HV30sXHghF0halPd8CgfDCz2NSy6KwW + 4)) / (float)(this.11Xh3vqwC9ZfPG5q0A0h657SQ4328JJoZPg0t2DcD835LMBLRqjcI8hoaK84 - 8);
                if (this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 < 0.0f) {
                    this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 = 0.0f;
                }
                if (this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 > 1.0f) {
                    this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 = 1.0f;
                }
                minecraft.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.41q83du4HaW59MJ9dbgIw283tnp9FTGdKAIaz3G2fKFS8kiLN47ib74Ajr5A(this.3jZQUlEaPrc55lhLO60REL644b0Q2Hl67NV2RNAroMtD4zaxTi6GVtY6h1y1, this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6);
                this.341FqR7gR9Z89F779fLfXdcwKO6ZA54xm6oS9N8sLphh7p10BkALs3o76F57 = minecraft.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.8akE4ycpP29ZNPe8U7TtIq1VzWnfb0Dy8d0ME93EebGs00PCtIc26x387brx(this.3jZQUlEaPrc55lhLO60REL644b0Q2Hl67NV2RNAroMtD4zaxTi6GVtY6h1y1);
            }
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            this.6AFa5CRoJnJBCx0H03fzeVl9KNGIrBgC22d1WVMgNN34pniepT7hKD4H3XOl(this.6G4e5GVolj2st66ECJ9KX18GrLrq5HV30sXHghF0halPd8CgfDCz2NSy6KwW + (int)(this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 * (this.11Xh3vqwC9ZfPG5q0A0h657SQ4328JJoZPg0t2DcD835LMBLRqjcI8hoaK84 - 8)), this.6gHTUk82zR49F118NAi27qpuVW3ZlsR2rQmUQxfA9ntlE4QsjuOuXG1qcbP9, 0, 66, 4, 20);
            this.6AFa5CRoJnJBCx0H03fzeVl9KNGIrBgC22d1WVMgNN34pniepT7hKD4H3XOl(this.6G4e5GVolj2st66ECJ9KX18GrLrq5HV30sXHghF0halPd8CgfDCz2NSy6KwW + (int)(this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 * (this.11Xh3vqwC9ZfPG5q0A0h657SQ4328JJoZPg0t2DcD835LMBLRqjcI8hoaK84 - 8)) + 4, this.6gHTUk82zR49F118NAi27qpuVW3ZlsR2rQmUQxfA9ntlE4QsjuOuXG1qcbP9, 196, 66, 4, 20);
        }
    }
    
    @Override
    public boolean 0LeWaef80ASn5OrS2pI64995rlF9h6C5L691dcbo1e1SRFnknWGyKa766ET9(final Minecraft minecraft, final int n, final int n2) {
        if (super.0LeWaef80ASn5OrS2pI64995rlF9h6C5L691dcbo1e1SRFnknWGyKa766ET9(minecraft, n, n2)) {
            this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 = (n - (this.6G4e5GVolj2st66ECJ9KX18GrLrq5HV30sXHghF0halPd8CgfDCz2NSy6KwW + 4)) / (float)(this.11Xh3vqwC9ZfPG5q0A0h657SQ4328JJoZPg0t2DcD835LMBLRqjcI8hoaK84 - 8);
            if (this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 < 0.0f) {
                this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 = 0.0f;
            }
            if (this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 > 1.0f) {
                this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6 = 1.0f;
            }
            minecraft.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.41q83du4HaW59MJ9dbgIw283tnp9FTGdKAIaz3G2fKFS8kiLN47ib74Ajr5A(this.3jZQUlEaPrc55lhLO60REL644b0Q2Hl67NV2RNAroMtD4zaxTi6GVtY6h1y1, this.6m1qd0020H9IAsw5M404q2rGRR17eTPz4QC1n158qYKk1HII6GyI9HveHkr6);
            this.341FqR7gR9Z89F779fLfXdcwKO6ZA54xm6oS9N8sLphh7p10BkALs3o76F57 = minecraft.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.8akE4ycpP29ZNPe8U7TtIq1VzWnfb0Dy8d0ME93EebGs00PCtIc26x387brx(this.3jZQUlEaPrc55lhLO60REL644b0Q2Hl67NV2RNAroMtD4zaxTi6GVtY6h1y1);
            return this.3qd96ngIW1AHTSnzZ7PS3ICtm2H3n2a8P7j66w05R71cS42cCCSFpDR5804i = true;
        }
        return false;
    }
    
    @Override
    public void 01U778BzOYfrS183c6jJ9lPiuQUphAZUO397N8V9957A5Dg0Q06bfD8CaXEd(final int n, final int n2) {
        this.3qd96ngIW1AHTSnzZ7PS3ICtm2H3n2a8P7j66w05R71cS42cCCSFpDR5804i = false;
    }
}
