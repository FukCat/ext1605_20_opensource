// 
// Decompiled by Procyon v0.6.0
// 

public class 09ku0Dip5v0fdX0NkO7dW4tQ7fkA3ctWceSSq0cueJeG9VP91ixCd37CYNMmtf3g7toUSy8t8ngN5dmP7luIAL9D712dzo44
{
    public float 9x8SF7Sm6KBd7Bl9uNykLCIU00v2F8xxu38KPYS7v38r3aCdp4EPwuP6p1cr;
    private double 7Vcu9h28b7tLA5X0X8LILZGnbdj0KaB5ZhpVKp5ZjPHP9nZt409xU0ua30eU;
    public int 19g54v387Hz6i9H0aWQdT5zXYF8fXnwhWS6T04JEB5ms34fdI70yYbvxr4H3;
    public float 7rGF2N5Z78ap5TXtRfflRj7w473480k9j6Jl4O5nZu85S5sa5z86CFzdxygi;
    public float 0904Nl96gg0Lq9zD82MSq71TbTP5cUsqet3Tz1EXKc95FfNIj6uRQq3lj0yY;
    public float 8N2k7sNNHnLT58TrWk3zQtDgT1lS3uufjNGQWXZj3AIR5f2Un6fSwuaUMC5I;
    private long 78o08vQsD7sFYxa0gDULl85620685WHAjc1S8pJz1mGrPD0719735gOtd3BM;
    private long 9I8pqr41l512Bf9cVG2eYoGvwyC3dEdoRQi4NQSYXD161L3BR4198dpqBT9V;
    private double 1j2Qf7IG24XOq419U7mkUCNPoVYiSo86G5Fur81xIS3xm7H7X8jIXKasxPTf;
    
    public 09ku0Dip5v0fdX0NkO7dW4tQ7fkA3ctWceSSq0cueJeG9VP91ixCd37CYNMmtf3g7toUSy8t8ngN5dmP7luIAL9D712dzo44(final float 9x8SF7Sm6KBd7Bl9uNykLCIU00v2F8xxu38KPYS7v38r3aCdp4EPwuP6p1cr) {
        this.0904Nl96gg0Lq9zD82MSq71TbTP5cUsqet3Tz1EXKc95FfNIj6uRQq3lj0yY = 1.0f;
        this.8N2k7sNNHnLT58TrWk3zQtDgT1lS3uufjNGQWXZj3AIR5f2Un6fSwuaUMC5I = 0.0f;
        this.1j2Qf7IG24XOq419U7mkUCNPoVYiSo86G5Fur81xIS3xm7H7X8jIXKasxPTf = 1.0;
        this.9x8SF7Sm6KBd7Bl9uNykLCIU00v2F8xxu38KPYS7v38r3aCdp4EPwuP6p1cr = 9x8SF7Sm6KBd7Bl9uNykLCIU00v2F8xxu38KPYS7v38r3aCdp4EPwuP6p1cr;
        this.78o08vQsD7sFYxa0gDULl85620685WHAjc1S8pJz1mGrPD0719735gOtd3BM = System.currentTimeMillis();
        this.9I8pqr41l512Bf9cVG2eYoGvwyC3dEdoRQi4NQSYXD161L3BR4198dpqBT9V = System.nanoTime() / 1000000L;
    }
    
    public void 1LZmq9W9ja88LOy9290iK04e854jh7NYiuuz0jOu16dum980Hyyl1VqzuLX5() {
        final long currentTimeMillis = System.currentTimeMillis();
        final long n = currentTimeMillis - this.78o08vQsD7sFYxa0gDULl85620685WHAjc1S8pJz1mGrPD0719735gOtd3BM;
        final long n2 = System.nanoTime() / 1000000L;
        if (n > 1000L) {
            this.1j2Qf7IG24XOq419U7mkUCNPoVYiSo86G5Fur81xIS3xm7H7X8jIXKasxPTf += (n / (double)(n2 - this.9I8pqr41l512Bf9cVG2eYoGvwyC3dEdoRQi4NQSYXD161L3BR4198dpqBT9V) - this.1j2Qf7IG24XOq419U7mkUCNPoVYiSo86G5Fur81xIS3xm7H7X8jIXKasxPTf) * 0.20000000298023224;
            this.78o08vQsD7sFYxa0gDULl85620685WHAjc1S8pJz1mGrPD0719735gOtd3BM = currentTimeMillis;
            this.9I8pqr41l512Bf9cVG2eYoGvwyC3dEdoRQi4NQSYXD161L3BR4198dpqBT9V = n2;
        }
        if (n < 0L) {
            this.78o08vQsD7sFYxa0gDULl85620685WHAjc1S8pJz1mGrPD0719735gOtd3BM = currentTimeMillis;
            this.9I8pqr41l512Bf9cVG2eYoGvwyC3dEdoRQi4NQSYXD161L3BR4198dpqBT9V = n2;
        }
        final double 7Vcu9h28b7tLA5X0X8LILZGnbdj0KaB5ZhpVKp5ZjPHP9nZt409xU0ua30eU = n2 / 1000.0;
        double n3 = (7Vcu9h28b7tLA5X0X8LILZGnbdj0KaB5ZhpVKp5ZjPHP9nZt409xU0ua30eU - this.7Vcu9h28b7tLA5X0X8LILZGnbdj0KaB5ZhpVKp5ZjPHP9nZt409xU0ua30eU) * this.1j2Qf7IG24XOq419U7mkUCNPoVYiSo86G5Fur81xIS3xm7H7X8jIXKasxPTf;
        this.7Vcu9h28b7tLA5X0X8LILZGnbdj0KaB5ZhpVKp5ZjPHP9nZt409xU0ua30eU = 7Vcu9h28b7tLA5X0X8LILZGnbdj0KaB5ZhpVKp5ZjPHP9nZt409xU0ua30eU;
        if (n3 < 0.0) {
            n3 = 0.0;
        }
        if (n3 > 1.0) {
            n3 = 1.0;
        }
        this.8N2k7sNNHnLT58TrWk3zQtDgT1lS3uufjNGQWXZj3AIR5f2Un6fSwuaUMC5I += (float)(n3 * this.0904Nl96gg0Lq9zD82MSq71TbTP5cUsqet3Tz1EXKc95FfNIj6uRQq3lj0yY * this.9x8SF7Sm6KBd7Bl9uNykLCIU00v2F8xxu38KPYS7v38r3aCdp4EPwuP6p1cr);
        this.19g54v387Hz6i9H0aWQdT5zXYF8fXnwhWS6T04JEB5ms34fdI70yYbvxr4H3 = (int)this.8N2k7sNNHnLT58TrWk3zQtDgT1lS3uufjNGQWXZj3AIR5f2Un6fSwuaUMC5I;
        this.8N2k7sNNHnLT58TrWk3zQtDgT1lS3uufjNGQWXZj3AIR5f2Un6fSwuaUMC5I -= this.19g54v387Hz6i9H0aWQdT5zXYF8fXnwhWS6T04JEB5ms34fdI70yYbvxr4H3;
        if (this.19g54v387Hz6i9H0aWQdT5zXYF8fXnwhWS6T04JEB5ms34fdI70yYbvxr4H3 > 10) {
            this.19g54v387Hz6i9H0aWQdT5zXYF8fXnwhWS6T04JEB5ms34fdI70yYbvxr4H3 = 10;
        }
        this.7rGF2N5Z78ap5TXtRfflRj7w473480k9j6Jl4O5nZu85S5sa5z86CFzdxygi = this.8N2k7sNNHnLT58TrWk3zQtDgT1lS3uufjNGQWXZj3AIR5f2Un6fSwuaUMC5I;
    }
}
