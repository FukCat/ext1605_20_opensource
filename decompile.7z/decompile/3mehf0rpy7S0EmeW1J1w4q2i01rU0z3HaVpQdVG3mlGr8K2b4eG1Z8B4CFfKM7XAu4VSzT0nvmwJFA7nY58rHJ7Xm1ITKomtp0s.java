import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 3mehf0rpy7S0EmeW1J1w4q2i01rU0z3HaVpQdVG3mlGr8K2b4eG1Z8B4CFfKM7XAu4VSzT0nvmwJFA7nY58rHJ7Xm1ITKomtp0s extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 5KUN886M2wlV026p0ex6Igj8v3qFAmYlx0gA1tZl0fEQML94GR2yah3tXixR;
    public int 5tjf2pCpG48J8qfT05Ln32K5bg00g94OeWd6dJ7O88ScJx5523r50J0dVrDF;
    public short[] 2G026C5lfkKlP5WXA2jGtkmwb6o5Lc9Mm12Ohh2k0mwvi0h0PRVGudYCy0uU;
    public byte[] 5pl677MJGACYvn1h4N05Ri05dO3pZqlrrN9e59M6p81gK13fCq3K047PrAUO;
    public byte[] 4ET37Mb9ci0qo6S2GMvm307JldKWf70u7UyGdmqP9q0fGItSq966URGrTE2C;
    public int 6iIjlN37brp76ErH3RASg1KR36X1Q3egGXMPo0EL6g6iE4WPjv1p5vbh5VGr;
    
    public 3mehf0rpy7S0EmeW1J1w4q2i01rU0z3HaVpQdVG3mlGr8K2b4eG1Z8B4CFfKM7XAu4VSzT0nvmwJFA7nY58rHJ7Xm1ITKomtp0s() {
        this.6t9cCgt41s5d1pQ7cjb3tIHK1IXU79b99NWj8CrXP2toB951Vr11rxkXisnp = true;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.5KUN886M2wlV026p0ex6Igj8v3qFAmYlx0gA1tZl0fEQML94GR2yah3tXixR = dataInputStream.readInt();
        this.5tjf2pCpG48J8qfT05Ln32K5bg00g94OeWd6dJ7O88ScJx5523r50J0dVrDF = dataInputStream.readInt();
        this.6iIjlN37brp76ErH3RASg1KR36X1Q3egGXMPo0EL6g6iE4WPjv1p5vbh5VGr = (dataInputStream.readShort() & 0xFFFF);
        this.2G026C5lfkKlP5WXA2jGtkmwb6o5Lc9Mm12Ohh2k0mwvi0h0PRVGudYCy0uU = new short[this.6iIjlN37brp76ErH3RASg1KR36X1Q3egGXMPo0EL6g6iE4WPjv1p5vbh5VGr];
        this.5pl677MJGACYvn1h4N05Ri05dO3pZqlrrN9e59M6p81gK13fCq3K047PrAUO = new byte[this.6iIjlN37brp76ErH3RASg1KR36X1Q3egGXMPo0EL6g6iE4WPjv1p5vbh5VGr];
        this.4ET37Mb9ci0qo6S2GMvm307JldKWf70u7UyGdmqP9q0fGItSq966URGrTE2C = new byte[this.6iIjlN37brp76ErH3RASg1KR36X1Q3egGXMPo0EL6g6iE4WPjv1p5vbh5VGr];
        for (int i = 0; i < this.6iIjlN37brp76ErH3RASg1KR36X1Q3egGXMPo0EL6g6iE4WPjv1p5vbh5VGr; ++i) {
            this.2G026C5lfkKlP5WXA2jGtkmwb6o5Lc9Mm12Ohh2k0mwvi0h0PRVGudYCy0uU[i] = dataInputStream.readShort();
        }
        dataInputStream.readFully(this.5pl677MJGACYvn1h4N05Ri05dO3pZqlrrN9e59M6p81gK13fCq3K047PrAUO);
        dataInputStream.readFully(this.4ET37Mb9ci0qo6S2GMvm307JldKWf70u7UyGdmqP9q0fGItSq966URGrTE2C);
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.5KUN886M2wlV026p0ex6Igj8v3qFAmYlx0gA1tZl0fEQML94GR2yah3tXixR);
        dataOutputStream.writeInt(this.5tjf2pCpG48J8qfT05Ln32K5bg00g94OeWd6dJ7O88ScJx5523r50J0dVrDF);
        dataOutputStream.writeShort((short)this.6iIjlN37brp76ErH3RASg1KR36X1Q3egGXMPo0EL6g6iE4WPjv1p5vbh5VGr);
        for (int i = 0; i < this.6iIjlN37brp76ErH3RASg1KR36X1Q3egGXMPo0EL6g6iE4WPjv1p5vbh5VGr; ++i) {
            dataOutputStream.writeShort(this.2G026C5lfkKlP5WXA2jGtkmwb6o5Lc9Mm12Ohh2k0mwvi0h0PRVGudYCy0uU[i]);
        }
        dataOutputStream.write(this.5pl677MJGACYvn1h4N05Ri05dO3pZqlrrN9e59M6p81gK13fCq3K047PrAUO);
        dataOutputStream.write(this.4ET37Mb9ci0qo6S2GMvm307JldKWf70u7UyGdmqP9q0fGItSq966URGrTE2C);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.1k2DWXDjuDkNEII0oHhbOiz9ZLJ15n3XGUKA567OWbDvw423ZPEbHwvUa5vQ(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 10 + this.6iIjlN37brp76ErH3RASg1KR36X1Q3egGXMPo0EL6g6iE4WPjv1p5vbh5VGr * 4;
    }
}
