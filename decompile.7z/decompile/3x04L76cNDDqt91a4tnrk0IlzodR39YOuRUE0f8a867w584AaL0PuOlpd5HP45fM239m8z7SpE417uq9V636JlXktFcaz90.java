import java.net.MalformedURLException;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 3x04L76cNDDqt91a4tnrk0IlzodR39YOuRUE0f8a867w584AaL0PuOlpd5HP45fM239m8z7SpE417uq9V636JlXktFcaz90
{
    private Random 61y9SbF9oY2P3ll79Zk6M903k4cxGGc5IDvHkt45I7636xT3wyJ83s32SO76;
    public Map<String, List<8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES>> 3jHGHYL6cE8o7487bReezSpQq8cgj7TNqvsgk01dmDPX7c0mnT00sO6d6heI;
    private List<8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES> 5YxT9icDym1B235OMdd295F32OLR9h8DY2ojU5DBF0iV6h6oBufcHB214pmQ;
    public int 80TaffiGsVf13U5bPuO700B3QQA9z3979jOlg384yCy5jIgmV0CXZ8lvd7AY;
    public boolean 3IxC1868kNnY5IIMhb1JP2LwgfvIaO327809Q59qeG3OG63089Q6j77MC3k5;
    
    public 3x04L76cNDDqt91a4tnrk0IlzodR39YOuRUE0f8a867w584AaL0PuOlpd5HP45fM239m8z7SpE417uq9V636JlXktFcaz90() {
        this.61y9SbF9oY2P3ll79Zk6M903k4cxGGc5IDvHkt45I7636xT3wyJ83s32SO76 = new Random();
        this.3jHGHYL6cE8o7487bReezSpQq8cgj7TNqvsgk01dmDPX7c0mnT00sO6d6heI = new HashMap<String, List<8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES>>();
        this.5YxT9icDym1B235OMdd295F32OLR9h8DY2ojU5DBF0iV6h6oBufcHB214pmQ = new ArrayList<8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES>();
        this.80TaffiGsVf13U5bPuO700B3QQA9z3979jOlg384yCy5jIgmV0CXZ8lvd7AY = 0;
        this.3IxC1868kNnY5IIMhb1JP2LwgfvIaO327809Q59qeG3OG63089Q6j77MC3k5 = true;
    }
    
    public 8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES 9L66DYAo71BD8LRrLg9qBlvu0VPoeULED02LjTI9652aNlxJcz619mXYGsFT(String s, final File file) {
        try {
            final String s2 = s;
            s = s.substring(0, s.indexOf("."));
            if (this.3IxC1868kNnY5IIMhb1JP2LwgfvIaO327809Q59qeG3OG63089Q6j77MC3k5) {
                while (Character.isDigit(s.charAt(s.length() - 1))) {
                    s = s.substring(0, s.length() - 1);
                }
            }
            s = s.replaceAll("/", ".");
            if (!this.3jHGHYL6cE8o7487bReezSpQq8cgj7TNqvsgk01dmDPX7c0mnT00sO6d6heI.containsKey(s)) {
                this.3jHGHYL6cE8o7487bReezSpQq8cgj7TNqvsgk01dmDPX7c0mnT00sO6d6heI.put(s, new ArrayList<8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES>());
            }
            final 8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES 8m556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES = new 8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES(s2, file.toURI().toURL());
            this.3jHGHYL6cE8o7487bReezSpQq8cgj7TNqvsgk01dmDPX7c0mnT00sO6d6heI.get(s).add(8m556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES);
            this.5YxT9icDym1B235OMdd295F32OLR9h8DY2ojU5DBF0iV6h6oBufcHB214pmQ.add(8m556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES);
            ++this.80TaffiGsVf13U5bPuO700B3QQA9z3979jOlg384yCy5jIgmV0CXZ8lvd7AY;
            return 8m556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES;
        }
        catch (final MalformedURLException cause) {
            cause.printStackTrace();
            throw new RuntimeException(cause);
        }
    }
    
    public 8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES 53UO66FCsn1bE2dxF6CpH8Pl321xb7f33KftMH34890z5CBmsdZMMIi724VP(final String s) {
        final List list = this.3jHGHYL6cE8o7487bReezSpQq8cgj7TNqvsgk01dmDPX7c0mnT00sO6d6heI.get(s);
        return (list == null) ? null : ((8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES)list.get(this.61y9SbF9oY2P3ll79Zk6M903k4cxGGc5IDvHkt45I7636xT3wyJ83s32SO76.nextInt(list.size())));
    }
    
    public 8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES 8xOARc6rm5b1WDu153Q0shU5lA0Z3FSj8l97dykjy2BkU8e2309W8j2Xb0PZ() {
        return this.2m7wwWK4NEUrLf807IH7jRXAICmOB8wEkk5d9mQzQ10GCmCBzZzNeP4We52o(null);
    }
    
    public 8M556p233c5DkGM81QRj52NYgL1IeYy56mK51NKRukhpMz2On2Ig5p6XGrL7HV455WvG1WYpgo6k9NgtHMUFymrWc8er4mi3ES 2m7wwWK4NEUrLf807IH7jRXAICmOB8wEkk5d9mQzQ10GCmCBzZzNeP4We52o(final List<String> list) {
        if (this.5YxT9icDym1B235OMdd295F32OLR9h8DY2ojU5DBF0iV6h6oBufcHB214pmQ.size() == 0) {
            return null;
        }
        int nextInt;
        for (nextInt = this.61y9SbF9oY2P3ll79Zk6M903k4cxGGc5IDvHkt45I7636xT3wyJ83s32SO76.nextInt(this.5YxT9icDym1B235OMdd295F32OLR9h8DY2ojU5DBF0iV6h6oBufcHB214pmQ.size()); list != null && list.contains(this.5YxT9icDym1B235OMdd295F32OLR9h8DY2ojU5DBF0iV6h6oBufcHB214pmQ.get(nextInt).1t1BKCe16NK9vcD0U34cqYoF0JHYNc19ZRBbc6V9U4AF7zf0Z349nSq1q78N); nextInt = ++nextInt % this.5YxT9icDym1B235OMdd295F32OLR9h8DY2ojU5DBF0iV6h6oBufcHB214pmQ.size()) {}
        return this.5YxT9icDym1B235OMdd295F32OLR9h8DY2ojU5DBF0iV6h6oBufcHB214pmQ.get(nextInt);
    }
}
