import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 1S8Z13J70AdD82z1og3YEdowZUz4do5hyK1shJ6v3bHh7w0Akmv3RRX6MNK0n71Ql9lR8g9FQZwIPm60mSSi6hhwPpvl8c1fpqYy extends 5Bo2RFI9pGj8v2K84b836NMiTffRXCH0AGsu472BB66U5L26PEBb2hLHi7P2O9l36k0d6u2nQ2404v2BZyvj9N2ko3amt55
{
    public 1S8Z13J70AdD82z1og3YEdowZUz4do5hyK1shJ6v3bHh7w0Akmv3RRX6MNK0n71Ql9lR8g9FQZwIPm60mSSi6hhwPpvl8c1fpqYy(final Minecraft minecraft) {
        super(minecraft);
    }
}
