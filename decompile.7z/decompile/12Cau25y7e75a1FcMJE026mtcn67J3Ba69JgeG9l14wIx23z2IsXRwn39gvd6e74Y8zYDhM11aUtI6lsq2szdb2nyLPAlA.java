import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 12Cau25y7e75a1FcMJE026mtcn67J3Ba69JgeG9l14wIx23z2IsXRwn39gvd6e74Y8zYDhM11aUtI6lsq2szdb2nyLPAlA extends 8B8KCcvZH9Dx0345x3v80ai3FSt8m2UFO5C54su1Nm9dmMI91lq3j7r25jSeUY2inpY3wGVmp3qdhvrLbS8CS69KG9Q5t26s
{
    public 12Cau25y7e75a1FcMJE026mtcn67J3Ba69JgeG9l14wIx23z2IsXRwn39gvd6e74Y8zYDhM11aUtI6lsq2szdb2nyLPAlA(final int n, final int n2) {
        super(n, n2);
    }
    
    @Override
    public int 9hFrB67UQ3xIdu153AXx7FYrppLysZW3gpO0hVR27pm9IQlKb2jF25i9DO3e(final int n, final Random random) {
        return (random.nextInt(10) == 0) ? 9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.672kXvfHLsy3clOht013QyUvZ2Lf3065JoUD0CfFUOy1l6f9d6Ap25Xnl6R2.016D6B0WzYa1oAf8GVzuN3e04Nkxq5CzkT5YVZhj2l5H8LW20C9lkr0R7pc5 : this.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
    }
}
