// 
// Decompiled by Procyon v0.6.0
// 

public class 4U0pu9Bov632WXr88MBKZ4IG7wdBg4acFjol3309WjSt1MaubjsrSJrGLMG2MGrxvbMRPRS7LG11g5CE8wj77rQFm4y8SoKGGafVoUX6d implements 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa
{
    private int 4K71rb8pJXe286G9f2o1gYiJ7yLm14v7wx7AbJYoa2B0f43yrfAG0fJLvi7S;
    private int 34Mrzp0ayw0fFxnP36970jWSvVqj8iQ1bS46I9rklE4lqJ8TnPzCiBfNq2TL;
    private 9m2wWv7Y0P6wvrh59Qp3DG2Cs297QBiT9d3C2Ym8a3VBQf0y8ksZza1rWedXIKg0UcWrch6Q377o8vJ607zis39k6dbDXymg[][] 7L1ZBgaltn71X2HcviWjNLTlIP087K4EbuGpVky59F9iKGwDsojm8G27spJ6;
    private 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 8A330Z61Wr4OakEK7ZJtOdKHw3A5cazTKz0Ou641Lj6G3CLBlS6w5xtx2KBb;
    
    public 4U0pu9Bov632WXr88MBKZ4IG7wdBg4acFjol3309WjSt1MaubjsrSJrGLMG2MGrxvbMRPRS7LG11g5CE8wj77rQFm4y8SoKGGafVoUX6d(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 8a330Z61Wr4OakEK7ZJtOdKHw3A5cazTKz0Ou641Lj6G3CLBlS6w5xtx2KBb, final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        this.8A330Z61Wr4OakEK7ZJtOdKHw3A5cazTKz0Ou641Lj6G3CLBlS6w5xtx2KBb = 8a330Z61Wr4OakEK7ZJtOdKHw3A5cazTKz0Ou641Lj6G3CLBlS6w5xtx2KBb;
        this.4K71rb8pJXe286G9f2o1gYiJ7yLm14v7wx7AbJYoa2B0f43yrfAG0fJLvi7S = n >> 4;
        this.34Mrzp0ayw0fFxnP36970jWSvVqj8iQ1bS46I9rklE4lqJ8TnPzCiBfNq2TL = n3 >> 4;
        final int n7 = n4 >> 4;
        final int n8 = n6 >> 4;
        this.7L1ZBgaltn71X2HcviWjNLTlIP087K4EbuGpVky59F9iKGwDsojm8G27spJ6 = new 9m2wWv7Y0P6wvrh59Qp3DG2Cs297QBiT9d3C2Ym8a3VBQf0y8ksZza1rWedXIKg0UcWrch6Q377o8vJ607zis39k6dbDXymg[n7 - this.4K71rb8pJXe286G9f2o1gYiJ7yLm14v7wx7AbJYoa2B0f43yrfAG0fJLvi7S + 1][n8 - this.34Mrzp0ayw0fFxnP36970jWSvVqj8iQ1bS46I9rklE4lqJ8TnPzCiBfNq2TL + 1];
        for (int i = this.4K71rb8pJXe286G9f2o1gYiJ7yLm14v7wx7AbJYoa2B0f43yrfAG0fJLvi7S; i <= n7; ++i) {
            for (int j = this.34Mrzp0ayw0fFxnP36970jWSvVqj8iQ1bS46I9rklE4lqJ8TnPzCiBfNq2TL; j <= n8; ++j) {
                this.7L1ZBgaltn71X2HcviWjNLTlIP087K4EbuGpVky59F9iKGwDsojm8G27spJ6[i - this.4K71rb8pJXe286G9f2o1gYiJ7yLm14v7wx7AbJYoa2B0f43yrfAG0fJLvi7S][j - this.34Mrzp0ayw0fFxnP36970jWSvVqj8iQ1bS46I9rklE4lqJ8TnPzCiBfNq2TL] = 8a330Z61Wr4OakEK7ZJtOdKHw3A5cazTKz0Ou641Lj6G3CLBlS6w5xtx2KBb.7c9x1zA6pt6wNR85ZLMaNksR9dgW3Ul967Y9IxCCm37kJyE185Iu6wF8e03Y(i, j);
            }
        }
    }
    
    @Override
    public int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(final int n, final int n2, final int n3) {
        if (n2 < 0) {
            return 0;
        }
        if (n2 >= 128) {
            return 0;
        }
        final int n4 = (n >> 4) - this.4K71rb8pJXe286G9f2o1gYiJ7yLm14v7wx7AbJYoa2B0f43yrfAG0fJLvi7S;
        final int n5 = (n3 >> 4) - this.34Mrzp0ayw0fFxnP36970jWSvVqj8iQ1bS46I9rklE4lqJ8TnPzCiBfNq2TL;
        try {
            return this.7L1ZBgaltn71X2HcviWjNLTlIP087K4EbuGpVky59F9iKGwDsojm8G27spJ6[n4][n5].6np964HeuqunCXkC85TYCXT1f06iEnBu82D66Q5u0FdZzT75w0p0x51J5HbK(n & 0xF, n2, n3 & 0xF);
        }
        catch (final ArrayIndexOutOfBoundsException ex) {
            return 0;
        }
    }
    
    @Override
    public 2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex 6hPp92kZVrpu289Er027gE6XGPzFeGBQ5pS5JM73GUT6dyg108A5z3pHTQtS(final int n, final int n2, final int n3) {
        return this.7L1ZBgaltn71X2HcviWjNLTlIP087K4EbuGpVky59F9iKGwDsojm8G27spJ6[(n >> 4) - this.4K71rb8pJXe286G9f2o1gYiJ7yLm14v7wx7AbJYoa2B0f43yrfAG0fJLvi7S][(n3 >> 4) - this.34Mrzp0ayw0fFxnP36970jWSvVqj8iQ1bS46I9rklE4lqJ8TnPzCiBfNq2TL].203fJlXpeUCL2ShOGG8s47z4czpaZV652k7Ivww3rZH2219I4N77P03m2gqp(n & 0xF, n2, n3 & 0xF);
    }
    
    @Override
    public float 761gLqveJwE4yc6llId2RV8yTKgzz6isE5Xt7xM4uAox3N0fFT6nz1KIZWYb(final int n, final int n2, final int n3) {
        if (3p9u95CB1CP0y3UiTUZMGY05o15X75Oi03v43rZTG0wGCHvXqU15Kt1Q8k8Op87au5qr4U1GCvu00LTfk2w3YhwqE0it1tw2g11k.2AJG81m1pl0O5bhn2XiQ37CD76Uoi3M5l8gTKvm6mx16vAu3Ik5oCR8W6P15) {
            return 1.0f;
        }
        return 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.4355dw65qSxJ8yr22Zfr3R6Epn3mRHQ5Pd62ylNaFW5v74TEK314dDe2oxC1[this.8fnTS03R1W0Dzbge50fcS6f7vOpnAiXLEecn59pE1Jx01tPIrGdhq87xb8dj(n, n2, n3, true)];
    }
    
    @Override
    public float 601Q1cZyHo6i3ye002F165wmjZTccN0mi586WeLpWIZ3th5V852e3gwXjae7(final int n, final int n2, final int n3) {
        return 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.4355dw65qSxJ8yr22Zfr3R6Epn3mRHQ5Pd62ylNaFW5v74TEK314dDe2oxC1[this.3gI9E0Qa8pp17bNiM4yI4lX0fOq4KjFJ4q7US59Se586SbU955Ha0UKj5aK8(n, n2, n3)];
    }
    
    public int 3gI9E0Qa8pp17bNiM4yI4lX0fOq4KjFJ4q7US59Se586SbU955Ha0UKj5aK8(final int n, final int n2, final int n3) {
        return this.8fnTS03R1W0Dzbge50fcS6f7vOpnAiXLEecn59pE1Jx01tPIrGdhq87xb8dj(n, n2, n3, false);
    }
    
    public int 8fnTS03R1W0Dzbge50fcS6f7vOpnAiXLEecn59pE1Jx01tPIrGdhq87xb8dj(final int n, final int n2, final int n3, final boolean b) {
        return this.72d4986X23NXQX8OD621500mp613V8qmBU1pc7dJdC0DnbM62VxIh35pAdjK(n, n2, n3, true, b);
    }
    
    public int 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3(final int n, final int n2, final int n3, final boolean b) {
        return this.72d4986X23NXQX8OD621500mp613V8qmBU1pc7dJdC0DnbM62VxIh35pAdjK(n, n2, n3, b, false);
    }
    
    public int 72d4986X23NXQX8OD621500mp613V8qmBU1pc7dJdC0DnbM62VxIh35pAdjK(final int n, final int n2, final int n3, final boolean b, final boolean b2) {
        int b3 = this.8A330Z61Wr4OakEK7ZJtOdKHw3A5cazTKz0Ou641Lj6G3CLBlS6w5xtx2KBb.8R2sYDCBg3QobS0j4jMh8W3mamazeux733Y1B8N25seN37q7lK8CFKw0P9W2;
        if (b2 && 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.8ZkMyUYHsrY76OZw5LJ00YOwex92AgW51WVJMaCWc622fCAz2PGpx9498DuU == 5) {
            b3 = Math.max(12, b3);
        }
        if (n < -32000000 || n3 < -32000000 || n >= 32000000 || n3 > 32000000) {
            return 15;
        }
        if (b) {
            final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM = this.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3);
            if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.8dtG1nv85N80Kk6w8c44s6Xt0utl6fSCfqXJq58A1Lc9w6J06tO5afpsC99t.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.71aPcnrFcbsW0ia1sWorA1n2TbJWrKou486caSbOk5jfum056bgTB1a18820.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.7qbg3s74pHNODf73E73E5RLL68h0q51dNLbBwK236RV5MkRR1hsrtTEbnGIw.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                int 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3 = this.8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3(n, n2 + 1, n3, false);
                final int 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X4 = this.8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3(n + 1, n2, n3, false);
                final int 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X5 = this.8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3(n - 1, n2, n3, false);
                final int 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X6 = this.8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3(n, n2, n3 + 1, false);
                final int 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X7 = this.8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3(n, n2, n3 - 1, false);
                if (8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X4 > 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3) {
                    8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3 = 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X4;
                }
                if (8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X5 > 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3) {
                    8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3 = 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X5;
                }
                if (8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X6 > 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3) {
                    8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3 = 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X6;
                }
                if (8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X7 > 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3) {
                    8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3 = 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X7;
                }
                return 8jXe6h7Eh62iS745lWvAN6q80UOq3E8gx5pPR1HhS87450HBZrAIIOsxN4X3;
            }
        }
        if (n2 < 0) {
            return 0;
        }
        if (n2 >= 128) {
            int n4 = 15 - b3;
            if (n4 < 0) {
                n4 = 0;
            }
            return n4;
        }
        return this.7L1ZBgaltn71X2HcviWjNLTlIP087K4EbuGpVky59F9iKGwDsojm8G27spJ6[(n >> 4) - this.4K71rb8pJXe286G9f2o1gYiJ7yLm14v7wx7AbJYoa2B0f43yrfAG0fJLvi7S][(n3 >> 4) - this.34Mrzp0ayw0fFxnP36970jWSvVqj8iQ1bS46I9rklE4lqJ8TnPzCiBfNq2TL].0fe19rZ7kF1ei3mAD2zzQtN9V5Ud0CD2YA7g26H5zE71V54Q6mrjbH94Oa8X(n & 0xF, n2, n3 & 0xF, b3);
    }
    
    @Override
    public int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(final int n, final int n2, final int n3) {
        if (n2 < 0) {
            return 0;
        }
        if (n2 >= 128) {
            return 0;
        }
        return this.7L1ZBgaltn71X2HcviWjNLTlIP087K4EbuGpVky59F9iKGwDsojm8G27spJ6[(n >> 4) - this.4K71rb8pJXe286G9f2o1gYiJ7yLm14v7wx7AbJYoa2B0f43yrfAG0fJLvi7S][(n3 >> 4) - this.34Mrzp0ayw0fFxnP36970jWSvVqj8iQ1bS46I9rklE4lqJ8TnPzCiBfNq2TL].50CsVF9a9rdiMdmoXEZZ4XGu71PP67f3RsfPr736Rcel3jDPEz6q8KeZTBbP(n & 0xF, n2, n3 & 0xF);
    }
    
    @Override
    public 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ 6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(final int n, final int n2, final int n3) {
        final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM = this.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3);
        return (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 0) ? 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.3o0aGvYiq3rCm97mlDzf0B9hr4SSr2zbjPZ3jO017bwy0Z3rR6Fr671OBCs3 : 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM].5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF;
    }
    
    @Override
    public boolean 40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(final int n, final int n2, final int n3) {
        final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3gtX9GUU6wdwzByKEps2xBmG14h5CxN4OFC2q5heb8ZC6C6z9632Rh5t94ea[this.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3)];
        return 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC != null && 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11krARXg1dz3Cs9T1417zcu0h3o23b6X5J17X8JguWkYPA1xFa6hm48g23zA();
    }
    
    @Override
    public 6Xshyu98BPKD0Kj2ysQ0pQPP3OrJj1w2t5T0uPrGog033gntT8UTcBftyFyvZHgyra2lx4a1692nuiLk581IYI8n94RXWk8Ry 9805301CWs03An9555qIw883P54dcq9802DkM5DuquNweM1NH26RH6oP02mr() {
        return this.8A330Z61Wr4OakEK7ZJtOdKHw3A5cazTKz0Ou641Lj6G3CLBlS6w5xtx2KBb.9805301CWs03An9555qIw883P54dcq9802DkM5DuquNweM1NH26RH6oP02mr();
    }
}
