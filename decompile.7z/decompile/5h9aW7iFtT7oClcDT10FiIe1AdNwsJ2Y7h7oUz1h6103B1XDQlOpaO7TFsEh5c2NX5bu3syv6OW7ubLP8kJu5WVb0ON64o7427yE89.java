// 
// Decompiled by Procyon v0.6.0
// 

public class 5h9aW7iFtT7oClcDT10FiIe1AdNwsJ2Y7h7oUz1h6103B1XDQlOpaO7TFsEh5c2NX5bu3syv6OW7ubLP8kJu5WVb0ON64o7427yE89
{
    protected int 639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r;
    protected int 3TjSNC1f8PHAQT1GF6Bom08wOmMgqF4F7KC11raR3HAoxpoUY3h80370wj1C;
    public int[] 4bJH090TU6D4pW1r0aTNZ8EtLu5uO3Nx9mVoi9mh84hkOOlS5aO07wsp6al1;
    private 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex 8120MhZIUxQfLJA6ZAb3Xgc48bsn1dz0G876yplH8j9oGHbXcOdCTeCs6EJ9;
    public final int 36V4YA4D5dJCkI6X322BeEZJ244pPRQ457hCa9A827d1978fv2Z7Glf97zu9;
    
    public 5h9aW7iFtT7oClcDT10FiIe1AdNwsJ2Y7h7oUz1h6103B1XDQlOpaO7TFsEh5c2NX5bu3syv6OW7ubLP8kJu5WVb0ON64o7427yE89(final int 639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r, final int 3TjSNC1f8PHAQT1GF6Bom08wOmMgqF4F7KC11raR3HAoxpoUY3h80370wj1C, final int[] 4bJH090TU6D4pW1r0aTNZ8EtLu5uO3Nx9mVoi9mh84hkOOlS5aO07wsp6al1, final 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex 8120MhZIUxQfLJA6ZAb3Xgc48bsn1dz0G876yplH8j9oGHbXcOdCTeCs6EJ9) {
        this.36V4YA4D5dJCkI6X322BeEZJ244pPRQ457hCa9A827d1978fv2Z7Glf97zu9 = 8120MhZIUxQfLJA6ZAb3Xgc48bsn1dz0G876yplH8j9oGHbXcOdCTeCs6EJ9.5P1b49yjUtk40LxWp0cULx98QzgbH9k0zk5GX23wZQUAD5Z5i99U0u0h97L4;
        this.639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r = 639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r;
        this.3TjSNC1f8PHAQT1GF6Bom08wOmMgqF4F7KC11raR3HAoxpoUY3h80370wj1C = 3TjSNC1f8PHAQT1GF6Bom08wOmMgqF4F7KC11raR3HAoxpoUY3h80370wj1C;
        this.4bJH090TU6D4pW1r0aTNZ8EtLu5uO3Nx9mVoi9mh84hkOOlS5aO07wsp6al1 = 4bJH090TU6D4pW1r0aTNZ8EtLu5uO3Nx9mVoi9mh84hkOOlS5aO07wsp6al1;
        this.8120MhZIUxQfLJA6ZAb3Xgc48bsn1dz0G876yplH8j9oGHbXcOdCTeCs6EJ9 = 8120MhZIUxQfLJA6ZAb3Xgc48bsn1dz0G876yplH8j9oGHbXcOdCTeCs6EJ9;
    }
    
    public boolean 8zDvxlifg2v7M5mTzZ01U8Hp5GK4vFsG10Itf2n8bAGupn8K0EATYPc9Gv8n(final int[] array) {
        for (int i = 0; i <= 3 - this.639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r; ++i) {
            for (int j = 0; j <= 3 - this.3TjSNC1f8PHAQT1GF6Bom08wOmMgqF4F7KC11raR3HAoxpoUY3h80370wj1C; ++j) {
                if (this.9h187avk05p0tn672R5E0Mfdug1dVZr4MoS164pvWu54W6v4jUGSjZBJGE39(array, i, j, true)) {
                    return true;
                }
                if (this.9h187avk05p0tn672R5E0Mfdug1dVZr4MoS164pvWu54W6v4jUGSjZBJGE39(array, i, j, false)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean 9h187avk05p0tn672R5E0Mfdug1dVZr4MoS164pvWu54W6v4jUGSjZBJGE39(final int[] array, final int n, final int n2, final boolean b) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                final int n3 = i - n;
                final int n4 = j - n2;
                int n5 = -1;
                if (n3 >= 0 && n4 >= 0 && n3 < this.639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r && n4 < this.3TjSNC1f8PHAQT1GF6Bom08wOmMgqF4F7KC11raR3HAoxpoUY3h80370wj1C) {
                    if (b) {
                        n5 = this.4bJH090TU6D4pW1r0aTNZ8EtLu5uO3Nx9mVoi9mh84hkOOlS5aO07wsp6al1[this.639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r - n3 - 1 + n4 * this.639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r];
                    }
                    else {
                        n5 = this.4bJH090TU6D4pW1r0aTNZ8EtLu5uO3Nx9mVoi9mh84hkOOlS5aO07wsp6al1[n3 + n4 * this.639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r];
                    }
                }
                if (array[i + j * 3] != n5) {
                    return false;
                }
            }
        }
        return true;
    }
    
    public 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex 1Z020Htn332472LUEwx58xcWeKLLnM7wllbc7L5BLsEfD286f0tsbwWZcr80(final int[] array) {
        return new 43Nc2QnnV13i1c3J76qJpd75c59A9CeY4VaW27tjdsO253ppIO6hy6AxgWx629vT375d3zh7lZ88397172uLJF8jexQRex(this.8120MhZIUxQfLJA6ZAb3Xgc48bsn1dz0G876yplH8j9oGHbXcOdCTeCs6EJ9.5P1b49yjUtk40LxWp0cULx98QzgbH9k0zk5GX23wZQUAD5Z5i99U0u0h97L4, this.8120MhZIUxQfLJA6ZAb3Xgc48bsn1dz0G876yplH8j9oGHbXcOdCTeCs6EJ9.79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp);
    }
    
    public int 176e9r94cKeG2ii7v8n7mb13PYg11lCd9CMl7UFIQh3554riwuHx4e1Tq4lw() {
        return this.639vuo1WRa77HM7e5e2iJ1N5OpEp9XkX9p8q4LiEDXwJM1N544lPm93zIa5r * this.3TjSNC1f8PHAQT1GF6Bom08wOmMgqF4F7KC11raR3HAoxpoUY3h80370wj1C;
    }
}
