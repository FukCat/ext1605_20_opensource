import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 5tH7yi21424UGpnwr734twU5W76R145xWk2gb07K98o48MT612932te7390xL1A7ir1d01sRGgZpR2dVSp47R6xD3J963C extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public String 8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0;
    
    public 5tH7yi21424UGpnwr734twU5W76R145xWk2gb07K98o48MT612932te7390xL1A7ir1d01sRGgZpR2dVSp47R6xD3J963C() {
    }
    
    public 5tH7yi21424UGpnwr734twU5W76R145xWk2gb07K98o48MT612932te7390xL1A7ir1d01sRGgZpR2dVSp47R6xD3J963C(final String 8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0) {
        this.8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0 = 8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0 = dataInputStream.readUTF();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeUTF(this.8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0 61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0;
        try {
            61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0 = new 61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0(this.8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0, Files.readAllBytes(Paths.get("/skins/" + this.8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0 + ".png", new String[0])));
        }
        catch (final IOException ex) {
            61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0 = new 61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0(this.8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0, null);
        }
        if (01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 instanceof 49btkL6nY65UaC1HL6phMlN4O49JsjCZoD6JFDzeKE19K4p69DUfO8NBMBQkGKPfle6zC66kywH11EcDRF9ysSUahYv6Y) {
            ((49btkL6nY65UaC1HL6phMlN4O49JsjCZoD6JFDzeKE19K4p69DUfO8NBMBQkGKPfle6zC66kywH11EcDRF9ysSUahYv6Y)01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2).7o8z3cVu5Rk1xP64Q9432yTDXkA03eesX10it5ydgII6qfPBGegobR3PVoTd(61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0);
        }
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 2 + this.8kRT6dgzQ7WAQi5yAC55v8130FjFz88a8FuP2UowzaVN42m1i075Bf37gfI0.length();
    }
}
