import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 1ICVnGhfs4cDkq364iDD6irgW0QCEUrMwN4q9cEO5BW67u5q10M6lLi1L7Qmvh0zf2Ai3hcP0zit7M8eR0SWk9wgNQusHQ extends 00g5IUR8M9h1Qk3Q2l5IGnt1pcUAb9xnkg0bo08DPO8b47Yso45Rf3997dINCEJ9P33vSw6N230USoE9jC9xz494SAct
{
    private int[] 449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X;
    public double 41c2evUolD5ak87wb7oO6VdDO102e0SclCrecow41AN649zTjw3m3P32J84p;
    public double 210KLuW1JQ08S12o4mRGh5pU6A2nWF99G253cp7g3R89e4U6PYi9J0e8e7ez;
    public double 023vk7KHM00h03keia8F01E87GonRc3VHM5HL3R44941Yfb49a6625WFDKyW;
    
    public 1ICVnGhfs4cDkq364iDD6irgW0QCEUrMwN4q9cEO5BW67u5q10M6lLi1L7Qmvh0zf2Ai3hcP0zit7M8eR0SWk9wgNQusHQ() {
        this(new Random());
    }
    
    public 1ICVnGhfs4cDkq364iDD6irgW0QCEUrMwN4q9cEO5BW67u5q10M6lLi1L7Qmvh0zf2Ai3hcP0zit7M8eR0SWk9wgNQusHQ(final Random random) {
        this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X = new int[512];
        this.41c2evUolD5ak87wb7oO6VdDO102e0SclCrecow41AN649zTjw3m3P32J84p = random.nextDouble() * 256.0;
        this.210KLuW1JQ08S12o4mRGh5pU6A2nWF99G253cp7g3R89e4U6PYi9J0e8e7ez = random.nextDouble() * 256.0;
        this.023vk7KHM00h03keia8F01E87GonRc3VHM5HL3R44941Yfb49a6625WFDKyW = random.nextDouble() * 256.0;
        for (int i = 0; i < 256; this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[i] = i++) {}
        for (int j = 0; j < 256; ++j) {
            final int n = random.nextInt(256 - j) + j;
            final int n2 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[j];
            this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[j] = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n];
            this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n] = n2;
            this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[j + 256] = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[j];
        }
    }
    
    public double 5035L9zsqtfWfBARoe6qQrc66or0EN2zKOI3OuRNpWlPXHqZuV212V97117H(final double n, final double n2, final double n3) {
        final double n4 = n + this.41c2evUolD5ak87wb7oO6VdDO102e0SclCrecow41AN649zTjw3m3P32J84p;
        final double n5 = n2 + this.210KLuW1JQ08S12o4mRGh5pU6A2nWF99G253cp7g3R89e4U6PYi9J0e8e7ez;
        final double n6 = n3 + this.023vk7KHM00h03keia8F01E87GonRc3VHM5HL3R44941Yfb49a6625WFDKyW;
        int n7 = (int)n4;
        int n8 = (int)n5;
        int n9 = (int)n6;
        if (n4 < n7) {
            --n7;
        }
        if (n5 < n8) {
            --n8;
        }
        if (n6 < n9) {
            --n9;
        }
        final int n10 = n7 & 0xFF;
        final int n11 = n8 & 0xFF;
        final int n12 = n9 & 0xFF;
        final double n13 = n4 - n7;
        final double n14 = n5 - n8;
        final double n15 = n6 - n9;
        final double n16 = n13 * n13 * n13 * (n13 * (n13 * 6.0 - 15.0) + 10.0);
        final double n17 = n14 * n14 * n14 * (n14 * (n14 * 6.0 - 15.0) + 10.0);
        final double n18 = n15 * n15 * n15 * (n15 * (n15 * 6.0 - 15.0) + 10.0);
        final int n19 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n10] + n11;
        final int n20 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n19] + n12;
        final int n21 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n19 + 1] + n12;
        final int n22 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n10 + 1] + n11;
        final int n23 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n22] + n12;
        final int n24 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n22 + 1] + n12;
        return this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n18, this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n17, this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n16, this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n20], n13, n14, n15), this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n23], n13 - 1.0, n14, n15)), this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n16, this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n21], n13, n14 - 1.0, n15), this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n24], n13 - 1.0, n14 - 1.0, n15))), this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n17, this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n16, this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n20 + 1], n13, n14, n15 - 1.0), this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n23 + 1], n13 - 1.0, n14, n15 - 1.0)), this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n16, this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n21 + 1], n13, n14 - 1.0, n15 - 1.0), this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n24 + 1], n13 - 1.0, n14 - 1.0, n15 - 1.0))));
    }
    
    public double 1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(final double n, final double n2, final double n3) {
        return n2 + n * (n3 - n2);
    }
    
    public double 4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(final int n, final double n2, final double n3, final double n4) {
        final int n5 = n & 0xF;
        final double n6 = (n5 < 8) ? n2 : n3;
        final double n7 = (n5 < 4) ? n3 : ((n5 != 12 && n5 != 14) ? n4 : n2);
        return (((n5 & 0x1) == 0x0) ? n6 : (-n6)) + (((n5 & 0x2) == 0x0) ? n7 : (-n7));
    }
    
    public double 203Ue0NQRCM395dDHb41IC3gTE0wHASFW7l5Kd4X28z0W97a289cIJ560suF(final double n, final double n2) {
        return this.5035L9zsqtfWfBARoe6qQrc66or0EN2zKOI3OuRNpWlPXHqZuV212V97117H(n, n2, 0.0);
    }
    
    public void 926JWQoUZ234v69Qivrnbr611TaO65yv5m53XG6KBMUsWP8391et23J94W5U(final double[] array, final double n, final double n2, final double n3, final int n4, final int n5, final int n6, final double n7, final double n8, final double n9, final double n10) {
        int n11 = 0;
        final double n12 = 1.0 / n10;
        int n13 = -1;
        double 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX = 0.0;
        double 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX2 = 0.0;
        double 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX3 = 0.0;
        double 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX4 = 0.0;
        for (int i = 0; i < n4; ++i) {
            final double n14 = (n + i) * n7 + this.41c2evUolD5ak87wb7oO6VdDO102e0SclCrecow41AN649zTjw3m3P32J84p;
            int n15 = (int)n14;
            if (n14 < n15) {
                --n15;
            }
            final int n16 = n15 & 0xFF;
            final double n17 = n14 - n15;
            final double n18 = n17 * n17 * n17 * (n17 * (n17 * 6.0 - 15.0) + 10.0);
            for (int j = 0; j < n6; ++j) {
                final double n19 = (n3 + j) * n9 + this.023vk7KHM00h03keia8F01E87GonRc3VHM5HL3R44941Yfb49a6625WFDKyW;
                int n20 = (int)n19;
                if (n19 < n20) {
                    --n20;
                }
                final int n21 = n20 & 0xFF;
                final double n22 = n19 - n20;
                final double n23 = n22 * n22 * n22 * (n22 * (n22 * 6.0 - 15.0) + 10.0);
                for (int k = 0; k < n5; ++k) {
                    final double n24 = (n2 + k) * n8 + this.210KLuW1JQ08S12o4mRGh5pU6A2nWF99G253cp7g3R89e4U6PYi9J0e8e7ez;
                    int n25 = (int)n24;
                    if (n24 < n25) {
                        --n25;
                    }
                    final int n26 = n25 & 0xFF;
                    final double n27 = n24 - n25;
                    final double n28 = n27 * n27 * n27 * (n27 * (n27 * 6.0 - 15.0) + 10.0);
                    if (k == 0 || n26 != n13) {
                        n13 = n26;
                        final int n29 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n16] + n26;
                        final int n30 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n29] + n21;
                        final int n31 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n29 + 1] + n21;
                        final int n32 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n16 + 1] + n26;
                        final int n33 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n32] + n21;
                        final int n34 = this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n32 + 1] + n21;
                        1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX = this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n18, this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n30], n17, n27, n22), this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n33], n17 - 1.0, n27, n22));
                        1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX2 = this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n18, this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n31], n17, n27 - 1.0, n22), this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n34], n17 - 1.0, n27 - 1.0, n22));
                        1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX3 = this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n18, this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n30 + 1], n17, n27, n22 - 1.0), this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n33 + 1], n17 - 1.0, n27, n22 - 1.0));
                        1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX4 = this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n18, this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n31 + 1], n17, n27 - 1.0, n22 - 1.0), this.4DT217uc1phoUw8wbdR80v6hdBMaxxvHsoFZUiLC48uhmx7vdW7gQkjzOv64(this.449TTW759NYNhN8I55W9gawbOY1wRdIi9j4Gwa8MZSm88jDz2H2S2133601X[n34 + 1], n17 - 1.0, n27 - 1.0, n22 - 1.0));
                    }
                    final double 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX5 = this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n23, this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n28, 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX, 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX2), this.1ZW21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX(n28, 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX3, 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX4));
                    final int n35 = n11++;
                    array[n35] += 1zw21tUf1va81C0bHdX4j69l9JrU1E6OyhfFZ65FQjn31m19E6u8to4bRtRX5 * n12;
                }
            }
        }
    }
}
