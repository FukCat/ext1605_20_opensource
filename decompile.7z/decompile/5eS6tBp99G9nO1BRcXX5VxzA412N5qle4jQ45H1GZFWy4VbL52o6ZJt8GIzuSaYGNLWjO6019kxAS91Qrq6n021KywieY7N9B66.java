import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 5eS6tBp99G9nO1BRcXX5VxzA412N5qle4jQ45H1GZFWy4VbL52o6ZJt8GIzuSaYGNLWjO6019kxAS91Qrq6n021KywieY7N9B66 extends 4325k26DmdDV5j1IjV8vrJo24qmGuT5bdNIPVFSKq79WjWX76Kvn9Ka2FTG9Oj8mEV9YUvbCa8k19y8M5Yv3alQH98valwFA6x4
{
    public 5eS6tBp99G9nO1BRcXX5VxzA412N5qle4jQ45H1GZFWy4VbL52o6ZJt8GIzuSaYGNLWjO6019kxAS91Qrq6n021KywieY7N9B66() {
        this.27MZR7Vsau5qN5V155085PngR83EV19wcMsl9W3YLJDrMggvdkWAu5tAS4Hf = true;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        super.5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(dataInputStream);
        this.89ZMZvJM7P89t2LhuJh0usV9Uit50q5j2m1dxl4FjBLFaw60MIkfnVo0r60U = dataInputStream.readByte();
        this.2v3jgPEGWF4g1HyZ16l4fH9sH1dXuzDIP65jk5oorm14J4XWYI2pu4L125sQ = dataInputStream.readByte();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        super.45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(dataOutputStream);
        dataOutputStream.writeByte(this.89ZMZvJM7P89t2LhuJh0usV9Uit50q5j2m1dxl4FjBLFaw60MIkfnVo0r60U);
        dataOutputStream.writeByte(this.2v3jgPEGWF4g1HyZ16l4fH9sH1dXuzDIP65jk5oorm14J4XWYI2pu4L125sQ);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 6;
    }
}
