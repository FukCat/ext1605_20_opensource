import org.lwjgl.util.glu.GLU;
import org.lwjgl.opengl.GL11;
import java.util.Date;
import java.util.Calendar;
import java.io.IOException;
import java.io.File;
import net.minecraft.client.Minecraft;
import java.nio.file.Files;
import java.nio.charset.Charset;
import java.nio.file.Paths;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 4XiQ5WlIPZ272kng7qb0S6UQYG08KRySIujYWz6i1dTzm6b00r3NCEA20B8d2n4Nqn0Lk7BtgwCEOkFBHeE1S9u2J6sUgs extends 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D
{
    private static final Random 36VawMUOs6ndC8I6F6Y7O17ft8hn1y6IwZ27pN29XDrQ7eX0j6mvkWLpp1RM;
    String[] 3N441I1RWNyXTzL8fXrtAPid8X7mUJe417y5rMNBN1ZqAAp2QgHhBg0b04Oo;
    private 5BnW28PCkF5CR9oZHNlKPkNmrJV15274D84C81uGqI5WM8gfWL1rjrI4IGE0iMC805R0291BCn8XLPb84ybnbeEL3pkM[][] 86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk;
    private String 2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP;
    private String 86n81aeztWkXEU2lqQZjrQLrnKd46X44E89Hgd3O8ihwdvkHRE0FR4yY41D9;
    
    public 4XiQ5WlIPZ272kng7qb0S6UQYG08KRySIujYWz6i1dTzm6b00r3NCEA20B8d2n4Nqn0Lk7BtgwCEOkFBHeE1S9u2J6sUgs() {
        this.3N441I1RWNyXTzL8fXrtAPid8X7mUJe417y5rMNBN1ZqAAp2QgHhBg0b04Oo = new String[] { " *   * * *   * *** *** *** *** *** ***", " ** ** * **  * *   *   * * * * *    * ", " * * * * * * * **  *   **  *** **   * ", " *   * * *  ** *   *   * * * * *    * ", " *   * * *   * *** *** * * * * *    * " };
        this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = "missingno";
        this.86n81aeztWkXEU2lqQZjrQLrnKd46X44E89Hgd3O8ihwdvkHRE0FR4yY41D9 = "";
        try {
            final ArrayList list = new ArrayList();
            String line;
            while ((line = new BufferedReader(new InputStreamReader(1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.5v4Cs6sI06e6Hjpg3rSI82gG008x14C2jag2OM7ADaW5U8a3DYSrf570CJm6("/title/splashes.txt"))).readLine()) != null) {
                final String trim = line.trim();
                if (trim.length() > 0) {
                    list.add(trim);
                }
            }
            this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = (String)list.get(4XiQ5WlIPZ272kng7qb0S6UQYG08KRySIujYWz6i1dTzm6b00r3NCEA20B8d2n4Nqn0Lk7BtgwCEOkFBHeE1S9u2J6sUgs.36VawMUOs6ndC8I6F6Y7O17ft8hn1y6IwZ27pN29XDrQ7eX0j6mvkWLpp1RM.nextInt(list.size()));
        }
        catch (final Exception ex) {}
    }
    
    @Override
    public void 79dcDBX8wOiJ7P492Y177gZw78gOSlsV8lxmDRioLVlEh14o5HL6Utyo3Gfq() {
        if (this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk != null) {
            for (int i = 0; i < this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk.length; ++i) {
                for (int j = 0; j < this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk[i].length; ++j) {
                    this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk[i][j].1EM7X6tH0x0d9lplMx1qM9HBcJ759h6ng4C8IiXbM3XJwH0OvRy4r4f1CE1r();
                }
            }
        }
    }
    
    private void 83126rceU8dFZmCp1Ux39Vgous0cloM49Iv4YFWI8kel38fSan16ATJV5HLb() {
        try {
            this.86n81aeztWkXEU2lqQZjrQLrnKd46X44E89Hgd3O8ihwdvkHRE0FR4yY41D9 = Files.readAllLines(Paths.get("./qfile", new String[0]), Charset.forName("utf8")).get(0);
            final File file = new File(Minecraft.74365lSUZG8SRi4QcP0LdVO61o0N3570jYi74Tv6MwBh3c90i6CydLQuxD79(), "saves/" + this.86n81aeztWkXEU2lqQZjrQLrnKd46X44E89Hgd3O8ihwdvkHRE0FR4yY41D9);
            if (!file.exists() || !file.isDirectory()) {
                throw new IOException();
            }
            this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(1).0Dn9XYbwOI0cTzjIRHga5tL990b9oummb9Q64SZBh9LU4M0I395Wln2t9pnG = true;
            this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(1).341FqR7gR9Z89F779fLfXdcwKO6ZA54xm6oS9N8sLphh7p10BkALs3o76F57 = "Quickload : " + this.86n81aeztWkXEU2lqQZjrQLrnKd46X44E89Hgd3O8ihwdvkHRE0FR4yY41D9;
            this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(1).11Xh3vqwC9ZfPG5q0A0h657SQ4328JJoZPg0t2DcD835LMBLRqjcI8hoaK84 = 80 + this.86n81aeztWkXEU2lqQZjrQLrnKd46X44E89Hgd3O8ihwdvkHRE0FR4yY41D9.length() * 4;
        }
        catch (final IOException ex) {
            this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(1).0Dn9XYbwOI0cTzjIRHga5tL990b9oummb9Q64SZBh9LU4M0I395Wln2t9pnG = false;
        }
    }
    
    @Override
    protected void 27HH93i69891UR8scaUy8Wa381SrOHnrgz1395TWPN543Aw65UPU60a9U5op(final char c, final int n) {
    }
    
    @Override
    public void 4An20JYjYn5ahp07NQmWFCuC33T53X6s4pd5325t5MV2inUXBh7is28o5l1C() {
        final Calendar instance = Calendar.getInstance();
        instance.setTime(new Date());
        final int value = instance.get(2);
        if (value == 5 && instance.get(5) == 5) {
            this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = "Happy birthday, 8064262!";
        }
        else if (value == 5 && instance.get(5) == 6) {
            this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = "Happy birthday, my beloved...";
        }
        else if (value == 7 && instance.get(5) == 15) {
            final String[] array = { "\"Screw you, cat!\"", "\"We're like a secret organization!\"", "Interval Days", "Interval Daze" };
            this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = array[4XiQ5WlIPZ272kng7qb0S6UQYG08KRySIujYWz6i1dTzm6b00r3NCEA20B8d2n4Nqn0Lk7BtgwCEOkFBHeE1S9u2J6sUgs.36VawMUOs6ndC8I6F6Y7O17ft8hn1y6IwZ27pN29XDrQ7eX0j6mvkWLpp1RM.nextInt(array.length)];
        }
        else if (value == 7 && instance.get(5) == 31) {
            this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = "39!";
        }
        else if (value == 2 && instance.get(5) == 3) {
            this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = "Drummin' along since 2000!";
        }
        else if ((value == 8 && instance.get(5) == 18) || (value == 5 && instance.get(5) == 24)) {
            this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = "Also try ShovelForge!";
        }
        else if (instance.get(10) == 7 && instance.get(12) == 27) {
            if (4XiQ5WlIPZ272kng7qb0S6UQYG08KRySIujYWz6i1dTzm6b00r3NCEA20B8d2n4Nqn0Lk7BtgwCEOkFBHeE1S9u2J6sUgs.36VawMUOs6ndC8I6F6Y7O17ft8hn1y6IwZ27pN29XDrQ7eX0j6mvkWLpp1RM.nextBoolean()) {
                this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = "How?";
            }
            else {
                this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP = "When you see it...";
            }
        }
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.clear();
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT(1, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 8, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 48, 120, 20, "Play", true));
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT(4, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 8 + 200 - 60, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 48, 60, 20, "Quickload", true));
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT(0, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 8, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 96 + 12, 100, 20, "Options", true));
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT(5, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 8, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 120 + 12, 80, 20, "Exit", true));
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT(6, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 8, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 84, 70, 20, "Visuals", true));
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT(7, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 8 + 75, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 84, 70, 20, "Extensions", true));
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 3UMIIzqx5FMhp9HnU61xgaBvDnO7m31RjMkns4m0y29cAPWoEFg43pdLnjW13w5WfDedafth867919Vy531ri2q32qrT(8, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 8 + 90, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 120 + 12, 80, 20, "Credits", true));
        this.83126rceU8dFZmCp1Ux39Vgous0cloM49Iv4YFWI8kel38fSan16ATJV5HLb();
        if (3TRs4A75rS0TtcUL36iKx34E6k4NB1XXM6i8cs9Khd3OUdqLNT1q99wqrgwtn53Nk1LerxKV5f8Dlt8MOX4uKK6df8l.8fWA5xW68v3c3otZuNHf4trgarlAHnP4FdxcmBHl3QMo1POyfJ4Ek68oWnok == null) {
            this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.get(1).0Dn9XYbwOI0cTzjIRHga5tL990b9oummb9Q64SZBh9LU4M0I395Wln2t9pnG = false;
        }
        if (0hAIC3TYFFRBw7X27377CB8mov7mOuK3ZuV6ofmix4NppPrBNqiUSiSy41S31Fvfz9jH1tpIf87stMiKd1Sp5T9snFpPbN.56fOEBIsM5JqtBCx6Bjo40o1D5jvZBeotwEb0wU25jjVWokZC5342ZAp34oX != null && !0hAIC3TYFFRBw7X27377CB8mov7mOuK3ZuV6ofmix4NppPrBNqiUSiSy41S31Fvfz9jH1tpIf87stMiKd1Sp5T9snFpPbN.56fOEBIsM5JqtBCx6Bjo40o1D5jvZBeotwEb0wU25jjVWokZC5342ZAp34oX.playing("BgMusic")) {
            1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.1FtenBjtbWTQMx7w9NQ2pQqFxhc78G5Djz3ghM24o7Tc21uHI6Cx8s0PaRpG.514dv3mYU7t95lOh23lLhBI10XBv07D8y61Goe1u7G926JNt2Y1WIoiHj5tm("mainmenu", true);
        }
    }
    
    @Override
    protected void 7OD0HqHbYI4579sDX4xzee60N9g9V78YwSmgkc1Y6fyN6rF6JwUqBEU5m77M(final 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03 5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03) {
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 0) {
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 6IV61XP22S12A511ZWuze1bb798817HpAQKUhn3BhO70eo2rG2fm8tn28699x603PdtCEi8ECxZhMRpovd0Qx83T225ALgT1O2(this, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn));
        }
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 1) {
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 8F5ch9i0cRte2v37lzRGH0GV0Y1jvjJOu2Sibx48MWK6W5A158IhVlBMvc7X7Imh4I2TkiBEDiCjdrOAdq41U9GUgc804gLw3c695(this));
        }
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 2) {
            if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.3Qh5JgDKG16I2LMH200ubt9Ib7aad5w24R460sAze1KErHj022lk1FkwVGo8(54)) {
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 7y3uHB6HoSMYi5DIDA0akSEhatU9ElCRFblJungv3MOq5l0U2jK1Y1G5Yj4sH3wuZvZQQEg1Q5Mm6qZ4pVtkOahPdFvr9ZVK(this));
            }
            else {
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 8Q5rXsMrRRFgdCH76Gkdit1Cb654Aew0Ob4M32l7S3FC8XT1nT96Gzi8r1urDRbw3nJlc52P8nv9a7mIHKo4j9f7ZglrwtdRGb(this));
            }
        }
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 3) {
            if (0rxyG061C13735Na37QRFiS1ZL2aZfgjFSg4hUH6koh8G1W87np57Qn07I3JVPOagnZ37919Ri63Peoq8KeXGcdiR8kg271679UC0.0T0CLiffrw8qZ09Bm16F6q56be7F83Xg6ndV4SE1Y4W4sgPDWr9SltcnkE9L) {
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.3Qh5JgDKG16I2LMH200ubt9Ib7aad5w24R460sAze1KErHj022lk1FkwVGo8(54) ? new 50PUc66UX1kOKbpJnHO563q2uk9QrDoG23E3LD36tXUi89HZ5TZQbP2p8Iq6AUGny6VlWi51H5vK5dGd3gFfwBZnuLiBVAOTX(this) : new 6U84K1JbAU7xFI0851AE2EM4ykqwAo7r03aLLIT2jX92n7aQfT06RN5ltPS3hdJj7k9H2FqGr79v385j902yBRXUN5yB02MDg6G(this));
            }
            else {
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 4iPxfE9NobLgCV7E18vEHT1cJ6lluXA02YrGIhCL2SlE5e6tfoFs52b4cqQ2AyS509L8nqdO9h4jR24EM6huGz76JTn8Gb("", "Downloading resources. Try again later."));
            }
        }
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 4 && this.86n81aeztWkXEU2lqQZjrQLrnKd46X44E89Hgd3O8ihwdvkHRE0FR4yY41D9 != "") {
            final File file = new File(Minecraft.74365lSUZG8SRi4QcP0LdVO61o0N3570jYi74Tv6MwBh3c90i6CydLQuxD79(), "saves/" + this.86n81aeztWkXEU2lqQZjrQLrnKd46X44E89Hgd3O8ihwdvkHRE0FR4yY41D9);
            if (file.exists() && file.isDirectory()) {
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.9n0vQC1y11r22OAFwQ1LEGORCMfqSz3H2W5tKiHBjq0tqdbVUB1jq32X1KQ8 = new 5Bo2RFI9pGj8v2K84b836NMiTffRXCH0AGsu472BB66U5L26PEBb2hLHi7P2O9l36k0d6u2nQ2404v2BZyvj9N2ko3amt55(this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr);
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.3aYeA7ake0QjnoN2mM18RmjL87K61kJ6LTR6757eYWVL92EF6a2A12Lc978r(this.86n81aeztWkXEU2lqQZjrQLrnKd46X44E89Hgd3O8ihwdvkHRE0FR4yY41D9);
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(null);
            }
        }
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 5) {
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.9T4tyP319hE2JojSscGq782dOrj03OgJ36X530YVJ0D1i2bPDWii9IVrSO0G();
            System.exit(39);
        }
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 6) {
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 4QXpSNklo0oYG8hH1VaLM9Axeet0s115GAtjb44qq2Bs47ZpydmiJUa98j17iDvN1d1DY0ThOp6eYYP9i9766525xsr9BLtT6(this));
        }
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 7) {
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 8xPF7Kr7rZ8rL5GoirJ2778903x3pj7164JgUNc6n00W3FtTk8ZQwn1n6U74795FYuCdxqi3wkFV7g86749ZQ66J9zcinPfsU(this));
        }
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 8) {
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(new 03y86U418xn7eB6C8LO0z6DDF9o48L43xZdZ6R3ct6MMO7i9NBGkkbHB0w3188dl1L0TI3Leq25iPe2H2wohuSG4ipq1uE4yf0(this));
        }
    }
    
    @Override
    public void 9zr0Ft7ATwYEg4elWEB8ucyDaj2700KJgZB3Cc51d8vF03zOM52iOvWHcrR5(final int n, final int n2, final float n3) {
        this.5S1K79XLhK48s404AETji776rN10k5t6zymKy3FSC71grsr64j85ILV6pJWZ();
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.2423D44YwU0rxXCBAYNu49Ev2WpxKRw67DiwCB63xVXr80FDU91BWvgU90x8(0, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 40, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b, -536870912, -2146697188);
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.2423D44YwU0rxXCBAYNu49Ev2WpxKRw67DiwCB63xVXr80FDU91BWvgU90x8(0, 0, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 40, 447997183, 11789567);
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        this.7nNL17fr51ug54eD57aH93udL9e9jXjaG3n2KIU6WD4fJyp8mmQ1JW2AlR7M(n3);
        GL11.glBindTexture(3553, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8("/gui/logo.png"));
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.8v7F8G8g1104wyQ7q86jd6WFsS0S8C9C5G6r53pazN5nIQt79hRlifP4WcDq(16777215);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)(this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 + 90), 70.0f, 0.0f);
        GL11.glRotatef(-20.0f, 0.0f, 0.0f, 1.0f);
        final float n4 = (1.8f - 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.71ISDl4gPc9Fk0C2Kj3oEr2CUJmxr50GP2V4kXkAyryW5TB554YLltsq7e3C(5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(System.currentTimeMillis() % 1000L / 1000.0f * 3.1415927f * 2.0f) * 0.1f)) * 100.0f / (this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ.513yBz0z1e0Xp8J9hG9YLezT8TFgNrrND64rO10vxk37SjfO36iSUM8NmZ6j(this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP) + 32);
        GL11.glScalef(n4, n4, n4);
        this.7hd18JPAm30YnhcZ8R4BhADB3iRynT8aWz54M1xf1qSS3I4uWxIHQH2B64Sx(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, this.2b8HgEu9sfcNR49M49R0NjR1Gapi1BRKvYfkCRg3h11BQXRYgg3Ki29X6mMP, 0, -8, 16776960);
        GL11.glPopMatrix();
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, "Logged in as " + this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.9BXi6e7QKCFcVY55o0g1F5t74mUhXb889P2W9e5q99Afb18HoY6of87hw54Q.133H4SABj815B05p53qsGvG0T6wXYQJeOV93GEbryghg5O6d9WK185g78Ibb, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 8, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 30, 1627389951);
        final String s = "Copyright Mojang. Distribution strictly prohibited.";
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, s, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s - this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ.513yBz0z1e0Xp8J9hG9YLezT8TFgNrrND64rO10vxk37SjfO36iSUM8NmZ6j(s) - 2, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b - 10, 16777215);
        final long maxMemory = Runtime.getRuntime().maxMemory();
        final long totalMemory = Runtime.getRuntime().totalMemory();
        final String string = "Free memory: " + (maxMemory - Runtime.getRuntime().freeMemory()) * 100L / maxMemory + "% of " + maxMemory / 1024L / 1024L + "MB";
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, string, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s - this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ.513yBz0z1e0Xp8J9hG9YLezT8TFgNrrND64rO10vxk37SjfO36iSUM8NmZ6j(string) - 2, 2, 8421504);
        final String string2 = "Allocated memory: " + totalMemory * 100L / maxMemory + "% (" + totalMemory / 1024L / 1024L + "MB)";
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, string2, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s - this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ.513yBz0z1e0Xp8J9hG9YLezT8TFgNrrND64rO10vxk37SjfO36iSUM8NmZ6j(string2) - 2, 12, 8421504);
        super.9zr0Ft7ATwYEg4elWEB8ucyDaj2700KJgZB3Cc51d8vF03zOM52iOvWHcrR5(n, n2, n3);
    }
    
    private void 7nNL17fr51ug54eD57aH93udL9e9jXjaG3n2KIU6WD4fJyp8mmQ1JW2AlR7M(final float n) {
        if (this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk == null) {
            this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk = new 5BnW28PCkF5CR9oZHNlKPkNmrJV15274D84C81uGqI5WM8gfWL1rjrI4IGE0iMC805R0291BCn8XLPb84ybnbeEL3pkM[this.3N441I1RWNyXTzL8fXrtAPid8X7mUJe417y5rMNBN1ZqAAp2QgHhBg0b04Oo[0].length()][this.3N441I1RWNyXTzL8fXrtAPid8X7mUJe417y5rMNBN1ZqAAp2QgHhBg0b04Oo.length];
            for (int i = 0; i < this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk.length; ++i) {
                for (int j = 0; j < this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk[i].length; ++j) {
                    this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk[i][j] = new 5BnW28PCkF5CR9oZHNlKPkNmrJV15274D84C81uGqI5WM8gfWL1rjrI4IGE0iMC805R0291BCn8XLPb84ybnbeEL3pkM(this, i, j);
                }
            }
        }
        GL11.glMatrixMode(5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        final int n2 = 120 * new 2CHDJp1C8lG352UVeot7et4hgyHXM6d5J8b9e2nQsCL5oMUY2n07S3FpqE7Sd05d7w5bj0DjXj9nOodrY77oPGTOk9mOFNc5o625Yd(this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw).97KE9hgl5Rx6Zyk302FB0M0SudbODjd4S04sLEhxU4GUh8JlQ9HJ86eGgS23;
        GLU.gluPerspective(70.0f, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA / (float)n2, 0.05f, 100.0f);
        GL11.glViewport(0, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw - n2, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, n2);
        GL11.glMatrixMode(5888);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glDisable(2884);
        GL11.glCullFace(1029);
        GL11.glDepthMask(true);
        for (int k = 0; k < 3; ++k) {
            GL11.glPushMatrix();
            GL11.glTranslatef(0.4f, 0.6f, -12.0f);
            if (k == 0) {
                GL11.glClear(256);
                GL11.glTranslatef(0.0f, -0.4f, 0.0f);
                GL11.glScalef(0.98f, 1.0f, 1.0f);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
            }
            if (k == 1) {
                GL11.glDisable(3042);
                GL11.glClear(256);
            }
            if (k == 2) {
                GL11.glEnable(3042);
                GL11.glBlendFunc(768, 1);
            }
            GL11.glScalef(1.0f, -1.0f, 1.0f);
            GL11.glRotatef(15.0f, 1.0f, 0.0f, 0.0f);
            GL11.glScalef(0.89f, 1.0f, 0.4f);
            GL11.glTranslatef(-this.3N441I1RWNyXTzL8fXrtAPid8X7mUJe417y5rMNBN1ZqAAp2QgHhBg0b04Oo[0].length() * 0.5f, -this.3N441I1RWNyXTzL8fXrtAPid8X7mUJe417y5rMNBN1ZqAAp2QgHhBg0b04Oo.length * 0.5f, 0.0f);
            GL11.glBindTexture(3553, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8(7yDngUXBYilDo3B5U1OQjbOC7YXT20yRn3Tcd85a5HhG5v856xXdCWUtjJXOc078JNt0up84KG4cgp466vtym7iZ695S7Udf.833cA0YF34t606AzhAl21SSFKu5o86ZfZT6w0TL8Lej56qphXp7Tl0V5475T(7yDngUXBYilDo3B5U1OQjbOC7YXT20yRn3Tcd85a5HhG5v856xXdCWUtjJXOc078JNt0up84KG4cgp466vtym7iZ695S7Udf.62Ccm2XAR6JqSDTgV762x61j971DNgsIrMhaXZxPs0fQnBC7ymR2l1v1V22X)));
            if (k == 0) {
                GL11.glBindTexture(3553, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8("/title/black.png"));
            }
            final 9KrE19lpX3K2Kr9vDpx83D2EBEn3g3P4322pS7Am8WoU4XwmWmr83E08z8sv7c888K7GjtmR69DF64fXsV3qX8t21I3p156KEH 9KrE19lpX3K2Kr9vDpx83D2EBEn3g3P4322pS7Am8WoU4XwmWmr83E08z8sv7c888K7GjtmR69DF64fXsV3qX8t21I3p156KEH = new 9KrE19lpX3K2Kr9vDpx83D2EBEn3g3P4322pS7Am8WoU4XwmWmr83E08z8sv7c888K7GjtmR69DF64fXsV3qX8t21I3p156KEH();
            for (int l = 0; l < this.3N441I1RWNyXTzL8fXrtAPid8X7mUJe417y5rMNBN1ZqAAp2QgHhBg0b04Oo.length; ++l) {
                for (int index = 0; index < this.3N441I1RWNyXTzL8fXrtAPid8X7mUJe417y5rMNBN1ZqAAp2QgHhBg0b04Oo[l].length(); ++index) {
                    if (this.3N441I1RWNyXTzL8fXrtAPid8X7mUJe417y5rMNBN1ZqAAp2QgHhBg0b04Oo[l].charAt(index) != ' ') {
                        GL11.glPushMatrix();
                        final 5BnW28PCkF5CR9oZHNlKPkNmrJV15274D84C81uGqI5WM8gfWL1rjrI4IGE0iMC805R0291BCn8XLPb84ybnbeEL3pkM 5BnW28PCkF5CR9oZHNlKPkNmrJV15274D84C81uGqI5WM8gfWL1rjrI4IGE0iMC805R0291BCn8XLPb84ybnbeEL3pkM = this.86e8pAja1jKc36OH3W998dy8IUg495Z9end3cN153Dl4bSY511Ii7NhH2iXk[index][l];
                        float n3 = (float)(5BnW28PCkF5CR9oZHNlKPkNmrJV15274D84C81uGqI5WM8gfWL1rjrI4IGE0iMC805R0291BCn8XLPb84ybnbeEL3pkM.2s54U4u7e11gRWhC2MVWYuCjR6uVlW092Yr0O3BZXg7btkg9a22u0Wo9j478 + (5BnW28PCkF5CR9oZHNlKPkNmrJV15274D84C81uGqI5WM8gfWL1rjrI4IGE0iMC805R0291BCn8XLPb84ybnbeEL3pkM.0FGK5roGLERe1rIWtx1GGzl5Yatf351wGLIqQ3iK1DJPNsm68XW6Z79Izk13 - 5BnW28PCkF5CR9oZHNlKPkNmrJV15274D84C81uGqI5WM8gfWL1rjrI4IGE0iMC805R0291BCn8XLPb84ybnbeEL3pkM.2s54U4u7e11gRWhC2MVWYuCjR6uVlW092Yr0O3BZXg7btkg9a22u0Wo9j478) * n);
                        float n4 = 1.0f;
                        float n5 = 1.0f;
                        final float n6 = 0.0f;
                        if (k == 0) {
                            n4 = n3 * 0.04f + 1.0f;
                            n5 = 1.0f / n4;
                            n3 = 0.0f;
                        }
                        GL11.glTranslatef((float)index, (float)l, n3);
                        GL11.glScalef(n4, n4, n4);
                        GL11.glRotatef(n6, 0.0f, 1.0f, 0.0f);
                        9KrE19lpX3K2Kr9vDpx83D2EBEn3g3P4322pS7Am8WoU4XwmWmr83E08z8sv7c888K7GjtmR69DF64fXsV3qX8t21I3p156KEH.47uFsco7k3MB69GCB74UB9R3EkROVQhfTX6e4vfh9tGQb5JpV1NpUJJZFMS4(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.26V475EeKyTVt6B142Z2Jgcs6tr37z2in7wZlqoDyiUykn30S0vQ2evr9SGO, n5, true);
                        GL11.glPopMatrix();
                    }
                }
            }
            GL11.glPopMatrix();
        }
        GL11.glDisable(3042);
        GL11.glMatrixMode(5889);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glPopMatrix();
        GL11.glViewport(0, 0, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7wa4Q09YKe4Yb610u0jt109nz9o7x3BF0dhmE0yPBjW08svGqii5A6pG84EA, this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.7n4jM037w4LsPm6ikFf20THdobbKbA6iKJdl98oj1myTsF8PUb5s91JTOGcw);
        GL11.glEnable(2884);
    }
    
    static Random 0281W784v5GkjtEc0nvQ222rIe0Xgz8OQ2qq7m3Vp5CSE4aN3vy6EMHy8kOw() {
        return 4XiQ5WlIPZ272kng7qb0S6UQYG08KRySIujYWz6i1dTzm6b00r3NCEA20B8d2n4Nqn0Lk7BtgwCEOkFBHeE1S9u2J6sUgs.36VawMUOs6ndC8I6F6Y7O17ft8hn1y6IwZ27pN29XDrQ7eX0j6mvkWLpp1RM;
    }
    
    static {
        36VawMUOs6ndC8I6F6Y7O17ft8hn1y6IwZ27pN29XDrQ7eX0j6mvkWLpp1RM = new Random();
    }
}
