import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2ln38KcW5Auc6aY0wgN2Uv6nWahJy6fsHVCU4MVbauH57b7dtQ2mIfw6Km81YaRR8YG8r45l0HX11L6BRTRuVjEa2llBYIp26x38m extends 3cicE9OcuQ29K8r10U2uUfKpu0noKEafUbw2915vFW0G88uOIN59T7E98VW968gI3dTP30nDL5DW6jg934fj60jaW3v0Q3xi3
{
    protected 2ln38KcW5Auc6aY0wgN2Uv6nWahJy6fsHVCU4MVbauH57b7dtQ2mIfw6Km81YaRR8YG8r45l0HX11L6BRTRuVjEa2llBYIp26x38m(final int n, final int n2) {
        super(n, n2, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.05M2lyfhkCWxFBaMQ4zXC4s76HnC5g08gem1NGa81EXm8lCOe51JljjWbII4);
    }
    
    @Override
    protected 2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex 8cW5T5YlOAxd2blGPDHwxROAJxAZ44YaVVZgMOsT8936vX6dFUzUTFYe648j() {
        return new 6rNnMce0Z9o9ZgEH1hCrjc470Py2d427dR01C0nFX01h79DjvS4w014cG16Le3OXp1H172g7Z4XXzCG2TIej5pd75M6Lu3BWg8();
    }
    
    @Override
    public int 8LTZgqX2KHwGhNpQ1gUZz1WaWt0W2TrjgClq35mEWEh8l45qEVZXQ21Rh3g0(final int n, final Random random) {
        return 0;
    }
    
    @Override
    public int 45k0se28RPK2IN33WJfb5g4oDd7zeQlWp0LvSfJeHBZ0aVU090Eh0r7XB665(final Random random) {
        return 0;
    }
    
    @Override
    public boolean 0h7ja7JP1RVvR1k3BkHI25xIPjD0Mt7VMr7R1eHBtT1qev9PQb01Fzly06mZ() {
        return false;
    }
}
