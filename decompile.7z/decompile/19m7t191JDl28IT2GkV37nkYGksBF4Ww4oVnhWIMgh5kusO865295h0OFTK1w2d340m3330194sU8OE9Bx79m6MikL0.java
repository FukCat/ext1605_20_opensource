import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 19m7t191JDl28IT2GkV37nkYGksBF4Ww4oVnhWIMgh5kusO865295h0OFTK1w2d340m3330194sU8OE9Bx79m6MikL0 extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 5T0K4mEkB1Hg0LsNeeMezg6J90w8GO7JXU4CuCl7lVQkqSa1FFmK5yYfn71b;
    public double 6UX71qqGvxouUDTC13c3qV75PAp2F1siZVYFR6fac7H8UnzKC0hK72Kj9cQd;
    public double 77e6E1uZUcheYcZIWrKKuPDEW87vZRba1G07w7F89hEUHiP1k8C85J90egYA;
    public double 97mv6xkm313987U87O9c140ffuZGC8yFk9S365150UwfQ24Y56AbSuS3yDJ8;
    public double 7T4m0N43WkZqtBml51X0srM2FSNg48cfbn8p9PYj66cgfLN8Tu1Mff8MZmV1;
    public double 9vUyMIRo06g82IDQ9S1evUxV1s2VwulG1jkPU3QIa3g4tPSueaGBB3O9uW1u;
    
    public 19m7t191JDl28IT2GkV37nkYGksBF4Ww4oVnhWIMgh5kusO865295h0OFTK1w2d340m3330194sU8OE9Bx79m6MikL0(final int 5t0K4mEkB1Hg0LsNeeMezg6J90w8GO7JXU4CuCl7lVQkqSa1FFmK5yYfn71b, final double 6ux71qqGvxouUDTC13c3qV75PAp2F1siZVYFR6fac7H8UnzKC0hK72Kj9cQd, final double 77e6E1uZUcheYcZIWrKKuPDEW87vZRba1G07w7F89hEUHiP1k8C85J90egYA, final double 97mv6xkm313987U87O9c140ffuZGC8yFk9S365150UwfQ24Y56AbSuS3yDJ8, final double 7t4m0N43WkZqtBml51X0srM2FSNg48cfbn8p9PYj66cgfLN8Tu1Mff8MZmV1, final double 9vUyMIRo06g82IDQ9S1evUxV1s2VwulG1jkPU3QIa3g4tPSueaGBB3O9uW1u) {
        this.5T0K4mEkB1Hg0LsNeeMezg6J90w8GO7JXU4CuCl7lVQkqSa1FFmK5yYfn71b = 5t0K4mEkB1Hg0LsNeeMezg6J90w8GO7JXU4CuCl7lVQkqSa1FFmK5yYfn71b;
        this.6UX71qqGvxouUDTC13c3qV75PAp2F1siZVYFR6fac7H8UnzKC0hK72Kj9cQd = 6ux71qqGvxouUDTC13c3qV75PAp2F1siZVYFR6fac7H8UnzKC0hK72Kj9cQd;
        this.77e6E1uZUcheYcZIWrKKuPDEW87vZRba1G07w7F89hEUHiP1k8C85J90egYA = 77e6E1uZUcheYcZIWrKKuPDEW87vZRba1G07w7F89hEUHiP1k8C85J90egYA;
        this.97mv6xkm313987U87O9c140ffuZGC8yFk9S365150UwfQ24Y56AbSuS3yDJ8 = 97mv6xkm313987U87O9c140ffuZGC8yFk9S365150UwfQ24Y56AbSuS3yDJ8;
        this.7T4m0N43WkZqtBml51X0srM2FSNg48cfbn8p9PYj66cgfLN8Tu1Mff8MZmV1 = 7t4m0N43WkZqtBml51X0srM2FSNg48cfbn8p9PYj66cgfLN8Tu1Mff8MZmV1;
        this.9vUyMIRo06g82IDQ9S1evUxV1s2VwulG1jkPU3QIa3g4tPSueaGBB3O9uW1u = 9vUyMIRo06g82IDQ9S1evUxV1s2VwulG1jkPU3QIa3g4tPSueaGBB3O9uW1u;
    }
    
    public 19m7t191JDl28IT2GkV37nkYGksBF4Ww4oVnhWIMgh5kusO865295h0OFTK1w2d340m3330194sU8OE9Bx79m6MikL0() {
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.5T0K4mEkB1Hg0LsNeeMezg6J90w8GO7JXU4CuCl7lVQkqSa1FFmK5yYfn71b = dataInputStream.readInt();
        this.6UX71qqGvxouUDTC13c3qV75PAp2F1siZVYFR6fac7H8UnzKC0hK72Kj9cQd = dataInputStream.readDouble();
        this.77e6E1uZUcheYcZIWrKKuPDEW87vZRba1G07w7F89hEUHiP1k8C85J90egYA = dataInputStream.readDouble();
        this.97mv6xkm313987U87O9c140ffuZGC8yFk9S365150UwfQ24Y56AbSuS3yDJ8 = dataInputStream.readDouble();
        this.7T4m0N43WkZqtBml51X0srM2FSNg48cfbn8p9PYj66cgfLN8Tu1Mff8MZmV1 = dataInputStream.readDouble();
        this.9vUyMIRo06g82IDQ9S1evUxV1s2VwulG1jkPU3QIa3g4tPSueaGBB3O9uW1u = dataInputStream.readDouble();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.5T0K4mEkB1Hg0LsNeeMezg6J90w8GO7JXU4CuCl7lVQkqSa1FFmK5yYfn71b);
        dataOutputStream.writeDouble(this.6UX71qqGvxouUDTC13c3qV75PAp2F1siZVYFR6fac7H8UnzKC0hK72Kj9cQd);
        dataOutputStream.writeDouble(this.77e6E1uZUcheYcZIWrKKuPDEW87vZRba1G07w7F89hEUHiP1k8C85J90egYA);
        dataOutputStream.writeDouble(this.97mv6xkm313987U87O9c140ffuZGC8yFk9S365150UwfQ24Y56AbSuS3yDJ8);
        dataOutputStream.writeDouble(this.7T4m0N43WkZqtBml51X0srM2FSNg48cfbn8p9PYj66cgfLN8Tu1Mff8MZmV1);
        dataOutputStream.writeDouble(this.9vUyMIRo06g82IDQ9S1evUxV1s2VwulG1jkPU3QIa3g4tPSueaGBB3O9uW1u);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.1I9597dT70NGCDsnq556ciKJr0Kq53r5D8K71MZImlm2OqbdwhCTjQ8T3ib8(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 44;
    }
}
