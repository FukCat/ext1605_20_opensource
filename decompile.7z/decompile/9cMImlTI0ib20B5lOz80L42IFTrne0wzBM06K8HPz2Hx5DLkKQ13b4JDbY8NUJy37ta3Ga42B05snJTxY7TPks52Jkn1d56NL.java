import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 9cMImlTI0ib20B5lOz80L42IFTrne0wzBM06K8HPz2Hx5DLkKQ13b4JDbY8NUJy37ta3Ga42B05snJTxY7TPks52Jkn1d56NL extends 0384B99m97xWn1Um6PibZX9PY7wVL39kyb6aO070zO5L07gLbfhXgGx9X8p57648s43wCkJTg76U0zr2925StGeelH2
{
    public 9cMImlTI0ib20B5lOz80L42IFTrne0wzBM06K8HPz2Hx5DLkKQ13b4JDbY8NUJy37ta3Ga42B05snJTxY7TPks52Jkn1d56NL(final int n, final int n2, final 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ, final boolean b) {
        super(n, n2, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ, b);
    }
    
    @Override
    public int 6M14lZVXL6xs4lKY6vj11vAQ2E9U9ZDOF0Nh9aCHYAlz8F6Pfx930Z7gxmzf(final Random random) {
        return 1;
    }
}
