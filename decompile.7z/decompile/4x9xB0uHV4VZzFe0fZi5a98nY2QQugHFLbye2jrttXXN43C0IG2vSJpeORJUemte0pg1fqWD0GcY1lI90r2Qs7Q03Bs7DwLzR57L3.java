// 
// Decompiled by Procyon v0.6.0
// 

public class 4x9xB0uHV4VZzFe0fZi5a98nY2QQugHFLbye2jrttXXN43C0IG2vSJpeORJUemte0pg1fqWD0GcY1lI90r2Qs7Q03Bs7DwLzR57L3 extends 2ByGp9QTaf1nuL0wD563U9vMxR8PZpNWAF07F72LVc4CKkS67sUa70Cf7F53rClj73oE94yND25ws57R21diM46tmT9108t1
{
    private boolean[] 638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g;
    private 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S 99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8;
    
    public 4x9xB0uHV4VZzFe0fZi5a98nY2QQugHFLbye2jrttXXN43C0IG2vSJpeORJUemte0pg1fqWD0GcY1lI90r2Qs7Q03Bs7DwLzR57L3(final 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S 99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8) {
        this.638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g = new boolean[10];
        this.99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8 = 99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8;
    }
    
    @Override
    public void 5uxFfrt8sBB4jw93SD0YOs4190gz0S5rn8sT225Jjx6P4S47B46Na53CKrPt(final int n, final boolean b) {
        int n2 = -1;
        if (n == this.99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8.7a0W1RU6Q8EbOS4A4lKs1uS0aGxdk63RpdvD08587ZlFAcxUAvMiu1kKm8pW.7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN) {
            n2 = 0;
        }
        if (n == this.99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8.3c8SpV9K1ddvX9lx4h2hOD9G9m5o1dGknq2J8f296yrV8gFD43Hhtf2353fH.7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN) {
            n2 = 1;
        }
        if (n == this.99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8.4WO3zvF2VJSJrydLjBu8Z2NY6rB4Yi5rkCoVAh3g1rSfaVFqR4WL0aI926u5.7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN) {
            n2 = 2;
        }
        if (n == this.99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8.813LRkk7pVtE7Ko1lsl5pqeor841vBVm8sAWN9bz76DwrQR9odtq5d2RnS7S.7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN) {
            n2 = 3;
        }
        if (n == this.99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8.2om4e4AYodl0O6AznpiYzPI1t109zUzPwqE02SJ4dXm7Q2ksR1N1fo08NmC7.7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN) {
            n2 = 4;
        }
        if (n == this.99BMl26I27iQcH7JE23y428VpRiIHr04x7ZT2s35oThEmFwKTYPUYNE934P8.46vj9daTh0uJGzMJGq9U4y3lwd639qggdWifULDkKxYX586STsGYvVa6Nbc6.7M9vbOHR7eAl017agGF84rYlw8NaF599n69iSj55uMdW5JjI69eY3aYhJTQN) {
            n2 = 5;
        }
        if (n2 >= 0) {
            this.638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g[n2] = b;
        }
    }
    
    @Override
    public void 5jdA0o4ie2tVN3t500jcIci6z008OGMG99DP4FTSM3Pe2H9QuZCataVp26Dr() {
        for (int i = 0; i < 10; ++i) {
            this.638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g[i] = false;
        }
    }
    
    @Override
    public void 2hzedYKpIF1o1Q3IJTlRsGX39n90414HF173TS45MTM7dW1Jn5pBMjsI2DBH(final 4C3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4 4c3O7N57UHjn62Xg8mHbpBT6a61oCsr58ODA6311klk1mjxIM0Z0QE16TO84PffN7NUIXAo7uqYwJ3dp7iAgjanW1Pe5fm4) {
        this.6K9nnqKO19RH7P24be5r16rehPDPHosne77g38EeUD8N57lH3O9l4GoBs0V6 = 0.0f;
        this.6fp2etLiruLgE253ROEUDE94Wi35fqC05XwZlNt270ugNo4ac5DO440f177o = 0.0f;
        this.1EFZz3c8b2Nz6g709v10tVBXXeOYlD0YDC2pTfqP9peScst38j8R7d99yjAH = this.638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g[4];
        this.1yqAuBCkeEeK9oP9NN89kgMSJuk0VVe9CLDX77G6w1tNM21RIF637j5NRZRI = this.638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g[5];
        if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7 != null) {
            for (int i = 0; i != 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7.length; ++i) {
                if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i] != null) {
                    if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getXAxisValue() != -1.0f || 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getYAxisValue() != -1.0f) {
                        this.6K9nnqKO19RH7P24be5r16rehPDPHosne77g38EeUD8N57lH3O9l4GoBs0V6 = -1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getXAxisValue();
                        if (this.6K9nnqKO19RH7P24be5r16rehPDPHosne77g38EeUD8N57lH3O9l4GoBs0V6 > -0.15 && this.6K9nnqKO19RH7P24be5r16rehPDPHosne77g38EeUD8N57lH3O9l4GoBs0V6 < 0.15) {
                            this.6K9nnqKO19RH7P24be5r16rehPDPHosne77g38EeUD8N57lH3O9l4GoBs0V6 = 0.0f;
                        }
                        this.6fp2etLiruLgE253ROEUDE94Wi35fqC05XwZlNt270ugNo4ac5DO440f177o = -1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.22fA9lsNe2RlKHJj8G7o21Uu6cd1c3Jr6nRlTZzT87uL0hx3vW0fsX9s03B7[i].getYAxisValue();
                        if (this.6fp2etLiruLgE253ROEUDE94Wi35fqC05XwZlNt270ugNo4ac5DO440f177o > -0.15 && this.6fp2etLiruLgE253ROEUDE94Wi35fqC05XwZlNt270ugNo4ac5DO440f177o < 0.15) {
                            this.6fp2etLiruLgE253ROEUDE94Wi35fqC05XwZlNt270ugNo4ac5DO440f177o = 0.0f;
                        }
                        if (this.6K9nnqKO19RH7P24be5r16rehPDPHosne77g38EeUD8N57lH3O9l4GoBs0V6 != 0.0f || this.6fp2etLiruLgE253ROEUDE94Wi35fqC05XwZlNt270ugNo4ac5DO440f177o != 0.0f) {
                            return;
                        }
                    }
                }
            }
        }
        if (this.638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g[0]) {
            ++this.6fp2etLiruLgE253ROEUDE94Wi35fqC05XwZlNt270ugNo4ac5DO440f177o;
        }
        if (this.638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g[1]) {
            --this.6fp2etLiruLgE253ROEUDE94Wi35fqC05XwZlNt270ugNo4ac5DO440f177o;
        }
        if (this.638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g[2]) {
            ++this.6K9nnqKO19RH7P24be5r16rehPDPHosne77g38EeUD8N57lH3O9l4GoBs0V6;
        }
        if (this.638zh4C44u0G7ffjWj0D73P1KN7nYx3426vM355hk9wKDua2VstSll4OSB3g[3]) {
            --this.6K9nnqKO19RH7P24be5r16rehPDPHosne77g38EeUD8N57lH3O9l4GoBs0V6;
        }
    }
}
