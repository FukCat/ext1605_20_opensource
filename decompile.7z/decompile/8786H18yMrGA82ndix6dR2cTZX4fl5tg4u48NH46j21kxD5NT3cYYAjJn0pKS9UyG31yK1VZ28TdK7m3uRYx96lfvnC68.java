import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 8786H18yMrGA82ndix6dR2cTZX4fl5tg4u48NH46j21kxD5NT3cYYAjJn0pKS9UyG31yK1VZ28TdK7m3uRYx96lfvnC68 extends 30a14b8670TpOgDYqya84etR7JlL5C8KILqCqsHHTt61TDGF6x8vAs2QVzyg5c3c363u5zk47qehIEn2YedE71xoM5BW9
{
    public boolean 9A2aQQ8LolOG500329dgJ4EuB5i390Ofwish4ew17t3pZ6QXIUNfwmw43C2T;
    public int 0Ggk84B0Zmw3mBpz55xdx106DJh2cNy2331MUGe8lpR71ct95OWTWsQO2VH0;
    public int 8PE4i27ChXLz4kLPv9DEudDATdX5Ss5VF8Q5gzFtIPY6MomA77G4xIntjZd7;
    String 3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1;
    
    public 8786H18yMrGA82ndix6dR2cTZX4fl5tg4u48NH46j21kxD5NT3cYYAjJn0pKS9UyG31yK1VZ28TdK7m3uRYx96lfvnC68() {
        this.9A2aQQ8LolOG500329dgJ4EuB5i390Ofwish4ew17t3pZ6QXIUNfwmw43C2T = false;
        this.0Ggk84B0Zmw3mBpz55xdx106DJh2cNy2331MUGe8lpR71ct95OWTWsQO2VH0 = -1;
        this.8PE4i27ChXLz4kLPv9DEudDATdX5Ss5VF8Q5gzFtIPY6MomA77G4xIntjZd7 = 0;
        this.3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1 = "";
    }
    
    public 8786H18yMrGA82ndix6dR2cTZX4fl5tg4u48NH46j21kxD5NT3cYYAjJn0pKS9UyG31yK1VZ28TdK7m3uRYx96lfvnC68(final String 7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS, final int 0Ggk84B0Zmw3mBpz55xdx106DJh2cNy2331MUGe8lpR71ct95OWTWsQO2VH0, final int 8pe4i27ChXLz4kLPv9DEudDATdX5Ss5VF8Q5gzFtIPY6MomA77G4xIntjZd7, final String 3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1) {
        this.9A2aQQ8LolOG500329dgJ4EuB5i390Ofwish4ew17t3pZ6QXIUNfwmw43C2T = false;
        this.0Ggk84B0Zmw3mBpz55xdx106DJh2cNy2331MUGe8lpR71ct95OWTWsQO2VH0 = -1;
        this.8PE4i27ChXLz4kLPv9DEudDATdX5Ss5VF8Q5gzFtIPY6MomA77G4xIntjZd7 = 0;
        this.3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1 = "";
        this.0Ggk84B0Zmw3mBpz55xdx106DJh2cNy2331MUGe8lpR71ct95OWTWsQO2VH0 = 0Ggk84B0Zmw3mBpz55xdx106DJh2cNy2331MUGe8lpR71ct95OWTWsQO2VH0;
        this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS = 7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS;
        this.8PE4i27ChXLz4kLPv9DEudDATdX5Ss5VF8Q5gzFtIPY6MomA77G4xIntjZd7 = 8pe4i27ChXLz4kLPv9DEudDATdX5Ss5VF8Q5gzFtIPY6MomA77G4xIntjZd7;
        this.3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1 = 3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.0Ggk84B0Zmw3mBpz55xdx106DJh2cNy2331MUGe8lpR71ct95OWTWsQO2VH0 = dataInputStream.readInt();
        this.8PE4i27ChXLz4kLPv9DEudDATdX5Ss5VF8Q5gzFtIPY6MomA77G4xIntjZd7 = dataInputStream.readInt();
        this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS = dataInputStream.readUTF();
        this.3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1 = dataInputStream.readUTF();
        try {
            this.9A2aQQ8LolOG500329dgJ4EuB5i390Ofwish4ew17t3pZ6QXIUNfwmw43C2T = 3TRs4A75rS0TtcUL36iKx34E6k4NB1XXM6i8cs9Khd3OUdqLNT1q99wqrgwtn53Nk1LerxKV5f8Dlt8MOX4uKK6df8l.8s2o5kgQR2KUW7HYNe66V6nvFcbh46mjpeKP79Ox3XiV7okbLUZKWede01qz(this.0Ggk84B0Zmw3mBpz55xdx106DJh2cNy2331MUGe8lpR71ct95OWTWsQO2VH0 + "" + this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS.substring(this.8PE4i27ChXLz4kLPv9DEudDATdX5Ss5VF8Q5gzFtIPY6MomA77G4xIntjZd7), this.3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1);
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.0Ggk84B0Zmw3mBpz55xdx106DJh2cNy2331MUGe8lpR71ct95OWTWsQO2VH0);
        dataOutputStream.writeInt(this.8PE4i27ChXLz4kLPv9DEudDATdX5Ss5VF8Q5gzFtIPY6MomA77G4xIntjZd7);
        dataOutputStream.writeUTF(this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS);
        dataOutputStream.writeUTF(this.3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        if (!this.9A2aQQ8LolOG500329dgJ4EuB5i390Ofwish4ew17t3pZ6QXIUNfwmw43C2T) {
            7l2e0fYR96rf6dpREUY30xWh65d1rOc3abJQrqtvYEW6GNMN9qeJW237wlzS37y9Xt8xV209FRDRzpsI4HOsGN7skzB8a0.4TOtWqH41d7jD9655kwO3Cg5UDFI8gwADO0lrcf8Wo27yqT11iUXxA20819F("[SecureChatEcho] INVALID SIGNATURE.");
        }
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.36fV28118dKFG2m0b7LfVD4kB8xETB1drZw35Ez94lGRqlV6j136WD3dAM71(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return this.7IouMq95vuynlssHsJvP9E4zmRj1mFOn76VI4i94mtDVMIQ6CEa4Ie3yIJNS.length() + this.3Cdnvz5OGPLy2KcFAbTD7P04gDUSEQ2VuP690Z2y42UN05nWJ60w2kFkx9e1.length() + 4 + 4;
    }
}
