import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 81CV90XRcbN36PmGbv1oHHVZ7m62c9QCQw3hV0vbUCl57X1MOglqM8L0vdZ71Ry8C28ad689YolPLwp14X82sXVg46Wj8u7 extends 04jG95z49Q0vzm7aDD4u7rv62B90mjfcT935e2Dzu8o9C0fd1Sk50n3k7fcwZrS9a3730pO5p6Gxj272Me3ugexz6x1jLF888XI4s2A55I
{
    public 81CV90XRcbN36PmGbv1oHHVZ7m62c9QCQw3hV0vbUCl57X1MOglqM8L0vdZ71Ry8C28ad689YolPLwp14X82sXVg46Wj8u7(final int n, final 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ) {
        super(n, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ);
        this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41 = 1;
        this.8KA5yJRt7pv9ZbpZI39s4nb12a25m0cl84QCU39blwneh2sFf2Vm5km8DcV9(true);
        this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 0.25f, 1.0f);
    }
    
    @Override
    protected 2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex 6Qw6RCu9ZEo5HDblBh0CRT406s02009a656IV4nL0AKcEElJwejXE8chN4hm() {
        return new 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23();
    }
    
    @Override
    public boolean 11krARXg1dz3Cs9T1417zcu0h3o23b6X5J17X8JguWkYPA1xFa6hm48g23zA() {
        return false;
    }
    
    @Override
    public boolean 35gUMxe6UGWsnci7k7ZiwHjA0P63Qs829v6WAF3u9tc6vXASiYOI7j512637() {
        return false;
    }
    
    @Override
    public int 9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP() {
        return 14;
    }
    
    @Override
    public boolean 545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(final 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa, final int n, final int n2, final int n3, final int n4) {
        return true;
    }
    
    @Override
    public void 4078HMR7qcMBAz3w7Wq6QiAdGBCLCJ7o6qt9rjDU11jPE3M066o5hv9stTs0(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final Random random) {
        final 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23 = (62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23)5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6hPp92kZVrpu289Er027gE6XGPzFeGBQ5pS5JM73GUT6dyg108A5z3pHTQtS(n, n2, n3);
        if (62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23.7A5js49u3w1saf3A6b4T54BL7kd4S1U491j3uHYFr7bkGut5b3HthPbCC3lP(0).79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp == 0) {
            return;
        }
        if (++62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23.9rPa3Mz1Q8Vn0nAJkI9X4poUzf7TBOIH2kWHRP3v7stG6B1y07q41bC8335m >= 2 && random.nextInt(3) == 0) {
            if (62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23.7A5js49u3w1saf3A6b4T54BL7kd4S1U491j3uHYFr7bkGut5b3HthPbCC3lP(0).79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp == 64) {
                5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.8Se74G1612zTSF1Y735n05AIga3GK82o21C5pJHImSa49cmW3vIQ0qH61Jr8(n, n2, n3, n, n2, n3);
            }
            62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23.2OTj3tDo1St0hFeuR5WrV9C8xemx0218exV9jyidNx1Bc7aUPWZq3zO1I88v(0, 1);
            62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23.9rPa3Mz1Q8Vn0nAJkI9X4poUzf7TBOIH2kWHRP3v7stG6B1y07q41bC8335m = 0;
            if (62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23.7A5js49u3w1saf3A6b4T54BL7kd4S1U491j3uHYFr7bkGut5b3HthPbCC3lP(0).79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp == 0) {
                for (int i = 0; i < 12; ++i) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6z0LyHt8cjp6K2a66C88t2L84s2JTd7v23E75aN3LSm3zx61W8xn9Pz0FaO0("smoke", n + random.nextDouble(), n2 + 0.4, n3 + random.nextDouble(), 0.0, 0.1, 0.0);
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.8Se74G1612zTSF1Y735n05AIga3GK82o21C5pJHImSa49cmW3vIQ0qH61Jr8(n, n2, n3, n, n2, n3);
                }
            }
        }
    }
    
    @Override
    public void 7jNRvNo4zAIf2f3tD2b0t0WvBYWgSGSb06I3pixGfMf56VV0kz2rwtjm8A54(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final Random random) {
        final 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23 = (62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23)5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6hPp92kZVrpu289Er027gE6XGPzFeGBQ5pS5JM73GUT6dyg108A5z3pHTQtS(n, n2, n3);
        if (62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23.7A5js49u3w1saf3A6b4T54BL7kd4S1U491j3uHYFr7bkGut5b3HthPbCC3lP(0).79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp == 0) {
            return;
        }
        if (random.nextInt(2) == 0) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6z0LyHt8cjp6K2a66C88t2L84s2JTd7v23E75aN3LSm3zx61W8xn9Pz0FaO0("snowballpoof", n + random.nextDouble(), n2 + 0.4, n3 + random.nextDouble(), 0.0, 0.0, 0.0);
        }
        if (random.nextInt(3) == 0) {
            for (int i = n2 + 1; i < Math.min(128, 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23.7A5js49u3w1saf3A6b4T54BL7kd4S1U491j3uHYFr7bkGut5b3HthPbCC3lP(0).79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp + n2); ++i) {
                if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, i, n3) != 0) {
                    break;
                }
                if (random.nextInt(6) == 0) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6z0LyHt8cjp6K2a66C88t2L84s2JTd7v23E75aN3LSm3zx61W8xn9Pz0FaO0("splash", n + random.nextDouble(), i + random.nextDouble(), n3 + random.nextDouble(), 0.0, 0.0, 0.0);
                }
            }
        }
    }
}
