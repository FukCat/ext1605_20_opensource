import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 88d2D932YwG6464Z24r4116cc88C85b1dStmP90VcBGkI3RBlaSduqOfF07e36NP4c1StdWc3QBatMNSh961HAeaAP5lo1i9 extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 10; ++i) {
            final int n4 = n + random.nextInt(8) - random.nextInt(8);
            final int n5 = n2 + random.nextInt(4) - random.nextInt(4);
            final int n6 = n3 + random.nextInt(8) - random.nextInt(8);
            if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n4, n5, n6) == 0) {
                for (int n7 = 1 + random.nextInt(random.nextInt(3) + 1), j = 0; j < n7; ++j) {
                    if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.0qsS5wG6NsWWQcO3975pHhf6HI7e6R2637bdNH3e7ZrL1zUWlx79W91p96gH.8RS28Xf0FuA8Ecl1T85B1mB0rQ585WxI8MN6PnD57WSn3kXaXF968F4kI5x1(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n4, n5 + j, n6)) {
                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n4, n5 + j, n6, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.0qsS5wG6NsWWQcO3975pHhf6HI7e6R2637bdNH3e7ZrL1zUWlx79W91p96gH.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    }
                }
            }
        }
        return true;
    }
}
