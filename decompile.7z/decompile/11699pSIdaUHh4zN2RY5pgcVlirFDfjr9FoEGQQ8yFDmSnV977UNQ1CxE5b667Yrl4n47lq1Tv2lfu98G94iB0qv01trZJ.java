// 
// Decompiled by Procyon v0.6.0
// 

public class 11699pSIdaUHh4zN2RY5pgcVlirFDfjr9FoEGQQ8yFDmSnV977UNQ1CxE5b667Yrl4n47lq1Tv2lfu98G94iB0qv01trZJ extends 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03
{
    public 11699pSIdaUHh4zN2RY5pgcVlirFDfjr9FoEGQQ8yFDmSnV977UNQ1CxE5b667Yrl4n47lq1Tv2lfu98G94iB0qv01trZJ(final int n, final int n2, final int n3, final String s, final int n4, final int n5) {
        super(n, n2, n3, n4, n5, s);
    }
}
