import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 8Ud5w5hd1B5G0Y5W14llL0MZM4hVCg41yhId5zZk3466e01h8M9IpIWZom6Bpzns0O3Gup6lkk0KL55zsg4eQQryD5C0U6212c15 extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 0x5Emtv0i0L3BTyVuydE19K6W3o6MwDRqWLmI1yeo10QukiNUlwG4I0p0DVn;
    public int 7dYOvXs3e25Y1p65CpbDsu5O19H2J2lxYY0m48lMzj5g08IY4yAMTNuzPaPH;
    public int 7y92IQ59gKgv044dL8UzgMMQ8DU0JlS6g6Dx0PMYQWF2XBjFE1t1D697ak2E;
    public int 0GzLN91tq1HcS3ihRG9d4SelyXb32nee92jbc1ylsy161rr1fX6vU5Iaazkg;
    public int 5i4iWr7rT8Az1QFzddw78SIn2njw1ZxSCL9L1Q76B8kNpgi98p61g5H3Tu4X;
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.0x5Emtv0i0L3BTyVuydE19K6W3o6MwDRqWLmI1yeo10QukiNUlwG4I0p0DVn = dataInputStream.readInt();
        this.5i4iWr7rT8Az1QFzddw78SIn2njw1ZxSCL9L1Q76B8kNpgi98p61g5H3Tu4X = dataInputStream.readByte();
        this.7dYOvXs3e25Y1p65CpbDsu5O19H2J2lxYY0m48lMzj5g08IY4yAMTNuzPaPH = dataInputStream.readInt();
        this.7y92IQ59gKgv044dL8UzgMMQ8DU0JlS6g6Dx0PMYQWF2XBjFE1t1D697ak2E = dataInputStream.readInt();
        this.0GzLN91tq1HcS3ihRG9d4SelyXb32nee92jbc1ylsy161rr1fX6vU5Iaazkg = dataInputStream.readInt();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.0x5Emtv0i0L3BTyVuydE19K6W3o6MwDRqWLmI1yeo10QukiNUlwG4I0p0DVn);
        dataOutputStream.writeByte(this.5i4iWr7rT8Az1QFzddw78SIn2njw1ZxSCL9L1Q76B8kNpgi98p61g5H3Tu4X);
        dataOutputStream.writeInt(this.7dYOvXs3e25Y1p65CpbDsu5O19H2J2lxYY0m48lMzj5g08IY4yAMTNuzPaPH);
        dataOutputStream.writeInt(this.7y92IQ59gKgv044dL8UzgMMQ8DU0JlS6g6Dx0PMYQWF2XBjFE1t1D697ak2E);
        dataOutputStream.writeInt(this.0GzLN91tq1HcS3ihRG9d4SelyXb32nee92jbc1ylsy161rr1fX6vU5Iaazkg);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.2957IQH1t5i6PHh5Mr65xn5g0v5gD1R2ZumkTs972SvQpz1bb05OT102q063(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 17;
    }
}
