import java.util.Arrays;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.io.FileNotFoundException;
import java.io.ByteArrayInputStream;
import java.util.zip.ZipFile;
import java.io.FileInputStream;
import java.io.File;
import java.net.MalformedURLException;
import net.minecraft.client.Minecraft;
import java.net.URL;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

// 
// Decompiled by Procyon v0.6.0
// 

public class 1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN
{
    public static List<String> 4eUW14lHuQQy8iFT1uuVUHSXayw7HV4qbsNu1cOVGoECe4jmtsJ7i6H944Fv;
    
    public static float 369AWaIx763AmDMElKtaxw1v8736Hd9436zT4kb46Iz21Y2Nw4rxl2u27Hjk(final float n) {
        return (n - 1.0f) * (n - 1.0f) * (n - 1.0f) + 1.0f;
    }
    
    @Deprecated
    public static float[] 5Uv6S9Bfdv65fj4T41RLcY6p04S0ehUzi6x9nToDTmtRuqPWBtt47r7h00WT(final float n, final float n2, final float n3, final float n4) {
        return new float[] { n * 0.58431375f + (1.0f - n) * n2, n * 0.0f + (1.0f - n) * n3, n * 1.0f + (1.0f - n) * n4 };
    }
    
    public static float[] 7iPFTwgC47r32s6Wp2N1r4pI8un6328fxCTA3sjXpSOZtb6unZol1940zs8J(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7) {
        return new float[] { n * n2 + (1.0f - n) * n5, n * n3 + (1.0f - n) * n6, n * n4 + (1.0f - n) * n7 };
    }
    
    public static boolean 47N4P64obVMQxBNms4941hv7HsZCQPlQPFKHR2gMrqfU12z9Jj9JB2Ab1Lgv(final int n) {
        return n == 0 || n == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.0qsS5wG6NsWWQcO3975pHhf6HI7e6R2637bdNH3e7ZrL1zUWlx79W91p96gH.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || n == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.9sm45HzfcZ1U42Q4q7dzs1j31rNGV5R6sTIDYw7i2eZayCv1m8wrfHjZ4CXy.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || n == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6Ex3e44yx6Pb4wQJ67L3N4098TTBR51lnqZ11F0l9W6hmds94I8F87SGLAws.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || n == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3812Uux845dt6r64jFGx1Mkns0f6r5lL2QzhVCBGmXq857zFTekLm9sNl2Ve.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || n == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3Ht8I3oQ07gZ528o9avTl50uD6Px1jkRaim3h11bSf1SLaVcf7w589MK6oDF.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || n == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.45rO5ODEm2B47LcG9c27I7CP9LlT47zCK0iH6q9yO52SNjf9UWQd26j57zun.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || n == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.49xZBeNWe5R177er90mO1v746gG1855YFe7aX9c09ydxcA9lB34O4S3qsXqT.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || n == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.1Qp0JaZY8j08gNvixC9lTVmYuhPF31BB7EM4Stx7l040d2ADn4eGQuWyK2M5.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || n == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3K3e7Cq22baxM08hd427Va7Yha5742TiP2q68VpfGe8nAX0AUAgju9j9751w.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
    }
    
    public static double 5tRIA8T1hG1406q37HIDCLk9sT37m5h166THw7U2GT2Ns15rGizocssSqh1y(final double n, final double n2) {
        final double n3 = Math.abs(n2 - n) % 360.0;
        return (n3 > 180.0) ? (360.0 - n3) : n3;
    }
    
    public static boolean 9631EC5o8TPNP4X7s8DH1Esb16vI9baa0Q1sU43S8av05lQ633DQSZX8tG8J(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7) {
        if (Math.sqrt(Math.pow(n5 - n2, 2.0) + Math.pow(n6 - n3, 2.0) + Math.pow(n7 - n4, 2.0)) > n) {
            return false;
        }
        final double n8 = n5 - n2;
        final double n9 = n6 - n3;
        final double n10 = n7 - n4;
        for (double sqrt = Math.sqrt(n8 * n8 + n9 * n9 + n10 * n10), n11 = 0.1, n12 = 0.0; n12 < sqrt; n12 += n11) {
            if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM((int)(n2 + n12 * n8 / sqrt), (int)(n3 + n12 * n9 / sqrt), (int)(n4 + n12 * n10 / sqrt)) != 0) {
                return true;
            }
        }
        return false;
    }
    
    public static int 5Dx6EwZtaSyGYj8N225L6VZqgpsTj895gc3QQ5D3ojI09t6K013DQ8pYoU44(final InputStream inputStream, final byte[] b, final int n, final int n2) throws IOException {
        int i;
        int read;
        for (i = 0; i < n2; i += read) {
            read = inputStream.read(b, n + i, n2 - i);
            if (read < 0) {
                break;
            }
        }
        return i;
    }
    
    public static void 567fBr40XGPyO7eIcrB3foHOeJ721ZS6z08dx0ek1y2dvBVGxUAf611l6Rga(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O, final 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2, final int n) {
        7G1t7sAbj835aKxG7YC29FWVyFQDj24l6bMlfB6b760rK0cREiO35HUDbb5F(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O, 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2, n, -1);
    }
    
    public static void 7G1t7sAbj835aKxG7YC29FWVyFQDj24l6bMlfB6b760rK0cREiO35HUDbb5F(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O, final 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2, final int n, final int n2) {
        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.9Q2HU4VRIHDwJpHQ14kY594OhW0Np80e85fr65M6CYCpcKVY8M23PsrUA1VM) {
            ((1WAHhFFfab9r5GF0Cu3f2uD6uUNuu258jg7y456albG0JgXcXAHDpUagRnzqu2fCEeL12gYFFDz9zsJ1wa9tsT9EC0O6yBY0)1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.9n0vQC1y11r22OAFwQ1LEGORCMfqSz3H2W5tKiHBjq0tqdbVUB1jq32X1KQ8).18Iwb7FQPoP30BqB3y4miWbaa4Y5hZNjq15Z2Q1HR6uLqY788p7j12hi16xx.7o8z3cVu5Rk1xP64Q9432yTDXkA03eesX10it5ydgII6qfPBGegobR3PVoTd(new 7pzuFGKwv3xOU23R2vBcfDD1sikX8YBum2XxjBSL9i1voX842m79Hiy0CnWKt231Ys8NlP7ZjC6x1q5q3B9e4TA47Ps71MZ2(70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O, 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2, n));
        }
        else {
            final long n3 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc;
            final long n4 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc;
            final long n5 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ;
            final long n6 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ;
            final long n7 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5 > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5 : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5;
            final long n8 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5 > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5 : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5;
            for (long n9 = n3; n9 <= n4; ++n9) {
                for (long n10 = n5; n10 <= n6; ++n10) {
                    for (long n11 = n7; n11 <= n8; ++n11) {
                        if (n2 != -1 && ((n9 + n11 % 2L) % 2L == 0L || n11 % 2L == 0L)) {
                            2b6350WH8ijNc6173bB28SL5NVCH9z4gi29wE1gp4CgG86t8z0tZ20x1kc0I(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n9, n10, n11, n2);
                        }
                        else {
                            2b6350WH8ijNc6173bB28SL5NVCH9z4gi29wE1gp4CgG86t8z0tZ20x1kc0I(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n9, n10, n11, n);
                        }
                    }
                }
            }
        }
    }
    
    public static void 2b6350WH8ijNc6173bB28SL5NVCH9z4gi29wE1gp4CgG86t8z0tZ20x1kc0I(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final long n, final long n2, final long n3, final int n4) {
        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf((int)n, (int)n2, (int)n3, n4);
        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.9Q2HU4VRIHDwJpHQ14kY594OhW0Np80e85fr65M6CYCpcKVY8M23PsrUA1VM && 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7 != null && 1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.9n0vQC1y11r22OAFwQ1LEGORCMfqSz3H2W5tKiHBjq0tqdbVUB1jq32X1KQ8 instanceof 1WAHhFFfab9r5GF0Cu3f2uD6uUNuu258jg7y456albG0JgXcXAHDpUagRnzqu2fCEeL12gYFFDz9zsJ1wa9tsT9EC0O6yBY0) {
            ((1WAHhFFfab9r5GF0Cu3f2uD6uUNuu258jg7y456albG0JgXcXAHDpUagRnzqu2fCEeL12gYFFDz9zsJ1wa9tsT9EC0O6yBY0)1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.9n0vQC1y11r22OAFwQ1LEGORCMfqSz3H2W5tKiHBjq0tqdbVUB1jq32X1KQ8).18Iwb7FQPoP30BqB3y4miWbaa4Y5hZNjq15Z2Q1HR6uLqY788p7j12hi16xx.7o8z3cVu5Rk1xP64Q9432yTDXkA03eesX10it5ydgII6qfPBGegobR3PVoTd(new 7f2E801RRxvAWAq0ISwURjjDm5o6sG81zuxH5550s8j57uU560LCJ102WkiX34D44Z9J2409G2tlTQ4uv7989H5bHC5SI3WTj(n4, (int)n, (int)n2, (int)n3, 10));
        }
    }
    
    public static boolean 7m04ZOzyq3FN702OM48X92154363rnLdXNwA0q08S2412Po5jNWd369ids6p(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O, final 0JBX68Xy93h6AtcsAQYnKhAH3tqqSdi51xzP2gqn2Dz3vUDEASPh81DDpsPv629t8X95kqU9No93Cbex761Cu7c84meg01txNW98 0jbx68Xy93h6AtcsAQYnKhAH3tqqSdi51xzP2gqn2Dz3vUDEASPh81DDpsPv629t8X95kqU9No93Cbex761Cu7c84meg01txNW98, final int n) {
        70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O 0sBz5VI5u9Q2UCtG396G5PEa05od78Dq7H6ACFVOP4QB7Bq2A8gt2VWyY1xF = 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O;
        for (int i = 0; i != n; ++i) {
            0sBz5VI5u9Q2UCtG396G5PEa05od78Dq7H6ACFVOP4QB7Bq2A8gt2VWyY1xF = 0sBz5VI5u9Q2UCtG396G5PEa05od78Dq7H6ACFVOP4QB7Bq2A8gt2VWyY1xF.0SBz5VI5u9Q2UCtG396G5PEa05od78Dq7H6ACFVOP4QB7Bq2A8gt2VWyY1xF(new 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O(1L, 0L, 0L).85MH9jz681rON1PmbpCYP4F8IPW6ZCx23R5qCbPjA6rtde389J4Wuajb22sz(0jbx68Xy93h6AtcsAQYnKhAH3tqqSdi51xzP2gqn2Dz3vUDEASPh81DDpsPv629t8X95kqU9No93Cbex761Cu7c84meg01txNW98));
            if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM((int)0sBz5VI5u9Q2UCtG396G5PEa05od78Dq7H6ACFVOP4QB7Bq2A8gt2VWyY1xF.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc, (int)0sBz5VI5u9Q2UCtG396G5PEa05od78Dq7H6ACFVOP4QB7Bq2A8gt2VWyY1xF.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ, (int)0sBz5VI5u9Q2UCtG396G5PEa05od78Dq7H6ACFVOP4QB7Bq2A8gt2VWyY1xF.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5) != 0) {
                return false;
            }
        }
        return true;
    }
    
    public static void 8tetd5aupSR9XGtG3jO9ukh2Rv6PKkUN12yUmw8l957f2AhFIVsxmQUj3ZD2() {
        new Exception().printStackTrace();
    }
    
    public static int 8Oq1I57w9nMV4xcg8IUTb31D6Wumtz10kJJWyh9ORMW4uP8Zr0oyd0bFHQ1k(final int n, final int n2, final int n3) {
        return n << 11 | n3 << 7 | n2;
    }
    
    public static URL 9P3TY758VM8951Z7q70WD5qYdKqLdB22jUqQNi8u6rFBU4uZnFfpCw0XU82v(final String s) {
        if (Minecraft.40G9X9sEbrNVWk1I68RpGi9486QjvBn75u9xmmmZ189amc26uqiJAf80zUYu) {
            try {
                return new URL("file:///" + Minecraft.8WQ9B51cG08Xzvtv4872kc1791FFx6EUAi7dtOrdc533169lB1oGze3Sm1ZJ + "/" + s);
            }
            catch (final MalformedURLException ex) {
                7l2e0fYR96rf6dpREUY30xWh65d1rOc3abJQrqtvYEW6GNMN9qeJW237wlzS37y9Xt8xV209FRDRzpsI4HOsGN7skzB8a0.4TOtWqH41d7jD9655kwO3Cg5UDFI8gwADO0lrcf8Wo27yqT11iUXxA20819F(ex.getMessage());
                System.exit(-1);
                return null;
            }
        }
        return 1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.class.getResource(s);
    }
    
    public static InputStream 5v4Cs6sI06e6Hjpg3rSI82gG008x14C2jag2OM7ADaW5U8a3DYSrf570CJm6(String substring) {
        if (Minecraft.40G9X9sEbrNVWk1I68RpGi9486QjvBn75u9xmmmZ189amc26uqiJAf80zUYu) {
            try {
                return new FileInputStream(new File(Minecraft.8WQ9B51cG08Xzvtv4872kc1791FFx6EUAi7dtOrdc533169lB1oGze3Sm1ZJ + "/" + substring));
            }
            catch (final FileNotFoundException ex) {
                try {
                    if (substring.startsWith("/")) {
                        substring = substring.substring(1);
                    }
                    final ZipFile zipFile = new ZipFile(new File(System.getProperty("user.dir") + "/../lib/client/minecraft.jar"));
                    final ZipEntry entry = zipFile.getEntry(substring);
                    final InputStream inputStream = zipFile.getInputStream(entry);
                    final byte[] buf = new byte[(int)entry.getSize()];
                    5Dx6EwZtaSyGYj8N225L6VZqgpsTj895gc3QQ5D3ojI09t6K013DQ8pYoU44(inputStream, buf, 0, (int)entry.getSize());
                    zipFile.close();
                    return new ByteArrayInputStream(buf);
                }
                catch (final Exception ex2) {
                    ex2.printStackTrace();
                    System.exit(-1);
                    return null;
                }
            }
        }
        return 1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.class.getResourceAsStream(substring);
    }
    
    public static int 2H957G8ip82G6rxfiUf3zblru0uP648DzY022SjD3PqVRZ2F11lS24e967i5(final int n, final int n2, final int n3) {
        return (n > n3) ? n3 : ((n < n2) ? n2 : n);
    }
    
    public static String 5D2s54927n4DKgyG72xyN0I2571Gf1lofyGtm297rlY5SYBWi0Gc4NBMKoQD(final byte[] array) {
        final StringBuilder sb = new StringBuilder(2 * array.length);
        for (int i = 0; i < array.length; ++i) {
            final String hexString = Integer.toHexString(0xFF & array[i]);
            if (hexString.length() == 1) {
                sb.append('0');
            }
            sb.append(hexString);
        }
        return sb.toString();
    }
    
    public static int 8Hz7yQrbpttYl62r56lFe782dI9GJEm7d3W4768d4S2Iay7QH2DbzVf66DGe(final int n, final int n2) {
        return (int)Math.floor(n / (float)n2);
    }
    
    public static String 454W4NdU03XRu31l9i7WvVfHjt72MsOpNaeZo649Z98rQP9Gm38926v5OA6W(final String s) {
        return (String)1qcx767hJMswx2G8a8rUVA7nXR8mott3As0B864hxZSx5c62gcj9i9TZ52jkJ00eEq8jDscE5KNOwcMhXf0l6Svy9XS9Hub4dtlG.9Uru1FW89ta6z8a2n5ZS0zZels0ZLixz72YO2Rq9k20H9W7ISBGNQrOp5tUL(1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.class, "bytesToHex", new Class[] { byte[].class }, 1qcx767hJMswx2G8a8rUVA7nXR8mott3As0B864hxZSx5c62gcj9i9TZ52jkJ00eEq8jDscE5KNOwcMhXf0l6Svy9XS9Hub4dtlG.9Uru1FW89ta6z8a2n5ZS0zZels0ZLixz72YO2Rq9k20H9W7ISBGNQrOp5tUL(1qcx767hJMswx2G8a8rUVA7nXR8mott3As0B864hxZSx5c62gcj9i9TZ52jkJ00eEq8jDscE5KNOwcMhXf0l6Svy9XS9Hub4dtlG.9Uru1FW89ta6z8a2n5ZS0zZels0ZLixz72YO2Rq9k20H9W7ISBGNQrOp5tUL(1qcx767hJMswx2G8a8rUVA7nXR8mott3As0B864hxZSx5c62gcj9i9TZ52jkJ00eEq8jDscE5KNOwcMhXf0l6Svy9XS9Hub4dtlG.8Ehd0r9aAHEF32cGHok0smD4vA0B3N9Qx96zs8VmDa6dhPs1YF2JWfDn7x46("java.security.MessageDigest"), "getInstance", new Class[] { String.class }, "SHA-256"), "digest", new Class[] { byte[].class }, s.getBytes(StandardCharsets.UTF_8)));
    }
    
    public static void 4B14YTlTqWTNVpM2G9851Dyfx9DbvQPLa5I81ItD974L7kJ315Qu8EP49Cg9(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O, final 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2, final int n, final int n2) {
        if (!5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.9Q2HU4VRIHDwJpHQ14kY594OhW0Np80e85fr65M6CYCpcKVY8M23PsrUA1VM) {
            final long n3 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc;
            final long n4 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2LsDejx2z108YO9SFunkKKgukC6lR70Di2Fz45gD2g7h88I023q041oXK1wc;
            final long n5 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ;
            final long n6 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.2L9p6nI7vtHf1Uc3iZ5m58UL8xeazIPSHn6OL1w5885zYbUbsH6Cfr14CeUQ;
            final long n7 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5 > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5 : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5;
            final long n8 = (70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5 > 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5) ? 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5 : 70pJAUdD1WtJoLsgqhZculD3p2Og8v0NcuiFqn8Jia5te028O6pE86DC0O3r8YMbA2ad5R7012MXZ7rnuhw2P7HBGVk61O2.9aAZu8pb9DazW48uu97j1h1eLN6h523tlM0Ej37M8KN54D1Sb1N5304aLUI5;
            for (long n9 = n3; n9 <= n4; ++n9) {
                for (long n10 = n5; n10 <= n6; ++n10) {
                    for (long n11 = n7; n11 <= n8; ++n11) {
                        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM((int)n9, (int)n10, (int)n11) == n) {
                            2b6350WH8ijNc6173bB28SL5NVCH9z4gi29wE1gp4CgG86t8z0tZ20x1kc0I(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n9, n10, n11, n2);
                        }
                    }
                }
            }
        }
    }
    
    static {
        1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.4eUW14lHuQQy8iFT1uuVUHSXayw7HV4qbsNu1cOVGoECe4jmtsJ7i6H944Fv = Arrays.asList("file://C:/skincache/", "https://raw.githubusercontent.com/exalpha-dev/exalpha-dev.github.io/main/skincache/");
    }
}
