// 
// Decompiled by Procyon v0.6.0
// 

public interface 2eW65D9EHx0617nSxYK6H2U87GXAGmVMMcnQ0Qx3IKJ7aL02x2rVQb0D60o365XaVZuVl17JguYJw71NR2UHXGnR7XPRMb63E5eFxbe
{
    boolean 2t2JXCo7jp147E4Wj9l15QN4PYqzD825NSGGLj6Y7D61ZqV4Mzcj1XtuU1By(final 85H57P2H4D6cj141sW70sW6k1pGNK4K4k78ms060bS9Wz8ktuElnkcl5YQCE3305VB1e75Xq1DQYF44ZEikQn64iKmEU62Tu9R5qy07u p0);
    
    void 2r0opNJ9u1kF2Su63n4dzYovVTF3BSN26NRReq4ar4r8blaq3bp2ricXtzBR(final double p0, final double p1, final double p2);
}
