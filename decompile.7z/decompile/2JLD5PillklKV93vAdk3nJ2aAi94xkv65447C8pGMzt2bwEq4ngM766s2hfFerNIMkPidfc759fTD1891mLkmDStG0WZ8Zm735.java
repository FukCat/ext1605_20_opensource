import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2JLD5PillklKV93vAdk3nJ2aAi94xkv65447C8pGMzt2bwEq4ngM766s2hfFerNIMkPidfc759fTD1891mLkmDStG0WZ8Zm735 extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    private Boolean 8HLLnM7nDrhW8xlmZZ60JHmqQdkLuo2q77mzXqGg1J3f23v74oT9q4Cl87Xq;
    
    public 2JLD5PillklKV93vAdk3nJ2aAi94xkv65447C8pGMzt2bwEq4ngM766s2hfFerNIMkPidfc759fTD1891mLkmDStG0WZ8Zm735() {
        this.8HLLnM7nDrhW8xlmZZ60JHmqQdkLuo2q77mzXqGg1J3f23v74oT9q4Cl87Xq = null;
    }
    
    public 2JLD5PillklKV93vAdk3nJ2aAi94xkv65447C8pGMzt2bwEq4ngM766s2hfFerNIMkPidfc759fTD1891mLkmDStG0WZ8Zm735 9Wjkl8JRef8VX8hq2T5ovlr2viAijM25dzAmu9wzMbBBDSvla8Z7267gPchG(final boolean b) {
        this.8HLLnM7nDrhW8xlmZZ60JHmqQdkLuo2q77mzXqGg1J3f23v74oT9q4Cl87Xq = b;
        return this;
    }
    
    private boolean 1RoivkFZYI13z001UdszthlasOPv46c8Xr5F5o01i7F0nf2YAZX991GBWXM3(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        int n4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.449GA8f0N005Fb6O5d4HBSxHZV01PAz6Qhko184YtIQxNvf7E8e8756HRemv.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        int n5 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3K3e7Cq22baxM08hd427Va7Yha5742TiP2q68VpfGe8nAX0AUAgju9j9751w.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        if (!Minecraft.4vZ36FKx2I9PxzXyWH4290I55Q6yd6FI668q2Ylv62ISy2u1yh710qJ4Q0Yo && random.nextInt(100) <= 5) {
            n4 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.6FQLYy9Ocr2qS3h675NJ4Qd5Fe3cfxhtpoFEk6WqCs37M45a2pHsl531qGH4.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
            n5 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.91CJ53zY6qOVdi28Pc79Fb3NZ5vy26Io6Ztw0t3JFBjCLh6v2i4G314VlnCx.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        }
        int n6 = random.nextInt(4) + 4;
        final int nextInt = random.nextInt(100);
        if (!Minecraft.4vZ36FKx2I9PxzXyWH4290I55Q6yd6FI668q2Ylv62ISy2u1yh710qJ4Q0Yo && nextInt >= 6 && nextInt <= 14) {
            n4 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.1kiatuTVB89Tx6O98m5QNH70xDP86OqBYgZ91asXJ6R943t61hEN8j8d3160.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
            n5 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.9ZI7b38AL4Ym25S0pKe9sbD77utsa81Uh3H8ESwgva1U3Z112n1NDf196C4G.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
            n6 = random.nextInt(1) + 1;
        }
        int n7 = 1;
        if (n2 < 1 || n2 + n6 + 1 > 128) {
            return false;
        }
        for (int i = n2; i <= n2 + 1 + n6; ++i) {
            int n8 = 1;
            if (i == n2) {
                n8 = 0;
            }
            if (i >= n2 + 1 + n6 - 2) {
                n8 = 2;
            }
            for (int n9 = n - n8; n9 <= n + n8 && n7 != 0; ++n9) {
                for (int n10 = n3 - n8; n10 <= n3 + n8 && n7 != 0; ++n10) {
                    if (i >= 0 && i < 128) {
                        final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n9, i, n10);
                        if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != 0 && 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != n5) {
                            n7 = 0;
                        }
                    }
                    else {
                        n7 = 0;
                    }
                }
            }
        }
        if (n7 == 0) {
            return false;
        }
        final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM2 = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 - 1, n3);
        if ((1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM2 == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.63nirDT0ysU52yrV7NrOFP3w5y6GfnHtl75Rxpz4tsleaNpwg02R6ida6v9c.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM2 == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.35wK7RXXc4Uu2oc9JBTTNWs6ng4la5dQ6N3KM9ii276gF3OhPeoRtqJ1k8qk.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) && n2 < 128 - n6 - 1) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, n2 - 1, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.35wK7RXXc4Uu2oc9JBTTNWs6ng4la5dQ6N3KM9ii276gF3OhPeoRtqJ1k8qk.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
            for (int j = n2 - 3 + n6; j <= n2 + n6; ++j) {
                final int n11 = j - (n2 + n6);
                for (int n12 = 1 - n11 / 2, k = n - n12; k <= n + n12; ++k) {
                    final int a = k - n;
                    for (int l = n3 - n12; l <= n3 + n12; ++l) {
                        final int a2 = l - n3;
                        if ((Math.abs(a) != n12 || Math.abs(a2) != n12 || (random.nextInt(2) != 0 && n11 != 0)) && !1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.25cFll7Xn2l3P9qpDfjmhENMHI2oz6lJ7OtyqhgIOq9u29Xr920bbMcIH1f0[5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(k, j, l)]) {
                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(k, j, l, n5);
                        }
                    }
                }
            }
            for (int n13 = 0; n13 < n6; ++n13) {
                final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM3 = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 + n13, n3);
                if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM3 == 0 || 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM3 == n5) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, n2 + n13, n3, n4);
                }
            }
            return true;
        }
        return false;
    }
    
    private void 08pSQzCJoBV6xmPjEE0qTBU1Ha8ZA9yT7RWCQ3aHyn94kX82GI1E26N6NUkR(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, int n, int round, int n2) {
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.73oWiFV9jc7E7Iv0djCWc7LSxsG7obhlJk814D0R1gXrf2A25o96ql6o9Z73.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.14Ks8Z3BJ852fcCm6iIDNKaHsvjx718uf048Oijp3690dG0HVc8yZ9T8Uf3l.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        float n3 = 0.0f;
        float n4 = random.nextFloat() * 3.1415927f * 2.0f;
        final int n5 = random.nextInt(8) + 7;
        float a = (float)round;
        for (int i = 0; i < n5; ++i) {
            n4 += (float)((random.nextFloat() - 0.5) * 0.1);
            ++n3;
            final float n6 = n3 / n5;
            n += (int)(5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.1724kYgc5e55Yw1mK1EZTYO084n57BWWaYUE7iquVDiu4hFo5J70Cori9WLs(n4) * (1.0f - n6));
            a += n6;
            n2 += (int)(5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(n4) * (1.0f - n6));
            round = Math.round(a);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, round, n2, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
        }
        round += random.nextInt(2) + 1;
        for (int n7 = random.nextInt(2) + 2, j = 0; j < n7; ++j) {
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n, round, n2, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2);
            for (float n8 = 0.0f; n8 < 6.283185307179586; n8 += (float)0.6283185307179586) {
                final int n9 = random.nextInt(j + 2) + j + 2;
                float n10 = (float)n;
                float n11 = (float)n2;
                for (int k = 0; k < n9; ++k) {
                    n11 += 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(n8);
                    n10 += 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.1724kYgc5e55Yw1mK1EZTYO084n57BWWaYUE7iquVDiu4hFo5J70Cori9WLs(n8);
                    if (!5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(Math.round(n10), round - j, Math.round(n11)).7xm2Jx0S8rI7617Ovpb5DFTezpfWmqzIiE2WYq1jc8o1SRpvc713WJ5tkWdP()) {
                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(Math.round(n10), round - j, Math.round(n11), 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2);
                    }
                }
            }
        }
    }
    
    private void 48sLvej9ydIxvA5c6p4sz8cbO9zjqI9iAAurAbauVHbi510X6fIDqU2J2huN(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.3We17EJvdsmHvL4uwZMIs6gOd30GS262z1LH4mOFeS5pG9XD6js5Zu56PANz.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        for (int nextInt = random.nextInt(3), i = 0; i < nextInt; ++i) {
            final int n4 = random.nextInt(4) + 2;
            int n5 = n;
            int n6 = n2;
            int n7 = n3;
            for (int j = 0; j < n4; ++j) {
                n5 += random.nextInt(3) - 1;
                --n6;
                n7 += random.nextInt(3) - 1;
                if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n5, n6, n7) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.9DwuHv1rF8tHn9hxQ74YH2a9UDMG087j4Z8NJ6X7ly1OaZNeZrC5MTA51CA7.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5, n6, n7, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                }
            }
        }
    }
    
    private boolean 89XbkY9FR8rVDm1g5B22t8xZQtKzL7q00FjDqI0502611aYyqa05bp39Vep8(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.73oWiFV9jc7E7Iv0djCWc7LSxsG7obhlJk814D0R1gXrf2A25o96ql6o9Z73.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        final int 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2 = 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.14Ks8Z3BJ852fcCm6iIDNKaHsvjx718uf048Oijp3690dG0HVc8yZ9T8Uf3l.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 - 1, n3) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.63nirDT0ysU52yrV7NrOFP3w5y6GfnHtl75Rxpz4tsleaNpwg02R6ida6v9c.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 - 1, n3) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.35wK7RXXc4Uu2oc9JBTTNWs6ng4la5dQ6N3KM9ii276gF3OhPeoRtqJ1k8qk.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
            return true;
        }
        final Random random2 = new Random(random.nextLong() + n + n2 + n3 + 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1FawBBFYvHD6RwlXAU5K97Vdl06vvbW1l7jIv9UTLqhT80S0VL74wGs85AKR);
        final ArrayList c = new ArrayList();
        c.add(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(n, n2 + (7 + random2.nextInt(10)), n3));
        int n4 = 0;
        while (c.size() > 0) {
            for (final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 : new ArrayList(c)) {
                final int n5 = (int)Math.round(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.2eY43A926V72BOu2G531aa2ZhODT8w5mCxf6jNpHYkd0HHxvk9yRC9Ix62k9);
                final int n6 = (int)Math.round(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.5wRQ3f09mhVbrkWp9ni13w5Ss0dIm9OImDlyjLJaXBrUy1xUXCzWTfQJow9c);
                final int n7 = (int)Math.round(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF);
                if ((5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n5, n6, n7).7xm2Jx0S8rI7617Ovpb5DFTezpfWmqzIiE2WYq1jc8o1SRpvc713WJ5tkWdP() && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n5, n6, n7) == 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv2) || n6 < 0 || (random2.nextInt(3) == 0 && c.size() > 3)) {
                    c.remove(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457);
                    if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n5, n6, n7) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.35wK7RXXc4Uu2oc9JBTTNWs6ng4la5dQ6N3KM9ii276gF3OhPeoRtqJ1k8qk.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n5, n6, n7) != 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.63nirDT0ysU52yrV7NrOFP3w5y6GfnHtl75Rxpz4tsleaNpwg02R6ida6v9c.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                        continue;
                    }
                    this.48sLvej9ydIxvA5c6p4sz8cbO9zjqI9iAAurAbauVHbi510X6fIDqU2J2huN(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random2, n5, n6, n7);
                }
                else {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n5, n6, n7, 6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0);
                    int n8 = 0;
                    while (random2.nextInt(c.size() / 30 + 2) <= 1) {
                        if (c.size() > 10000) {
                            break;
                        }
                        if (++n8 >= 4) {
                            break;
                        }
                        c.add(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.8wLY5gyzx357NR05a1m1Q7cyQ5cP7To9781nF4W25WMgL6r0iK9XkS2j5OD2(random2.nextInt(3) - 1, -1.0, random2.nextInt(3) - 1));
                    }
                    if (n4 > 2 && random2.nextInt(Math.max(40, 78 - n4)) == 3) {
                        this.08pSQzCJoBV6xmPjEE0qTBU1Ha8ZA9yT7RWCQ3aHyn94kX82GI1E26N6NUkR(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random, n5, n6, n7);
                    }
                    c.remove(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457);
                    c.add(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.8wLY5gyzx357NR05a1m1Q7cyQ5cP7To9781nF4W25WMgL6r0iK9XkS2j5OD2(0.0, -1.0, 0.0));
                }
            }
            ++n4;
        }
        return true;
    }
    
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        final Random random2 = new Random(random.nextLong() + n + n2 + n3 + 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1FawBBFYvHD6RwlXAU5K97Vdl06vvbW1l7jIv9UTLqhT80S0VL74wGs85AKR);
        if (!Minecraft.4vZ36FKx2I9PxzXyWH4290I55Q6yd6FI668q2Ylv62ISy2u1yh710qJ4Q0Yo && this.8HLLnM7nDrhW8xlmZZ60JHmqQdkLuo2q77mzXqGg1J3f23v74oT9q4Cl87Xq != null && (random2.nextInt(150) == 0 || this.8HLLnM7nDrhW8xlmZZ60JHmqQdkLuo2q77mzXqGg1J3f23v74oT9q4Cl87Xq)) {
            return this.89XbkY9FR8rVDm1g5B22t8xZQtKzL7q00FjDqI0502611aYyqa05bp39Vep8(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random, n, n2, n3);
        }
        return this.1RoivkFZYI13z001UdszthlasOPv46c8Xr5F5o01i7F0nf2YAZX991GBWXM3(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, random, n, n2, n3);
    }
}
