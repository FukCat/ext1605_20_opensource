import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2767Sd9RReR2toa40FYNPj4zn4moCivWz14d612QMcrQmhl32u9F69oy43vIZlr30TT4ZaMMXzZH8TMNw2dXJofnA1ADPd1v3k8M extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    private int 88DTAfg4A3uSNGoswP24W02R8skmy4qXj3trsPJT05CDo8yO4b7A3m5h702a;
    
    public 2767Sd9RReR2toa40FYNPj4zn4moCivWz14d612QMcrQmhl32u9F69oy43vIZlr30TT4ZaMMXzZH8TMNw2dXJofnA1ADPd1v3k8M(final int 88DTAfg4A3uSNGoswP24W02R8skmy4qXj3trsPJT05CDo8yO4b7A3m5h702a) {
        this.88DTAfg4A3uSNGoswP24W02R8skmy4qXj3trsPJT05CDo8yO4b7A3m5h702a = 88DTAfg4A3uSNGoswP24W02R8skmy4qXj3trsPJT05CDo8yO4b7A3m5h702a;
    }
    
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 64; ++i) {
            final int n4 = n3 + random.nextInt(8) - random.nextInt(8);
            final int n5 = n2 + random.nextInt(4) - random.nextInt(4);
            final int n6 = n + random.nextInt(8) - random.nextInt(8);
            final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n6, n5 - 1, n4);
            final boolean b = 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 9 || 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 79;
            if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n6, n5, n4) == 0) {
                if (b) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n6, n5, n4, this.88DTAfg4A3uSNGoswP24W02R8skmy4qXj3trsPJT05CDo8yO4b7A3m5h702a);
                }
            }
        }
        return true;
    }
}
