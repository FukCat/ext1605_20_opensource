import java.awt.image.BufferedImage;

// 
// Decompiled by Procyon v0.6.0
// 

public class 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8
{
    public BufferedImage 7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt;
    public boolean 7nZd26GuIqnsEa9SeKzT3d6gmAbGL10esszITeH6X3bC1LGh45KoJ3YGB3Gy;
    public int 4A88fE1g769E02Wq6X1szwm91x4a4YqtgZUMP4xe7980Fslb1yvQLRrM19Nc;
    public int 2Vb2BPcw9iYma1r4CTtS842M3ZVp80uvLAa97tWZc5r71YE09P0H340cc949;
    public boolean 8CmuW2WYm4zZd6GWotT1OdV34ZStAgIoG00cyqcuHMuyMM21HEh3GaZp4mpd;
    
    public 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8() {
        this.7nZd26GuIqnsEa9SeKzT3d6gmAbGL10esszITeH6X3bC1LGh45KoJ3YGB3Gy = false;
        this.4A88fE1g769E02Wq6X1szwm91x4a4YqtgZUMP4xe7980Fslb1yvQLRrM19Nc = 1;
        this.2Vb2BPcw9iYma1r4CTtS842M3ZVp80uvLAa97tWZc5r71YE09P0H340cc949 = -1;
        this.8CmuW2WYm4zZd6GWotT1OdV34ZStAgIoG00cyqcuHMuyMM21HEh3GaZp4mpd = false;
    }
    
    public void 5ecQ0QRfuWiJg3dl3ngZPlnby904839D118bEm61FJpDYFoe4QAl1g0XmO2t() {
        if (this.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt.getHeight() != this.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt.getWidth() / 2) {
            this.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt = this.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt.getSubimage(0, 0, this.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt.getWidth(), this.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt.getWidth() / 2);
        }
        this.7nZd26GuIqnsEa9SeKzT3d6gmAbGL10esszITeH6X3bC1LGh45KoJ3YGB3Gy = ((this.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt.getRGB((int)(54.0f * (this.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt.getWidth() / 64.0f)), (int)(20.0f * (this.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt.getHeight() / 32.0f))) & 0xFF000000) == 0x0);
    }
}
