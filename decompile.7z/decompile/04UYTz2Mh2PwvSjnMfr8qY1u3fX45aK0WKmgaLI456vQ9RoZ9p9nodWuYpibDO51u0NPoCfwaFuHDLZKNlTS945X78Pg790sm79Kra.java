import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 04UYTz2Mh2PwvSjnMfr8qY1u3fX45aK0WKmgaLI456vQ9RoZ9p9nodWuYpibDO51u0NPoCfwaFuHDLZKNlTS945X78Pg790sm79Kra extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    private int 28dPPatX03kfPtH0WUEX1D2u0y9L768NaaK5G52rYF4ERyX41677efzir9so;
    
    public 04UYTz2Mh2PwvSjnMfr8qY1u3fX45aK0WKmgaLI456vQ9RoZ9p9nodWuYpibDO51u0NPoCfwaFuHDLZKNlTS945X78Pg790sm79Kra(final int 28dPPatX03kfPtH0WUEX1D2u0y9L768NaaK5G52rYF4ERyX41677efzir9so) {
        this.28dPPatX03kfPtH0WUEX1D2u0y9L768NaaK5G52rYF4ERyX41677efzir9so = 28dPPatX03kfPtH0WUEX1D2u0y9L768NaaK5G52rYF4ERyX41677efzir9so;
    }
    
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 4; ++i) {
            final int n4 = n + random.nextInt(8) - random.nextInt(8);
            final int n5 = n2 + random.nextInt(4) - random.nextInt(4);
            final int n6 = n3 + random.nextInt(8) - random.nextInt(8);
            int n7 = 0;
            if (n5 > 90) {
                n7 = 1;
            }
            else if (n5 > 80) {
                n7 = ((random.nextInt(100) > 80) ? 1 : 0);
            }
            if (n7 != 0) {
                if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n4, n5, n6) == 0) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n4, n5, n6, this.28dPPatX03kfPtH0WUEX1D2u0y9L768NaaK5G52rYF4ERyX41677efzir9so);
                }
            }
        }
        return true;
    }
}
