import net.minecraft.client.MinecraftApplet;
import java.awt.Canvas;
import java.awt.Component;
import java.awt.Frame;
import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public final class 0S3owDFxo1IcvKENk6RM1wCL1sk5N4S43d7zLJcMQX1MWD4kBrJ63e9C552YRwL864u4T1d7N1bb156uN5V3hnJ2Lca4Ltx5P extends Minecraft
{
    final Frame 3lc984wioDJFr5uVDQdCO3gsODL2vh7D3P2DwXv69JuNyyRWg4Y6HFUk9I2M;
    
    public 0S3owDFxo1IcvKENk6RM1wCL1sk5N4S43d7zLJcMQX1MWD4kBrJ63e9C552YRwL864u4T1d7N1bb156uN5V3hnJ2Lca4Ltx5P(final Component component, final Canvas canvas, final MinecraftApplet minecraftApplet, final int n, final int n2, final boolean b, final Frame 3lc984wioDJFr5uVDQdCO3gsODL2vh7D3P2DwXv69JuNyyRWg4Y6HFUk9I2M) {
        super(component, canvas, minecraftApplet, n, n2, b);
        this.3lc984wioDJFr5uVDQdCO3gsODL2vh7D3P2DwXv69JuNyyRWg4Y6HFUk9I2M = 3lc984wioDJFr5uVDQdCO3gsODL2vh7D3P2DwXv69JuNyyRWg4Y6HFUk9I2M;
        0S3owDFxo1IcvKENk6RM1wCL1sk5N4S43d7zLJcMQX1MWD4kBrJ63e9C552YRwL864u4T1d7N1bb156uN5V3hnJ2Lca4Ltx5P.5Dn33cKLDp4ugCwpD8dAC0Qb0gK4WT4AEqJf0YUJc3Hq6EO32BfTsK678CKb = this;
    }
    
    @Override
    public void 4MXL229F865NFbyV2H086q2G622AN6Ujb6j3w8468w9V9LRXP33fsBq93417(final 8O94wV86zi53NUGjB4bjuz07OdZ5AQMFj36j262U4havnb1rT68h61Uu6kluKGu3Zt2A50x51X06Z0VPHPWJM7ZjgEn0n32nr 8o94wV86zi53NUGjB4bjuz07OdZ5AQMFj36j262U4havnb1rT68h61Uu6kluKGu3Zt2A50x51X06Z0VPHPWJM7ZjgEn0n32nr) {
        this.3lc984wioDJFr5uVDQdCO3gsODL2vh7D3P2DwXv69JuNyyRWg4Y6HFUk9I2M.removeAll();
        this.3lc984wioDJFr5uVDQdCO3gsODL2vh7D3P2DwXv69JuNyyRWg4Y6HFUk9I2M.add(new 9hij01kqN0o2FAl605673v1pp8S0nAJrGx5uTq0s4oT5AuH04JalTntqp8W2BLgvFYrfjrp7SDxn9tKBX3Ma4B9LW5Ah0T(8o94wV86zi53NUGjB4bjuz07OdZ5AQMFj36j262U4havnb1rT68h61Uu6kluKGu3Zt2A50x51X06Z0VPHPWJM7ZjgEn0n32nr), "Center");
        this.3lc984wioDJFr5uVDQdCO3gsODL2vh7D3P2DwXv69JuNyyRWg4Y6HFUk9I2M.validate();
    }
}
