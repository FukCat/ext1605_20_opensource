import java.util.logging.Level;
import java.net.SocketTimeoutException;
import java.net.DatagramPacket;
import java.io.IOException;
import java.net.MulticastSocket;
import java.util.Iterator;
import java.net.InetAddress;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import org.lwjgl.Sys;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.concurrent.atomic.AtomicInteger;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2959V74TYTY4lhDc33xON2ko5AE6Tts6R1SzS9tHT9UB6gO6FU0no63BC75Ixl5ArZBDYMm8tOv711Rt3gGlVCOuM3w
{
    private static final AtomicInteger 04iLgcPVYlkFQ1z8CCjl9K5RRFo87I3BXb917yZS3sxWv9985d95vl30PsxL;
    private static final Logger 6oES59ytM702rH8nNMp4QSVqQ36N1xi0c5ebhgyslEt68hq8ARUU5Feh89Jf;
    private static final String 6iHgeEaDL4TY1eiZ29uo5RRuCiezPjRlVZXk90SC3oEunk038vwToyr5fU93 = "CL_00001133";
    
    static {
        04iLgcPVYlkFQ1z8CCjl9K5RRFo87I3BXb917yZS3sxWv9985d95vl30PsxL = new AtomicInteger(0);
        6oES59ytM702rH8nNMp4QSVqQ36N1xi0c5ebhgyslEt68hq8ARUU5Feh89Jf = LogManager.getLogManager().getLogger(7yDngUXBYilDo3B5U1OQjbOC7YXT20yRn3Tcd85a5HhG5v856xXdCWUtjJXOc078JNt0up84KG4cgp466vtym7iZ695S7Udf.833cA0YF34t606AzhAl21SSFKu5o86ZfZT6w0TL8Lej56qphXp7Tl0V5475T(7yDngUXBYilDo3B5U1OQjbOC7YXT20yRn3Tcd85a5HhG5v856xXdCWUtjJXOc078JNt0up84KG4cgp466vtym7iZ695S7Udf.4Mn44antCz29B6GKYv6d2ZW6jUZp3xLB1XTEKn5O2h7Xzs27I617Goaxn8XY));
    }
    
    public static class LanServer
    {
        private final String 3v7ndO5yb9ansYexDL4fxwy5mWZktFy119Sl4NEu5QDVTkbRNgRxc841m839;
        private final String 67mXPYFik3OTr8SeShGuGzfg76v3NAXeKwLh50xLxNQ28ek7909h1w9u94f4;
        private long 75TGcvKSLT516Q9C20KFCRJ406eSchkZn8yC5f8Bmq1vGJRK9VqQ18471WUE;
        private static final String 09541M42bK51376rwb7S30878b836Z4xCL135sCXLEPUdAArS7Xd13i9Z1dA = "CL_00001134";
        
        public LanServer(final String 3v7ndO5yb9ansYexDL4fxwy5mWZktFy119Sl4NEu5QDVTkbRNgRxc841m839, final String 67mXPYFik3OTr8SeShGuGzfg76v3NAXeKwLh50xLxNQ28ek7909h1w9u94f4) {
            this.3v7ndO5yb9ansYexDL4fxwy5mWZktFy119Sl4NEu5QDVTkbRNgRxc841m839 = 3v7ndO5yb9ansYexDL4fxwy5mWZktFy119Sl4NEu5QDVTkbRNgRxc841m839;
            this.67mXPYFik3OTr8SeShGuGzfg76v3NAXeKwLh50xLxNQ28ek7909h1w9u94f4 = 67mXPYFik3OTr8SeShGuGzfg76v3NAXeKwLh50xLxNQ28ek7909h1w9u94f4;
            this.75TGcvKSLT516Q9C20KFCRJ406eSchkZn8yC5f8Bmq1vGJRK9VqQ18471WUE = Sys.getTime() * 1000L / Sys.getTimerResolution();
        }
        
        public String 14j4o7tstXfcx8M08j0S432QGMi71fs96gKoEmhHMLVQz247V7670r00eOR9() {
            return this.3v7ndO5yb9ansYexDL4fxwy5mWZktFy119Sl4NEu5QDVTkbRNgRxc841m839;
        }
        
        public String 8gM7pIBK1I76SCft4Dhm813bD256bmhlhOrb5h1mMYJ3i7FFAMb9LSfc7uw2() {
            return this.67mXPYFik3OTr8SeShGuGzfg76v3NAXeKwLh50xLxNQ28ek7909h1w9u94f4;
        }
        
        public void 04W88zu2434rH5KSiplYwuX5J2HRsV2SgDIT38qBV8XVz0wUb2NY5BCpH2aW() {
            this.75TGcvKSLT516Q9C20KFCRJ406eSchkZn8yC5f8Bmq1vGJRK9VqQ18471WUE = Sys.getTime() * 1000L / Sys.getTimerResolution();
        }
    }
    
    public static class LanServerList
    {
        private final ArrayList<LanServer> 8qiGAomP1Ac59NByARiO6pVjqT4C6N37mr32u6eG2epkwyCHGmsH5PxpA9JO;
        boolean 8R0mBB7qtp39935XMEFi447KYF8skIV0XL1aWdss5yPZm1ex2uh66NCDjg85;
        private static final String 5Lw1SQWLG80U10f06kq95YIR7fW76FAzTEIJ9296C9Nq0Hn6726cSy59Nr40 = "CL_00001136";
        
        public LanServerList() {
            this.8qiGAomP1Ac59NByARiO6pVjqT4C6N37mr32u6eG2epkwyCHGmsH5PxpA9JO = new ArrayList<LanServer>();
        }
        
        public synchronized boolean 53A5WI0FU98UL8SXf5cJVaH1xv8pv3UGLAjw753vVH5y6xI0PW0Z8240M6rY() {
            return this.8R0mBB7qtp39935XMEFi447KYF8skIV0XL1aWdss5yPZm1ex2uh66NCDjg85;
        }
        
        public synchronized void 0y8txWznESNB1q0JYvpTmTj4BNS015M11I5smw3PILvvh9x8IV38iS08E1q0() {
            this.8R0mBB7qtp39935XMEFi447KYF8skIV0XL1aWdss5yPZm1ex2uh66NCDjg85 = false;
        }
        
        public synchronized List<LanServer> 52XI3RXerJv8CbWlcvMpwK9y35fi0m50zFf24uZqVddP89zIWh0vc8cgSBBR() {
            return Collections.unmodifiableList((List<? extends LanServer>)this.8qiGAomP1Ac59NByARiO6pVjqT4C6N37mr32u6eG2epkwyCHGmsH5PxpA9JO);
        }
        
        public synchronized void 6JWlo5oTbj6698u3MxWj43m8jjLW826DJsk9l6DW0z4oK6cxa991XuVMtgSV(final String s, final InetAddress inetAddress) {
            final String 59V9sUb61z999BarE7i2lAf6nVJLWX1M71ysnHms7svRPio2p2T1awrUEUv1 = 2YB9960LOPNMLAGHAAkdb5HH3At78KO17BgVoYj90Y0pPt2375Y5qqBd8107zKN0uj5gwgewBQzPmCW13Ma8Ny7B7R5oT2CVmYiV6.59V9sUb61z999BarE7i2lAf6nVJLWX1M71ysnHms7svRPio2p2T1awrUEUv1(s);
            final String 2PoL1qkbQNTCzTZoW6zerx1fOqeZ7P9Oio4GWx6FL41Yd63766W47TzbEj51 = 2YB9960LOPNMLAGHAAkdb5HH3At78KO17BgVoYj90Y0pPt2375Y5qqBd8107zKN0uj5gwgewBQzPmCW13Ma8Ny7B7R5oT2CVmYiV6.2PoL1qkbQNTCzTZoW6zerx1fOqeZ7P9Oio4GWx6FL41Yd63766W47TzbEj51(s);
            if (2PoL1qkbQNTCzTZoW6zerx1fOqeZ7P9Oio4GWx6FL41Yd63766W47TzbEj51 != null) {
                final String string = inetAddress.getHostAddress() + ":" + 2PoL1qkbQNTCzTZoW6zerx1fOqeZ7P9Oio4GWx6FL41Yd63766W47TzbEj51;
                boolean b = false;
                for (final LanServer lanServer : this.8qiGAomP1Ac59NByARiO6pVjqT4C6N37mr32u6eG2epkwyCHGmsH5PxpA9JO) {
                    if (lanServer.8gM7pIBK1I76SCft4Dhm813bD256bmhlhOrb5h1mMYJ3i7FFAMb9LSfc7uw2().equals(string)) {
                        lanServer.04W88zu2434rH5KSiplYwuX5J2HRsV2SgDIT38qBV8XVz0wUb2NY5BCpH2aW();
                        b = true;
                        break;
                    }
                }
                if (!b) {
                    this.8qiGAomP1Ac59NByARiO6pVjqT4C6N37mr32u6eG2epkwyCHGmsH5PxpA9JO.add(new LanServer(59V9sUb61z999BarE7i2lAf6nVJLWX1M71ysnHms7svRPio2p2T1awrUEUv1, string));
                    this.8R0mBB7qtp39935XMEFi447KYF8skIV0XL1aWdss5yPZm1ex2uh66NCDjg85 = true;
                }
            }
        }
    }
    
    public static class ThreadLanServerFind extends Thread
    {
        private final LanServerList 5K3sbQn5X6ulj0GQ3fhSzWEJld90E9S4eChV16qYUBMZ26x064s1ny2w4eON;
        private final InetAddress 5u8aht315N4kaG3o8hr41398KCm7udkU1m2nMTx4Qod98ZFnoF9V7Xr880gb;
        private final MulticastSocket 9TIT1Oh03A2XA7jeuG3SzugWFnrI2oc818408ineX5q2lnc58swhho8Ca7m8;
        private static final String 9Mny94npF0LbWrJ2fye1flUmV44PK9522l2S4ypZod7UyPxBvo30U6LTUkRW = "CL_00001135";
        
        public ThreadLanServerFind(final LanServerList 5k3sbQn5X6ulj0GQ3fhSzWEJld90E9S4eChV16qYUBMZ26x064s1ny2w4eON) throws IOException {
            super("LanServerDetector #" + 2959V74TYTY4lhDc33xON2ko5AE6Tts6R1SzS9tHT9UB6gO6FU0no63BC75Ixl5ArZBDYMm8tOv711Rt3gGlVCOuM3w.04iLgcPVYlkFQ1z8CCjl9K5RRFo87I3BXb917yZS3sxWv9985d95vl30PsxL.incrementAndGet());
            this.5K3sbQn5X6ulj0GQ3fhSzWEJld90E9S4eChV16qYUBMZ26x064s1ny2w4eON = 5k3sbQn5X6ulj0GQ3fhSzWEJld90E9S4eChV16qYUBMZ26x064s1ny2w4eON;
            this.setDaemon(true);
            this.9TIT1Oh03A2XA7jeuG3SzugWFnrI2oc818408ineX5q2lnc58swhho8Ca7m8 = new MulticastSocket(4445);
            this.5u8aht315N4kaG3o8hr41398KCm7udkU1m2nMTx4Qod98ZFnoF9V7Xr880gb = InetAddress.getByName("224.0.2.60");
            this.9TIT1Oh03A2XA7jeuG3SzugWFnrI2oc818408ineX5q2lnc58swhho8Ca7m8.setSoTimeout(5000);
            this.9TIT1Oh03A2XA7jeuG3SzugWFnrI2oc818408ineX5q2lnc58swhho8Ca7m8.joinGroup(this.5u8aht315N4kaG3o8hr41398KCm7udkU1m2nMTx4Qod98ZFnoF9V7Xr880gb);
        }
        
        @Override
        public void run() {
            final byte[] buf = new byte[1024];
            while (!this.isInterrupted()) {
                final DatagramPacket p = new DatagramPacket(buf, buf.length);
                try {
                    this.9TIT1Oh03A2XA7jeuG3SzugWFnrI2oc818408ineX5q2lnc58swhho8Ca7m8.receive(p);
                }
                catch (final SocketTimeoutException ex) {
                    continue;
                }
                catch (final IOException thrown) {
                    2959V74TYTY4lhDc33xON2ko5AE6Tts6R1SzS9tHT9UB6gO6FU0no63BC75Ixl5ArZBDYMm8tOv711Rt3gGlVCOuM3w.6oES59ytM702rH8nNMp4QSVqQ36N1xi0c5ebhgyslEt68hq8ARUU5Feh89Jf.log(Level.SEVERE, "Couldn't ping server", thrown);
                    break;
                }
                final String str = new String(p.getData(), p.getOffset(), p.getLength());
                2959V74TYTY4lhDc33xON2ko5AE6Tts6R1SzS9tHT9UB6gO6FU0no63BC75Ixl5ArZBDYMm8tOv711Rt3gGlVCOuM3w.6oES59ytM702rH8nNMp4QSVqQ36N1xi0c5ebhgyslEt68hq8ARUU5Feh89Jf.log(Level.FINEST, p.getAddress() + ": " + str);
                this.5K3sbQn5X6ulj0GQ3fhSzWEJld90E9S4eChV16qYUBMZ26x064s1ny2w4eON.6JWlo5oTbj6698u3MxWj43m8jjLW826DJsk9l6DW0z4oK6cxa991XuVMtgSV(str, p.getAddress());
            }
            try {
                this.9TIT1Oh03A2XA7jeuG3SzugWFnrI2oc818408ineX5q2lnc58swhho8Ca7m8.leaveGroup(this.5u8aht315N4kaG3o8hr41398KCm7udkU1m2nMTx4Qod98ZFnoF9V7Xr880gb);
            }
            catch (final IOException ex2) {}
            this.9TIT1Oh03A2XA7jeuG3SzugWFnrI2oc818408ineX5q2lnc58swhho8Ca7m8.close();
        }
    }
}
