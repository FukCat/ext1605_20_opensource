// 
// Decompiled by Procyon v0.6.0
// 

public class 8suuoyAmK77iaFQ5gqG532Zz1Nv6r737qh0KwPWU6hZ2XAqPKKq2VBh1bljt8U5054nka5A758kGL0XoH2zY29jd9365Gog9UY
{
    public static final int 45qw06H7q9aJJI31b7S7OZjhuZ553U7ENP8LDwK4Qn7xiCna5b80uqHgvQ32 = 0;
    public static final int 5KxDyM7k4kcJRHEr96bsde80Dt6Hljh4j493A4tbRq5wa6J526beNv172R7h = 1;
    public static final int 7428IZS3In0X71oA2783VCAlqVYJD98NPy4PD49DSJ6yfqVid72U4r24LUHh = 2;
    public static final int 5qHbm20m5EuZ3025vcTG9wtv0N0kZWK856ApB6t7Xn969sKS66AF0I7c9kXh = 3;
    public static final int 28CqyV8MkTL0NILicW3qE3gbG0Xl22h98dvz97F8GxQZ02T1PmB6ztls3c66 = 4;
    public static final int 7XhY8ZJrEp0Tbei4VNVX9pJgNEQ7HXW3ujmIA7c8gn63L3uVv6jWBw5dh6SY = 5;
    public static final int 41w45cYhbqtpafiK4b46ZlTz11r2AfKxTyv2eqQt458Bal704TQEn0P0hf1W = 16;
    public static final int 2Mh05t4gdOuYF815vtJ09QetxMkBBz7C3t1E9647whM7Bo0k9Vx8tfe2p29j = 127;
    
    public static int 4dD10Vjg8EXQlPqLn1740KeipDH3q81QpEc7eJ1kIDKnDkDuh78Z6nVgtW23(final int n) {
        switch (n) {
            case 0:
            case 1: {
                return n + 2;
            }
            case 2:
            case 3: {
                return n - 2;
            }
            default: {
                return -1;
            }
        }
    }
}
