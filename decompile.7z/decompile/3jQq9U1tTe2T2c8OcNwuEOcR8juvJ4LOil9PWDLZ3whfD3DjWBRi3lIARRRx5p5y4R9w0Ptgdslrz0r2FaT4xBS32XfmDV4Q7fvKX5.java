import java.awt.Dimension;
import java.awt.Canvas;

// 
// Decompiled by Procyon v0.6.0
// 

class 3jQq9U1tTe2T2c8OcNwuEOcR8juvJ4LOil9PWDLZ3whfD3DjWBRi3lIARRRx5p5y4R9w0Ptgdslrz0r2FaT4xBS32XfmDV4Q7fvKX5 extends Canvas
{
    public 3jQq9U1tTe2T2c8OcNwuEOcR8juvJ4LOil9PWDLZ3whfD3DjWBRi3lIARRRx5p5y4R9w0Ptgdslrz0r2FaT4xBS32XfmDV4Q7fvKX5(final int n) {
        this.setPreferredSize(new Dimension(n, n));
        this.setMinimumSize(new Dimension(n, n));
    }
}
