import java.io.DataOutputStream;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.ByteArrayInputStream;
import java.util.zip.CRC32;
import java.io.IOException;
import java.io.InputStream;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0 extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public String 6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K;
    public byte[] 1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L;
    public int 6vJrscivz8Dr993Dj7MZo481L37wVrM6doiirR72x2pvRXfxc81wlBD83qet;
    public boolean 9Mi7w69w192uYATgCYt7QwA4fo8F3ZKa5qTmWzCCwdBNv8qE5r3wlRUt7272;
    
    public 61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0() {
        this.6vJrscivz8Dr993Dj7MZo481L37wVrM6doiirR72x2pvRXfxc81wlBD83qet = -1;
        this.9Mi7w69w192uYATgCYt7QwA4fo8F3ZKa5qTmWzCCwdBNv8qE5r3wlRUt7272 = false;
    }
    
    public 61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0(final String s, final byte[] array, final int 6vJrscivz8Dr993Dj7MZo481L37wVrM6doiirR72x2pvRXfxc81wlBD83qet) {
        this(s, array);
        this.6vJrscivz8Dr993Dj7MZo481L37wVrM6doiirR72x2pvRXfxc81wlBD83qet = 6vJrscivz8Dr993Dj7MZo481L37wVrM6doiirR72x2pvRXfxc81wlBD83qet;
    }
    
    public 61059or8zNBWWjcRx8p82AllVu428I7lUI9jAy05q5Jn5bocU2s0w5J3s6F49b7A4L5MHih96070a9kP6G9tC560lNeBh0(final String 6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K, final byte[] 1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L) {
        this.6vJrscivz8Dr993Dj7MZo481L37wVrM6doiirR72x2pvRXfxc81wlBD83qet = -1;
        this.9Mi7w69w192uYATgCYt7QwA4fo8F3ZKa5qTmWzCCwdBNv8qE5r3wlRUt7272 = false;
        this.6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K = 6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K;
        this.1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L = 1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        final int int1 = dataInputStream.readInt();
        if (int1 > 0) {
            this.6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K = dataInputStream.readUTF();
            final int int2 = dataInputStream.readInt();
            this.1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L = new byte[1024];
            final int int3 = dataInputStream.readInt();
            try {
                1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.5Dx6EwZtaSyGYj8N225L6VZqgpsTj895gc3QQ5D3ojI09t6K013DQ8pYoU44(dataInputStream, this.1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L, 0, 1024);
            }
            catch (final IOException ex) {
                this.9Mi7w69w192uYATgCYt7QwA4fo8F3ZKa5qTmWzCCwdBNv8qE5r3wlRUt7272 = true;
                return;
            }
            final CRC32 crc32 = new CRC32();
            crc32.update(this.1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L, 0, 1024);
            if ((int)crc32.getValue() != int3) {
                this.9Mi7w69w192uYATgCYt7QwA4fo8F3ZKa5qTmWzCCwdBNv8qE5r3wlRUt7272 = true;
                return;
            }
            final 74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX 186bsEdE0L8avI1T6188HOBkw74Rv2C84f9rbbXELJN9UVCSqDM617l7y7BO = 74396401n67rAne2KEaVaEoh9nk1hB9T85P7cKNGObfdpHiKi8Lfd5f6YmBF53y4g331iR60dsRhm5zX4cf7RjY4Vu76FX.186bsEdE0L8avI1T6188HOBkw74Rv2C84f9rbbXELJN9UVCSqDM617l7y7BO(this.6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K, int1);
            186bsEdE0L8avI1T6188HOBkw74Rv2C84f9rbbXELJN9UVCSqDM617l7y7BO.9cz7Vn98gE08Y4N68LMaUZqR034r0KI31q3sL1hSrAF18DrcnKIY245062Yk(this.1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L, int2);
            if (186bsEdE0L8avI1T6188HOBkw74Rv2C84f9rbbXELJN9UVCSqDM617l7y7BO.9O1NrmW1QwxhgB5D7Vd06gSDyvy5p9L7ScBn1nCcKehSekZg3ig5102xlUI3()) {
                try {
                    final BufferedImage read = ImageIO.read(new ByteArrayInputStream(186bsEdE0L8avI1T6188HOBkw74Rv2C84f9rbbXELJN9UVCSqDM617l7y7BO.8u4H8s1OU3Y6C3EtLsf7U008wY0JFo6lT55WW90fs2awsRCSuIlxzgDspTR6));
                    final 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8 = new 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8();
                    9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.7q9ZI9Cq1X1WBs2pVjUilNUMeIsX6fDe1rx1tFnzfDwr720WVe92w5ezHImt = read;
                    9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8.5ecQ0QRfuWiJg3dl3ngZPlnby904839D118bEm61FJpDYFoe4QAl1g0XmO2t();
                    if (2mJJdB3LsncojI8IS9KAhF1KG7slntud2SEi4bDkoEJ08tUHDrwj09XifPRx3s84uv4URo67oh4G23ml69HanQAJ0Tyicz5RWqN.3XjG0HsI9P115a26L6q6r8fTAuTA0NW0u782v45C6a6G67W4694E50720Eyq) {
                        String string = System.getProperty(7yDngUXBYilDo3B5U1OQjbOC7YXT20yRn3Tcd85a5HhG5v856xXdCWUtjJXOc078JNt0up84KG4cgp466vtym7iZ695S7Udf.833cA0YF34t606AzhAl21SSFKu5o86ZfZT6w0TL8Lej56qphXp7Tl0V5475T(7yDngUXBYilDo3B5U1OQjbOC7YXT20yRn3Tcd85a5HhG5v856xXdCWUtjJXOc078JNt0up84KG4cgp466vtym7iZ695S7Udf.1Mq8T0QNr27egvw7Ii5njC2U34iHqD9xm0XHd85K26sr2HmLXKQgJ5Uz42hp)) + "/.minecraft/skincache/";
                        if (System.getProperty("os.name").contains("indows")) {
                            string = "C:/skincache/";
                        }
                        ImageIO.write(read, "png", new File(string + this.6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K + ".png"));
                    }
                    2mJJdB3LsncojI8IS9KAhF1KG7slntud2SEi4bDkoEJ08tUHDrwj09XifPRx3s84uv4URo67oh4G23ml69HanQAJ0Tyicz5RWqN.226wVH57Lp66MLBfb7TgqFt13liW2JIF99oxK9QVTeGc32MDUxm3arc8WW9T(this.6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K, 9gsziL0TnLKZsYW24fnfQMQI3W1WK3BzGpJhThYuO8u9SD5K2PCrm7OuVl09XIeJ9Z8tgj54b8DhIyhCzQa3Y7CqOx9q0AsrfBd8);
                }
                catch (final Exception ex2) {
                    7l2e0fYR96rf6dpREUY30xWh65d1rOc3abJQrqtvYEW6GNMN9qeJW237wlzS37y9Xt8xV209FRDRzpsI4HOsGN7skzB8a0.100zpjGx871CfQ97LIlXB4L1a18kKl6sZ3OLerqmn87iT5wYRd5Zq70vJ0m3("Error loading skin for " + this.6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K);
                    ex2.printStackTrace();
                }
            }
        }
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        if (this.9Mi7w69w192uYATgCYt7QwA4fo8F3ZKa5qTmWzCCwdBNv8qE5r3wlRUt7272 && 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 instanceof 49btkL6nY65UaC1HL6phMlN4O49JsjCZoD6JFDzeKE19K4p69DUfO8NBMBQkGKPfle6zC66kywH11EcDRF9ysSUahYv6Y) {
            ((49btkL6nY65UaC1HL6phMlN4O49JsjCZoD6JFDzeKE19K4p69DUfO8NBMBQkGKPfle6zC66kywH11EcDRF9ysSUahYv6Y)01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2).7o8z3cVu5Rk1xP64Q9432yTDXkA03eesX10it5ydgII6qfPBGegobR3PVoTd(new 5tH7yi21424UGpnwr734twU5W76R145xWk2gb07K98o48MT612932te7390xL1A7ir1d01sRGgZpR2dVSp47R6xD3J963C(this.6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K));
        }
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return (this.1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L == null) ? 4 : (4 + this.6HipIK0Tg11o54niaw0h4m1R9hX7LFN9x2tJsWvqlaABt70g77dlzy6K329K.length() + this.1hja64w3X2c3mOBk49a32Ebm5JjberlW1G8yRM5J8a57Wj97Ooi6634C650L.length);
    }
}
