// 
// Decompiled by Procyon v0.6.0
// 

public abstract class 1NK9kI2b7F731M711L5RbZEQkjd55g2J4231p4cv3tUHFCYwE47aodyc5oruS4J4KeFGq1Wq39tQzVWLQ46CSq869mlGEQ
{
    public float 43kSim8M1g78iU9b1q9Vd8gHHQRf514Ee02YEGcy5Q9KOjh25E083va9Zy1u;
    public boolean 18EZfzq3XX2ZLxVL9F5i0N6VCm36GRE1W3K1NnBgJ8S7z151hiEb7JnAtns5;
    
    public 1NK9kI2b7F731M711L5RbZEQkjd55g2J4231p4cv3tUHFCYwE47aodyc5oruS4J4KeFGq1Wq39tQzVWLQ46CSq869mlGEQ() {
        this.18EZfzq3XX2ZLxVL9F5i0N6VCm36GRE1W3K1NnBgJ8S7z151hiEb7JnAtns5 = false;
    }
    
    public static 3Iqil0tbvs6CCp2NW2cKwosmbL5NWIvuth3W5YxoWHzIqMXsL8GtN424RpGZ3ZA1ufKKGKty5nPAm118YQXJhD13N3yU0y 971LCw0obKd0LddSl3s84Lt6rr6CjrRi6FMVe8M5U26b5XshqYHX75uf04IN(final int n, final int n2, final float n3, final float n4, final float n5, final int n6, final int n7, final int n8, final boolean 3a1kEaA8CvtIQOTe9tDQQ9c4FmoG2ce9KvARiKuGBRPOz9HXT8E3ydtFDxfd) {
        final 3Iqil0tbvs6CCp2NW2cKwosmbL5NWIvuth3W5YxoWHzIqMXsL8GtN424RpGZ3ZA1ufKKGKty5nPAm118YQXJhD13N3yU0y 3Iqil0tbvs6CCp2NW2cKwosmbL5NWIvuth3W5YxoWHzIqMXsL8GtN424RpGZ3ZA1ufKKGKty5nPAm118YQXJhD13N3yU0y = new 3Iqil0tbvs6CCp2NW2cKwosmbL5NWIvuth3W5YxoWHzIqMXsL8GtN424RpGZ3ZA1ufKKGKty5nPAm118YQXJhD13N3yU0y(n, n2);
        3Iqil0tbvs6CCp2NW2cKwosmbL5NWIvuth3W5YxoWHzIqMXsL8GtN424RpGZ3ZA1ufKKGKty5nPAm118YQXJhD13N3yU0y.3p7n6kt6Ba7y3vt2jY2o41rG0RV05LSLCpW5L79b7ulZIeD8vsj1oPBlKl0z(n3, n4, n5, n6, n7, n8);
        3Iqil0tbvs6CCp2NW2cKwosmbL5NWIvuth3W5YxoWHzIqMXsL8GtN424RpGZ3ZA1ufKKGKty5nPAm118YQXJhD13N3yU0y.7v68YBu326do3T117PNJU7gQs0VfO62aAx2JtwJddR0k3k1ORPHcjShGFE57(0.0f, 0.0f, 0.0f);
        3Iqil0tbvs6CCp2NW2cKwosmbL5NWIvuth3W5YxoWHzIqMXsL8GtN424RpGZ3ZA1ufKKGKty5nPAm118YQXJhD13N3yU0y.3a1kEaA8CvtIQOTe9tDQQ9c4FmoG2ce9KvARiKuGBRPOz9HXT8E3ydtFDxfd = 3a1kEaA8CvtIQOTe9tDQQ9c4FmoG2ce9KvARiKuGBRPOz9HXT8E3ydtFDxfd;
        return 3Iqil0tbvs6CCp2NW2cKwosmbL5NWIvuth3W5YxoWHzIqMXsL8GtN424RpGZ3ZA1ufKKGKty5nPAm118YQXJhD13N3yU0y;
    }
    
    public void 4ApHQJcACm7U9P9uh6i0Zk07poI8aG016moYbJ60GZC5MOSl3gTp97C812hR(final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
    }
    
    public void 2wXF9QqCT46wH3224nw6S55aQ9715A607UpxEzQDOd6Hn7Mur0hXbqy17xd0(final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
    }
}
