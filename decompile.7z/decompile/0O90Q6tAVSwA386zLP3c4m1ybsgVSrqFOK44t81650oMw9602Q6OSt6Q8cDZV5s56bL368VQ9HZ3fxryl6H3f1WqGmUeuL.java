import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 0O90Q6tAVSwA386zLP3c4m1ybsgVSrqFOK44t81650oMw9602Q6OSt6Q8cDZV5s56bL368VQ9HZ3fxryl6H3f1WqGmUeuL extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public String 2OUW701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9;
    
    public 0O90Q6tAVSwA386zLP3c4m1ybsgVSrqFOK44t81650oMw9602Q6OSt6Q8cDZV5s56bL368VQ9HZ3fxryl6H3f1WqGmUeuL() {
        this.2OUW701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9 = "";
    }
    
    public 0O90Q6tAVSwA386zLP3c4m1ybsgVSrqFOK44t81650oMw9602Q6OSt6Q8cDZV5s56bL368VQ9HZ3fxryl6H3f1WqGmUeuL(final String 2ouw701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9) {
        this.2OUW701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9 = "";
        this.2OUW701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9 = 2ouw701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.2OUW701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9 = dataInputStream.readUTF();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeUTF(this.2OUW701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.1FtenBjtbWTQMx7w9NQ2pQqFxhc78G5Djz3ghM24o7Tc21uHI6Cx8s0PaRpG.5B00dFmpR6s8g6Dq0NvED7gFMPdY8SrHObgsMKC2un2AyC3y6awC0k1j6Y9k(this.2OUW701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return this.2OUW701SJKquXM04Ym5v9JPnpzxG0ge5J2gA78h4l0ho4hme1q5UPi60h9U9.length() + 2;
    }
}
