// 
// Decompiled by Procyon v0.6.0
// 

public class 8v21XqGBKlb5tBoXN248rU79X3Ur28kL5v5kBi86cs994juAv5Zura8oq57fB44zfSTwl5EryhT7i5HUAQe33uivs44Rv53e extends 2UQBJP5xVBLvcOj4Zez1XaJembU13Cma9CKxz4KHBXDgtLvI3Q228ox61gusX4MQeIDyXmP4j3bUou3222GJ6BeabF38
{
    protected float[] 8FS3Ncp2JbVavISpIUz9iIn9ODk7wV141cO1Q5g0ODSrg3L0vRA5DMc7iM6H;
    protected float[] 79JZCJAD8GYec7s6mK8819gjqE9g93I84TXN3s9ALWgQP5I81w48Xj252TR9;
    protected float[] 2F86OI73u4EOlkhobJ73Bg83W7dq9sMKxd4926nfRj1jvL1p6226M0rrrhi4;
    protected float[] 345q09Qa9N8d00XmAeoUALq1XNvGoaGH17466gdKgKEPIPFEHjfUl1I549qv;
    private int 9ZYVu9Qp113TX8tpXTT5VQv4YWsb18SI898dGKiT3e843244cGjA75t7oUDX;
    
    public 8v21XqGBKlb5tBoXN248rU79X3Ur28kL5v5kBi86cs994juAv5Zura8oq57fB44zfSTwl5EryhT7i5HUAQe33uivs44Rv53e() {
        super(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.1Qp0JaZY8j08gNvixC9lTVmYuhPF31BB7EM4Stx7l040d2ADn4eGQuWyK2M5.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41);
        this.8FS3Ncp2JbVavISpIUz9iIn9ODk7wV141cO1Q5g0ODSrg3L0vRA5DMc7iM6H = new float[256];
        this.79JZCJAD8GYec7s6mK8819gjqE9g93I84TXN3s9ALWgQP5I81w48Xj252TR9 = new float[256];
        this.2F86OI73u4EOlkhobJ73Bg83W7dq9sMKxd4926nfRj1jvL1p6226M0rrrhi4 = new float[256];
        this.345q09Qa9N8d00XmAeoUALq1XNvGoaGH17466gdKgKEPIPFEHjfUl1I549qv = new float[256];
        this.9ZYVu9Qp113TX8tpXTT5VQv4YWsb18SI898dGKiT3e843244cGjA75t7oUDX = 0;
    }
    
    @Override
    public void 88ejD45Q8LEgM39W23b9PS53H72qux6CoqBH3EmIU8XRRLm3446Q9e3d4IQv() {
        ++this.9ZYVu9Qp113TX8tpXTT5VQv4YWsb18SI898dGKiT3e843244cGjA75t7oUDX;
        if (1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.4ZJzjV4ZUIoAEZm80Eg9UZ6ydiptq3Q0W2umW7h3bRHqfDcd45vw553X6qt7.5IuIjxdsOFzPSsO2O3W0Xgmre5LzkBRPKy1Qr3K03wRK0E6JS94OW9Svbehn.21n1Yc74v7G6eY24T7KSj34XifI3R56mzeD6BEe0SmDhkmylgeGogGH3s6Mb == 2 && !this.88024hG6da4f4kcVfOqR8cTJ36RtCs13wB6V30Rs17vqAj14F4Cqz3neFg20) {
            return;
        }
        this.88024hG6da4f4kcVfOqR8cTJ36RtCs13wB6V30Rs17vqAj14F4Cqz3neFg20 = false;
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 16; ++j) {
                float n = 0.0f;
                for (int k = i - 1; k <= i + 1; ++k) {
                    n += this.8FS3Ncp2JbVavISpIUz9iIn9ODk7wV141cO1Q5g0ODSrg3L0vRA5DMc7iM6H[(k & 0xF) + (j & 0xF) * 16];
                }
                this.79JZCJAD8GYec7s6mK8819gjqE9g93I84TXN3s9ALWgQP5I81w48Xj252TR9[i + j * 16] = n / 3.3f + this.2F86OI73u4EOlkhobJ73Bg83W7dq9sMKxd4926nfRj1jvL1p6226M0rrrhi4[i + j * 16] * 0.8f;
            }
        }
        for (int l = 0; l < 16; ++l) {
            for (int n2 = 0; n2 < 16; ++n2) {
                final float[] 2f86OI73u4EOlkhobJ73Bg83W7dq9sMKxd4926nfRj1jvL1p6226M0rrrhi4 = this.2F86OI73u4EOlkhobJ73Bg83W7dq9sMKxd4926nfRj1jvL1p6226M0rrrhi4;
                final int n3 = l + n2 * 16;
                2f86OI73u4EOlkhobJ73Bg83W7dq9sMKxd4926nfRj1jvL1p6226M0rrrhi4[n3] += this.345q09Qa9N8d00XmAeoUALq1XNvGoaGH17466gdKgKEPIPFEHjfUl1I549qv[l + n2 * 16] * 0.05f;
                if (this.2F86OI73u4EOlkhobJ73Bg83W7dq9sMKxd4926nfRj1jvL1p6226M0rrrhi4[l + n2 * 16] < 0.0f) {
                    this.2F86OI73u4EOlkhobJ73Bg83W7dq9sMKxd4926nfRj1jvL1p6226M0rrrhi4[l + n2 * 16] = 0.0f;
                }
                final float[] 345q09Qa9N8d00XmAeoUALq1XNvGoaGH17466gdKgKEPIPFEHjfUl1I549qv = this.345q09Qa9N8d00XmAeoUALq1XNvGoaGH17466gdKgKEPIPFEHjfUl1I549qv;
                final int n4 = l + n2 * 16;
                345q09Qa9N8d00XmAeoUALq1XNvGoaGH17466gdKgKEPIPFEHjfUl1I549qv[n4] -= 0.1f;
                if (Math.random() < 0.05) {
                    this.345q09Qa9N8d00XmAeoUALq1XNvGoaGH17466gdKgKEPIPFEHjfUl1I549qv[l + n2 * 16] = 0.5f;
                }
            }
        }
        final float[] 79JZCJAD8GYec7s6mK8819gjqE9g93I84TXN3s9ALWgQP5I81w48Xj252TR9 = this.79JZCJAD8GYec7s6mK8819gjqE9g93I84TXN3s9ALWgQP5I81w48Xj252TR9;
        this.79JZCJAD8GYec7s6mK8819gjqE9g93I84TXN3s9ALWgQP5I81w48Xj252TR9 = this.8FS3Ncp2JbVavISpIUz9iIn9ODk7wV141cO1Q5g0ODSrg3L0vRA5DMc7iM6H;
        this.8FS3Ncp2JbVavISpIUz9iIn9ODk7wV141cO1Q5g0ODSrg3L0vRA5DMc7iM6H = 79JZCJAD8GYec7s6mK8819gjqE9g93I84TXN3s9ALWgQP5I81w48Xj252TR9;
        for (int n5 = 0; n5 < 256; ++n5) {
            float n6 = this.8FS3Ncp2JbVavISpIUz9iIn9ODk7wV141cO1Q5g0ODSrg3L0vRA5DMc7iM6H[n5];
            if (n6 > 1.0f) {
                n6 = 1.0f;
            }
            if (n6 < 0.0f) {
                n6 = 0.0f;
            }
            final float n7 = n6 * n6;
            int n8 = (int)(32.0f + n7 * 32.0f);
            int n9 = (int)(50.0f + n7 * 64.0f);
            int n10 = 255;
            final int n11 = (int)(146.0f + n7 * 50.0f);
            if (this.06P3mXenpD5L0FS19r771z79X4G6ToUmlYYq950W8EH6ukeiX4WQd6Wqr2uA) {
                final int n12 = (n8 * 30 + n9 * 59 + n10 * 11) / 100;
                final int n13 = (n8 * 30 + n9 * 70) / 100;
                final int n14 = (n8 * 30 + n10 * 70) / 100;
                n8 = n12;
                n9 = n13;
                n10 = n14;
            }
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n5 * 4 + 0] = (byte)n8;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n5 * 4 + 1] = (byte)n9;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n5 * 4 + 2] = (byte)n10;
            this.8hTHSC7rG7gfcnHOO1IR8LKJ5WbfgWP4DZy894U21YDCTVhNU4pMPGK2WT4D[n5 * 4 + 3] = (byte)n11;
        }
    }
}
