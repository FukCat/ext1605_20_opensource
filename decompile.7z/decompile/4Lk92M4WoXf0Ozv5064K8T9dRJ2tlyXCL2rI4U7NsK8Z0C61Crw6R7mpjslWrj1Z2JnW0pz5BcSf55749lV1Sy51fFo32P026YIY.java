import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 4Lk92M4WoXf0Ozv5064K8T9dRJ2tlyXCL2rI4U7NsK8Z0C61Crw6R7mpjslWrj1Z2JnW0pz5BcSf55749lV1Sy51fFo32P026YIY extends 7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR
{
    public 4Lk92M4WoXf0Ozv5064K8T9dRJ2tlyXCL2rI4U7NsK8Z0C61Crw6R7mpjslWrj1Z2JnW0pz5BcSf55749lV1Sy51fFo32P026YIY(final int n, final int 9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41) {
        super(n, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.0e51g5n7QQ2bM6IT7Q28hAbJkebnbMOVd3lRo7XioWLAkvTHV9DQxASpl4S7);
        this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41 = 9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41;
    }
    
    @Override
    public int 9hFrB67UQ3xIdu153AXx7FYrppLysZW3gpO0hVR27pm9IQlKb2jF25i9DO3e(final int n, final Random random) {
        if ((n & 0x8) != 0x0) {
            return 0;
        }
        return 0dby7k68oS8bMP61EdwuR2s558o8vwfZCMui3fm7WNgl5q0kgKt1Twtdb81iRcZM6DYIJZgxzus8L7aK8IV2h06A2w74wN.9Qa0F797sw0T152ZoNi3F09xYZt8h284Gq0075u6Bm6ue810zsuSvCsLNDMx.016D6B0WzYa1oAf8GVzuN3e04Nkxq5CzkT5YVZhj2l5H8LW20C9lkr0R7pc5;
    }
}
