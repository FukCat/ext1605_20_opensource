import org.lwjgl.opengl.GL11;
import java.nio.IntBuffer;

// 
// Decompiled by Procyon v0.6.0
// 

public class 267F7Tk1eh6L7B95WAPutuH580JV4FRJNILpQ74h9OefxCtZkSM5aBL9LXKFpTFHSXhcU3Q396Tb0J0dqeuk44fWB0753C5OycvO
{
    private int 7o2RF4113054L71IvDoHzUrFz05rG725M3541ReuD63NTHUgIpJ29W09Xl3L;
    private int 7NH3b0tohzW4YOSs4ZdjkbKgQv1iz8fIhMpa8OC8RZGzexeB8TlW9pv2JndJ;
    private int 554vR8vePfXK3gMxfFB37t1hA5dw8V6m4h9dxVmjq3Gw84kE39P0Ys0RIdtB;
    private float 3b55C02fa7X8fKVv2908vl6TdUxE5eE3Cj27j76PRZGuut8gTB2RN47SU4l7;
    private float 46O735wt4m9sI4d3f3Pw5elML21YTwlX8jN5nfk7bG8CRyOA14BAb1S5dhnt;
    private float 9966Sz2GgAZvOBfUmN17k3JU44rh9BRDJ9oNG4abacLEic4C82NSvS85FG8K;
    private IntBuffer 74THKt5l8dym6JfoK37ARFh5i27pNHiaNeL4coK94wGKqs8JzR5meGU839C0;
    private boolean 7BTz4I6sxReYKMJOxb5KD1L93t6Gz6vfLaGhr78pNu66oz1R4lCpo2MPm4G3;
    private boolean 690LJcKIKVy573x2FQS2nDR4qG9v6g9TrhRnu9BTi24k7P7zVhpxqcw1VTX5;
    
    public 267F7Tk1eh6L7B95WAPutuH580JV4FRJNILpQ74h9OefxCtZkSM5aBL9LXKFpTFHSXhcU3Q396Tb0J0dqeuk44fWB0753C5OycvO() {
        this.74THKt5l8dym6JfoK37ARFh5i27pNHiaNeL4coK94wGKqs8JzR5meGU839C0 = 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1R0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2(65536);
        this.7BTz4I6sxReYKMJOxb5KD1L93t6Gz6vfLaGhr78pNu66oz1R4lCpo2MPm4G3 = false;
        this.690LJcKIKVy573x2FQS2nDR4qG9v6g9TrhRnu9BTi24k7P7zVhpxqcw1VTX5 = false;
    }
    
    public void 954E1WdjtQ17485yq3XxhV282N8iZI5ShF4ZZ4w9mY44gpa9CIG31SVqZn3D(final int 7o2RF4113054L71IvDoHzUrFz05rG725M3541ReuD63NTHUgIpJ29W09Xl3L, final int 7nh3b0tohzW4YOSs4ZdjkbKgQv1iz8fIhMpa8OC8RZGzexeB8TlW9pv2JndJ, final int 554vR8vePfXK3gMxfFB37t1hA5dw8V6m4h9dxVmjq3Gw84kE39P0Ys0RIdtB, final double n, final double n2, final double n3) {
        this.7BTz4I6sxReYKMJOxb5KD1L93t6Gz6vfLaGhr78pNu66oz1R4lCpo2MPm4G3 = true;
        this.74THKt5l8dym6JfoK37ARFh5i27pNHiaNeL4coK94wGKqs8JzR5meGU839C0.clear();
        this.7o2RF4113054L71IvDoHzUrFz05rG725M3541ReuD63NTHUgIpJ29W09Xl3L = 7o2RF4113054L71IvDoHzUrFz05rG725M3541ReuD63NTHUgIpJ29W09Xl3L;
        this.7NH3b0tohzW4YOSs4ZdjkbKgQv1iz8fIhMpa8OC8RZGzexeB8TlW9pv2JndJ = 7nh3b0tohzW4YOSs4ZdjkbKgQv1iz8fIhMpa8OC8RZGzexeB8TlW9pv2JndJ;
        this.554vR8vePfXK3gMxfFB37t1hA5dw8V6m4h9dxVmjq3Gw84kE39P0Ys0RIdtB = 554vR8vePfXK3gMxfFB37t1hA5dw8V6m4h9dxVmjq3Gw84kE39P0Ys0RIdtB;
        this.3b55C02fa7X8fKVv2908vl6TdUxE5eE3Cj27j76PRZGuut8gTB2RN47SU4l7 = (float)n;
        this.46O735wt4m9sI4d3f3Pw5elML21YTwlX8jN5nfk7bG8CRyOA14BAb1S5dhnt = (float)n2;
        this.9966Sz2GgAZvOBfUmN17k3JU44rh9BRDJ9oNG4abacLEic4C82NSvS85FG8K = (float)n3;
    }
    
    public boolean 42c5QZuLs30bBHkIDQq5ia2X458Q5A7it474k9tMosSVCn1lX0m78h4jv6VU(final int n, final int n2, final int n3) {
        return this.7BTz4I6sxReYKMJOxb5KD1L93t6Gz6vfLaGhr78pNu66oz1R4lCpo2MPm4G3 && (n == this.7o2RF4113054L71IvDoHzUrFz05rG725M3541ReuD63NTHUgIpJ29W09Xl3L && n2 == this.7NH3b0tohzW4YOSs4ZdjkbKgQv1iz8fIhMpa8OC8RZGzexeB8TlW9pv2JndJ && n3 == this.554vR8vePfXK3gMxfFB37t1hA5dw8V6m4h9dxVmjq3Gw84kE39P0Ys0RIdtB);
    }
    
    public void 7jB65jx205D2ySgR7Mjnn2dWnr39f40mEfoFdJ285L04676NkeVi6k1q1u2g(final int n) {
        this.74THKt5l8dym6JfoK37ARFh5i27pNHiaNeL4coK94wGKqs8JzR5meGU839C0.put(n);
        if (this.74THKt5l8dym6JfoK37ARFh5i27pNHiaNeL4coK94wGKqs8JzR5meGU839C0.remaining() == 0) {
            this.3r631O46TwV4qd0NsYhMLFA563feas35b8iR1oMKEY7S29pJu3PFo8k38P04();
        }
    }
    
    public void 3r631O46TwV4qd0NsYhMLFA563feas35b8iR1oMKEY7S29pJu3PFo8k38P04() {
        if (this.7BTz4I6sxReYKMJOxb5KD1L93t6Gz6vfLaGhr78pNu66oz1R4lCpo2MPm4G3) {
            if (!this.690LJcKIKVy573x2FQS2nDR4qG9v6g9TrhRnu9BTi24k7P7zVhpxqcw1VTX5) {
                this.74THKt5l8dym6JfoK37ARFh5i27pNHiaNeL4coK94wGKqs8JzR5meGU839C0.flip();
                this.690LJcKIKVy573x2FQS2nDR4qG9v6g9TrhRnu9BTi24k7P7zVhpxqcw1VTX5 = true;
            }
            if (this.74THKt5l8dym6JfoK37ARFh5i27pNHiaNeL4coK94wGKqs8JzR5meGU839C0.remaining() > 0) {
                GL11.glPushMatrix();
                GL11.glTranslatef(this.7o2RF4113054L71IvDoHzUrFz05rG725M3541ReuD63NTHUgIpJ29W09Xl3L - this.3b55C02fa7X8fKVv2908vl6TdUxE5eE3Cj27j76PRZGuut8gTB2RN47SU4l7, this.7NH3b0tohzW4YOSs4ZdjkbKgQv1iz8fIhMpa8OC8RZGzexeB8TlW9pv2JndJ - this.46O735wt4m9sI4d3f3Pw5elML21YTwlX8jN5nfk7bG8CRyOA14BAb1S5dhnt, this.554vR8vePfXK3gMxfFB37t1hA5dw8V6m4h9dxVmjq3Gw84kE39P0Ys0RIdtB - this.9966Sz2GgAZvOBfUmN17k3JU44rh9BRDJ9oNG4abacLEic4C82NSvS85FG8K);
                GL11.glCallLists(this.74THKt5l8dym6JfoK37ARFh5i27pNHiaNeL4coK94wGKqs8JzR5meGU839C0);
                GL11.glPopMatrix();
            }
        }
    }
    
    public void 7585RWrF9134Ns1g5uYdU0uxYtOAQ2P6X08n4K9hK47p7x49c1k10dUQnEy3() {
        this.7BTz4I6sxReYKMJOxb5KD1L93t6Gz6vfLaGhr78pNu66oz1R4lCpo2MPm4G3 = false;
        this.690LJcKIKVy573x2FQS2nDR4qG9v6g9TrhRnu9BTi24k7P7zVhpxqcw1VTX5 = false;
    }
}
