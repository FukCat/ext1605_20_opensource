import java.io.DataOutputStream;
import java.util.zip.DataFormatException;
import java.io.IOException;
import java.util.zip.Inflater;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 5e03Tw416352dqfOT3a1e9ub8TL3BP2V33fuoOIeRH3s3Q3F4g7iZ5A7B20lkPkUb0cS0QkvD5flxyn6Y2cI3K7HwdN3I94o5 extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 3qJ34Bz8gCIf64K5exr8yJo90bI1hG8rg83I7n3CS2M9K27Q7q939xS5z6b7;
    public int 1H9hE7UAOf38V1h3io18RbPfTlzA6172CBBS6OX3xJ8uSZ29ke54xKRV90D6;
    public int 2z4l2p6uf5ltJ0zT7G8a1yp919k7V2DyZnCK2Yym4L819eavt8J40718907o;
    public int 11NERD48Oy926ihAl7a4MorPS40vYOa92htki8hk6fph6v2g58qjcbzx8Jr3;
    public int 9c3oL8jY44auvp7F5B04793L7njYV3MJ143K34mdB1M4oQ90pew28z8pwhWt;
    public int 2vJRhJPdwW4OuM5bf4bEsQRlZg0nzF74hpxMYLu4Vo5G7D4BEUFw8p176Yyp;
    public byte[] 88620BRyc8Pm07e9j0xMv2Wk613wrT4SgKdFqsCte1Cp3wNc6C8I3aG4mrad;
    private int 51CFRucd19691E2Hn077o6rI8QmUdUX401UZJUsL8Vwtisudas1u120H83qL;
    
    public 5e03Tw416352dqfOT3a1e9ub8TL3BP2V33fuoOIeRH3s3Q3F4g7iZ5A7B20lkPkUb0cS0QkvD5flxyn6Y2cI3K7HwdN3I94o5() {
        this.6t9cCgt41s5d1pQ7cjb3tIHK1IXU79b99NWj8CrXP2toB951Vr11rxkXisnp = true;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.3qJ34Bz8gCIf64K5exr8yJo90bI1hG8rg83I7n3CS2M9K27Q7q939xS5z6b7 = dataInputStream.readInt();
        this.1H9hE7UAOf38V1h3io18RbPfTlzA6172CBBS6OX3xJ8uSZ29ke54xKRV90D6 = dataInputStream.readShort();
        this.2z4l2p6uf5ltJ0zT7G8a1yp919k7V2DyZnCK2Yym4L819eavt8J40718907o = dataInputStream.readInt();
        this.11NERD48Oy926ihAl7a4MorPS40vYOa92htki8hk6fph6v2g58qjcbzx8Jr3 = dataInputStream.read() + 1;
        this.9c3oL8jY44auvp7F5B04793L7njYV3MJ143K34mdB1M4oQ90pew28z8pwhWt = dataInputStream.read() + 1;
        this.2vJRhJPdwW4OuM5bf4bEsQRlZg0nzF74hpxMYLu4Vo5G7D4BEUFw8p176Yyp = dataInputStream.read() + 1;
        final byte[] array = new byte[dataInputStream.readInt()];
        dataInputStream.readFully(array);
        this.88620BRyc8Pm07e9j0xMv2Wk613wrT4SgKdFqsCte1Cp3wNc6C8I3aG4mrad = new byte[this.11NERD48Oy926ihAl7a4MorPS40vYOa92htki8hk6fph6v2g58qjcbzx8Jr3 * this.9c3oL8jY44auvp7F5B04793L7njYV3MJ143K34mdB1M4oQ90pew28z8pwhWt * this.2vJRhJPdwW4OuM5bf4bEsQRlZg0nzF74hpxMYLu4Vo5G7D4BEUFw8p176Yyp * 5 / 2];
        final Inflater inflater = new Inflater();
        inflater.setInput(array);
        try {
            inflater.inflate(this.88620BRyc8Pm07e9j0xMv2Wk613wrT4SgKdFqsCte1Cp3wNc6C8I3aG4mrad);
        }
        catch (final DataFormatException ex) {
            throw new IOException("Bad compressed data format");
        }
        finally {
            inflater.end();
        }
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeInt(this.3qJ34Bz8gCIf64K5exr8yJo90bI1hG8rg83I7n3CS2M9K27Q7q939xS5z6b7);
        dataOutputStream.writeShort(this.1H9hE7UAOf38V1h3io18RbPfTlzA6172CBBS6OX3xJ8uSZ29ke54xKRV90D6);
        dataOutputStream.writeInt(this.2z4l2p6uf5ltJ0zT7G8a1yp919k7V2DyZnCK2Yym4L819eavt8J40718907o);
        dataOutputStream.write(this.11NERD48Oy926ihAl7a4MorPS40vYOa92htki8hk6fph6v2g58qjcbzx8Jr3 - 1);
        dataOutputStream.write(this.9c3oL8jY44auvp7F5B04793L7njYV3MJ143K34mdB1M4oQ90pew28z8pwhWt - 1);
        dataOutputStream.write(this.2vJRhJPdwW4OuM5bf4bEsQRlZg0nzF74hpxMYLu4Vo5G7D4BEUFw8p176Yyp - 1);
        dataOutputStream.writeInt(this.51CFRucd19691E2Hn077o6rI8QmUdUX401UZJUsL8Vwtisudas1u120H83qL);
        dataOutputStream.write(this.88620BRyc8Pm07e9j0xMv2Wk613wrT4SgKdFqsCte1Cp3wNc6C8I3aG4mrad, 0, this.51CFRucd19691E2Hn077o6rI8QmUdUX401UZJUsL8Vwtisudas1u120H83qL);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.3qzz2ClUupGvhm7RfMR00QnmWltx9u1Gg1cwHT7x9dBZ41Oy47dUUOv58KWh(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 17 + this.51CFRucd19691E2Hn077o6rI8QmUdUX401UZJUsL8Vwtisudas1u120H83qL;
    }
}
