import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 29QWwQLvTW8p1VsQv4V28P1qxx9jf5yzoV9nmYl4VZDZ33159BJ03NRKjwPT9CfxKiFOM017f3wp3CJZl5OaSCkai4x7lM extends 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC
{
    public 29QWwQLvTW8p1VsQv4V28P1qxx9jf5yzoV9nmYl4VZDZ33159BJ03NRKjwPT9CfxKiFOM017f3wp3CJZl5OaSCkai4x7lM(final int n, final int n2) {
        super(n, n2, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.5Q24DSAx4PkS1eunpH8O3lzVC9N1Qx2izdUfYWD79R242Mn8jVOLVbK7A5yn);
    }
    
    @Override
    public 85H57P2H4D6cj141sW70sW6k1pGNK4K4k78ms060bS9Wz8ktuElnkcl5YQCE3305VB1e75Xq1DQYF44ZEikQn64iKmEU62Tu9R5qy07u 3bij4GE3F3Ym8Tj5mrW954sQU66Nm526G6r6WtltdPMgh4iGYTj57E59MauA(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        final float n4 = 0.125f;
        switch (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P) {
            case 2: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 1.0f - n4, 1.0f, 1.0f, 1.0f);
                break;
            }
            case 3: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, n4);
                break;
            }
            case 4: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(1.0f - n4, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
                break;
            }
            case 5: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, n4, 1.0f, 1.0f);
                break;
            }
            case 6: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 1.0f - n4, 0.0f, 1.0f, 1.0f, 1.0f);
                break;
            }
            case 7: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, n4, 1.0f);
                break;
            }
        }
        return super.3bij4GE3F3Ym8Tj5mrW954sQU66Nm526G6r6WtltdPMgh4iGYTj57E59MauA(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3);
    }
    
    @Override
    public 85H57P2H4D6cj141sW70sW6k1pGNK4K4k78ms060bS9Wz8ktuElnkcl5YQCE3305VB1e75Xq1DQYF44ZEikQn64iKmEU62Tu9R5qy07u 1lI9KIuLRpwqxNkCdN55OQH58jw8pL0BXEJQS6of99lsw25B2Gb7un13njcy(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        final float n4 = 0.125f;
        switch (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P) {
            case 2: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 1.0f - n4, 1.0f, 1.0f, 1.0f);
                break;
            }
            case 3: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, n4);
                break;
            }
            case 4: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(1.0f - n4, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
                break;
            }
            case 5: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, n4, 1.0f, 1.0f);
                break;
            }
            case 6: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 1.0f - n4, 0.0f, 1.0f, 1.0f, 1.0f);
                break;
            }
            case 7: {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, n4, 1.0f);
                break;
            }
        }
        return super.1lI9KIuLRpwqxNkCdN55OQH58jw8pL0BXEJQS6of99lsw25B2Gb7un13njcy(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3);
    }
    
    @Override
    public boolean 11krARXg1dz3Cs9T1417zcu0h3o23b6X5J17X8JguWkYPA1xFa6hm48g23zA() {
        return false;
    }
    
    @Override
    public boolean 35gUMxe6UGWsnci7k7ZiwHjA0P63Qs829v6WAF3u9tc6vXASiYOI7j512637() {
        return false;
    }
    
    @Override
    public int 9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP() {
        return 8;
    }
    
    @Override
    public boolean 26Sw8fe154f6YmvVZ7TYtX7TGoLNJ4WtS6WLf9Z0avd7SUy77UUQ2HeN8LJq(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        return 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2 - 1, n3) || 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2 + 1, n3) || 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n - 1, n2, n3) || 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n + 1, n2, n3) || 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 - 1) || 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 + 1);
    }
    
    @Override
    public void 9dBY743F7pu8itvayn3EN3079gT8EaP3kLK1qF737Eyz85R9HEMP9t7nzhe9(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final int n4) {
        int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        if ((5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 0 || n4 == 2) && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 + 1)) {
            5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 2;
        }
        else if ((5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 0 || n4 == 3) && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 - 1)) {
            5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 3;
        }
        else if ((5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 0 || n4 == 4) && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n + 1, n2, n3)) {
            5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 4;
        }
        else if ((5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 0 || n4 == 5) && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n - 1, n2, n3)) {
            5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 5;
        }
        else if ((5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 0 || n4 == 6) && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2 + 1, n3)) {
            5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 6;
        }
        else if ((5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 0 || n4 == 7) && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2 - 1, n3)) {
            5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 7;
        }
        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2aY9ewCwes7sqWoh05haEv808w14A1Ex0D7a0h8R0mMEGD3D43356m0O5840(n, n2, n3, 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P);
    }
    
    @Override
    public void 7Y3tozvAo32fnL40Aj23V3Z0UTg24ELW02SnQs781Of4EIXyFofcbvW6li4c(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final int n4) {
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        boolean b = false;
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 2 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 + 1)) {
            b = true;
        }
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 3 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 - 1)) {
            b = true;
        }
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 4 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n + 1, n2, n3)) {
            b = true;
        }
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 5 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n - 1, n2, n3)) {
            b = true;
        }
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 6 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2 + 1, n3)) {
            b = true;
        }
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 7 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2 - 1, n3)) {
            b = true;
        }
        if (!b) {
            this.34c2i0BTc9ESKRlH8o24MFx27N7S3sQf54gg2xV6ZbZrdGZ1JlWKc3u2Dk65(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3, 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P);
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(n, n2, n3, 0);
        }
        super.7Y3tozvAo32fnL40Aj23V3Z0UTg24ELW02SnQs781Of4EIXyFofcbvW6li4c(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3, n4);
    }
    
    @Override
    public int 6M14lZVXL6xs4lKY6vj11vAQ2E9U9ZDOF0Nh9aCHYAlz8F6Pfx930Z7gxmzf(final Random random) {
        return 1;
    }
}
