import org.lwjgl.opengl.GL11;
import org.lwjgl.input.Keyboard;

// 
// Decompiled by Procyon v0.6.0
// 

public class 3Xti2N11uT0gsUTFzbAfKFoImjt4o7U8ADuci1WnO7L674tKV1H04y3z6caD3M9bA43c17LfKMVr2rpXb64lh6juIDtH95tV1q0 extends 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D
{
    protected String 3BbKr3cd9N5h406k372X9SZ7eH5Lv362589RH5JCrDLtVqVb1gKv3COd2w9K;
    private 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7 2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3;
    private int 0JtjX5ETryZyHwpk0VPmyrGji3xJ7PKD0QTKuyN2xQRYuxfKjdWcB1x8g6O4;
    private int 8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h;
    
    public 3Xti2N11uT0gsUTFzbAfKFoImjt4o7U8ADuci1WnO7L674tKV1H04y3z6caD3M9bA43c17LfKMVr2rpXb64lh6juIDtH95tV1q0(final 32hEVM0XD2Xy0JyG2L4l211oj4dY03p80MuLzDig1Y1Bo1lRUp88x4KH4sITP8KnPXC6r383O8470y5Rrjqt7Bi1sA1O7 2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3) {
        this.3BbKr3cd9N5h406k372X9SZ7eH5Lv362589RH5JCrDLtVqVb1gKv3COd2w9K = "Edit sign message:";
        this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h = 0;
        this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3 = 2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3;
    }
    
    @Override
    public void 4An20JYjYn5ahp07NQmWFCuC33T53X6s4pd5325t5MV2inUXBh7is28o5l1C() {
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.clear();
        Keyboard.enableRepeatEvents(true);
        this.1d6PR7WWyH754Aw3qtyb1559Y1EkYtnXOgjR3rQ36S0339si8Vv55r7ps6nX.add(new 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03(0, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2 - 100, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 4 + 120, "Done"));
    }
    
    @Override
    public void 43zN406CnnMvKt50m1T5x9TK6olZW559Ze5Um8SL6U0pyu07041JesDT1Mts() {
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    public void 79dcDBX8wOiJ7P492Y177gZw78gOSlsV8lxmDRioLVlEh14o5HL6Utyo3Gfq() {
        ++this.0JtjX5ETryZyHwpk0VPmyrGji3xJ7PKD0QTKuyN2xQRYuxfKjdWcB1x8g6O4;
    }
    
    @Override
    protected void 7OD0HqHbYI4579sDX4xzee60N9g9V78YwSmgkc1Y6fyN6rF6JwUqBEU5m77M(final 5DS92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03 5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03) {
        if (5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.0Dn9XYbwOI0cTzjIRHga5tL990b9oummb9Q64SZBh9LU4M0I395Wln2t9pnG && 5ds92tZtNLGXc337pD67wpiwM2Woutg6vM7xeI9TAcXr2naB8Xp87x97OI01ZaS4z6x8rbXLuQ5HB8uT0Luwrer6Qg3RCJ4Q03.71vmuXt5424MGpB5uTnXh37vbo2Q33axLwdOw9McdUv44kGo5NRAxfK0llfj == 0) {
            this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.26102Q6EROXLN4oo5xLi125cz22Wd83TMpMd7H46v352PdYe4s8bP17ZT2dZ();
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(null);
        }
    }
    
    @Override
    protected void 27HH93i69891UR8scaUy8Wa381SrOHnrgz1395TWPN543Aw65UPU60a9U5op(final char c, final int n) {
        if (n == 200) {
            this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h = (this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h - 1 & 0x3);
        }
        if (n == 208 || n == 28) {
            this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h = (this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h + 1 & 0x3);
        }
        if (n == 14 && this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b[this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h].length() > 0) {
            this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b[this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h] = this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b[this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h].substring(0, this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b[this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h].length() - 1);
        }
        if (" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~\u2302\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8?\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1??????????".indexOf(c) >= 0 && this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b[this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h].length() < 15) {
            this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.1fQB1d9e3utQ8rFvp8d2Gkn28QrfgJFLjZ1b5mmGTkI4vj7n4gLZsqZv073b[this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h] += c;
        }
    }
    
    @Override
    public void 9zr0Ft7ATwYEg4elWEB8ucyDaj2700KJgZB3Cc51d8vF03zOM52iOvWHcrR5(final int n, final int n2, final float n3) {
        this.5S1K79XLhK48s404AETji776rN10k5t6zymKy3FSC71grsr64j85ILV6pJWZ();
        this.7hd18JPAm30YnhcZ8R4BhADB3iRynT8aWz54M1xf1qSS3I4uWxIHQH2B64Sx(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, this.3BbKr3cd9N5h406k372X9SZ7eH5Lv362589RH5JCrDLtVqVb1gKv3COd2w9K, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2, 40, 16777215);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)(this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s / 2), (float)(this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b / 2), 50.0f);
        final float n4 = 93.75f;
        GL11.glScalef(-n4, -n4, -n4);
        GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        if (this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.7LfK4m7Nkevw8KLtBGOhC343i0Yn59U0N4WJ4qF0be3j8XIZ4m6Q1lUf04Jm() == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.3FJOncK0A81yjqFj2MiftTDhO3Ew09Y8Bs91GNA685U4LNH1Cfn2uDr9B31I) {
            GL11.glRotatef(this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.8P1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh() * 360 / 16.0f, 0.0f, 1.0f, 0.0f);
        }
        else {
            final int 8p1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh = this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.8P1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh();
            float n5 = 0.0f;
            if (8p1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh == 2) {
                n5 = 180.0f;
            }
            if (8p1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh == 4) {
                n5 = 90.0f;
            }
            if (8p1MA52WsFXRYb19I8i3g8y4tS106PT09SWONxkzWkiOL1j81VZx5mE749nh == 5) {
                n5 = -90.0f;
            }
            GL11.glRotatef(n5, 0.0f, 1.0f, 0.0f);
            GL11.glTranslatef(0.0f, 0.3125f, 0.0f);
        }
        if (this.0JtjX5ETryZyHwpk0VPmyrGji3xJ7PKD0QTKuyN2xQRYuxfKjdWcB1x8g6O4 / 6 % 2 == 0) {
            this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.85V30gaDG6Xj02sL1WMJ6m7N3gebUU2eCs1PGgQQD6Xtde9DRR7P1cfb37XE = this.8Bj26GCy2ZngD8c5WKl8P6U0Wyve5xv44k6g1phwLN6iY2WCho4O2FwpG80h;
        }
        50PcM39TlE8N0B2bxyy5YI00m794x2Y0f23aOBkmdG37AHUDE4XMj3v78TWzz20C5l79Dygp2wJlh1Jd73Z48447lkLIN6iaWKTT46.3WreG121nf0O8uWON2gD7jWzn3TtTikfJZ4sI7S6oVEM2jjkIt51o6DdC6EA.5p9DvVvCX9HA3RRBhH46015tQ00S1TT6Q6D8yf4z3s8Q9xbjhubZ2YNfq150(this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3, -0.5, -0.75, -0.5, 0.0f);
        this.2q135qupQY2lcg1SJ2s8CfUE10a190jRwX90iosEsMbSRaD4vOlKhL8Q02D3.85V30gaDG6Xj02sL1WMJ6m7N3gebUU2eCs1PGgQQD6Xtde9DRR7P1cfb37XE = -1;
        GL11.glPopMatrix();
        super.9zr0Ft7ATwYEg4elWEB8ucyDaj2700KJgZB3Cc51d8vF03zOM52iOvWHcrR5(n, n2, n3);
    }
}
