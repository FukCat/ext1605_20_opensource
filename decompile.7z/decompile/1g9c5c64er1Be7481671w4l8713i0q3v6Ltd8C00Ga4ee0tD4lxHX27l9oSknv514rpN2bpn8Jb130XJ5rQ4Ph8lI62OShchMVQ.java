// 
// Decompiled by Procyon v0.6.0
// 

public class 1g9c5c64er1Be7481671w4l8713i0q3v6Ltd8C00Ga4ee0tD4lxHX27l9oSknv514rpN2bpn8Jb130XJ5rQ4Ph8lI62OShchMVQ
{
    public final byte[] 2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU;
    
    public 1g9c5c64er1Be7481671w4l8713i0q3v6Ltd8C00Ga4ee0tD4lxHX27l9oSknv514rpN2bpn8Jb130XJ5rQ4Ph8lI62OShchMVQ(final int n) {
        this.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU = new byte[n >> 1];
    }
    
    public 1g9c5c64er1Be7481671w4l8713i0q3v6Ltd8C00Ga4ee0tD4lxHX27l9oSknv514rpN2bpn8Jb130XJ5rQ4Ph8lI62OShchMVQ(final byte[] 2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU) {
        this.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU = 2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU;
    }
    
    public int 6NDQZ279aA35RAAcvrwNf551m5uCxuz3nLoAE4R5O5C7SFSYIJ283EnjEL0m(final int n, final int n2, final int n3) {
        final int n4 = n << 11 | n3 << 7 | n2;
        final int n5 = n4 >> 1;
        return ((n4 & 0x1) == 0x0) ? (this.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU[n5] & 0xF) : (this.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU[n5] >> 4 & 0xF);
    }
    
    public void 493RggokAg7F1PytzXg4zR6GOSCVMIUkS3WxpJR06xKZqxKJUkSz5vrKMjKQ(final int n, final int n2, final int n3, final int n4) {
        final int n5 = n << 11 | n3 << 7 | n2;
        final int n6 = n5 >> 1;
        if ((n5 & 0x1) == 0x0) {
            this.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU[n6] = (byte)((this.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU[n6] & 0xF0) | (n4 & 0xF));
        }
        else {
            this.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU[n6] = (byte)((this.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU[n6] & 0xF) | (n4 & 0xF) << 4);
        }
    }
    
    public boolean 2X1E5aT1n6KknKs5ID1GW8Xwe6PI938XL1l4W8XcU4u3SO8i9Al3bS5EzHEi() {
        return this.2qJmXbD7pIj51567xH8s8do34al46ZlD85d5uCwBvXM2G71g6icxNIG8LttU != null;
    }
}
