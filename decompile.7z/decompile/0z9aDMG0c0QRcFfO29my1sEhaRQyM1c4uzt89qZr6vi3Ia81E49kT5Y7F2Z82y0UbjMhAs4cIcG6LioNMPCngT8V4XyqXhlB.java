// 
// Decompiled by Procyon v0.6.0
// 

public class 0z9aDMG0c0QRcFfO29my1sEhaRQyM1c4uzt89qZr6vi3Ia81E49kT5Y7F2Z82y0UbjMhAs4cIcG6LioNMPCngT8V4XyqXhlB implements 6Xshyu98BPKD0Kj2ysQ0pQPP3OrJj1w2t5T0uPrGog033gntT8UTcBftyFyvZHgyra2lx4a1692nuiLk581IYI8n94RXWk8Ry
{
    @Override
    public double 39mJVmq3bl4dbH51995p9tocRB43bFXruO32GkxVTy54fzIxdy5dt9OeTC2A(final int n, final int n2, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer layer) {
        return 0.0;
    }
    
    @Override
    public double 4hoZRS129yUan88AHp1ksCfja1h93mYKfFda82Qtd8pqKm7G4bgpnYsijiMu(final int n, final int n2, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer layer) {
        return 0.0;
    }
    
    @Override
    public 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl 7j1lR4019pucW00n7wn38afjBd62vEMB6B6SVB9068f4kyPzw4E6wI65ufr8(final int n, final int n2, final 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.Layer layer) {
        return 5ivWu5fw81lFMju719L22Mulv8zG27JoVOLR8YJ449815zjXt9yq6P1W2j4mAr7cr5vz8iYBvRPyA8oeO7yrs5U8vBW888dl.2dCM22Pc7rV0IQo46JM3ja84x9AHCGNPeSCDVFoTi3969B8hv2sM7nr6o61r(0.0, 0.0, layer);
    }
}
