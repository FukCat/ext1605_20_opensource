import net.minecraft.client.Minecraft;

// 
// Decompiled by Procyon v0.6.0
// 

public class 8t9rS75g22igGMqdfHw4bakI3bn47943YArm99JKjxCT4UtzR40Gyk2ZA41MUxP0129jV4yP8Bq9AKJptnK1MuRns0ohd36DF6v extends Thread
{
    private final Minecraft 69x4v6H5i9ri158NSDwY3Lyb7ELd7B19em377C58smaJfhTn394086G2QC1H;
    
    public 8t9rS75g22igGMqdfHw4bakI3bn47943YArm99JKjxCT4UtzR40Gyk2ZA41MUxP0129jV4yP8Bq9AKJptnK1MuRns0ohd36DF6v(final Minecraft 69x4v6H5i9ri158NSDwY3Lyb7ELd7B19em377C58smaJfhTn394086G2QC1H) {
        this.69x4v6H5i9ri158NSDwY3Lyb7ELd7B19em377C58smaJfhTn394086G2QC1H = 69x4v6H5i9ri158NSDwY3Lyb7ELd7B19em377C58smaJfhTn394086G2QC1H;
    }
    
    @Override
    public void run() {
        while (true) {
            final 0hAIC3TYFFRBw7X27377CB8mov7mOuK3ZuV6ofmix4NppPrBNqiUSiSy41S31Fvfz9jH1tpIf87stMiKd1Sp5T9snFpPbN 1FtenBjtbWTQMx7w9NQ2pQqFxhc78G5Djz3ghM24o7Tc21uHI6Cx8s0PaRpG = this.69x4v6H5i9ri158NSDwY3Lyb7ELd7B19em377C58smaJfhTn394086G2QC1H.1FtenBjtbWTQMx7w9NQ2pQqFxhc78G5Djz3ghM24o7Tc21uHI6Cx8s0PaRpG;
            if (!1FtenBjtbWTQMx7w9NQ2pQqFxhc78G5Djz3ghM24o7Tc21uHI6Cx8s0PaRpG.0Q48c7Q5B51VmKR6v879976kWbp8F737S8T15SyjAj664KVBIuoLfz0qRtAW()) {
                break;
            }
            try {
                Thread.sleep(10L);
            }
            catch (final Exception ex) {}
            1FtenBjtbWTQMx7w9NQ2pQqFxhc78G5Djz3ghM24o7Tc21uHI6Cx8s0PaRpG.718z1OJ9VakHqRSuN9qHt03I9336Di6o7ObA2RkDlwQ9KQzNeZ53VZA8sC69();
        }
    }
}
