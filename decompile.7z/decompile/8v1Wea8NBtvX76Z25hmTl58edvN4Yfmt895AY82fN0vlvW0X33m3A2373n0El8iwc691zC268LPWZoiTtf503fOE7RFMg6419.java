import java.util.Collection;
import java.io.DataInput;
import java.io.IOException;
import java.util.Iterator;
import java.io.DataOutput;
import java.util.HashMap;
import java.util.Map;

// 
// Decompiled by Procyon v0.6.0
// 

public class 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 extends 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi
{
    private Map<String, 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi> 493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G;
    
    public 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419() {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G = new HashMap<String, 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi>();
    }
    
    @Override
    void 7OU3N2lgEecd9p9DtAmaF5EwE4f0u28Oaa9zcxqnm3XW1bDsPewY15rIFs80(final DataOutput dataOutput) throws IOException {
        final Iterator<03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi> iterator = this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.values().iterator();
        while (iterator.hasNext()) {
            03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi.78J371L0tO529ZkE8c9oYbZ1V4VtvwmXY8SqyrOhkx0OrNxa9X2sjgw70byi(iterator.next(), dataOutput);
        }
        dataOutput.writeByte(0);
    }
    
    @Override
    void 96fSDIRBY01vu6bNpWo4KQJG8fCN2WIew9WR04d4yvq9Lxko60PpMIEkyn00(final DataInput dataInput) throws IOException {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.clear();
        03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi 5ldnVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814;
        while ((5ldnVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814 = 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi.5LDNVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814(dataInput)).3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr() != 0) {
            this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(5ldnVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814.1bXdxI1r44PJ8H3Al9yKRQUvLOdXu12zCf91TjxP6d3yYuCbub216zk5B9xc(), 5ldnVyd2pmowX1DSG8ngM5pR3H5jJV40rIfaVh6JqRUcI9Czr9VIMYjOE814);
        }
    }
    
    public Collection<03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi> 7Nmdbr2ySWTWPYBjFFp2Pj5o350YfKPz3M4LF0Uy1488hQ70sr9S06Q7XbE6() {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.values();
    }
    
    @Override
    public byte 3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr() {
        return 10;
    }
    
    public void 4rFZR656C2J6KAokVeC6rx53FteIkH749jR6M84UHBMgX25fddfsA1eK9S1C(final String s, final 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi.6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 81He1bIIJJMR8zvF6lGeBPhKdpx7LcUtklc0GzUbEzVBztQ35S9k0M2U3R9h(final String s, final byte b) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, new 7eh6ri0t9ycCp8J7L2hLcpxyx60qg0pLnKkXo51739KRIBwUj6gXgu6C5veRwhFJ97P9a3Q85E2k1TnCo0ab2Y7ZdM1keD6(b).6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 4187VfOMhaao03wXG5C9NjLjSfpR57ffgaJ3cqGdn1bCw89TT81979V15GRg(final String s, final short n) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, new 71JZdqce1m9979i3cSBBlOj3ETTvHGDPSWO291hY4ds9z4R7UJ0T2V1rNWb7twoV1Tf9MH0frb0MPpjV7R84FayCU8r3366qF3FCbom1H(n).6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 6kL0Mx1R6k8Wg2Ectkqdi9vX18WxTjhoRxVGiLxG8FNlkx2gT9D39wYEYN6Y(final String s, final int n) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, new 5vLi42tz24A1bKSOsig3qqCTWQJ6JU22J1RtQm2UWWOXkk3bkZ24aN8A7pIf8W41hLW8pdXSEswAGTbMo4Suk6TmvHH9dV4OhrU(n).6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 8KB79zX3AGN4bUK1uftZEgW09nWDo6r73iOIxRFY559O4T4qQ2LEvtvuAPXI(final String s, final long n) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, new 5mF38RZ5Q1L89Hl3rVDp829qxQ86dKNS3ayHb2CTCpLo55OMoBi9019b6ETd8Y90m89QuQpcEnae3jHohQBnPO9Rf7k15l(n).6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 8777PHZOS4HEgA5u6Tbf9H849TkcEjVYjHwspeqZ5i336sE91grlBH441X24(final String s, final float n) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, new 09Khv82el60zcD4X75muqO07J4UCSBbGjrciEn701oHQ424aXL3f7qy41XSva67YQCnM46P1kh2a0wsS92Pe05yy3Rpk0572n(n).6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 3xYiVy0Vnx17gt4Xk4cbfNncrpWgY5ZTKHtpZw2VGSS9Twl4l7UaTt5rLJsI(final String s, final double n) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, new 20vQdcXWP2tdq36Nqw3EFGw0qUYN96832lkzEzf8gd2S1DkJpqVeZI1k9XL0Swqa7r1ny7P9tX47F8H11ycA4I066jGQ5TW8Ab(n).6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 1rxP9ETV7dgs884Atc9ka25qP61xCkUpbS9MY1eLrS3umivXLz7efvG80ePC(final String s, final String s2) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, new 5320B5B2PAe1Msr7UU0iIN551u42U9hRsa5VP260D729PAz32nhTE5lhHX7upTAB1P7wW6jq7894K4ABR3SNw45C3si50Ldou5Ux12(s2).6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 87m34ujrlf8Oy11KcO1u0bOu2htWJM2bt6DTp7cshM6aNd71Zs1O98chdHgz(final String s, final byte[] array) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, new 3k7fks2663LUy0ues29Fx7SaYSSvMXM4l89hG8z0T5vi9m60Qmi1Az50Gvoe8014U15R85MFw0sp4kiyAnFPv3XCdb9j(array).6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 178D23GfRft9nJ2b514lwP0yB1kafaY4407IB0Z3776YdInSq2Vc0TDP8ULo(final String s, final 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419) {
        this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.put(s, 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419.6ZP4X6oD41dsJ1oGd437Mr3m1j3923qk0u9WN0oFT0X54cIGduhS08Y29Zgo(s));
    }
    
    public void 3R2j00845aDHtp6faw6Q8P2POC79nYQlMiqrjo9i1bcX7TU4im1fZCr4HRb1(final String s, final boolean b) {
        this.81He1bIIJJMR8zvF6lGeBPhKdpx7LcUtklc0GzUbEzVBztQ35S9k0M2U3R9h(s, (byte)(b ? 1 : 0));
    }
    
    public boolean 9KYye1q32g6ikPIa5h6X24xR74KlJnN7ozIq1Zrg1zu3mm32Y8F139EIz3Ev(final String s) {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s);
    }
    
    public byte 9mkVY0mC11hsL93HPki34E3IL4pc0yM9i5e51tW7M1R7L6z5FJmcNLU66LTI(final String s) {
        return (byte)(this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s).0NYkuWw75sX68PMRr947nS18PIPw5004dqKm5dxrU87fONtExsYNS2n6rzyU : 0);
    }
    
    public short 6nPdcM4USY7O5Es6FgDuW2JoNCKhKf57jkhVU8353fn4H0v8CF3Hf33dYWa7(final String s) {
        return (short)(this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s).4S7x5m9RwvKdciD36qsIO6MGsshjFEL7XIKc0lF281D5rZ36E5UvKN0fwyVm : 0);
    }
    
    public int 8v6RTdxFq558Jfei8eLryq7v9nG0S13D93sIGU4U8GjNQ58lGoKC6LBCFRL0(final String s) {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s).7qK2j92HDR48v3J0ywhtZ02P904g3S9lpB84GJG0kttRLiTVd7HFx7Z90Q5s : 0;
    }
    
    public long 1Sr659qCY0M5cH37Ds404nB8Y5tJH0fKsB4NUUPRT70S5RD2w85B86dnEzN5(final String s) {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s).7QWfAB1154Ks8W4Uq6u8z52lAd3Q6fDQs5yJb1PEoNcV8gJytBPtV1ycEZA0 : 0L;
    }
    
    public float 0WCmn5p6d0Q8n36TYIXmO31VJYliAmxH07BCZBG0O30PK61u61V18n1vO0Fv(final String s) {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s).7bCSu2L647xiTT55nI6i5g0D9ZDV6k3prxL74xPkt7nC1B9isrC06UhM0I05 : 0.0f;
    }
    
    public double 7AQ0KPD4cyDEsGRul0qDH2bdCMZE63Ud60YhoECd25j7OWmuDO60792cy9q3(final String s) {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s).2N07oENEKn76ATH2s4H9s13SxUsCxmUfv9otar786Cz22m0831J25a5NPzyQ : 0.0;
    }
    
    public String 5XLpzXNriQ5Dd0yKNX8GcC5iRu7BpQtrUw3YvoQ4DY2M7r4LeO9V1SqeOt9m(final String s) {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s).1UBe19rU9818tEIAN2P7x38668eh2o12tTR7R800pabtP6YuUZB34Tf4b5XQ : "";
    }
    
    public byte[] 8b22sYt9fiOINw0abOiE8JWt0exb9cD2ervK0j8M3Sd0ux5I4dpoW4YsrQ26(final String s) {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s).6d0w049a3cREb8tv0023583W7Ay4K51a2G2bQsc3Y9S5Ob5m4ayA7JOY19h1 : new byte[0];
    }
    
    public 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419 2X5HaW0x84nY85GZPK3rw2W89RK5SMSqnvsNgMkiGE86K6aH89tP6PfZ3DZp(final String s) {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s) : new 8v1Wea8NBtvX76Z25hmTl58edvN4Yfmt895AY82fN0vlvW0X33m3A2373n0El8iwc691zC268LPWZoiTtf503fOE7RFMg6419();
    }
    
    public 4d42WC8IOlF5b2geal4NQk6ibJke2bs4240Y3lhJnxK7i21K1Pf54b98jw84dTo8q6xfwV0T2segbUDIqe6bax9oDWcwB 88bUF77TBdJg1fgX78V2H0j8ReA06l86iI2k5M6Z2W6AxZVA2157H2k3EZlv(final String s) {
        return this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.containsKey(s) ? this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.get(s) : new 4d42WC8IOlF5b2geal4NQk6ibJke2bs4240Y3lhJnxK7i21K1Pf54b98jw84dTo8q6xfwV0T2segbUDIqe6bax9oDWcwB();
    }
    
    public boolean 6u70dUA8gTNAuFm8BlKCl2kH8tI9KgtnGQElfZhmBFqoc31X79gYzzcff49p(final String s) {
        return this.9mkVY0mC11hsL93HPki34E3IL4pc0yM9i5e51tW7M1R7L6z5FJmcNLU66LTI(s) != 0;
    }
    
    @Override
    public String toString() {
        return "" + this.493BSKb79eU40AdD18U0vCn6wQn1UmzBuLg4Zqqay5x3VpR6CEV0J4pnZ73G.size() + " entries";
    }
}
