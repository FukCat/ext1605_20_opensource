import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 3d1jKLb8cfGcqAt4167966biv6J0W44J4vt6EKF1B3p71tv5id0t15S5epWR1W654i20Q7izA222k5dRwNr598UuOzETjR4soC8 extends 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC
{
    public 3d1jKLb8cfGcqAt4167966biv6J0W44J4vt6EKF1B3p71tv5id0t15S5epWR1W654i20Q7izA222k5dRwNr598UuOzETjR4soC8(final int n, final int n2) {
        super(n, n2, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.0e51g5n7QQ2bM6IT7Q28hAbJkebnbMOVd3lRo7XioWLAkvTHV9DQxASpl4S7);
    }
    
    @Override
    public int 8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(final int n) {
        return (n <= 1) ? 4 : this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41;
    }
    
    @Override
    public int 6M14lZVXL6xs4lKY6vj11vAQ2E9U9ZDOF0Nh9aCHYAlz8F6Pfx930Z7gxmzf(final Random random) {
        return 0;
    }
}
