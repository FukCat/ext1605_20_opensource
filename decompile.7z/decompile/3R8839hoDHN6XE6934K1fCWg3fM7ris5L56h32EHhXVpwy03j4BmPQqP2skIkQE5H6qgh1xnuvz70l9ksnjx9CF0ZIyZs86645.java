// 
// Decompiled by Procyon v0.6.0
// 

public class 3R8839hoDHN6XE6934K1fCWg3fM7ris5L56h32EHhXVpwy03j4BmPQqP2skIkQE5H6qgh1xnuvz70l9ksnjx9CF0ZIyZs86645 extends 55XXM28b6p84b4G2l6B1InnTc701h21NG7n6pZPb2RkqeSGMf12ZMp058OFNNJP04Q3WjX0S3IEUdu0p0YkM1TMGm5WXG2Nme6
{
    public 3R8839hoDHN6XE6934K1fCWg3fM7ris5L56h32EHhXVpwy03j4BmPQqP2skIkQE5H6qgh1xnuvz70l9ksnjx9CF0ZIyZs86645(final int n, final int 6w5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H) {
        super(n, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.5VIqxS8QiV686T0mkWE5UjNSgm9pGGyfV565gwInxD8w206h9M2Q59Ckujvj);
        this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H = 6w5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H;
    }
    
    @Override
    public int 2b1pbetRmJyaMfSXs7k02a96ZB84GA6lI6KnMBwqDWfFcMKEifg20ytG350E(final int n) {
        if (n == 1) {
            return this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H - 16;
        }
        if (n == 0) {
            return this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H + 16;
        }
        return this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H;
    }
}
