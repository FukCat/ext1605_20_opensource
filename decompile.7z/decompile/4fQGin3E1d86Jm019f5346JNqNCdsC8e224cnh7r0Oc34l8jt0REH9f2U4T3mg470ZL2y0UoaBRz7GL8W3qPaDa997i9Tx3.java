import java.awt.Graphics;
import java.awt.image.DataBufferInt;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.image.BufferedImage;

// 
// Decompiled by Procyon v0.6.0
// 

public class 4fQGin3E1d86Jm019f5346JNqNCdsC8e224cnh7r0Oc34l8jt0REH9f2U4T3mg470ZL2y0UoaBRz7GL8W3qPaDa997i9Tx3 implements 1yvTo5vLKhtZ8Jdf75TPzqWv5K5FAzIHa4r19RT64mMh13Pj2aH0VKS6mi433493GrZdkE65w9B85LU6qAlbS6G55i1q0
{
    private int[] 1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC;
    private int 4mXW209UmCEdG11lBA7U9tVj2T1801YznuMQO695N5s0nGEIo3nT6gU6o3Em;
    private int 6s099fR0u84owa9DVzd9bsqCk0QJWFgdvjsClOpop5U42df4pZcAj9J7b8g6;
    
    @Override
    public BufferedImage 5zpderewV3x1X6sDa6TS2B2RfCzwfHSc6W7OdKR4j9EtS2r2WS940VAdQvh0(final BufferedImage bufferedImage) {
        if (bufferedImage == null) {
            return null;
        }
        this.4mXW209UmCEdG11lBA7U9tVj2T1801YznuMQO695N5s0nGEIo3nT6gU6o3Em = 64;
        this.6s099fR0u84owa9DVzd9bsqCk0QJWFgdvjsClOpop5U42df4pZcAj9J7b8g6 = 32;
        final BufferedImage bufferedImage2 = new BufferedImage(this.4mXW209UmCEdG11lBA7U9tVj2T1801YznuMQO695N5s0nGEIo3nT6gU6o3Em, this.6s099fR0u84owa9DVzd9bsqCk0QJWFgdvjsClOpop5U42df4pZcAj9J7b8g6, 2);
        final Graphics graphics = bufferedImage2.getGraphics();
        graphics.drawImage(bufferedImage, 0, 0, null);
        graphics.dispose();
        this.1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC = ((DataBufferInt)bufferedImage2.getRaster().getDataBuffer()).getData();
        this.6brUM7ZGaH4Qs68Ja6VesV1QPXN2xTgOF6p4bmJhImWBrQ3100Ji23yt02XE(0, 0, 32, 16);
        this.7gBkAywIp0El9t9dnOlBlY1gBu97V157LGBayloBYHo7IIiqw7W98AmqRgn2(32, 0, 64, 32);
        this.6brUM7ZGaH4Qs68Ja6VesV1QPXN2xTgOF6p4bmJhImWBrQ3100Ji23yt02XE(0, 16, 64, 32);
        boolean b = false;
        for (int i = 32; i < 64; ++i) {
            for (int j = 0; j < 16; ++j) {
                if ((this.1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC[i + j * 64] >> 24 & 0xFF) < 128) {
                    b = true;
                }
            }
        }
        if (!b) {
            for (int k = 32; k < 64; ++k) {
                for (int l = 0; l < 16; ++l) {
                    if ((this.1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC[k + l * 64] >> 24 & 0xFF) < 128) {}
                }
            }
        }
        return bufferedImage2;
    }
    
    private void 7gBkAywIp0El9t9dnOlBlY1gBu97V157LGBayloBYHo7IIiqw7W98AmqRgn2(final int n, final int n2, final int n3, final int n4) {
        if (!this.5uVU9MQ2rUx05H31Jood8lWqAVd0A9rUtJJ7rCUTYAZ0mh556WRAd2fKgyu7(n, n2, n3, n4)) {
            for (int i = n; i < n3; ++i) {
                for (int j = n2; j < n4; ++j) {
                    final int[] 1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC = this.1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC;
                    final int n5 = i + j * this.4mXW209UmCEdG11lBA7U9tVj2T1801YznuMQO695N5s0nGEIo3nT6gU6o3Em;
                    1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC[n5] &= 0xFFFFFF;
                }
            }
        }
    }
    
    private void 6brUM7ZGaH4Qs68Ja6VesV1QPXN2xTgOF6p4bmJhImWBrQ3100Ji23yt02XE(final int n, final int n2, final int n3, final int n4) {
        for (int i = n; i < n3; ++i) {
            for (int j = n2; j < n4; ++j) {
                final int[] 1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC = this.1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC;
                final int n5 = i + j * this.4mXW209UmCEdG11lBA7U9tVj2T1801YznuMQO695N5s0nGEIo3nT6gU6o3Em;
                1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC[n5] |= 0xFF000000;
            }
        }
    }
    
    private boolean 5uVU9MQ2rUx05H31Jood8lWqAVd0A9rUtJJ7rCUTYAZ0mh556WRAd2fKgyu7(final int n, final int n2, final int n3, final int n4) {
        for (int i = n; i < n3; ++i) {
            for (int j = n2; j < n4; ++j) {
                if ((this.1z1726QbD70LiLK1OIH7x9oP1qU24AjdP6E51I5f5C5UmJsSVL29s1bF4AMC[i + j * this.4mXW209UmCEdG11lBA7U9tVj2T1801YznuMQO695N5s0nGEIo3nT6gU6o3Em] >> 24 & 0xFF) < 128) {
                    return true;
                }
            }
        }
        return false;
    }
}
