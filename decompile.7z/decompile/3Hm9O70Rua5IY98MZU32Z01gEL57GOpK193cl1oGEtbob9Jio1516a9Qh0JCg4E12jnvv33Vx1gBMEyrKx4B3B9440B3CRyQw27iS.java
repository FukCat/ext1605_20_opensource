import java.util.List;
import java.io.File;

// 
// Decompiled by Procyon v0.6.0
// 

public class 3Hm9O70Rua5IY98MZU32Z01gEL57GOpK193cl1oGEtbob9Jio1516a9Qh0JCg4E12jnvv33Vx1gBMEyrKx4B3B9440B3CRyQw27iS extends 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY
{
    public 3Hm9O70Rua5IY98MZU32Z01gEL57GOpK193cl1oGEtbob9Jio1516a9Qh0JCg4E12jnvv33Vx1gBMEyrKx4B3B9440B3CRyQw27iS(final File file, final String s) {
        super(file, s);
    }
    
    public 5D3Kb3ACD4U69935L8YcgwF1Vsl27lrSRN45mVc2J7UkxF9vRf7uB29j9e524OY70E244iU0jS93597Ti1F3M0aN997g9i[] 78AQ10XbeKro228VUy47y36BUi7zwBwND394vFbuqMbs9l0BrGJ4HR96D1sI() {
        return null;
    }
    
    public List<90P0dxYV933962vrBscE8SJ47l3hwQ27nZOE7q65yy1e4746xU1hHS51Z1i9H26Ji8nFe07VXUaRlpDTbqnc6kupP2ao82> 8oADBp42n4G2Ly6U1WLv70n6VyS2bkokzo8dF7ayUqDb1A6ofY86pUJA8mf8() {
        return null;
    }
    
    public int 3aA7gqc98DXj3fwbeNnFBHBmFQuh9AhS6S07RjE8Zcd8Q4yvv0Va7R87RPn9(final long n, final long n2) {
        return 0;
    }
}
