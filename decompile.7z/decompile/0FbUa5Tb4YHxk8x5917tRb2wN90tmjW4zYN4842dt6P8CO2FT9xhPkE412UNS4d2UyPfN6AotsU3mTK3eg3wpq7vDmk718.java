// 
// Decompiled by Procyon v0.6.0
// 

public class 0FbUa5Tb4YHxk8x5917tRb2wN90tmjW4zYN4842dt6P8CO2FT9xhPkE412UNS4d2UyPfN6AotsU3mTK3eg3wpq7vDmk718 extends 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ
{
    @Override
    public boolean 3nCAcSXE24ypw0NnjcJe4d1pRapWy5WwH5u9iEFWwvgrgojP9oxn7tAFFGwk() {
        return true;
    }
    
    @Override
    public boolean 7xm2Jx0S8rI7617Ovpb5DFTezpfWmqzIiE2WYq1jc8o1SRpvc713WJ5tkWdP() {
        return false;
    }
    
    @Override
    public boolean 9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV() {
        return false;
    }
}
