import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Dimension;
import javax.swing.Box;
import java.io.IOException;
import java.awt.Font;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.imageio.ImageIO;
import java.awt.Container;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.LayoutManager;
import java.awt.FlowLayout;
import java.awt.Component;
import javax.swing.JPanel;

// 
// Decompiled by Procyon v0.6.0
// 

public class 2QvX7J3RQevmZZ0fbqxYb04Yi8M8aC2OaD61L7HQ58UQEXi7RT65EMCkamaFuTS0rI246r8DB838Tv3q3b6eZA1p67AxU9iTGpQgw7
{
    public static void 8mrizGWQ0Mh6Pp4tb49FU0IZkwN1499r0Sqo62o9pWcK97N2T9z24ygg2kGb(final JPanel panel, final Component[] array) {
        final JPanel comp = new JPanel(new FlowLayout(0));
        comp.setBackground(new Color(30, 30, 30));
        for (int length = array.length, i = 0; i < length; ++i) {
            comp.add(array[i]);
        }
        panel.add(comp);
    }
    
    public static void main(final String[] array) {
        final JFrame frame = new JFrame("\u00e2\u2014\u20201.0.16.05");
        frame.setSize(330, 210);
        final JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, 1));
        panel.setAlignmentX(0.0f);
        panel.setMaximumSize(panel.getPreferredSize());
        panel.setBackground(new Color(30, 30, 30));
        frame.add(panel);
        try {
            final JLabel label = new JLabel(new ImageIcon(ImageIO.read(1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.9P3TY758VM8951Z7q70WD5qYdKqLdB22jUqQNi8u6rFBU4uZnFfpCw0XU82v("/dirt.png")).getScaledInstance(50, 50, 2)));
            label.setText("Launcher");
            label.setForeground(Color.WHITE);
            label.setFont(new Font("Arial", 0, 30));
            8mrizGWQ0Mh6Pp4tb49FU0IZkwN1499r0Sqo62o9pWcK97N2T9z24ygg2kGb(panel, new Component[] { label });
        }
        catch (final IOException ex) {
            ex.printStackTrace();
        }
        final Box horizontalBox = Box.createHorizontalBox();
        horizontalBox.setSize(new Dimension(300, 3));
        panel.add(horizontalBox);
        final JTextField textField = new JTextField();
        textField.setPreferredSize(new Dimension(200, 20));
        final JLabel label2 = new JLabel("Player name");
        label2.setForeground(Color.WHITE);
        8mrizGWQ0Mh6Pp4tb49FU0IZkwN1499r0Sqo62o9pWcK97N2T9z24ygg2kGb(panel, new Component[] { label2, textField });
        final JTextField textField2 = new JTextField();
        textField2.setPreferredSize(new Dimension(200, 20));
        final JLabel label3 = new JLabel("Launch options");
        label3.setForeground(Color.WHITE);
        8mrizGWQ0Mh6Pp4tb49FU0IZkwN1499r0Sqo62o9pWcK97N2T9z24ygg2kGb(panel, new Component[] { label3, textField2 });
        final JButton comp = new JButton();
        comp.setText("Start");
        panel.add(comp);
        frame.setVisible(true);
    }
}
