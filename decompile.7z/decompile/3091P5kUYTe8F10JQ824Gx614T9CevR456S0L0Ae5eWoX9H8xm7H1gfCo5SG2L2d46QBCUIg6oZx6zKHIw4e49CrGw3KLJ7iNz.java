import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 3091P5kUYTe8F10JQ824Gx614T9CevR456S0L0Ae5eWoX9H8xm7H1gfCo5SG2L2d46QBCUIg6oZx6zKHIw4e49CrGw3KLJ7iNz extends 4325k26DmdDV5j1IjV8vrJo24qmGuT5bdNIPVFSKq79WjWX76Kvn9Ka2FTG9Oj8mEV9YUvbCa8k19y8M5Yv3alQH98valwFA6x4
{
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        super.5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(dataInputStream);
        this.32IePI70ogeJpKwlw99WMbygHnX7iquc00HHszN008hEOF6C06fbvoR7bxIV = dataInputStream.readByte();
        this.55K97y551O34c270aFA8fuBwB9Z3h3M5T4u9shhaW8Vi7vH5ePeFf295bXno = dataInputStream.readByte();
        this.4bfk3jX8Cka91MqwpVL5YCz1YQF0Rd1X8d1ddI9yu2962ygg3rWzwN17l792 = dataInputStream.readByte();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        super.45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(dataOutputStream);
        dataOutputStream.writeByte(this.32IePI70ogeJpKwlw99WMbygHnX7iquc00HHszN008hEOF6C06fbvoR7bxIV);
        dataOutputStream.writeByte(this.55K97y551O34c270aFA8fuBwB9Z3h3M5T4u9shhaW8Vi7vH5ePeFf295bXno);
        dataOutputStream.writeByte(this.4bfk3jX8Cka91MqwpVL5YCz1YQF0Rd1X8d1ddI9yu2962ygg3rWzwN17l792);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 7;
    }
}
