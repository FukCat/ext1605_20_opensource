// 
// Decompiled by Procyon v0.6.0
// 

public class 482OYQz81kD01ly0z3m0n0OLYUW17902236362FWPtSN680B94NJ6m3uU51kM0j8S7sHTSnrzaxfc0DBqm5ME13f3K6b1L7My extends 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC
{
    protected 482OYQz81kD01ly0z3m0n0OLYUW17902236362FWPtSN680B94NJ6m3uU51kM0j8S7sHTSnrzaxfc0DBqm5ME13f3K6b1L7My(final int n) {
        super(n, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.5WF5oX9aUEBL77ccYN2TXJTrVT509u4kr62y2VQ7i4qLtf61163yUapLBxEF);
        this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41 = 48;
    }
    
    @Override
    public void 9zlUsEN0b02n1ta8xaI01Pe74R276mX3pR23289wdn9e5XzJQdaDzuPCj2QL(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        for (int n4 = 2, i = n - n4; i <= n + n4; ++i) {
            for (int j = n2 - n4; j <= n2 + n4; ++j) {
                for (int k = n3 - n4; k <= n3 + n4; ++k) {
                    if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(i, j, k) == 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.48vJoOIJt15P5mCD3szk3QoP21Ya9f5381N237U51K027s0J0H87b0ZD496P) {}
                }
            }
        }
    }
    
    @Override
    public void 8qD29hufvNapctrhFKbzZTP9xZ90te8ulRO3PkpoG9ygH2gpXw89usJK4GL3(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        for (int n4 = 2, i = n - n4; i <= n + n4; ++i) {
            for (int j = n2 - n4; j <= n2 + n4; ++j) {
                for (int k = n3 - n4; k <= n3 + n4; ++k) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2o8y6Ygcs7HA37YDck69dX5RfMWU2tEV0S4YF3qT4at5b6kUrDkO426732Ca(i, j, k, 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(i, j, k));
                }
            }
        }
    }
}
