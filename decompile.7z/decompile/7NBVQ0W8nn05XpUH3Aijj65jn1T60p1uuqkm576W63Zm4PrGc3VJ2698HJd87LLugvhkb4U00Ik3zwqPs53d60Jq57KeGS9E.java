import org.lwjgl.input.Keyboard;

// 
// Decompiled by Procyon v0.6.0
// 

public class 7NBVQ0W8nn05XpUH3Aijj65jn1T60p1uuqkm576W63Zm4PrGc3VJ2698HJd87LLugvhkb4U00Ik3zwqPs53d60Jq57KeGS9E extends 3JtyNvNqN9kLf4RFXz7Fi009OPt48kRSSvJ552I1qLHaDizfWTpAD2ZjN7091Uy4jlGaMN9V1zt5UjrbVzvKgfqCpGj68S7D
{
    private String 3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u;
    private int 1RGx682dPmDyrA6yaPNaoM6y232VbptfCLbQTPSijyR3iKTyq721u0p309bc;
    
    public 7NBVQ0W8nn05XpUH3Aijj65jn1T60p1uuqkm576W63Zm4PrGc3VJ2698HJd87LLugvhkb4U00Ik3zwqPs53d60Jq57KeGS9E() {
        this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u = "";
        this.1RGx682dPmDyrA6yaPNaoM6y232VbptfCLbQTPSijyR3iKTyq721u0p309bc = 0;
    }
    
    @Override
    public void 4An20JYjYn5ahp07NQmWFCuC33T53X6s4pd5325t5MV2inUXBh7is28o5l1C() {
        Keyboard.enableRepeatEvents(true);
    }
    
    @Override
    public void 43zN406CnnMvKt50m1T5x9TK6olZW559Ze5Um8SL6U0pyu07041JesDT1Mts() {
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    public void 79dcDBX8wOiJ7P492Y177gZw78gOSlsV8lxmDRioLVlEh14o5HL6Utyo3Gfq() {
        ++this.1RGx682dPmDyrA6yaPNaoM6y232VbptfCLbQTPSijyR3iKTyq721u0p309bc;
    }
    
    @Override
    protected void 27HH93i69891UR8scaUy8Wa381SrOHnrgz1395TWPN543Aw65UPU60a9U5op(final char c, final int n) {
        if (n == 1) {
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(null);
        }
        else if (n == 28) {
            if (this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.trim().length() > 0) {
                this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.8m10eD4o1nI4Yvt03uA2QMfUSGy4I2qp5qLsfQsDidFNBgCWTWjd2T5zayR5.231gCaejfJ6cL74n5Je6m3mTJIUPH9m5CbNuj5N4ke6b1Afnf4QzNJeGv8B0(this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.trim());
                1WAt54cM2S9HXBE2tf8vYm3Ind025Sf2dsQX7QMLl5G8NnHoRiW1ncB7Owy2FMxwF68U3LMu8o452Ucs6r4G9svQ91OCmip.0Cm3s8rw0zOT4712xCTQWMpeI3bbCAHMip9u9GiDRqZ5fikPZiqtu59Ne1rL.8RE0128kf7wva064sQUJOS8L9G3w5V9gk0Qrz52s0qWi1q3KB37727x8PLKw("dc:" + this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u);
            }
            this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.6d2Q962XavWIyK2mppq0vU2tlSu9moK4ckx8NlHiW64kcoOn5G8qHAgY284G(null);
        }
        else {
            if (n == 14 && this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.length() > 0) {
                this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u = this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.substring(0, this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.length() - 1);
            }
            if (" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~\u2302\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8?\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1??????????".indexOf(c) >= 0 && this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.length() < 100) {
                this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u += c;
            }
        }
    }
    
    @Override
    public void 9zr0Ft7ATwYEg4elWEB8ucyDaj2700KJgZB3Cc51d8vF03zOM52iOvWHcrR5(final int n, final int n2, final float n3) {
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.0zEK7Ya35KrGoBUefz5kDC2FtMvEeQ0VZd705ddMg5qu7RhW9J01B4TC6J6C(2, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b - 14, this.7D1F92H3H1s2I819zA5xfH1J4dqlQXK8iftRRxU738A8yYBxlg5nKCr80f6s - 2, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b - 2, Integer.MIN_VALUE);
        38CnN321GxNbFp2q11TJ3rPrSZJj7L8Fp8629ctHWkbJOKg6N5vE742WMdRPkhsRPB1jzh2Q8hxRz7vY77F6WBlc91iF2dKLRBrzu.40nlkVV0D2719pTGAy1jN1I63gaF6u9MTwQpPudv3why207rwi3fGT4Lc1Pa(this.56952p8MDR6qjywXK83j3Y9gs3Y0yeaDqYfM0KgdrfxS1pq1qDz2u4NrAYLZ, "> " + this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u + ((this.1RGx682dPmDyrA6yaPNaoM6y232VbptfCLbQTPSijyR3iKTyq721u0p309bc / 6 % 2 == 0) ? "_" : ""), 4, this.1ZGU6EBHzCc98fxJx4g21FATakQ2ML03Oz8QcKG0g5164tdb2mn90Q581Z8b - 12, 14737632);
    }
    
    @Override
    protected void 1Nwq9X5O6zB3l5Q6jlp7vRyJCy003716XQtYd21t186l1xHxa83OF67TpS6Q(final int n, final int n2, final int n3) {
        if (n3 == 0 && this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.2w11sSa7Bs9LcLsC7934u93KQ7ddy7D30Qm40R9Tadk9wwIXYd41bvx16wT6.89909916ME58p8KX3952Ka8p95x7wx4M2w4bb34045k10E7Bxs7hx2N9ganm != null) {
            if (this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.length() > 0 && !this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.endsWith(" ")) {
                this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u += " ";
            }
            this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u += this.9Ub2scmFm24PA95AiyDk3w4l4S8rO1HWqn83Xi65E7H1r5r0mt4Zc36Az8kr.2w11sSa7Bs9LcLsC7934u93KQ7ddy7D30Qm40R9Tadk9wwIXYd41bvx16wT6.89909916ME58p8KX3952Ka8p95x7wx4M2w4bb34045k10E7Bxs7hx2N9ganm;
            final int endIndex = 100;
            if (this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.length() > endIndex) {
                this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u = this.3gwpNpAN6dKg8Q4Qhm66Ys35dUHgmIx9o53Y41G9iLIJr3sU42hRdycPV77u.substring(0, endIndex);
            }
        }
    }
}
