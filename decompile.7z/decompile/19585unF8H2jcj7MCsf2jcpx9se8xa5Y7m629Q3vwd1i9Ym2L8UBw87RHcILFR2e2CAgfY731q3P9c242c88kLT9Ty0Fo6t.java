import org.lwjgl.opengl.GLContext;

// 
// Decompiled by Procyon v0.6.0
// 

public class 19585unF8H2jcj7MCsf2jcpx9se8xa5Y7m629Q3vwd1i9Ym2L8UBw87RHcILFR2e2CAgfY731q3P9c242c88kLT9Ty0Fo6t
{
    private static boolean 5910jib0Lx46jN1H7v5iuZH1Q1817X72D0Gn1Nlq9763XfSU3QixUg0Z165A;
    
    public boolean 29yUTsNwkpa9JfkF05p3U24nqisnNxyNhtS7s3I2vXM2hV6VeffTx42r9W6J() {
        return 19585unF8H2jcj7MCsf2jcpx9se8xa5Y7m629Q3vwd1i9Ym2L8UBw87RHcILFR2e2CAgfY731q3P9c242c88kLT9Ty0Fo6t.5910jib0Lx46jN1H7v5iuZH1Q1817X72D0Gn1Nlq9763XfSU3QixUg0Z165A && GLContext.getCapabilities().GL_ARB_occlusion_query;
    }
    
    static {
        19585unF8H2jcj7MCsf2jcpx9se8xa5Y7m629Q3vwd1i9Ym2L8UBw87RHcILFR2e2CAgfY731q3P9c242c88kLT9Ty0Fo6t.5910jib0Lx46jN1H7v5iuZH1Q1817X72D0Gn1Nlq9763XfSU3QixUg0Z165A = false;
    }
}
