import java.util.Objects;

// 
// Decompiled by Procyon v0.6.0
// 

public class 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3
{
    public int 8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM;
    public int 0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174;
    
    public 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3(final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3) {
        this(61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM, 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174);
    }
    
    public 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3(final int 8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM, final int 0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174) {
        this.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM = 8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM;
        this.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174 = 0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174;
    }
    
    public int 5ZR6ielH0gxIT8YmA1m4F65rkWUs4cP2723lV4Hy6tl6rO7opLrvOyTWthww() {
        return this.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM;
    }
    
    public int 47IAru15P2DzBMMdHFDJNZXRKMMGzW0ZSLEGX87l25z9CdPzg63Pq5T04vvr() {
        return this.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174;
    }
    
    public 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 2wwtPfGg0JGJPRvt877jq70T0XUQ8Uck2igW1QUed3TPLGg765xcKBkexT3A(final int n) {
        return new 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3(this.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM * n, this.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174 * n);
    }
    
    public void 0t72uE0X6e9X1lk504mMn0Usl2040LLyJIqoCM5A8QY4qQ7Bui0LPvUn4qLg(final int n, final int n2) {
        this.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM += n;
        this.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174 += n2;
    }
    
    public 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 43cW0BG7D6e15UgFxhYIhnbmvR9R0GKm0lZwapr276d869pJ379mWCc345jT(final int n, final int n2) {
        return new 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3(this.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM + n, this.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174 + n2);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3)) {
            return false;
        }
        final 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3 = (61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3)o;
        return this.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM == 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM && this.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174 == 61bqrHDP9YdMp07z5iABWtMK66t4gcvjql3dTcp0J4v61Wuvvw3MdEOM7lNr9AGis7r2odCsX9s05wc3f7aM3l1ogYNoot3.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.8lC0vu3ZWMb5RN6uf3yOxqcTF6il1w83697KcOEhd66eGI1Wh3lPZPcE05RM, this.0bm3C9QEP6bCapmYMP36ISZ8F3a48ODO4a58xz6U9hA99ZZj4RI1S24iD174);
    }
}
