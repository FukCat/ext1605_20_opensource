import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 4fk1yZl15mKbNm8QhkL4XjZ0DBFgh6r779AsC4K87vOP6l05f21BH69fjWB0tmGzzXgSMy6V7nw4D66RkH4OygOS1W3ASz9sry extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 41SOjLbJkcYg135tROnpbb98261Rg06o8gwqKlquzW5Xl4Gd6a71731yHPdo;
    public int 35R096iII61kQHz6TOX68XMH5nPEj8U7Ncf8L2Jmyz8JiEHKsi4YF8sJB8sy;
    public int 4BV3gR973ewVaMVIgMop5xq3la3tpMZ74351x250rhmK9h3i7dbTTPPvjV8M;
    public int 7XK40Z3498a65VnT386o5R3R45kdJyQN68g7bD8fjZMtd870278TqEAH9H3S;
    public int 34L0KePPJ95iIKPu3Xv2mZ47b0j828t11213K6I71N1aDcx34mx02Z13281u;
    
    public 4fk1yZl15mKbNm8QhkL4XjZ0DBFgh6r779AsC4K87vOP6l05f21BH69fjWB0tmGzzXgSMy6V7nw4D66RkH4OygOS1W3ASz9sry() {
    }
    
    public 4fk1yZl15mKbNm8QhkL4XjZ0DBFgh6r779AsC4K87vOP6l05f21BH69fjWB0tmGzzXgSMy6V7nw4D66RkH4OygOS1W3ASz9sry(final int 34L0KePPJ95iIKPu3Xv2mZ47b0j828t11213K6I71N1aDcx34mx02Z13281u, final int 41SOjLbJkcYg135tROnpbb98261Rg06o8gwqKlquzW5Xl4Gd6a71731yHPdo, final int 35R096iII61kQHz6TOX68XMH5nPEj8U7Ncf8L2Jmyz8JiEHKsi4YF8sJB8sy, final int 4bv3gR973ewVaMVIgMop5xq3la3tpMZ74351x250rhmK9h3i7dbTTPPvjV8M, final int 7xk40Z3498a65VnT386o5R3R45kdJyQN68g7bD8fjZMtd870278TqEAH9H3S) {
        this.34L0KePPJ95iIKPu3Xv2mZ47b0j828t11213K6I71N1aDcx34mx02Z13281u = 34L0KePPJ95iIKPu3Xv2mZ47b0j828t11213K6I71N1aDcx34mx02Z13281u;
        this.41SOjLbJkcYg135tROnpbb98261Rg06o8gwqKlquzW5Xl4Gd6a71731yHPdo = 41SOjLbJkcYg135tROnpbb98261Rg06o8gwqKlquzW5Xl4Gd6a71731yHPdo;
        this.35R096iII61kQHz6TOX68XMH5nPEj8U7Ncf8L2Jmyz8JiEHKsi4YF8sJB8sy = 35R096iII61kQHz6TOX68XMH5nPEj8U7Ncf8L2Jmyz8JiEHKsi4YF8sJB8sy;
        this.4BV3gR973ewVaMVIgMop5xq3la3tpMZ74351x250rhmK9h3i7dbTTPPvjV8M = 4bv3gR973ewVaMVIgMop5xq3la3tpMZ74351x250rhmK9h3i7dbTTPPvjV8M;
        this.7XK40Z3498a65VnT386o5R3R45kdJyQN68g7bD8fjZMtd870278TqEAH9H3S = 7xk40Z3498a65VnT386o5R3R45kdJyQN68g7bD8fjZMtd870278TqEAH9H3S;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.34L0KePPJ95iIKPu3Xv2mZ47b0j828t11213K6I71N1aDcx34mx02Z13281u = dataInputStream.read();
        this.41SOjLbJkcYg135tROnpbb98261Rg06o8gwqKlquzW5Xl4Gd6a71731yHPdo = dataInputStream.readInt();
        this.35R096iII61kQHz6TOX68XMH5nPEj8U7Ncf8L2Jmyz8JiEHKsi4YF8sJB8sy = dataInputStream.read();
        this.4BV3gR973ewVaMVIgMop5xq3la3tpMZ74351x250rhmK9h3i7dbTTPPvjV8M = dataInputStream.readInt();
        this.7XK40Z3498a65VnT386o5R3R45kdJyQN68g7bD8fjZMtd870278TqEAH9H3S = dataInputStream.read();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.write(this.34L0KePPJ95iIKPu3Xv2mZ47b0j828t11213K6I71N1aDcx34mx02Z13281u);
        dataOutputStream.writeInt(this.41SOjLbJkcYg135tROnpbb98261Rg06o8gwqKlquzW5Xl4Gd6a71731yHPdo);
        dataOutputStream.write(this.35R096iII61kQHz6TOX68XMH5nPEj8U7Ncf8L2Jmyz8JiEHKsi4YF8sJB8sy);
        dataOutputStream.writeInt(this.4BV3gR973ewVaMVIgMop5xq3la3tpMZ74351x250rhmK9h3i7dbTTPPvjV8M);
        dataOutputStream.write(this.7XK40Z3498a65VnT386o5R3R45kdJyQN68g7bD8fjZMtd870278TqEAH9H3S);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.2BymmR7j3vL5G30aTVGR18mAC2vOc29Czt1y6JjqML7yv5E1l3YVgF434sO2(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 11;
    }
}
