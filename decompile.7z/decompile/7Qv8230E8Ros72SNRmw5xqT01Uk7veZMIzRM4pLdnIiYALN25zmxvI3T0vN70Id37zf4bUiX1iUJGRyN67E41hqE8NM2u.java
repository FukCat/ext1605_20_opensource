import org.lwjgl.opengl.GL11;
import net.minecraft.client.Minecraft;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

// 
// Decompiled by Procyon v0.6.0
// 

public class 7Qv8230E8Ros72SNRmw5xqT01Uk7veZMIzRM4pLdnIiYALN25zmxvI3T0vN70Id37zf4bUiX1iUJGRyN67E41hqE8NM2u extends 3W0d28OFdXcKp4p5sJF2NY3wOKKdPb2FwuG0BLk9y18f2pN4kKKw9zLnwO3k3RS31Nz2bMsm8s5q4D0514o6bz9M7kScW8
{
    private int 9SB6LX271wt1N9R6FPQT2tkxrjYvp5zeNUgjferC20YRxzVuz1y6IOOXW25S;
    private BufferedImage 6xIjRAF772BRqOBNus4gr78k843P39SI5692Xo8B1847XMaHiO3808rtgOk6;
    public 2jD07HfU76WzqP8wGz7ll2Zo5oWLoe7N9pE17R5yFKLHN01H3Ws7w4MFs3yR8iM8V033MrU1i0Jelj7NkmurBOh938rq321ll 8Q693FBKPN5j0pdKG0XzN75si5WTE9p4CQ3M4u040GnL9O98xyP6kN624E9k;
    
    public 7Qv8230E8Ros72SNRmw5xqT01Uk7veZMIzRM4pLdnIiYALN25zmxvI3T0vN70Id37zf4bUiX1iUJGRyN67E41hqE8NM2u() {
        this.9SB6LX271wt1N9R6FPQT2tkxrjYvp5zeNUgjferC20YRxzVuz1y6IOOXW25S = -1;
        this.8Q693FBKPN5j0pdKG0XzN75si5WTE9p4CQ3M4u040GnL9O98xyP6kN624E9k = new 2jD07HfU76WzqP8wGz7ll2Zo5oWLoe7N9pE17R5yFKLHN01H3Ws7w4MFs3yR8iM8V033MrU1i0Jelj7NkmurBOh938rq321ll();
        this.0Sg7537VnLZ7du5FsLln7EYJ7tLG9LfdbFsVG53zuLLa94D21JXk6aie9tls = "Extension Standard";
        this.6rK7r47m1wf6M34G2s0hL7m282kBAy4521c3axU19Y9WKmYF8gZ6ryN7JLjP = "The standard design of Extension 16.05";
        try {
            this.6xIjRAF772BRqOBNus4gr78k843P39SI5692Xo8B1847XMaHiO3808rtgOk6 = ImageIO.read(1C60sf2EFRm3M9sgtt9V3x6TdOM3Vz7taJT0eA1658wF2g6zejH5rqp8qCr8w0yh8W291kew4rauuaF0804w7TM2aw8JN.5v4Cs6sI06e6Hjpg3rSI82gG008x14C2jag2OM7ADaW5U8a3DYSrf570CJm6("/pack.png"));
        }
        catch (final IOException ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public void 6kOi4sh8w5g34shttmoUUEDgCPE5VRiNwN076cQcxuDFXDkU0y92lK2v99vL(final Minecraft minecraft) {
        if (this.6xIjRAF772BRqOBNus4gr78k843P39SI5692Xo8B1847XMaHiO3808rtgOk6 != null) {
            minecraft.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.23swr7mqK54Yo1qph1JJ5nr7IZcL0bO0cEmdT4n3yev5424Oz6BOyfXVggMZ(this.9SB6LX271wt1N9R6FPQT2tkxrjYvp5zeNUgjferC20YRxzVuz1y6IOOXW25S);
        }
    }
    
    @Override
    public void 7X6Ocgi2aWrG07279w14Ok6jeWFPa9bmt1my2NA0a1ZEmdxx5QjSOn3mi5a8(final Minecraft minecraft) {
        if (this.6xIjRAF772BRqOBNus4gr78k843P39SI5692Xo8B1847XMaHiO3808rtgOk6 != null && this.9SB6LX271wt1N9R6FPQT2tkxrjYvp5zeNUgjferC20YRxzVuz1y6IOOXW25S < 0) {
            this.9SB6LX271wt1N9R6FPQT2tkxrjYvp5zeNUgjferC20YRxzVuz1y6IOOXW25S = minecraft.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.1BSFEHd336lH8JfA2w35JiGWqukE049E001767W1o8r4eUhCdf1SuM948qw6(this.6xIjRAF772BRqOBNus4gr78k843P39SI5692Xo8B1847XMaHiO3808rtgOk6);
        }
        if (this.6xIjRAF772BRqOBNus4gr78k843P39SI5692Xo8B1847XMaHiO3808rtgOk6 != null) {
            minecraft.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.2FngD4U0pd65pnJ2uUkjT0MQGf5Dn69MpHQ9hHdo5NZWQWiViGc62I6GRw3J(this.9SB6LX271wt1N9R6FPQT2tkxrjYvp5zeNUgjferC20YRxzVuz1y6IOOXW25S);
        }
        else {
            GL11.glBindTexture(3553, minecraft.6k7260CiP0XTr745HhMVzH4snG33O0674eoXAU199DGO78b3mDwG4V9Rs8yO.7vr7L7MEUPLNFHeDB0cpS18i1kbYTl3cg8B9xZTI4Q7Y2C8A0s7Y075Qa7O8("/gui/unknown_pack.png"));
        }
    }
}
