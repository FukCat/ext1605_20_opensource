import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 9Kx5iC91iGXA0d88S9zn8Hq67U27m16JltwcPFXh2aLO7sEK2vz49l963pB4I2cmk7Z5di8pcRrBRlnnf2cS08WpktXH3hV5h69vb extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public long 478uR7n6KC2r1SBt5OMeJFKAMimr5VQBC52wJc3s19DO2f4W3s1c1q143h3u;
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.478uR7n6KC2r1SBt5OMeJFKAMimr5VQBC52wJc3s19DO2f4W3s1c1q143h3u = dataInputStream.readLong();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeLong(this.478uR7n6KC2r1SBt5OMeJFKAMimr5VQBC52wJc3s19DO2f4W3s1c1q143h3u);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.1VX9439M9IgzP3zC3Y3qdp7JA4mrYkJStpgu9g9VW01PuDiE4478e3Nzn5Z1(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 8;
    }
}
