import java.io.DataInput;
import java.io.IOException;
import java.io.DataOutput;

// 
// Decompiled by Procyon v0.6.0
// 

public class 71JZdqce1m9979i3cSBBlOj3ETTvHGDPSWO291hY4ds9z4R7UJ0T2V1rNWb7twoV1Tf9MH0frb0MPpjV7R84FayCU8r3366qF3FCbom1H extends 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi
{
    public short 4S7x5m9RwvKdciD36qsIO6MGsshjFEL7XIKc0lF281D5rZ36E5UvKN0fwyVm;
    
    public 71JZdqce1m9979i3cSBBlOj3ETTvHGDPSWO291hY4ds9z4R7UJ0T2V1rNWb7twoV1Tf9MH0frb0MPpjV7R84FayCU8r3366qF3FCbom1H() {
    }
    
    public 71JZdqce1m9979i3cSBBlOj3ETTvHGDPSWO291hY4ds9z4R7UJ0T2V1rNWb7twoV1Tf9MH0frb0MPpjV7R84FayCU8r3366qF3FCbom1H(final short 4s7x5m9RwvKdciD36qsIO6MGsshjFEL7XIKc0lF281D5rZ36E5UvKN0fwyVm) {
        this.4S7x5m9RwvKdciD36qsIO6MGsshjFEL7XIKc0lF281D5rZ36E5UvKN0fwyVm = 4s7x5m9RwvKdciD36qsIO6MGsshjFEL7XIKc0lF281D5rZ36E5UvKN0fwyVm;
    }
    
    @Override
    void 7OU3N2lgEecd9p9DtAmaF5EwE4f0u28Oaa9zcxqnm3XW1bDsPewY15rIFs80(final DataOutput dataOutput) throws IOException {
        dataOutput.writeShort(this.4S7x5m9RwvKdciD36qsIO6MGsshjFEL7XIKc0lF281D5rZ36E5UvKN0fwyVm);
    }
    
    @Override
    void 96fSDIRBY01vu6bNpWo4KQJG8fCN2WIew9WR04d4yvq9Lxko60PpMIEkyn00(final DataInput dataInput) throws IOException {
        this.4S7x5m9RwvKdciD36qsIO6MGsshjFEL7XIKc0lF281D5rZ36E5UvKN0fwyVm = dataInput.readShort();
    }
    
    @Override
    public byte 3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr() {
        return 2;
    }
    
    @Override
    public String toString() {
        return "" + this.4S7x5m9RwvKdciD36qsIO6MGsshjFEL7XIKc0lF281D5rZ36E5UvKN0fwyVm;
    }
}
