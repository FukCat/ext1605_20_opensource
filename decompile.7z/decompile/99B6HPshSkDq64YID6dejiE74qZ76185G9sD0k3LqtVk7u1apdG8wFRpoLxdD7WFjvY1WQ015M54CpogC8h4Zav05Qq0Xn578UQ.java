import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 99B6HPshSkDq64YID6dejiE74qZ76185G9sD0k3LqtVk7u1apdG8wFRpoLxdD7WFjvY1WQ015M54CpogC8h4Zav05Qq0Xn578UQ extends 04jG95z49Q0vzm7aDD4u7rv62B90mjfcT935e2Dzu8o9C0fd1Sk50n3k7fcwZrS9a3730pO5p6Gxj272Me3ugexz6x1jLF888XI4s2A55I
{
    private Class<? extends 2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex> 8K2pq151q3u0f367KBnOXaN7AzCL5sROtllz7v9immH23Iq1fm0dDTCl3U49;
    private boolean 21Ex8510mez73OKj2mmsGByAHpblWL50tx3VeEKaR6Ovu40lE3Hv998hV2dj;
    
    protected 99B6HPshSkDq64YID6dejiE74qZ76185G9sD0k3LqtVk7u1apdG8wFRpoLxdD7WFjvY1WQ015M54CpogC8h4Zav05Qq0Xn578UQ(final int n, final Class<? extends 2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex> 8k2pq151q3u0f367KBnOXaN7AzCL5sROtllz7v9immH23Iq1fm0dDTCl3U49, final boolean 21Ex8510mez73OKj2mmsGByAHpblWL50tx3VeEKaR6Ovu40lE3Hv998hV2dj) {
        super(n, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.0e51g5n7QQ2bM6IT7Q28hAbJkebnbMOVd3lRo7XioWLAkvTHV9DQxASpl4S7);
        this.21Ex8510mez73OKj2mmsGByAHpblWL50tx3VeEKaR6Ovu40lE3Hv998hV2dj = 21Ex8510mez73OKj2mmsGByAHpblWL50tx3VeEKaR6Ovu40lE3Hv998hV2dj;
        this.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41 = 4;
        this.8K2pq151q3u0f367KBnOXaN7AzCL5sROtllz7v9immH23Iq1fm0dDTCl3U49 = 8k2pq151q3u0f367KBnOXaN7AzCL5sROtllz7v9immH23Iq1fm0dDTCl3U49;
        final float n2 = 0.25f;
        this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f - n2, 0.0f, 0.5f - n2, 0.5f + n2, 1.0f, 0.5f + n2);
    }
    
    @Override
    public 85H57P2H4D6cj141sW70sW6k1pGNK4K4k78ms060bS9Wz8ktuElnkcl5YQCE3305VB1e75Xq1DQYF44ZEikQn64iKmEU62Tu9R5qy07u 3bij4GE3F3Ym8Tj5mrW954sQU66Nm526G6r6WtltdPMgh4iGYTj57E59MauA(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public 85H57P2H4D6cj141sW70sW6k1pGNK4K4k78ms060bS9Wz8ktuElnkcl5YQCE3305VB1e75Xq1DQYF44ZEikQn64iKmEU62Tu9R5qy07u 1lI9KIuLRpwqxNkCdN55OQH58jw8pL0BXEJQS6of99lsw25B2Gb7un13njcy(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        this.7HrN9mB4wUkhLz6Jv5Blt17mi7qe5SHb15Xr6B89oQb9l6VN0cY5Haa30I6j(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3);
        return super.1lI9KIuLRpwqxNkCdN55OQH58jw8pL0BXEJQS6of99lsw25B2Gb7un13njcy(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3);
    }
    
    @Override
    public void 7HrN9mB4wUkhLz6Jv5Blt17mi7qe5SHb15Xr6B89oQb9l6VN0cY5Haa30I6j(final 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa, final int n, final int n2, final int n3) {
        if (!this.21Ex8510mez73OKj2mmsGByAHpblWL50tx3VeEKaR6Ovu40lE3Hv998hV2dj) {
            final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
            final float n4 = 0.28125f;
            final float n5 = 0.78125f;
            final float n6 = 0.0f;
            final float n7 = 1.0f;
            final float n8 = 0.125f;
            this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 2) {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(n6, n4, 1.0f - n8, n7, n5, 1.0f);
            }
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 3) {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(n6, n4, 0.0f, n7, n5, n8);
            }
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 4) {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(1.0f - n8, n4, n6, 1.0f, n5, n7);
            }
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 5) {
                this.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, n4, n6, n8, n5, n7);
            }
        }
    }
    
    @Override
    public int 9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP() {
        return -1;
    }
    
    @Override
    public boolean 35gUMxe6UGWsnci7k7ZiwHjA0P63Qs829v6WAF3u9tc6vXASiYOI7j512637() {
        return false;
    }
    
    @Override
    public boolean 11krARXg1dz3Cs9T1417zcu0h3o23b6X5J17X8JguWkYPA1xFa6hm48g23zA() {
        return false;
    }
    
    @Override
    protected 2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex 6Qw6RCu9ZEo5HDblBh0CRT406s02009a656IV4nL0AKcEElJwejXE8chN4hm() {
        try {
            return (2CH1O4x7hQ8O572ZyMcDZ0DyK1wE6ClgR80TmjF09FNFhK5mAp683Y6Ta2UZHl4sgGdxggI0w5C4914xpTP3PjkjRTzm228ex)this.8K2pq151q3u0f367KBnOXaN7AzCL5sROtllz7v9immH23Iq1fm0dDTCl3U49.getDeclaredConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
        }
        catch (final Exception cause) {
            throw new RuntimeException(cause);
        }
    }
    
    @Override
    public int 9hFrB67UQ3xIdu153AXx7FYrppLysZW3gpO0hVR27pm9IQlKb2jF25i9DO3e(final int n, final Random random) {
        return 9ygxPoiW4c6wxGp26X118F0yxK032lk54Et3G9z9La2P3u89472GAyR8g9qCe7Mm61D4aJdzSiABhv3paZ7eid82x1ned.1kh95G9G2xoVXwfeXfq2zw2YVJqR8FOW931667oNkT1sLxs58kMQ1HU1x31N.016D6B0WzYa1oAf8GVzuN3e04Nkxq5CzkT5YVZhj2l5H8LW20C9lkr0R7pc5;
    }
    
    @Override
    public void 7Y3tozvAo32fnL40Aj23V3Z0UTg24ELW02SnQs781Of4EIXyFofcbvW6li4c(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3, final int n4) {
        boolean b = false;
        if (this.21Ex8510mez73OKj2mmsGByAHpblWL50tx3VeEKaR6Ovu40lE3Hv998hV2dj) {
            if (!5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n, n2 - 1, n3).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = true;
            }
        }
        else {
            final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
            b = true;
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 2 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n, n2, n3 + 1).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = false;
            }
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 3 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n, n2, n3 - 1).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = false;
            }
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 4 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n + 1, n2, n3).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = false;
            }
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 5 && 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n - 1, n2, n3).9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                b = false;
            }
        }
        if (b) {
            this.34c2i0BTc9ESKRlH8o24MFx27N7S3sQf54gg2xV6ZbZrdGZ1JlWKc3u2Dk65(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3, 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3));
            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.7e80T2772odYwi7VqXc3urUV6zE953105DSt0kIi75139Kv08G5rOdV1aEtf(n, n2, n3, 0);
        }
        super.7Y3tozvAo32fnL40Aj23V3Z0UTg24ELW02SnQs781Of4EIXyFofcbvW6li4c(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3, n4);
    }
}
