// 
// Decompiled by Procyon v0.6.0
// 

public final class 5bVTl2lZ5AVe10bX0vWHd9D0fC2sGkIsMfWx1U0125gW553EU1THpcnu1XLKi9luS3ixwA6AFyvERJ9vuJ7DyGLV2xlV6wE41MQq extends 4G8N90QIG5OcZ1977907FAqlT5XxS2Q2IP4le3OEd75DSJASUkDI9MQfE9veO9x59wjSSnk07et2THZ40805ZhTlR2wF4Bx9D27J
{
    public 5bVTl2lZ5AVe10bX0vWHd9D0fC2sGkIsMfWx1U0125gW553EU1THpcnu1XLKi9luS3ixwA6AFyvERJ9vuJ7DyGLV2xlV6wE41MQq(final String s, final float n, final float n2) {
        super(s, n, n2);
    }
    
    @Override
    public String 4ysb026Q69QQ1Y451ML4JO19j79dea8A1yeC6Ff4otUgu8OmJfVTcf6gMhf7() {
        return "step.gravel";
    }
}
