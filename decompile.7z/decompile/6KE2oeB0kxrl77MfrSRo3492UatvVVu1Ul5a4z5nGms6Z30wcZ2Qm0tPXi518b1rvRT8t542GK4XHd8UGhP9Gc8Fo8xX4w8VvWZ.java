import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 6KE2oeB0kxrl77MfrSRo3492UatvVVu1Ul5a4z5nGms6Z30wcZ2Qm0tPXi518b1rvRT8t542GK4XHd8UGhP9Gc8Fo8xX4w8VvWZ extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public int 54q7o5xgGnf3hiyA63o26KoR98ZJpM3hsJ38kk4n7Wv6952Ds0x8MNIGFGe2;
    public int 111801QZ3bU47X2NF0Ew8IabDSipomqQMlgnSD4iYcVD9Z766p2t06ZuO544;
    public int 9bXjQYBYFtINCfbtV68606E1Fm1V75q1MwRj5yIyOTT6S2nfy3lR8uBQmyFF;
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.54q7o5xgGnf3hiyA63o26KoR98ZJpM3hsJ38kk4n7Wv6952Ds0x8MNIGFGe2 = (dataInputStream.readShort() & 0xFFFF);
        this.111801QZ3bU47X2NF0Ew8IabDSipomqQMlgnSD4iYcVD9Z766p2t06ZuO544 = dataInputStream.readByte();
        this.9bXjQYBYFtINCfbtV68606E1Fm1V75q1MwRj5yIyOTT6S2nfy3lR8uBQmyFF = dataInputStream.readShort();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeShort(this.54q7o5xgGnf3hiyA63o26KoR98ZJpM3hsJ38kk4n7Wv6952Ds0x8MNIGFGe2);
        dataOutputStream.writeByte(this.111801QZ3bU47X2NF0Ew8IabDSipomqQMlgnSD4iYcVD9Z766p2t06ZuO544);
        dataOutputStream.writeShort(this.9bXjQYBYFtINCfbtV68606E1Fm1V75q1MwRj5yIyOTT6S2nfy3lR8uBQmyFF);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2.46G4X3qjtkjoDtwe4l1PDt2JyfZ3yLa50p5FsFs9d32iIA4NQ59Wc9t1qyth(this);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 5;
    }
}
