import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 5Ez5C60D7d94XnXH343n0BsooUJCyEgJDOSVfu33mYnxU0oKDrP3tJ08aXtC0p68O6OZ8r46R1O9H9KjS7626vVnGlh3v2RxkR3 extends 55XXM28b6p84b4G2l6B1InnTc701h21NG7n6pZPb2RkqeSGMf12ZMp058OFNNJP04Q3WjX0S3IEUdu0p0YkM1TMGm5WXG2Nme6
{
    public 5Ez5C60D7d94XnXH343n0BsooUJCyEgJDOSVfu33mYnxU0oKDrP3tJ08aXtC0p68O6OZ8r46R1O9H9KjS7626vVnGlh3v2RxkR3(final int n, final int n2) {
        super(n, n2, 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ.0e51g5n7QQ2bM6IT7Q28hAbJkebnbMOVd3lRo7XioWLAkvTHV9DQxASpl4S7);
    }
    
    @Override
    public int 2b1pbetRmJyaMfSXs7k02a96ZB84GA6lI6KnMBwqDWfFcMKEifg20ytG350E(final int n) {
        if (n <= 1) {
            return 4;
        }
        return this.6W5537e39RouptxKN4twH4Q68yb8iZUQeG6F99r78QC079rRm3kSkaWx5l3H;
    }
    
    @Override
    public int 45k0se28RPK2IN33WJfb5g4oDd7zeQlWp0LvSfJeHBZ0aVU090Eh0r7XB665(final Random random) {
        return 0;
    }
}
