import java.awt.image.BufferedImage;
import org.lwjgl.opengl.GL11;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.nio.IntBuffer;

// 
// Decompiled by Procyon v0.6.0
// 

public class 87k6gZdUF64lRd2414n3C9YY0RqdbbURZjg76Q3wg8n1vyhOeSdCGqtgKyQUo9TtGm8AxXBADPj6456Y0svQ4I3QmXX6S4J0
{
    private int[] 8x14g69mRutr1NHYXrprur89pnZS0A7d27ny9oSIGXe4NG9ut5I3u9Y6W4O4;
    public int 2M1ksx6FHZ0it4TrOPvHM2GzwEH0FYSJ3Nc35ZW515Tv2l561ZCNlgo5iUc0;
    private int 9oQT7w2ro0U81RT25S4yr00KjqlY0AT278H36W7v3AGIhyE7G2v0wIh26pdA;
    private IntBuffer 7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36;
    
    public 87k6gZdUF64lRd2414n3C9YY0RqdbbURZjg76Q3wg8n1vyhOeSdCGqtgKyQUo9TtGm8AxXBADPj6456Y0svQ4I3QmXX6S4J0(final 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S 90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S, final String s, final 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u) {
        this.8x14g69mRutr1NHYXrprur89pnZS0A7d27ny9oSIGXe4NG9ut5I3u9Y6W4O4 = new int[256];
        this.2M1ksx6FHZ0it4TrOPvHM2GzwEH0FYSJ3Nc35ZW515Tv2l561ZCNlgo5iUc0 = 0;
        this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36 = 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.1R0cvYjOOKvGsD06D0rUI7v5l8UW5g50A7vNmbfAYuiFodFv87BlfGv90Uh2(1024);
        BufferedImage read;
        try {
            read = ImageIO.read(5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.8nB09v2wL31LD7473aXNMbJrX47AX71iPMP6yPX544heeDvxj78y5qTJYk68.1k4uc1i9aprs9834A7rEVW0D2zfl3BI2g00e7D4rgDYDih8Qu9WukuM46qw0.35L3yK6n9jMB61q7Q57v3QnT9AbuQoT2q7ZWl0ne7W843s9HPtt8y52AD4o0(s));
        }
        catch (final IOException cause) {
            throw new RuntimeException(cause);
        }
        final int width = read.getWidth();
        final int height = read.getHeight();
        final int[] rgbArray = new int[width * height];
        read.getRGB(0, 0, width, height, rgbArray, 0, width);
        for (int i = 0; i < 256; ++i) {
            final int n = i % 16;
            final int n2 = i / 16;
            int j;
            for (j = 7; j >= 0; --j) {
                final int n3 = n * 8 + j;
                int n4 = 1;
                for (int n5 = 0; n5 < 8 && n4 != 0; ++n5) {
                    if ((rgbArray[n3 + (n2 * 8 + n5) * width] & 0xFF) > 0) {
                        n4 = 0;
                    }
                }
                if (n4 == 0) {
                    break;
                }
            }
            if (i == 32) {
                j = 2;
            }
            this.8x14g69mRutr1NHYXrprur89pnZS0A7d27ny9oSIGXe4NG9ut5I3u9Y6W4O4[i] = j + 2;
        }
        this.2M1ksx6FHZ0it4TrOPvHM2GzwEH0FYSJ3Nc35ZW515Tv2l561ZCNlgo5iUc0 = 5Lml2WQU47jeFJG239AnmSQZG8A856GHcgfCWv3MQ32Se6j5ertND69E03Xxrcpd3AQ5kTI4Rh5cBQl7Opa23XEF064r9u.1BSFEHd336lH8JfA2w35JiGWqukE049E001767W1o8r4eUhCdf1SuM948qw6(read);
        this.9oQT7w2ro0U81RT25S4yr00KjqlY0AT278H36W7v3AGIhyE7G2v0wIh26pdA = 6L0q9fOrT3gF3u9BA7jz880F0hAJeJojaOFZ2y4Q31W9X7S69DROtyz6GWD1c52miu9YzUO1G91Iny44J8D6t8qjkA5482F8.138K2t9YH4nAdJ6uDNr4xjMccU3H5E3JlRhhv9Vj028i2gtCBW9T2h1ZHTH4(288);
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        for (int k = 0; k < 256; ++k) {
            GL11.glNewList(this.9oQT7w2ro0U81RT25S4yr00KjqlY0AT278H36W7v3AGIhyE7G2v0wIh26pdA + k, 4864);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
            final int n6 = k % 16 * 8;
            final int n7 = k / 16 * 8;
            final float n8 = 7.99f;
            final float n9 = 0.0f;
            final float n10 = 0.0f;
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(0.0, 0.0f + n8, 0.0, n6 / 128.0f + n9, (n7 + n8) / 128.0f + n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(0.0f + n8, 0.0f + n8, 0.0, (n6 + n8) / 128.0f + n9, (n7 + n8) / 128.0f + n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(0.0f + n8, 0.0, 0.0, (n6 + n8) / 128.0f + n9, n7 / 128.0f + n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(0.0, 0.0, 0.0, n6 / 128.0f + n9, n7 / 128.0f + n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
            GL11.glTranslatef((float)this.8x14g69mRutr1NHYXrprur89pnZS0A7d27ny9oSIGXe4NG9ut5I3u9Y6W4O4[k], 0.0f, 0.0f);
            GL11.glEndList();
        }
        for (int l = 0; l < 32; ++l) {
            final int n11 = (l >> 3 & 0x1) * 85;
            int n12 = (l >> 2 & 0x1) * 170 + n11;
            int n13 = (l >> 1 & 0x1) * 170 + n11;
            int n14 = (l >> 0 & 0x1) * 170 + n11;
            if (l == 6) {
                n12 += 85;
            }
            final boolean b = l >= 16;
            if (90P07uZ93FV38QPsG5GgcjVd0O5zVftJ2njw12bRpuE6u921Q5J0x70PHNIU5J3nfuDgzdQUop5j2cxeO57fI2BKfG7S.10iD31fC4Dyj31q37QyatM61p3w770PmS1ab3DF69GDMkU6z9rOWos13CZo8) {
                final int n15 = (n12 * 30 + n13 * 59 + n14 * 11) / 100;
                final int n16 = (n12 * 30 + n13 * 70) / 100;
                final int n17 = (n12 * 30 + n14 * 70) / 100;
                n12 = n15;
                n13 = n16;
                n14 = n17;
            }
            if (b) {
                n12 /= 4;
                n13 /= 4;
                n14 /= 4;
            }
            GL11.glNewList(this.9oQT7w2ro0U81RT25S4yr00KjqlY0AT278H36W7v3AGIhyE7G2v0wIh26pdA + 256 + l, 4864);
            GL11.glColor3f(n12 / 255.0f, n13 / 255.0f, n14 / 255.0f);
            GL11.glEndList();
        }
    }
    
    public void 7O80YtY13ocjL32iQirNQ7EqMUSsWbw50vG6T0eNj0T6K7665q49ol6j3MF1(final String s, final int n, final int n2, final int n3) {
        this.7b55Qn9Zh0WFfTw1Tz391F1c3JHILqk770cGEC2z7FzPRjBu4G70P37ERQNt(s, n + 1, n2 + 1, n3, true);
        this.9WH7LUf546x263V85v8o87x6d2Y7ZY7fPYyzVR9F61aJ7PnY1EAuj01xIk30(s, n, n2, n3);
    }
    
    public void 9WH7LUf546x263V85v8o87x6d2Y7ZY7fPYyzVR9F61aJ7PnY1EAuj01xIk30(final String s, final int n, final int n2, final int n3) {
        this.7b55Qn9Zh0WFfTw1Tz391F1c3JHILqk770cGEC2z7FzPRjBu4G70P37ERQNt(s, n, n2, n3, false);
    }
    
    public void 7b55Qn9Zh0WFfTw1Tz391F1c3JHILqk770cGEC2z7FzPRjBu4G70P37ERQNt(final String s, final int n, final int n2, int n3, final boolean b) {
        if (s != null) {
            if (b) {
                final int n4 = n3 & 0xFF000000;
                n3 = (n3 & 0xFCFCFC) >> 2;
                n3 += n4;
                n3 = (n3 = ((n4 == 255 || n4 == 0) ? (n3 | 0xFF000000) : (n3 | n4 / 2 << 24)));
            }
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glBindTexture(3553, this.2M1ksx6FHZ0it4TrOPvHM2GzwEH0FYSJ3Nc35ZW515Tv2l561ZCNlgo5iUc0);
            final float n5 = (n3 >> 16 & 0xFF) / 255.0f;
            final float n6 = (n3 >> 8 & 0xFF) / 255.0f;
            final float n7 = (n3 & 0xFF) / 255.0f;
            float n8 = (n3 >> 24 & 0xFF) / 255.0f;
            if (n8 == 0.0f) {
                n8 = 1.0f;
            }
            GL11.glColor4f(n5, n6, n7, n8);
            this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.clear();
            GL11.glPushMatrix();
            GL11.glTranslatef((float)n, (float)n2, 0.0f);
            for (int i = 0; i < s.length(); ++i) {
                while (s.charAt(i) == '��' && s.length() > i + 1) {
                    int index = "0123456789abcdef".indexOf(s.toLowerCase().charAt(i + 1));
                    if (index < 0 || index > 15) {
                        index = 15;
                    }
                    this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.put(this.9oQT7w2ro0U81RT25S4yr00KjqlY0AT278H36W7v3AGIhyE7G2v0wIh26pdA + 256 + index + (b ? 16 : 0));
                    if (this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.remaining() == 0) {
                        this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.flip();
                        GL11.glCallLists(this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36);
                        this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.clear();
                    }
                    i += 2;
                }
                final int index2 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~\u2302\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8?\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1??????????".indexOf(s.charAt(i));
                if (index2 >= 0) {
                    this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.put(this.9oQT7w2ro0U81RT25S4yr00KjqlY0AT278H36W7v3AGIhyE7G2v0wIh26pdA + index2 + 32);
                }
                if (this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.remaining() == 0) {
                    this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.flip();
                    GL11.glCallLists(this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36);
                    this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.clear();
                }
            }
            this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36.flip();
            GL11.glCallLists(this.7qLFntpvL5T2w5wzCnIPL048cblJcmO3KiPZFp1PloM8v0t63bz0BuSVyg36);
            GL11.glPopMatrix();
        }
    }
    
    public int 513yBz0z1e0Xp8J9hG9YLezT8TFgNrrND64rO10vxk37SjfO36iSUM8NmZ6j(final String s) {
        if (s == null) {
            return 0;
        }
        int n = 0;
        for (int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) == '��') {
                ++i;
            }
            else {
                final int index = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_'abcdefghijklmnopqrstuvwxyz{|}~\u2302\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8?\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1??????????".indexOf(s.charAt(i));
                if (index >= 0) {
                    n += this.8x14g69mRutr1NHYXrprur89pnZS0A7d27ny9oSIGXe4NG9ut5I3u9Y6W4O4[index + 32];
                }
            }
        }
        return n;
    }
}
