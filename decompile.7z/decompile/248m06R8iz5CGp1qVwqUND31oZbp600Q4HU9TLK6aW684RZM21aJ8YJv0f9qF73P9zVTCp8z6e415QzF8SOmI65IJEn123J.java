import java.io.DataOutput;
import java.io.IOException;
import java.io.DataInput;

// 
// Decompiled by Procyon v0.6.0
// 

public class 248m06R8iz5CGp1qVwqUND31oZbp600Q4HU9TLK6aW684RZM21aJ8YJv0f9qF73P9zVTCp8z6e415QzF8SOmI65IJEn123J extends 03JTF9Xo7W555dAaov40z7pwon54qb0y6Yx9m91uZJ2HjXFBxdSe50Qt5nW290cN79FCMsvdRZI1MQfMU5vi7COWOuc1nTi
{
    @Override
    void 96fSDIRBY01vu6bNpWo4KQJG8fCN2WIew9WR04d4yvq9Lxko60PpMIEkyn00(final DataInput dataInput) throws IOException {
    }
    
    @Override
    void 7OU3N2lgEecd9p9DtAmaF5EwE4f0u28Oaa9zcxqnm3XW1bDsPewY15rIFs80(final DataOutput dataOutput) throws IOException {
    }
    
    @Override
    public byte 3wowDZDPWK9JN99sIF7PRHv8vOi9iO22KUu34j6iwbBy6uLTPEM3A27h4Kqr() {
        return 0;
    }
    
    @Override
    public String toString() {
        return "END";
    }
}
