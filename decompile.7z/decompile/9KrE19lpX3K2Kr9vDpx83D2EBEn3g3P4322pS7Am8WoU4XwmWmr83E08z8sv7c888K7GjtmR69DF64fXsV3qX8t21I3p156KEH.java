import org.lwjgl.opengl.GL11;

// 
// Decompiled by Procyon v0.6.0
// 

public class 9KrE19lpX3K2Kr9vDpx83D2EBEn3g3P4322pS7Am8WoU4XwmWmr83E08z8sv7c888K7GjtmR69DF64fXsV3qX8t21I3p156KEH
{
    private 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa 260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW;
    private int 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
    private boolean 3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy;
    private boolean 2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46;
    
    public 9KrE19lpX3K2Kr9vDpx83D2EBEn3g3P4322pS7Am8WoU4XwmWmr83E08z8sv7c888K7GjtmR69DF64fXsV3qX8t21I3p156KEH(final 91939oNf1Y0e1z5nkW2dm98CK2pI4dR8Ym7YbeSBj8Tjc9f04Gzwu018OGlZ9TEx3uECry3Y5j397G50H1FoB4q346zRCiRYa 260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW) {
        this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = -1;
        this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = false;
        this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 = false;
        this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW = 260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW;
    }
    
    public 9KrE19lpX3K2Kr9vDpx83D2EBEn3g3P4322pS7Am8WoU4XwmWmr83E08z8sv7c888K7GjtmR69DF64fXsV3qX8t21I3p156KEH() {
        this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = -1;
        this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = false;
        this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 = false;
    }
    
    public void 5881i11iep1e88Y3ZNCM7D9yDpN7mU3XbTeY081Ipm7cEOQjWUodgUu2nBbM(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3, final int 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258) {
        this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        this.33FXCCJAzisnQv6WjQt6jKIe245XnX7ZmA0538v1e2KufQ35X3eNz4tw7F42(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = -1;
    }
    
    public boolean 33FXCCJAzisnQv6WjQt6jKIe245XnX7ZmA0538v1e2KufQ35X3eNz4tw7F42(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final int 9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP();
        1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.7HrN9mB4wUkhLz6Jv5Blt17mi7qe5SHb15Xr6B89oQb9l6VN0cY5Haa30I6j(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        switch (9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP) {
            case -1: {
                return true;
            }
            case 1: {
                return this.5mXZGX3IUOI3005X5l3ocw5rZoXPiY87s7q7YP6y52QXsGlTn0Vz1jd2GD3V(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 2: {
                return this.3v7BiQ2RpL6yJCwz7GDc5Qz0o59T2qIo50WkU33P8G9TTAs7sn4982WId5EK(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 3: {
                return this.4hml809U519l9uAM3j2423vV5ZHC7f1lQI2i422B9lSAfSv20JZ3m6K7gig2(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 4: {
                return this.99lHkqs3rdyDqmATSHE8u17bA6T7Sy4YN3H9qaf37mfMS17FM0QGjpkX4DHX(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 5: {
                return this.9CG9vJ3pt41ntlMJiRJkt9YkRpX6FvU9rtXc5y5FkvrsF2oME9S8Ksl6AJU7(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 6: {
                return this.78eFp7F47rBLNwlYXpH797X2j8LRM09PE9qzSbj390SCz3oh5EVZbOY94s4F(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 7: {
                return this.4rT8HOSHs584bxNNoOuY8vYjox7u5Mtgo1uI9N4aVdA0eG4t72zDxDDGDlh4(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 8: {
                return this.1vqU4FBtq7rOPZ5a6KNRLG3A9Of7lWvgigJxCkO0436F94H0bO3MoJ83Rpa6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 9: {
                return this.14GxM75995p5Wr788537qDl25deDi08BFNzzn6Q2l8394Ner0AM3ijHf7RF8(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 10: {
                return this.301E4Fg2576lD5pIL00Y9U8e5Yj4Wd8YN53dhLAz7G1f29kbfDi9120U6zp3(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 11: {
                return this.33YJVc6I9kV8vv5NZ7O0n769O7go9n2ZBS72mricO0ZI5IV1K4N19KOimtkh(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 12: {
                return this.12m6bh4Q9sj89ihw5KY7a4G4rI8hphCaDOe4fawWjdz8EFabLXY2W8fRVO09(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 13: {
                return this.2pboSq9199Z3zY0kyQgFH7p1328RC8S9W04JhmameH0g15vtnUo5qS8IKU1h(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
            case 14: {
                return this.8B43235r8C9U031fm58MPaJBX5ue76jn55uq1BI2rFGWP6v055e5x5khTmjs(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, false);
            }
            default: {
                return this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            }
        }
    }
    
    private boolean 8B43235r8C9U031fm58MPaJBX5ue76jn55uq1BI2rFGWP6v055e5x5khTmjs(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3, final boolean b) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        final int n4 = 1;
        final int n5 = 0;
        float n6 = 1.0f;
        if (!b) {
            n6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3);
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n7 = (n4 * 16.0 + 1.0) / 256.0;
        final double n8 = (n4 * 16.0 + 15.0 - 0.01) / 256.0;
        final double n9 = (n5 * 16.0 + 1.0) / 512.0;
        final double n10 = (n5 * 16.0 + 15.0 - 0.01) / 512.0;
        final double n11 = n + 0.0625;
        final double n12 = n + 0.9375;
        final double n13 = n3 + 0.0625;
        final double n14 = n3 + 0.9375;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n2, n14, n7, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n2, n13, n7, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n2, n13, n8, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n2, n14, n8, n10);
        final double n15 = (n4 * 16.0 + 0.0) / 256.0;
        final double n16 = (n4 * 16.0 + 16.0 - 0.01) / 256.0;
        final double n17 = (n5 * 16.0 + 0.0) / 512.0;
        final double n18 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n19 = n + 1;
        final double n20 = n2 + 0.0625;
        final double n21 = n3 + 1;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n, n20, n21, n15, n18);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n, n20, n3, n15, n17);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n19, n20, n3, n16, n17);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n19, n20, n21, n16, n18);
        if (!b) {
            n6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 - 1);
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n22 = (n4 * 16.0 + 1.0) / 256.0;
        final double n23 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n24 = (n5 * 16.0 + 0.0) / 512.0;
        final double n25 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n26 = n;
        final double n27 = n + 1;
        final double n28 = n2 + 0.0625;
        final double n29 = n2 + 0.25;
        final double n30 = n3;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n26, n29, n30, n22, n25);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n27, n29, n30, n22, n24);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n27, n28, n30, n23, n24);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n26, n28, n30, n23, n25);
        final double n31 = (n4 * 16.0 + 0.0) / 256.0;
        final double n32 = (n4 * 16.0 + 1.0 - 0.01) / 256.0;
        final double n33 = (n5 * 16.0 + 1.0) / 512.0;
        final double n34 = (n5 * 16.0 + 15.0 - 0.01) / 512.0;
        final double n35 = n + 0.0625;
        final double n36 = n + 0.9375;
        final double n37 = n2;
        final double n38 = n2 + 0.0625;
        final double n39 = n3 + 0.0625;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n35, n38, n39, n31, n34);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n36, n38, n39, n31, n33);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n36, n37, n39, n32, n33);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n35, n37, n39, n32, n34);
        if (!b) {
            n6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 + 1);
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n40 = (n4 * 16.0 + 1.0) / 256.0;
        final double n41 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n42 = (n5 * 16.0 + 0.0) / 512.0;
        final double n43 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n44 = n;
        final double n45 = n + 1;
        final double n46 = n2 + 0.0625;
        final double n47 = n2 + 0.25;
        final double n48 = n3 + 1;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n45, n47, n48, n40, n43);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n44, n47, n48, n40, n42);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n44, n46, n48, n41, n42);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n45, n46, n48, n41, n43);
        final double n49 = (n4 * 16.0 + 0.0) / 256.0;
        final double n50 = (n4 * 16.0 + 1.0 - 0.01) / 256.0;
        final double n51 = (n5 * 16.0 + 1.0) / 512.0;
        final double n52 = (n5 * 16.0 + 15.0 - 0.01) / 512.0;
        final double n53 = n + 0.0625;
        final double n54 = n + 0.9375;
        final double n55 = n2;
        final double n56 = n2 + 0.0625;
        final double n57 = n3 + 0.9375;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n54, n56, n57, n49, n52);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n53, n56, n57, n49, n51);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n53, n55, n57, n50, n51);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n54, n55, n57, n50, n52);
        if (!b) {
            n6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2, n3);
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n58 = (n4 * 16.0 + 1.0) / 256.0;
        final double n59 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n60 = (n5 * 16.0 + 0.0) / 512.0;
        final double n61 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n62 = n;
        final double n63 = n2 + 0.0625;
        final double n64 = n2 + 0.25;
        final double n65 = n3;
        final double n66 = n3 + 1;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n62, n64, n66, n58, n61);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n62, n64, n65, n58, n60);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n62, n63, n65, n59, n60);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n62, n63, n66, n59, n61);
        final double n67 = (n4 * 16.0 + 1.0) / 256.0;
        final double n68 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n69 = (n5 * 16.0 + 0.0) / 512.0;
        final double n70 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n71 = n + 0.0625;
        final double n72 = n2;
        final double n73 = n2 + 0.0625;
        final double n74 = n3 + 0.0625;
        final double n75 = n3 + 0.9375;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n71, n73, n75, n67, n70);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n71, n73, n74, n67, n69);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n71, n72, n74, n68, n69);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n71, n72, n75, n68, n70);
        if (!b) {
            n6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2, n3);
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n76 = (n4 * 16.0 + 1.0) / 256.0;
        final double n77 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n78 = (n5 * 16.0 + 0.0) / 512.0;
        final double n79 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n80 = n + 1;
        final double n81 = n2 + 0.0625;
        final double n82 = n2 + 0.25;
        final double n83 = n3;
        final double n84 = n3 + 1;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n80, n82, n83, n76, n79);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n80, n82, n84, n76, n78);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n80, n81, n84, n77, n78);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n80, n81, n83, n77, n79);
        final double n85 = (n4 * 16.0 + 1.0) / 256.0;
        final double n86 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n87 = (n5 * 16.0 + 0.0) / 512.0;
        final double n88 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n89 = n + 0.9375;
        final double n90 = n2;
        final double n91 = n2 + 0.0625;
        final double n92 = n3 + 0.0625;
        final double n93 = n3 + 0.9375;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n89, n91, n92, n85, n88);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n89, n91, n93, n85, n87);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n89, n90, n93, n86, n87);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n89, n90, n92, n86, n88);
        if (!b) {
            n6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3);
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n94 = (n4 * 16.0 + 0.0) / 256.0;
        final double n95 = (n4 * 16.0 + 1.0 - 0.01) / 256.0;
        final double n96 = (n5 * 16.0 + 0.0) / 512.0;
        final double n97 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n98 = n + 0.0;
        final double n99 = n + 0.0625;
        final double n100 = n2 + 0.25;
        final double n101 = n3 + 0.0;
        final double n102 = n3 + 1;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n99, n100, n102, n94, n97);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n99, n100, n101, n94, n96);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n98, n100, n101, n95, n96);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n98, n100, n102, n95, n97);
        final double n103 = (n4 * 16.0 + 0.0) / 256.0;
        final double n104 = (n4 * 16.0 + 1.0 - 0.01) / 256.0;
        final double n105 = (n5 * 16.0 + 0.0) / 512.0;
        final double n106 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n107 = n + 0.9375;
        final double n108 = n + 1;
        final double n109 = n2 + 0.25;
        final double n110 = n3 + 0.0;
        final double n111 = n3 + 1;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n108, n109, n111, n103, n106);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n108, n109, n110, n103, n105);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n107, n109, n110, n104, n105);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n107, n109, n111, n104, n106);
        final double n112 = (n4 * 16.0 + 1.0) / 256.0;
        final double n113 = (n4 * 16.0 + 15.0 - 0.01) / 256.0;
        final double n114 = (n5 * 16.0 + 0.0) / 512.0;
        final double n115 = (n5 * 16.0 + 1.0 - 0.01) / 512.0;
        final double n116 = n + 0.0625;
        final double n117 = n + 0.9375;
        final double n118 = n2 + 0.25;
        final double n119 = n3 + 0.0;
        final double n120 = n3 + 0.0625;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n117, n118, n120, n112, n115);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n117, n118, n119, n112, n114);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n116, n118, n119, n113, n114);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n116, n118, n120, n113, n115);
        final double n121 = (n4 * 16.0 + 1.0) / 256.0;
        final double n122 = (n4 * 16.0 + 15.0 - 0.01) / 256.0;
        final double n123 = (n5 * 16.0 + 0.0) / 512.0;
        final double n124 = (n5 * 16.0 + 1.0 - 0.01) / 512.0;
        final double n125 = n + 0.0625;
        final double n126 = n + 0.9375;
        final double n127 = n2 + 0.25;
        final double n128 = n3 + 0.9375;
        final double n129 = n3 + 1;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n126, n127, n129, n121, n124);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n126, n127, n128, n121, n123);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n125, n127, n128, n122, n123);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n125, n127, n129, n122, n124);
        final double n130 = (n4 * 16.0 + 1.0) / 256.0;
        final double n131 = (n4 * 16.0 + 15.0 - 0.01) / 256.0;
        final double n132 = (n5 * 16.0 + 1.0) / 512.0;
        final double n133 = (n5 * 16.0 + 15.0 - 0.01) / 512.0;
        final double n134 = n + 0.0625;
        final double n135 = n + 0.9375;
        final double n136 = n2 + 0.125;
        final double n137 = n3 + 0.0625;
        final double n138 = n3 + 0.9375;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n135, n136, n138, n130, n133);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n135, n136, n137, n130, n132);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n134, n136, n137, n131, n132);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n134, n136, n138, n131, n133);
        if (!b) {
            n6 = Math.min(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3 - 1), 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3));
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n139 = (n4 * 16.0 + 1.0) / 256.0;
        final double n140 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n141 = (n5 * 16.0 + 1.0) / 512.0;
        final double n142 = (n5 * 16.0 + 15.0 - 0.01) / 512.0;
        final double n143 = n + 0.0625;
        final double n144 = n + 0.9375;
        final double n145 = n2 + 0.125;
        final double n146 = n2 + 0.25;
        final double n147 = n3 + 0.9375;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n143, n146, n147, n139, n142);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n144, n146, n147, n139, n141);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n144, n145, n147, n140, n141);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n143, n145, n147, n140, n142);
        if (!b) {
            n6 = Math.min(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3 + 1), 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3));
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n148 = (n4 * 16.0 + 1.0) / 256.0;
        final double n149 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n150 = (n5 * 16.0 + 1.0) / 512.0;
        final double n151 = (n5 * 16.0 + 15.0 - 0.01) / 512.0;
        final double n152 = n + 0.0625;
        final double n153 = n + 0.9375;
        final double n154 = n2 + 0.125;
        final double n155 = n2 + 0.25;
        final double n156 = n3 + 0.0625;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n153, n155, n156, n148, n151);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n152, n155, n156, n148, n150);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n152, n154, n156, n149, n150);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n153, n154, n156, n149, n151);
        if (!b) {
            n6 = Math.min(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2 + 1, n3), 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3));
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n157 = (n4 * 16.0 + 1.0) / 256.0;
        final double n158 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n159 = (n5 * 16.0 + 0.0) / 512.0;
        final double n160 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n161 = n + 0.9375;
        final double n162 = n2 + 0.125;
        final double n163 = n2 + 0.25;
        final double n164 = n3 + 0.0625;
        final double n165 = n3 + 0.9375;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n161, n163, n165, n157, n160);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n161, n163, n164, n157, n159);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n161, n162, n164, n158, n159);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n161, n162, n165, n158, n160);
        if (!b) {
            n6 = Math.min(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2 + 1, n3), 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3));
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6, n6, n6);
        final double n166 = (n4 * 16.0 + 1.0) / 256.0;
        final double n167 = (n4 * 16.0 + 4.0 - 0.01) / 256.0;
        final double n168 = (n5 * 16.0 + 0.0) / 512.0;
        final double n169 = (n5 * 16.0 + 16.0 - 0.01) / 512.0;
        final double n170 = n + 0.0625;
        final double n171 = n2 + 0.125;
        final double n172 = n2 + 0.25;
        final double n173 = n3 + 0.0625;
        final double n174 = n3 + 0.9375;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n170, n172, n173, n166, n169);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n170, n172, n174, n166, n168);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n170, n171, n174, n167, n168);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n170, n171, n173, n167, n169);
        int n175 = 13;
        int n176 = 12;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(1.0f, 1.0f, 1.0f);
        final 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23 = b ? null : ((62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23)this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.6hPp92kZVrpu289Er027gE6XGPzFeGBQ5pS5JM73GUT6dyg108A5z3pHTQtS(n, n2, n3));
        if (!b && n2 > 1) {
            final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 - 1, n3);
            final 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q24 = (62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23)this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.6hPp92kZVrpu289Er027gE6XGPzFeGBQ5pS5JM73GUT6dyg108A5z3pHTQtS(n, n2, n3);
            if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.9ahEk44g1W40z5V183H1RPKo0ScPg2l3Vgv7Ym9H7D0cyl61r006LaO0nr04.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(0.2f, 1.0f, 0.2f);
            }
            else if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.38JbakIO9Vv8b277ud91V8kcowZjbd150n0DOoEKElI232Vo714ou0Uc7b33.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(0.1f, 1.0f, 0.4f);
            }
            else if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06vDOK1oHQ49s4ep0eYM58NjzVjvojuaPT412iLRFZX84J0e1myg2lc1BP2t.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(1.0f, 0.8f, 0.0f);
            }
            else if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.87oBz6hfVZJYumkYtRlHO0L8Ah8393rs22OW044A4Ro4BNjfDb4yX0Xl6AxE.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.2Vmt65Wfq25lrKVxPZ90No4Ne6dH3mnZ449gv6BJP3mAdMR0kEHjAtLqb9vT.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                if (62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q24.7A5js49u3w1saf3A6b4T54BL7kd4S1U491j3uHYFr7bkGut5b3HthPbCC3lP(0).79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp == 64) {
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(1.0f, 0.0f, 0.0f);
                }
                else {
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(0.5f, 0.0f, 0.0f);
                }
            }
            else if (1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.7bEA0Vj8fc40nfMg7Ksg06A4gnumIq005OvGbY74NGnhO198g9DD332xa7p5.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
                n175 = 3;
                n176 = 4;
            }
        }
        if (62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23 == null || 62FF97b5AUKe9Y4lEvtgdzqy6g2tK98fpcjH0f96lIwyM9UB83H0xn459mU4Kw6Qg709jljQ4De7T9o95jRtjPiPkl9q23.7A5js49u3w1saf3A6b4T54BL7kd4S1U491j3uHYFr7bkGut5b3HthPbCC3lP(0).79d1F939h1INyxg1oYp3epHUW8nvY23X9CpXFrDNY7E1sU1bt8Ix5Aw0EsGp > 0) {
            final double n177 = (n175 * 16.0 + 1.0) / 256.0;
            final double n178 = (n175 * 16.0 + 15.0 - 0.01) / 256.0;
            final double n179 = (n176 * 16.0 + 1.0) / 512.0;
            final double n180 = (n176 * 16.0 + 15.0 - 0.01) / 512.0;
            final double n181 = n + 0.0625;
            final double n182 = n + 0.9375;
            final double n183 = n2 + 0.125;
            final double n184 = n3 + 0.0625;
            final double n185 = n3 + 0.9375;
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n182, n183, n185, n177, n180);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n182, n183, n184, n177, n179);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n181, n183, n184, n178, n179);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n181, n183, n185, n178, n180);
        }
        return true;
    }
    
    public boolean 3v7BiQ2RpL6yJCwz7GDc5Qz0o59T2qIo50WkU33P8G9TTAs7sn4982WId5EK(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6d2I3I4vOb31k71n5T3Q571f8H4GnV6FZgY5OqJVJfhWr0f15B8y07v17loo[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0] > 0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1.0f;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
        final double n4 = 0.4000000059604645;
        final double n5 = 0.5 - n4;
        final double n6 = 0.20000000298023224;
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 1) {
            this.2d040vjeuigO94rTcLCz673jfA79MB6yE4BOaIcHIi9yHHFMH7a2no0a61vr(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n - n5, n2 + n6, n3, -n4, 0.0);
        }
        else if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 2) {
            this.2d040vjeuigO94rTcLCz673jfA79MB6yE4BOaIcHIi9yHHFMH7a2no0a61vr(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n + n5, n2 + n6, n3, n4, 0.0);
        }
        else if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 3) {
            this.2d040vjeuigO94rTcLCz673jfA79MB6yE4BOaIcHIi9yHHFMH7a2no0a61vr(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2 + n6, n3 - n5, 0.0, -n4);
        }
        else if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 4) {
            this.2d040vjeuigO94rTcLCz673jfA79MB6yE4BOaIcHIi9yHHFMH7a2no0a61vr(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2 + n6, n3 + n5, 0.0, n4);
        }
        else {
            this.2d040vjeuigO94rTcLCz673jfA79MB6yE4BOaIcHIi9yHHFMH7a2no0a61vr(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 0.0, 0.0);
        }
        return true;
    }
    
    public boolean 12m6bh4Q9sj89ihw5KY7a4G4rI8hphCaDOe4fawWjdz8EFabLXY2W8fRVO09(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        final int n4 = 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P & 0x7;
        final boolean b = (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P & 0x8) > 0;
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        final boolean b2 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0;
        if (!b2) {
            this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6rS3xbs7wahIF9bMwSla3UwNjKn0NEJxwOr6TzBWLXXgX67f27Rv4f3UQ7Hv.9Jh5mk8D5l9P2bI8Lv7m90647ug7tSSFv7qK59d4IjI9GQxu4G3jcaZl5w41;
        }
        final float n5 = 0.25f;
        final float n6 = 0.1875f;
        final float n7 = 0.1875f;
        if (n4 == 5) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f - n6, 0.0f, 0.5f - n5, 0.5f + n6, n7, 0.5f + n5);
        }
        else if (n4 == 6) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f - n5, 0.0f, 0.5f - n6, 0.5f + n5, n7, 0.5f + n6);
        }
        else if (n4 == 4) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f - n6, 0.5f - n5, 1.0f - n7, 0.5f + n6, 0.5f + n5, 1.0f);
        }
        else if (n4 == 3) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f - n6, 0.5f - n5, 0.0f, 0.5f + n6, 0.5f + n5, n7);
        }
        else if (n4 == 2) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(1.0f - n7, 0.5f - n5, 0.5f - n6, 1.0f, 0.5f + n5, 0.5f + n6);
        }
        else if (n4 == 1) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.5f - n5, 0.5f - n6, n7, 0.5f + n5, 0.5f + n6);
        }
        this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        if (!b2) {
            this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = -1;
        }
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6d2I3I4vOb31k71n5T3Q571f8H4GnV6FZgY5OqJVJfhWr0f15B8y07v17loo[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0] > 0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1.0f;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
        int n8 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0);
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            n8 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n9 = (n8 & 0xF) << 4;
        final int n10 = n8 & 0xFF0;
        float n11 = n9 / 256.0f;
        float n12 = (n9 + 15.99f) / 256.0f;
        float n13 = n10 / 512.0f;
        float n14 = (n10 + 15.99f) / 512.0f;
        final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457[] array = new 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457[8];
        final float n15 = 0.0625f;
        final float n16 = 0.0625f;
        final float n17 = 0.625f;
        array[0] = 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(-n15, 0.0, -n16);
        array[1] = 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(n15, 0.0, -n16);
        array[2] = 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(n15, 0.0, n16);
        array[3] = 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(-n15, 0.0, n16);
        array[4] = 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(-n15, n17, -n16);
        array[5] = 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(n15, n17, -n16);
        array[6] = 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(n15, n17, n16);
        array[7] = 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.3U7R0JnTZ7kX6vm964SG7F17UI6Z3EKpRyZKAO1uH3hS7xiw24qS6FA35810(-n15, n17, n16);
        for (int i = 0; i < 8; ++i) {
            if (b) {
                final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 = array[i];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF -= 0.0625;
                array[i].040Y53WV6CD369l1cRf83BC162Z395T1Roimm2brn42FqRrVsnMtDMRUS9VT(0.69813174f);
            }
            else {
                final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti458 = array[i];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti458.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF += 0.0625;
                array[i].040Y53WV6CD369l1cRf83BC162Z395T1Roimm2brn42FqRrVsnMtDMRUS9VT(-0.69813174f);
            }
            if (n4 == 6) {
                array[i].89EusN5nf6y2A83GY1CJV9o0s3Y4jcXNeGL7xf44yK679n2wKsH4c1oK4X7a(1.5707964f);
            }
            if (n4 < 5) {
                final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti459 = array[i];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti459.5wRQ3f09mhVbrkWp9ni13w5Ss0dIm9OImDlyjLJaXBrUy1xUXCzWTfQJow9c -= 0.375;
                array[i].040Y53WV6CD369l1cRf83BC162Z395T1Roimm2brn42FqRrVsnMtDMRUS9VT(1.5707964f);
                if (n4 == 4) {
                    array[i].89EusN5nf6y2A83GY1CJV9o0s3Y4jcXNeGL7xf44yK679n2wKsH4c1oK4X7a(0.0f);
                }
                if (n4 == 3) {
                    array[i].89EusN5nf6y2A83GY1CJV9o0s3Y4jcXNeGL7xf44yK679n2wKsH4c1oK4X7a(3.1415927f);
                }
                if (n4 == 2) {
                    array[i].89EusN5nf6y2A83GY1CJV9o0s3Y4jcXNeGL7xf44yK679n2wKsH4c1oK4X7a(1.5707964f);
                }
                if (n4 == 1) {
                    array[i].89EusN5nf6y2A83GY1CJV9o0s3Y4jcXNeGL7xf44yK679n2wKsH4c1oK4X7a(-1.5707964f);
                }
                final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti460 = array[i];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti460.2eY43A926V72BOu2G531aa2ZhODT8w5mCxf6jNpHYkd0HHxvk9yRC9Ix62k9 += n + 0.5;
                final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti461 = array[i];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti461.5wRQ3f09mhVbrkWp9ni13w5Ss0dIm9OImDlyjLJaXBrUy1xUXCzWTfQJow9c += n2 + 0.5f;
                final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti462 = array[i];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti462.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF += n3 + 0.5;
            }
            else {
                final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti463 = array[i];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti463.2eY43A926V72BOu2G531aa2ZhODT8w5mCxf6jNpHYkd0HHxvk9yRC9Ix62k9 += n + 0.5;
                final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti464 = array[i];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti464.5wRQ3f09mhVbrkWp9ni13w5Ss0dIm9OImDlyjLJaXBrUy1xUXCzWTfQJow9c += n2 + 0.125f;
                final 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti465 = array[i];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti465.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF += n3 + 0.5;
            }
        }
        2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466 = null;
        2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467 = null;
        2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468 = null;
        2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti457 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469 = null;
        for (int j = 0; j < 6; ++j) {
            if (j == 0) {
                n11 = (n9 + 7) / 256.0f;
                n12 = (n9 + 9 - 0.01f) / 256.0f;
                n13 = (n10 + 6) / 512.0f;
                n14 = (n10 + 8 - 0.01f) / 512.0f;
            }
            else if (j == 2) {
                n11 = (n9 + 7) / 256.0f;
                n12 = (n9 + 9 - 0.01f) / 256.0f;
                n13 = (n10 + 6) / 512.0f;
                n14 = (n10 + 16 - 0.01f) / 512.0f;
            }
            if (j == 0) {
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466 = array[0];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467 = array[1];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468 = array[2];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469 = array[3];
            }
            else if (j == 1) {
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466 = array[7];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467 = array[6];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468 = array[5];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469 = array[4];
            }
            else if (j == 2) {
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466 = array[1];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467 = array[0];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468 = array[4];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469 = array[5];
            }
            else if (j == 3) {
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466 = array[2];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467 = array[1];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468 = array[5];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469 = array[6];
            }
            else if (j == 4) {
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466 = array[3];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467 = array[2];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468 = array[6];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469 = array[7];
            }
            else if (j == 5) {
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466 = array[0];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467 = array[3];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468 = array[7];
                2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469 = array[4];
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466.2eY43A926V72BOu2G531aa2ZhODT8w5mCxf6jNpHYkd0HHxvk9yRC9Ix62k9, 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466.5wRQ3f09mhVbrkWp9ni13w5Ss0dIm9OImDlyjLJaXBrUy1xUXCzWTfQJow9c, 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti466.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF, n11, n14);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467.2eY43A926V72BOu2G531aa2ZhODT8w5mCxf6jNpHYkd0HHxvk9yRC9Ix62k9, 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467.5wRQ3f09mhVbrkWp9ni13w5Ss0dIm9OImDlyjLJaXBrUy1xUXCzWTfQJow9c, 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti467.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF, n12, n14);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468.2eY43A926V72BOu2G531aa2ZhODT8w5mCxf6jNpHYkd0HHxvk9yRC9Ix62k9, 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468.5wRQ3f09mhVbrkWp9ni13w5Ss0dIm9OImDlyjLJaXBrUy1xUXCzWTfQJow9c, 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti468.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF, n12, n13);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469.2eY43A926V72BOu2G531aa2ZhODT8w5mCxf6jNpHYkd0HHxvk9yRC9Ix62k9, 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469.5wRQ3f09mhVbrkWp9ni13w5Ss0dIm9OImDlyjLJaXBrUy1xUXCzWTfQJow9c, 2eMAz4P6NLNrwz70A5Qv10BoP9ox8TFDDjhjO8qUZxA2cY8xN2XQ0mX7rR4w70M8wo670XPdO2g3OeHdfL1NaM0Ti469.9b28GWdUe2qjFeRQAc3a071tcbRHxOK47OiFLvE6J6I5wltZ44A820V8g7cF, n11, n13);
        }
        return true;
    }
    
    public boolean 4hml809U519l9uAM3j2423vV5ZHC7f1lQI2i422B9lSAfSv20JZ3m6K7gig2(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, int n2, final int n3) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        int n4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0);
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            n4 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
        final int n5 = (n4 & 0xF) << 4;
        final int n6 = n4 & 0xFF0;
        double n7 = n5 / 256.0f;
        double n8 = (n5 + 15.99f) / 256.0f;
        double n9 = n6 / 512.0f;
        double n10 = (n6 + 15.99f) / 512.0f;
        final float n11 = 1.4f;
        if (!this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2 - 1, n3) && !1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5P0gbq1QR95V381vsU1YW37ky63wbm4kYI9hdNi97J2K2578j94T1ly7HaX4.0i86EzqEpk5Ai1Xn9lrztZ9h39bh6lZr83LbjW0vs7ragT51YP68nVAIfIDE(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3)) {
            final float n12 = 0.2f;
            final float n13 = 0.0625f;
            if ((n + n2 + n3 & 0x1) == 0x1) {
                n7 = n5 / 256.0f;
                n8 = (n5 + 15.99f) / 256.0f;
                n9 = (n6 + 16) / 512.0f;
                n10 = (n6 + 15.99f + 16.0f) / 512.0f;
            }
            if ((n / 2 + n2 / 2 + n3 / 2 & 0x1) == 0x1) {
                final double n14 = n8;
                n8 = n7;
                n7 = n14;
            }
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5P0gbq1QR95V381vsU1YW37ky63wbm4kYI9hdNi97J2K2578j94T1ly7HaX4.0i86EzqEpk5Ai1Xn9lrztZ9h39bh6lZr83LbjW0vs7ragT51YP68nVAIfIDE(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2, n3)) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + n11 + n13, n3 + 1, n8, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0 + n13, n3 + 1, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0 + n13, n3 + 0, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + n11 + n13, n3 + 0, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + n11 + n13, n3 + 0, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0 + n13, n3 + 0, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0 + n13, n3 + 1, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + n11 + n13, n3 + 1, n8, n9);
            }
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5P0gbq1QR95V381vsU1YW37ky63wbm4kYI9hdNi97J2K2578j94T1ly7HaX4.0i86EzqEpk5Ai1Xn9lrztZ9h39bh6lZr83LbjW0vs7ragT51YP68nVAIfIDE(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2, n3)) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + n11 + n13, n3 + 0, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - 0, n2 + 0 + n13, n3 + 0, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - 0, n2 + 0 + n13, n3 + 1, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + n11 + n13, n3 + 1, n8, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + n11 + n13, n3 + 1, n8, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - 0, n2 + 0 + n13, n3 + 1, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - 0, n2 + 0 + n13, n3 + 0, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + n11 + n13, n3 + 0, n7, n9);
            }
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5P0gbq1QR95V381vsU1YW37ky63wbm4kYI9hdNi97J2K2578j94T1ly7HaX4.0i86EzqEpk5Ai1Xn9lrztZ9h39bh6lZr83LbjW0vs7ragT51YP68nVAIfIDE(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 - 1)) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n11 + n13, n3 + n12, n8, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0 + n13, n3 + 0, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0 + n13, n3 + 0, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n11 + n13, n3 + n12, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n11 + n13, n3 + n12, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0 + n13, n3 + 0, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0 + n13, n3 + 0, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n11 + n13, n3 + n12, n8, n9);
            }
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5P0gbq1QR95V381vsU1YW37ky63wbm4kYI9hdNi97J2K2578j94T1ly7HaX4.0i86EzqEpk5Ai1Xn9lrztZ9h39bh6lZr83LbjW0vs7ragT51YP68nVAIfIDE(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 + 1)) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n11 + n13, n3 + 1 - n12, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0 + n13, n3 + 1 - 0, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0 + n13, n3 + 1 - 0, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n11 + n13, n3 + 1 - n12, n8, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n11 + n13, n3 + 1 - n12, n8, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0 + n13, n3 + 1 - 0, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0 + n13, n3 + 1 - 0, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n11 + n13, n3 + 1 - n12, n7, n9);
            }
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5P0gbq1QR95V381vsU1YW37ky63wbm4kYI9hdNi97J2K2578j94T1ly7HaX4.0i86EzqEpk5Ai1Xn9lrztZ9h39bh6lZr83LbjW0vs7ragT51YP68nVAIfIDE(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3)) {
                final double n15 = n + 0.5 + 0.5;
                final double n16 = n + 0.5 - 0.5;
                final double n17 = n3 + 0.5 + 0.5;
                final double n18 = n3 + 0.5 - 0.5;
                final double n19 = n + 0.5 - 0.5;
                final double n20 = n + 0.5 + 0.5;
                final double n21 = n3 + 0.5 - 0.5;
                final double n22 = n3 + 0.5 + 0.5;
                final double n23 = n5 / 256.0f;
                final double n24 = (n5 + 15.99f) / 256.0f;
                final double n25 = n6 / 512.0f;
                final double n26 = (n6 + 15.99f) / 512.0f;
                ++n2;
                final float n27 = -0.2f;
                if ((n + n2 + n3 & 0x1) == 0x0) {
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n19, n2 + n27, n3 + 0, n24, n25);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15, n2 + 0, n3 + 0, n24, n26);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15, n2 + 0, n3 + 1, n23, n26);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n19, n2 + n27, n3 + 1, n23, n25);
                    final double n28 = n5 / 256.0f;
                    final double n29 = (n5 + 15.99f) / 256.0f;
                    final double n30 = (n6 + 16) / 512.0f;
                    final double n31 = (n6 + 15.99f + 16.0f) / 512.0f;
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n20, n2 + n27, n3 + 1, n29, n30);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n2 + 0, n3 + 1, n29, n31);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n2 + 0, n3 + 0, n28, n31);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n20, n2 + n27, n3 + 0, n28, n30);
                }
                else {
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n27, n22, n24, n25);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0, n18, n24, n26);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0, n18, n23, n26);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n27, n22, n23, n25);
                    final double n32 = n5 / 256.0f;
                    final double n33 = (n5 + 15.99f) / 256.0f;
                    final double n34 = (n6 + 16) / 512.0f;
                    final double n35 = (n6 + 15.99f + 16.0f) / 512.0f;
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n27, n21, n33, n34);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0, n17, n33, n35);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0, n17, n32, n35);
                    8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n27, n21, n32, n34);
                }
            }
        }
        else {
            final double n36 = n + 0.5 + 0.2;
            final double n37 = n + 0.5 - 0.2;
            final double n38 = n3 + 0.5 + 0.2;
            final double n39 = n3 + 0.5 - 0.2;
            final double n40 = n + 0.5 - 0.3;
            final double n41 = n + 0.5 + 0.3;
            final double n42 = n3 + 0.5 - 0.3;
            final double n43 = n3 + 0.5 + 0.3;
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n40, n2 + n11, n3 + 1, n8, n9);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n36, n2 + 0, n3 + 1, n8, n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n36, n2 + 0, n3 + 0, n7, n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n40, n2 + n11, n3 + 0, n7, n9);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n41, n2 + n11, n3 + 0, n8, n9);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n37, n2 + 0, n3 + 0, n8, n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n37, n2 + 0, n3 + 1, n7, n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n41, n2 + n11, n3 + 1, n7, n9);
            final double n44 = n5 / 256.0f;
            final double n45 = (n5 + 15.99f) / 256.0f;
            final double n46 = (n6 + 16) / 512.0f;
            final double n47 = (n6 + 15.99f + 16.0f) / 512.0f;
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n11, n43, n45, n46);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0, n39, n45, n47);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0, n39, n44, n47);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n11, n43, n44, n46);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n11, n42, n45, n46);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0, n38, n45, n47);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0, n38, n44, n47);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n11, n42, n44, n46);
            final double n48 = n + 0.5 - 0.5;
            final double n49 = n + 0.5 + 0.5;
            final double n50 = n3 + 0.5 - 0.5;
            final double n51 = n3 + 0.5 + 0.5;
            final double n52 = n + 0.5 - 0.4;
            final double n53 = n + 0.5 + 0.4;
            final double n54 = n3 + 0.5 - 0.4;
            final double n55 = n3 + 0.5 + 0.4;
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n52, n2 + n11, n3 + 0, n44, n46);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n48, n2 + 0, n3 + 0, n44, n47);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n48, n2 + 0, n3 + 1, n45, n47);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n52, n2 + n11, n3 + 1, n45, n46);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n53, n2 + n11, n3 + 1, n44, n46);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n49, n2 + 0, n3 + 1, n44, n47);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n49, n2 + 0, n3 + 0, n45, n47);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n53, n2 + n11, n3 + 0, n45, n46);
            final double n56 = n5 / 256.0f;
            final double n57 = (n5 + 15.99f) / 256.0f;
            final double n58 = n6 / 512.0f;
            final double n59 = (n6 + 15.99f) / 512.0f;
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n11, n55, n56, n58);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0, n51, n56, n59);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0, n51, n57, n59);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n11, n55, n57, n58);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + n11, n54, n56, n58);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 0, n50, n56, n59);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 0, n50, n57, n59);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + n11, n54, n57, n58);
        }
        return true;
    }
    
    public boolean 9CG9vJ3pt41ntlMJiRJkt9YkRpX6FvU9rtXc5y5FkvrsF2oME9S8Ksl6AJU7(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        int n4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.40s72DHRk8450V5ix2YuPy19ut9O9fnZo2l52KE2s66iT2f3JBdYdBQ0t825(1, this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3));
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            n4 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
        final int n5 = (n4 & 0xF) << 4;
        final int n6 = n4 & 0xFF0;
        double n7 = n5 / 256.0f;
        double n8 = (n5 + 15.99f) / 256.0f;
        double n9 = n6 / 512.0f;
        double n10 = (n6 + 15.99f) / 512.0f;
        final float n11 = 0.0f;
        final float n12 = 0.03125f;
        boolean b = 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2, n3) || (!this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n - 1, n2, n3) && 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2 - 1, n3));
        boolean b2 = 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2, n3) || (!this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n + 1, n2, n3) && 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2 - 1, n3));
        boolean b3 = 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 - 1) || (!this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 - 1) && 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3 - 1));
        boolean b4 = 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 + 1) || (!this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 + 1) && 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3 + 1));
        if (!this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2 + 1, n3)) {
            if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n - 1, n2, n3) && 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2 + 1, n3)) {
                b = true;
            }
            if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n + 1, n2, n3) && 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2 + 1, n3)) {
                b2 = true;
            }
            if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 - 1) && 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3 - 1)) {
                b3 = true;
            }
            if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 + 1) && 27z47Dz7IHWC552Bs3MHO45TO82HS8j31lW2Sosde2SXU0XH0q8y6GBlm5lZGSNW90zy88IZA46EKGO67GFK51P1rBQBpsZ.2n7PPKaPQK4e1S8hGrZ539cP354hPVySFXW17uTgsiOc5nMU1VnD44UiK57l(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3 + 1)) {
                b4 = true;
            }
        }
        final float n13 = 0.3125f;
        float n14 = (float)(n + 0);
        float n15 = (float)(n + 1);
        float n16 = (float)(n3 + 0);
        float n17 = (float)(n3 + 1);
        int n18 = 0;
        if ((b || b2) && !b3 && !b4) {
            n18 = 1;
        }
        if ((b3 || b4) && !b2 && !b) {
            n18 = 2;
        }
        if (n18 != 0) {
            n7 = (n5 + 16) / 256.0f;
            n8 = (n5 + 16 + 15.99f) / 256.0f;
            n9 = n6 / 512.0f;
            n10 = (n6 + 15.99f) / 512.0f;
        }
        if (n18 == 0) {
            if (b2 || b3 || b4 || b) {
                if (!b) {
                    n14 += n13;
                }
                if (!b) {
                    n7 += n13 / 16.0f;
                }
                if (!b2) {
                    n15 -= n13;
                }
                if (!b2) {
                    n8 -= n13 / 16.0f;
                }
                if (!b3) {
                    n16 += n13;
                }
                if (!b3) {
                    n9 += n13 / 32.0f;
                }
                if (!b4) {
                    n17 -= n13;
                }
                if (!b4) {
                    n10 -= n13 / 32.0f;
                }
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15 + n11, n2 + n12, n17 + n11, n8, n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15 + n11, n2 + n12, n16 - n11, n8, n9);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n14 - n11, n2 + n12, n16 - n11, n7, n9);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n14 - n11, n2 + n12, n17 + n11, n7, n10);
        }
        if (n18 == 1) {
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15 + n11, n2 + n12, n17 + n11, n8, n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15 + n11, n2 + n12, n16 - n11, n8, n9);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n14 - n11, n2 + n12, n16 - n11, n7, n9);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n14 - n11, n2 + n12, n17 + n11, n7, n10);
        }
        if (n18 == 2) {
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15 + n11, n2 + n12, n17 + n11, n8, n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15 + n11, n2 + n12, n16 - n11, n7, n10);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n14 - n11, n2 + n12, n16 - n11, n7, n9);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n14 - n11, n2 + n12, n17 + n11, n8, n9);
        }
        final double n19 = (n5 + 16) / 256.0f;
        final double n20 = (n5 + 16 + 15.99f) / 256.0f;
        final double n21 = n6 / 512.0f;
        final double n22 = (n6 + 15.99f) / 512.0f;
        if (!this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2 + 1, n3)) {
            if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n - 1, n2, n3) && this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n - 1, n2 + 1, n3) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.7vfE1ZBd73eYQDtuiOF43q42Z16u3BkPsCcGOfu4RXswiX2wTNf07niBo9j8.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + 1 + n11, n3 + 1 + n11, n20, n21);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + 0 - n11, n3 + 1 + n11, n19, n21);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + 0 - n11, n3 + 0 - n11, n19, n22);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + 1 + n11, n3 + 0 - n11, n20, n22);
            }
            if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n + 1, n2, n3) && this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n + 1, n2 + 1, n3) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.7vfE1ZBd73eYQDtuiOF43q42Z16u3BkPsCcGOfu4RXswiX2wTNf07niBo9j8.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + 0 - n11, n3 + 1 + n11, n19, n22);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + 1 + n11, n3 + 1 + n11, n20, n22);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + 1 + n11, n3 + 0 - n11, n20, n21);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + 0 - n11, n3 + 0 - n11, n19, n21);
            }
            if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 - 1) && this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 + 1, n3 - 1) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.7vfE1ZBd73eYQDtuiOF43q42Z16u3BkPsCcGOfu4RXswiX2wTNf07niBo9j8.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 0 - n11, n3 + n12, n19, n22);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 1 + n11, n3 + n12, n20, n22);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 1 + n11, n3 + n12, n20, n21);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 0 - n11, n3 + n12, n19, n21);
            }
            if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.40WjOxIOf0c936DXdK4Nw96i4wVrQz0WXqCZNEA4Pb08lox7ndN45RPFOUUa(n, n2, n3 + 1) && this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2 + 1, n3 + 1) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.7vfE1ZBd73eYQDtuiOF43q42Z16u3BkPsCcGOfu4RXswiX2wTNf07niBo9j8.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 1 + n11, n3 + 1 - n12, n20, n21);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 0 - n11, n3 + 1 - n12, n19, n21);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 0 - n11, n3 + 1 - n12, n19, n22);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 1 + n11, n3 + 1 - n12, n20, n22);
            }
        }
        return true;
    }
    
    public boolean 14GxM75995p5Wr788537qDl25deDi08BFNzzn6Q2l8394Ner0AM3ijHf7RF8(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        int n4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.40s72DHRk8450V5ix2YuPy19ut9O9fnZo2l52KE2s66iT2f3JBdYdBQ0t825(0, 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P);
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            n4 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
        final int n5 = (n4 & 0xF) << 4;
        final int n6 = n4 & 0xFF0;
        final double n7 = n5 / 256.0f;
        final double n8 = (n5 + 15.99f) / 256.0f;
        final double n9 = n6 / 512.0f;
        final double n10 = (n6 + 15.99f) / 512.0f;
        final float n11 = 0.0625f;
        float n12 = (float)(n + 1);
        float n13 = (float)(n + 1);
        float n14 = (float)(n + 0);
        float n15 = (float)(n + 0);
        float n16 = (float)(n3 + 0);
        float n17 = (float)(n3 + 1);
        float n18 = (float)(n3 + 1);
        float n19 = (float)(n3 + 0);
        float n20 = n2 + n11;
        float n21 = n2 + n11;
        float n22 = n2 + n11;
        float n23 = n2 + n11;
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P != 1 && 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P != 2 && 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P != 3 && 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P != 7) {
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 8) {
                n13 = (n12 = (float)(n + 0));
                n15 = (n14 = (float)(n + 1));
                n19 = (n16 = (float)(n3 + 1));
                n18 = (n17 = (float)(n3 + 0));
            }
            else if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 9) {
                n15 = (n12 = (float)(n + 0));
                n14 = (n13 = (float)(n + 1));
                n17 = (n16 = (float)(n3 + 0));
                n19 = (n18 = (float)(n3 + 1));
            }
        }
        else {
            n15 = (n12 = (float)(n + 1));
            n14 = (n13 = (float)(n + 0));
            n17 = (n16 = (float)(n3 + 1));
            n19 = (n18 = (float)(n3 + 0));
        }
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P != 2 && 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P != 4) {
            if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 3 || 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 5) {
                ++n21;
                ++n22;
            }
        }
        else {
            ++n20;
            ++n23;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n20, n16, n8, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n21, n17, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n14, n22, n18, n7, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15, n23, n19, n7, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n15, n23, n19, n7, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n14, n22, n18, n7, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n21, n17, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n20, n16, n8, n9);
        return true;
    }
    
    public boolean 1vqU4FBtq7rOPZ5a6KNRLG3A9Of7lWvgigJxCkO0436F94H0bO3MoJ83Rpa6(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        int n4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0);
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            n4 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
        final int n5 = (n4 & 0xF) << 4;
        final int n6 = n4 & 0xFF0;
        final double n7 = n5 / 256.0f;
        final double n8 = (n5 + 15.99f) / 256.0f;
        final double n9 = n6 / 512.0f;
        final double n10 = (n6 + 15.99f) / 512.0f;
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        final float n11 = 0.0f;
        final float n12 = 0.05f;
        switch (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P) {
            case 7: {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + n12, n3 + 1 + n11, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + n12, n3 + 0 - n11, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + n12, n3 + 0 - n11, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + n12, n3 + 1 + n11, n8, n9);
                break;
            }
            case 6: {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 1 - n12, n3 + 1 + n11, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 1 - n12, n3 + 1 + n11, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 1 - n12, n3 + 0 - n11, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 1 - n12, n3 + 0 - n11, n8, n9);
                break;
            }
            case 5: {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + 1 + n11, n3 + 1 + n11, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + 0 - n11, n3 + 1 + n11, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + 0 - n11, n3 + 0 - n11, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n12, n2 + 1 + n11, n3 + 0 - n11, n8, n9);
                break;
            }
            case 4: {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + 0 - n11, n3 + 1 + n11, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + 1 + n11, n3 + 1 + n11, n8, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + 1 + n11, n3 + 0 - n11, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 - n12, n2 + 0 - n11, n3 + 0 - n11, n7, n10);
                break;
            }
            case 3: {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 0 - n11, n3 + n12, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 1 + n11, n3 + n12, n8, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 1 + n11, n3 + n12, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 0 - n11, n3 + n12, n7, n10);
                break;
            }
            case 2: {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 1 + n11, n3 + 1 - n12, n7, n9);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1 + n11, n2 + 0 - n11, n3 + 1 - n12, n7, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 0 - n11, n3 + 1 - n12, n8, n10);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0 - n11, n2 + 1 + n11, n3 + 1 - n12, n8, n9);
                break;
            }
        }
        return true;
    }
    
    public boolean 5mXZGX3IUOI3005X5l3ocw5rZoXPiY87s7q7YP6y52QXsGlTn0Vz1jd2GD3V(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
        this.5Tty6465kPS2a8fEVS8kON27ApL089XmrR7FmOrMdg4AFs4nyY8dXttzus98(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3), n, n2, n3);
        return true;
    }
    
    public boolean 78eFp7F47rBLNwlYXpH797X2j8LRM09PE9qzSbj390SCz3oh5EVZbOY94s4F(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
        this.55NY14L243YUTKwU1D4Z3DnPc7HIAmZpR4A2G0Kec99iQDO4Ss35ixOJ15M3(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3), n, n2 - 0.0625f, n3);
        return true;
    }
    
    public void 2d040vjeuigO94rTcLCz673jfA79MB6yE4BOaIcHIi9yHHFMH7a2no0a61vr(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, double n, final double n2, double n3, final double n4, final double n5) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        int n6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0);
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            n6 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n7 = (n6 & 0xF) << 4;
        final int n8 = n6 & 0xFF0;
        final float n9 = n7 / 256.0f;
        final float n10 = (n7 + 15.99f) / 256.0f;
        final float n11 = n8 / 512.0f;
        final float n12 = (n8 + 15.99f) / 512.0f;
        final double n13 = n9 + 0.02734375;
        final double n14 = n11 + 0.0234375;
        final double n15 = n9 + 0.03515625;
        final double n16 = n11 + 0.03125;
        n += 0.5;
        n3 += 0.5;
        final double n17 = n - 0.5;
        final double n18 = n + 0.5;
        final double n19 = n3 - 0.5;
        final double n20 = n3 + 0.5;
        final double n21 = 0.0625;
        final double n22 = 0.625;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n4 * (1.0 - n22) - n21, n2 + n22, n3 + n5 * (1.0 - n22) - n21, n13, n14);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n4 * (1.0 - n22) - n21, n2 + n22, n3 + n5 * (1.0 - n22) + n21, n13, n16);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n4 * (1.0 - n22) + n21, n2 + n22, n3 + n5 * (1.0 - n22) + n21, n15, n16);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n4 * (1.0 - n22) + n21, n2 + n22, n3 + n5 * (1.0 - n22) - n21, n15, n14);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n - n21, n2 + 1.0, n19, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n - n21 + n4, n2 + 0.0, n19 + n5, n9, n12);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n - n21 + n4, n2 + 0.0, n20 + n5, n10, n12);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n - n21, n2 + 1.0, n20, n10, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n21, n2 + 1.0, n20, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n4 + n21, n2 + 0.0, n20 + n5, n9, n12);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n4 + n21, n2 + 0.0, n19 + n5, n10, n12);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + n21, n2 + 1.0, n19, n10, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n2 + 1.0, n3 + n21, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17 + n4, n2 + 0.0, n3 + n21 + n5, n9, n12);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n18 + n4, n2 + 0.0, n3 + n21 + n5, n10, n12);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n18, n2 + 1.0, n3 + n21, n10, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n18, n2 + 1.0, n3 - n21, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n18 + n4, n2 + 0.0, n3 - n21 + n5, n9, n12);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17 + n4, n2 + 0.0, n3 - n21 + n5, n10, n12);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n2 + 1.0, n3 - n21, n10, n11);
    }
    
    public void 5Tty6465kPS2a8fEVS8kON27ApL089XmrR7FmOrMdg4AFs4nyY8dXttzus98(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final double n2, final double n3, final double n4) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        int n5 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.562a2lhwZKvA2q1SYRkk6a3ib277RkRI785Nc3EOo7NAF01ZLdp6C8534NoH(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, 0, n, n2, n3, n4);
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            n5 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n6 = (n5 & 0xF) << 4;
        final int n7 = n5 & 0xFF0;
        final double n8 = n6 / 256.0f;
        final double n9 = (n6 + 15.99f) / 256.0f;
        final double n10 = n7 / 512.0f;
        final double n11 = (n7 + 15.99f) / 512.0f;
        final double n12 = n2 + 0.5 - 0.44999998807907104;
        final double n13 = n2 + 0.5 + 0.44999998807907104;
        final double n14 = n4 + 0.5 - 0.44999998807907104;
        final double n15 = n4 + 0.5 + 0.44999998807907104;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 1.0, n14, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 0.0, n14, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 0.0, n15, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 1.0, n15, n9, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 1.0, n15, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 0.0, n15, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 0.0, n14, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 1.0, n14, n9, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 1.0, n15, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 0.0, n15, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 0.0, n14, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 1.0, n14, n9, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 1.0, n14, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 0.0, n14, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 0.0, n15, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 1.0, n15, n9, n10);
    }
    
    public void 55NY14L243YUTKwU1D4Z3DnPc7HIAmZpR4A2G0Kec99iQDO4Ss35ixOJ15M3(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final double n2, final double n3, final double n4) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        int n5 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.40s72DHRk8450V5ix2YuPy19ut9O9fnZo2l52KE2s66iT2f3JBdYdBQ0t825(0, n);
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            n5 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n6 = (n5 & 0xF) << 4;
        final int n7 = n5 & 0xFF0;
        final double n8 = n6 / 256.0f;
        final double n9 = (n6 + 15.99f) / 256.0f;
        final double n10 = n7 / 512.0f;
        final double n11 = (n7 + 15.99f) / 512.0f;
        final double n12 = n2 + 0.5 - 0.25;
        final double n13 = n2 + 0.5 + 0.25;
        final double n14 = n4 + 0.5 - 0.5;
        final double n15 = n4 + 0.5 + 0.5;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 1.0, n14, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 0.0, n14, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 0.0, n15, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 1.0, n15, n9, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 1.0, n15, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 0.0, n15, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 0.0, n14, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n3 + 1.0, n14, n9, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 1.0, n15, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 0.0, n15, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 0.0, n14, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 1.0, n14, n9, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 1.0, n14, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 0.0, n14, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 0.0, n15, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n13, n3 + 1.0, n15, n9, n10);
        final double n16 = n2 + 0.5 - 0.5;
        final double n17 = n2 + 0.5 + 0.5;
        final double n18 = n4 + 0.5 - 0.25;
        final double n19 = n4 + 0.5 + 0.25;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n3 + 1.0, n18, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n3 + 0.0, n18, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n3 + 0.0, n18, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n3 + 1.0, n18, n9, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n3 + 1.0, n18, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n3 + 0.0, n18, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n3 + 0.0, n18, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n3 + 1.0, n18, n9, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n3 + 1.0, n19, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n3 + 0.0, n19, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n3 + 0.0, n19, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n3 + 1.0, n19, n9, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n3 + 1.0, n19, n8, n10);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n16, n3 + 0.0, n19, n8, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n3 + 0.0, n19, n9, n11);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n17, n3 + 1.0, n19, n9, n10);
    }
    
    public boolean 99lHkqs3rdyDqmATSHE8u17bA6T7Sy4YN3H9qaf37mfMS17FM0QGjpkX4DHX(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        final boolean 545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3, 1);
        final boolean 545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe2 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3, 0);
        final boolean[] array = { 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 - 1, 2), 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 + 1, 3), 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2, n3, 4), 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2, n3, 5) };
        if (!545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe && !545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe2 && !array[0] && !array[1] && !array[2] && !array[3]) {
            return false;
        }
        boolean b = false;
        final float n4 = 0.5f;
        final float n5 = 1.0f;
        final float n6 = 0.8f;
        final float n7 = 0.6f;
        final double 984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 = 0.0;
        final double 06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g = 1.0;
        final 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ 5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF;
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        final float 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj4 = this.1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj4(n, n2, n3, 5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF);
        final float 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj5 = this.1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj4(n, n2, n3 + 1, 5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF);
        final float 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj6 = this.1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj4(n + 1, n2, n3 + 1, 5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF);
        final float 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj7 = this.1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj4(n + 1, n2, n3, 5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF);
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe) {
            b = true;
            int n8 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.40s72DHRk8450V5ix2YuPy19ut9O9fnZo2l52KE2s66iT2f3JBdYdBQ0t825(1, 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P);
            float n9 = (float)9SL4SDf2otit8aKAUl336vAsw14OUqz4M03At0H4nZ53vU9zdFuREviUZ8xL1o595dQ13J1Ma7o1X9Cl3B2C7rvYz0DB6aaB.095Ly7ZAX9X0f1Rq9s7oTu0pRU3c6dBQ3cvQ223MPK9WOW3mWP1964jH1Vhe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF);
            if (n9 > -999.0f) {
                n8 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.40s72DHRk8450V5ix2YuPy19ut9O9fnZo2l52KE2s66iT2f3JBdYdBQ0t825(2, 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P);
            }
            final int n10 = (n8 & 0xF) << 4;
            final int n11 = n8 & 0xFF0;
            double n12 = (n10 + 8.0) / 256.0;
            double n13 = (n11 + 8.0) / 512.0;
            if (n9 < -999.0f) {
                n9 = 0.0f;
            }
            else {
                n12 = (n10 + 16) / 256.0f;
                n13 = (n11 + 16) / 512.0f;
            }
            final float n14 = 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(n9) * 8.0f / 256.0f;
            final float n15 = 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.1724kYgc5e55Yw1mK1EZTYO084n57BWWaYUE7iquVDiu4hFo5J70Cori9WLs(n9) * 8.0f / 256.0f;
            final float n16 = 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.8Q0rmEh0J3viHS03YD2yB0d94U7H4EG1h6T7M5wAvjX290TsPr9Qkjs8oy0m(n9) * 8.0f / 512.0f;
            final float n17 = 5t78bjRYk0fi1yaf7z3x8U13h4eev2t4rjz0b1ldW6157a5RnUXxo75a0MwN32lv961oZ9qzC8R65xSGg9OE86P22SYrvn.1724kYgc5e55Yw1mK1EZTYO084n57BWWaYUE7iquVDiu4hFo5J70Cori9WLs(n9) * 8.0f / 512.0f;
            final float 4qky7xvWyVTA0E5BzBSmBd43onLI7A59UQ3p1p10OTGVbtrsuZQ9f91Fo5jK = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4QKY7xvWyVTA0E5BzBSmBd43onLI7A59UQ3p1p10OTGVbtrsuZQ9f91Fo5jK(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n5 * 4qky7xvWyVTA0E5BzBSmBd43onLI7A59UQ3p1p10OTGVbtrsuZQ9f91Fo5jK, n5 * 4qky7xvWyVTA0E5BzBSmBd43onLI7A59UQ3p1p10OTGVbtrsuZQ9f91Fo5jK, n5 * 4qky7xvWyVTA0E5BzBSmBd43onLI7A59UQ3p1p10OTGVbtrsuZQ9f91Fo5jK);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj4, n3 + 0, n12 - n15 - n14, n13 - n17 + n16);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 0, n2 + 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj5, n3 + 1, n12 - n15 + n14, n13 + n17 + n16);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj6, n3 + 1, n12 + n15 + n14, n13 + n17 - n16);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n + 1, n2 + 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj7, n3 + 0, n12 + n15 - n14, n13 - n17 - n16);
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe2) {
            final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n4 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, n4 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz, n4 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz);
            this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0));
            b = true;
        }
        for (int i = 0; i < 4; ++i) {
            int n18 = n;
            int n19 = n3;
            if (i == 0) {
                n19 = n3 - 1;
            }
            if (i == 1) {
                ++n19;
            }
            if (i == 2) {
                n18 = n - 1;
            }
            if (i == 3) {
                ++n18;
            }
            final int 40s72DHRk8450V5ix2YuPy19ut9O9fnZo2l52KE2s66iT2f3JBdYdBQ0t825 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.40s72DHRk8450V5ix2YuPy19ut9O9fnZo2l52KE2s66iT2f3JBdYdBQ0t825(i + 2, 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P);
            final int n20 = (40s72DHRk8450V5ix2YuPy19ut9O9fnZo2l52KE2s66iT2f3JBdYdBQ0t825 & 0xF) << 4;
            final int n21 = 40s72DHRk8450V5ix2YuPy19ut9O9fnZo2l52KE2s66iT2f3JBdYdBQ0t825 & 0xFF0;
            if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || array[i]) {
                float n22;
                float n23;
                float n24;
                float n25;
                float n26;
                float n27;
                if (i == 0) {
                    n22 = 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj4;
                    n23 = 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj7;
                    n24 = (float)n;
                    n25 = (float)(n + 1);
                    n26 = (float)n3;
                    n27 = (float)n3;
                }
                else if (i == 1) {
                    n22 = 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj6;
                    n23 = 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj5;
                    n24 = (float)(n + 1);
                    n25 = (float)n;
                    n26 = (float)(n3 + 1);
                    n27 = (float)(n3 + 1);
                }
                else if (i == 2) {
                    n22 = 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj5;
                    n23 = 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj4;
                    n24 = (float)n;
                    n25 = (float)n;
                    n26 = (float)(n3 + 1);
                    n27 = (float)n3;
                }
                else {
                    n22 = 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj7;
                    n23 = 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj6;
                    n24 = (float)(n + 1);
                    n25 = (float)(n + 1);
                    n26 = (float)n3;
                    n27 = (float)(n3 + 1);
                }
                b = true;
                final double n28 = (n20 + 0) / 256.0f;
                final double n29 = (n20 + 16 - 0.01) / 256.0;
                final double n30 = (n21 + (1.0f - n22) * 16.0f) / 512.0f;
                final double n31 = (n21 + (1.0f - n23) * 16.0f) / 512.0f;
                final double n32 = (n21 + 16 - 0.01) / 512.0;
                final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n18, n2, n19);
                float n33;
                if (i < 2) {
                    n33 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 * n6;
                }
                else {
                    n33 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 * n7;
                }
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n5 * n33, n5 * n33, n5 * n33);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n24, n2 + n22, n26, n28, n30);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n25, n2 + n23, n27, n29, n31);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n25, n2 + 0, n27, n29, n32);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n24, n2 + 0, n26, n28, n32);
            }
        }
        1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 = 984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99;
        1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g = 06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g;
        return b;
    }
    
    private float 1ao0RN8unC7pJwWc3Ss0Rbm9R6Tskz7t59XYHGl9gb28u6r52celfqr4Gmj4(final int n, final int n2, final int n3, final 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ) {
        int n4 = 0;
        float n5 = 0.0f;
        for (int i = 0; i < 4; ++i) {
            final int n6 = n - (i & 0x1);
            final int n7 = n3 - (i >> 1 & 0x1);
            if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n6, n2 + 1, n7) == 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ) {
                return 1.0f;
            }
            final 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ 6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF(n6, n2, n7);
            if (6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF != 233716kL3y8r6gxg1ubCqEq995rLpa58n0ugDk5G90CW3LAprbMx379L3Bn7N16N8oRevy2kz6Kq01hN7sQb7K1dAC7XqQ) {
                if (!6bgc9eSLzI2wMf5xA55DnfS4LTTED2EB5uQeLx6Sw3e6I13HD3Bc6u5UC8pF.9ds4xXwo0Mq8r5JKgqLfl7fC5v2nx49P75PMHmC41N3fXTw36Yw0TplRa9YV()) {
                    ++n5;
                    ++n4;
                }
            }
            else {
                final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n6, n2, n7);
                if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P >= 8 || 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 0) {
                    n5 += 9SL4SDf2otit8aKAUl336vAsw14OUqz4M03At0H4nZ53vU9zdFuREviUZ8xL1o595dQ13J1Ma7o1X9Cl3B2C7rvYz0DB6aaB.0CpFHVxepg4q76WfYfXG95JTd5eovK3dM5ZzVImyB8VH2SwyDBl475apQ93N(5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P) * 10.0f;
                    n4 += 10;
                }
                n5 += 9SL4SDf2otit8aKAUl336vAsw14OUqz4M03At0H4nZ53vU9zdFuREviUZ8xL1o595dQ13J1Ma7o1X9Cl3B2C7rvYz0DB6aaB.0CpFHVxepg4q76WfYfXG95JTd5eovK3dM5ZzVImyB8VH2SwyDBl475apQ93N(5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P);
                ++n4;
            }
        }
        return 1.0f - n5 / n4;
    }
    
    public void 9NJ02OJYe8t3NgqWF0N29S9Z3FR2327BQxzeY2i9Tt19ENQlZ56Sc2u36Mnn(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final int n, final int n2, final int n3) {
        final float n4 = 0.5f;
        final float n5 = 1.0f;
        final float n6 = 0.8f;
        final float n7 = 0.6f;
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.0xlkp29IV3dqDsM1STBVfF0j99RiS6z898o5R0ZD1U10LYpJKhI0806gUiFW();
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3);
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2 - 1, n3);
        if (6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 < 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n4 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2, n4 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2, n4 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2);
        this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, -0.5, -0.5, -0.5, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0));
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2 + 1, n3);
        if (6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 < 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n5 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3, n5 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3, n5 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3);
        this.684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, -0.5, -0.5, -0.5, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(1));
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3 - 1);
        if (6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 < 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4, n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4, n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4);
        this.11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, -0.5, -0.5, -0.5, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(2));
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n, n2, n3 + 1);
        if (6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 < 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5, n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5, n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5);
        this.0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, -0.5, -0.5, -0.5, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(3));
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n - 1, n2, n3);
        if (6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 < 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6, n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6, n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6);
        this.9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, -0.5, -0.5, -0.5, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(4));
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, n + 1, n2, n3);
        if (6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 < 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7, n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7, n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7);
        this.9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, -0.5, -0.5, -0.5, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(5));
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
    }
    
    public boolean 7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final int 31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        return this.1okY9OqfLybYqJWV2BjOCdg4Ps1l7FJadJ89AXF34H51K40C84JKM05bOvL3(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, (31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO >> 16 & 0xFF) / 255.0f, (31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO >> 8 & 0xFF) / 255.0f, (31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO & 0xFF) / 255.0f);
    }
    
    public boolean 1okY9OqfLybYqJWV2BjOCdg4Ps1l7FJadJ89AXF34H51K40C84JKM05bOvL3(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3, final float n4, final float n5, final float n6) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        boolean b = false;
        final float n7 = 0.5f;
        final float n8 = 1.0f;
        final float n9 = 0.8f;
        final float n10 = 0.6f;
        final float n11 = n7 * n4;
        final float n12 = n8 * n4;
        final float n13 = n9 * n4;
        final float n14 = n10 * n4;
        final float n15 = n7 * n5;
        final float n16 = n8 * n5;
        final float n17 = n9 * n5;
        final float n18 = n10 * n5;
        final float n19 = n7 * n6;
        final float n20 = n8 * n6;
        final float n21 = n9 * n6;
        final float n22 = n10 * n6;
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3, 0)) {
            final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n11 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2, n15 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2, n19 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2);
            this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 0));
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3, 1)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g != 1.0 && !1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF.3nCAcSXE24ypw0NnjcJe4d1pRapWy5WwH5u9iEFWwvgrgojP9oxn7tAFFGwk()) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n12 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3, n16 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3, n20 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3);
            this.684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 1));
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 - 1, 2)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 - 1);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 > 0.0) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n13 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4, n17 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4, n21 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4);
            this.11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 2));
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 + 1, 3)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 + 1);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 < 1.0) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n13 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5, n17 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5, n21 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5);
            this.0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 3));
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2, n3, 4)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2, n3);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF > 0.0) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n14 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6, n18 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6, n22 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6);
            this.9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 4));
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2, n3, 5)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2, n3);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 < 1.0) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n14 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7, n18 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7, n22 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7);
            this.9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 5));
            b = true;
        }
        return b;
    }
    
    public boolean 2pboSq9199Z3zY0kyQgFH7p1328RC8S9W04JhmameH0g15vtnUo5qS8IKU1h(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final int 31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        return this.001ytZKmo3sH0UaTNKh7AY4t01lL748DPX263r767GE0SZy28xs5e2WS2V06(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, (31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO >> 16 & 0xFF) / 255.0f, (31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO >> 8 & 0xFF) / 255.0f, (31ICGIY74Duc1J9EZqW0ci2nAy3ZZ5XJW6kW31Psd6xsbn0VRAnPc3p5eHrO & 0xFF) / 255.0f);
    }
    
    public boolean 001ytZKmo3sH0UaTNKh7AY4t01lL748DPX263r767GE0SZy28xs5e2WS2V06(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3, final float n4, final float n5, final float n6) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        boolean b = false;
        final float n7 = 0.5f;
        final float n8 = 1.0f;
        final float n9 = 0.8f;
        final float n10 = 0.6f;
        final float n11 = n7 * n4;
        final float n12 = n8 * n4;
        final float n13 = n9 * n4;
        final float n14 = n10 * n4;
        final float n15 = n7 * n5;
        final float n16 = n8 * n5;
        final float n17 = n9 * n5;
        final float n18 = n10 * n5;
        final float n19 = n7 * n6;
        final float n20 = n8 * n6;
        final float n21 = n9 * n6;
        final float n22 = n10 * n6;
        final float n23 = 0.0625f;
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3, 0)) {
            final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n11 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2, n15 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2, n19 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2);
            this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 0));
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3, 1)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g != 1.0 && !1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5k766ZNqRNmCnqR3SfETL73c37Oa81S650D3P1DA0T0DnscFOJ208bzu2IIF.3nCAcSXE24ypw0NnjcJe4d1pRapWy5WwH5u9iEFWwvgrgojP9oxn7tAFFGwk()) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n12 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3, n16 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3, n20 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3);
            this.684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 1));
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 - 1, 2)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 - 1);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 > 0.0) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n13 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4, n17 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4, n21 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(0.0f, 0.0f, n23);
            this.11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 2));
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(0.0f, 0.0f, -n23);
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 + 1, 3)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 + 1);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 < 1.0) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n13 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5, n17 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5, n21 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(0.0f, 0.0f, -n23);
            this.0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 3));
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(0.0f, 0.0f, n23);
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2, n3, 4)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2, n3);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF > 0.0) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n14 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6, n18 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6, n22 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(n23, 0.0f, 0.0f);
            this.9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 4));
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(-n23, 0.0f, 0.0f);
            b = true;
        }
        if (this.2k504b6WDZ8LU6hvqu2n3Xo5HG4275MzRyH4229pi421pgzBqidfqwaRXb46 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.545u4P7BP87i8n2M5A14gfQu8Q0V53utS9t5GA6Ht7M89kWJ6o1OI5lVnWSe(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2, n3, 5)) {
            float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2, n3);
            if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 < 1.0) {
                6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
            }
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n14 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7, n18 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7, n22 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(-n23, 0.0f, 0.0f);
            this.9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 5));
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(n23, 0.0f, 0.0f);
            b = true;
        }
        return b;
    }
    
    public boolean 33YJVc6I9kV8vv5NZ7O0n769O7go9n2ZBS72mricO0ZI5IV1K4N19KOimtkh(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final boolean b = false;
        final float n4 = 0.375f;
        final float n5 = 0.625f;
        1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(n4, 0.0f, n4, n5, 1.0f, n5);
        this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        int n6 = 0;
        boolean b2 = false;
        if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n - 1, n2, n3) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n + 1, n2, n3) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
            n6 = 1;
        }
        if (this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3 - 1) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 || this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3 + 1) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0) {
            b2 = true;
        }
        final boolean b3 = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n - 1, n2, n3) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        final boolean b4 = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n + 1, n2, n3) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        final boolean b5 = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3 - 1) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        final boolean b6 = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n, n2, n3 + 1) == 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
        if (n6 == 0 && !b2) {
            n6 = 1;
        }
        final float n7 = 0.4375f;
        final float n8 = 0.5625f;
        final float n9 = 0.75f;
        final float n10 = 0.9375f;
        final float n11 = b3 ? 0.0f : n7;
        final float n12 = b4 ? 1.0f : n8;
        final float n13 = b5 ? 0.0f : n7;
        final float n14 = b6 ? 1.0f : n8;
        if (n6 != 0) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(n11, n9, n7, n12, n10, n8);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        }
        if (b2) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(n7, n9, n13, n8, n10, n14);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        }
        final float n15 = 0.375f;
        final float n16 = 0.5625f;
        if (n6 != 0) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(n11, n15, n7, n12, n16, n8);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        }
        if (b2) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(n7, n15, n13, n8, n16, n14);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        }
        1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        return b;
    }
    
    public boolean 301E4Fg2576lD5pIL00Y9U8e5Yj4Wd8YN53dhLAz7G1f29kbfDi9120U6zp3(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final boolean b = false;
        final int 5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P = this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW.5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P(n, n2, n3);
        if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 0) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 0.5f, 0.5f, 1.0f);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        }
        else if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 1) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 0.5f, 1.0f, 1.0f);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f, 0.0f, 0.0f, 1.0f, 0.5f, 1.0f);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        }
        else if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 2) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 0.5f, 0.5f);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        }
        else if (5hNl94V3210ap24vFIX1nJ7qOz6LHsQ5NN3CFu8V75N52pd4m20ybB8Fk28P == 3) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.5f);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.5f, 1.0f, 0.5f, 1.0f);
            this.7D416z2L8lk2i96ruF4p5uw7u6qfREA1yc13xZsQPG252dR3e6z4jv2mVs8P(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3);
        }
        1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        return b;
    }
    
    public boolean 4rT8HOSHs584bxNNoOuY8vYjox7u5Mtgo1uI9N4aVdA0eG4t72zDxDDGDlh4(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final int n, final int n2, final int n3) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        final 7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR 7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR = (7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR)1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC;
        final float n4 = 0.5f;
        final float n5 = 1.0f;
        final float n6 = 0.8f;
        final float n7 = 0.6f;
        final float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3);
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 - 1, n3);
        if (7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 > 0.0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6d2I3I4vOb31k71n5T3Q571f8H4GnV6FZgY5OqJVJfhWr0f15B8y07v17loo[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0] > 0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2 = 1.0f;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n4 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2, n4 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2, n4 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz2);
        this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 0));
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2 + 1, n3);
        if (7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g < 1.0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6d2I3I4vOb31k71n5T3Q571f8H4GnV6FZgY5OqJVJfhWr0f15B8y07v17loo[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0] > 0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3 = 1.0f;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n5 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3, n5 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3, n5 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz3);
        this.684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 1));
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 - 1);
        if (7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 > 0.0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6d2I3I4vOb31k71n5T3Q571f8H4GnV6FZgY5OqJVJfhWr0f15B8y07v17loo[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0] > 0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4 = 1.0f;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4, n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4, n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz4);
        int 11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 2);
        if (11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN < 0) {
            this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = true;
            11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN = -11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN;
        }
        this.11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN);
        this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = false;
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3 + 1);
        if (7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 < 1.0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6d2I3I4vOb31k71n5T3Q571f8H4GnV6FZgY5OqJVJfhWr0f15B8y07v17loo[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0] > 0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5 = 1.0f;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5, n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5, n6 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz5);
        int 11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN2 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 3);
        if (11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN2 < 0) {
            this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = true;
            11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN2 = -11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN2;
        }
        this.0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN2);
        this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = false;
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n - 1, n2, n3);
        if (7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF > 0.0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6d2I3I4vOb31k71n5T3Q571f8H4GnV6FZgY5OqJVJfhWr0f15B8y07v17loo[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0] > 0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6 = 1.0f;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6, n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6, n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz6);
        int 11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN3 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 4);
        if (11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN3 < 0) {
            this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = true;
            11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN3 = -11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN3;
        }
        this.9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN3);
        this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = false;
        float 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n + 1, n2, n3);
        if (7q926m93a36jQTtmYhNYbZq4L7z26LBflco6R4gwsJgQ067Xw20VVuAXjkRJ4q4BUX5sQZFFIUo7w6Uw2yVEHURhPBENfI6leR.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 < 1.0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 = 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6d2I3I4vOb31k71n5T3Q571f8H4GnV6FZgY5OqJVJfhWr0f15B8y07v17loo[1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0] > 0) {
            6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7 = 1.0f;
        }
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5dgjULYVi1NvgUYo1snBN8liDbF9k8oar8tMB8su4W4194ph3AYTPoOzIXT8(n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7, n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7, n7 * 6nG8SvG8MW35COMQv4LSd8rQ2JDJAIa371K2aCmeToTo6975s8Q0POTNG5xz7);
        int 11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN4 = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN(this.260AsKr6bEQezOE2oYzVIYtqM1A3Z95aEUwA6c7x2mg2aT0gQkdt7289KPkW, n, n2, n3, 5);
        if (11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN4 < 0) {
            this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = true;
            11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN4 = -11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN4;
        }
        this.9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, n2, n3, 11j2w776N23HH6A1X1pL20T29g8d0hzbo1TCg7Q257L8Y61xExl27ZjH49oN4);
        final boolean b = true;
        this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy = false;
        return b;
    }
    
    public void 5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final double n, final double n2, final double n3, int 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n4 = (5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xF) << 4;
        final int n5 = 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xFF0;
        double n6 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF * 16.0) / 256.0;
        double n7 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 * 16.0 - 0.01) / 256.0;
        double n8 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 * 16.0) / 512.0;
        double n9 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 * 16.0 - 0.01) / 512.0;
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 > 1.0) {
            n6 = (n4 + 0.0f) / 256.0f;
            n7 = (n4 + 15.99f) / 256.0f;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 > 1.0) {
            n8 = (n5 + 0.0f) / 512.0f;
            n9 = (n5 + 15.99f) / 512.0f;
        }
        final double n10 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF;
        final double n11 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0;
        final double n12 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99;
        final double n13 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7;
        final double n14 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n10, n12, n14, n6, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n10, n12, n13, n6, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n12, n13, n7, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n12, n14, n7, n9);
    }
    
    public void 684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final double n, final double n2, final double n3, int 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n4 = (5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xF) << 4;
        final int n5 = 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xFF0;
        double n6 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF * 16.0) / 256.0;
        double n7 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 * 16.0 - 0.01) / 256.0;
        double n8 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 * 16.0) / 512.0;
        double n9 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 * 16.0 - 0.01) / 512.0;
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 > 1.0) {
            n6 = (n4 + 0.0f) / 256.0f;
            n7 = (n4 + 15.99f) / 256.0f;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 > 1.0) {
            n8 = (n5 + 0.0f) / 512.0f;
            n9 = (n5 + 15.99f) / 512.0f;
        }
        final double n10 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF;
        final double n11 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0;
        final double n12 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g;
        final double n13 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7;
        final double n14 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n12, n14, n7, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n12, n13, n7, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n10, n12, n13, n6, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n10, n12, n14, n6, n9);
    }
    
    public void 11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final double n, final double n2, final double n3, int 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n4 = (5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xF) << 4;
        final int n5 = 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xFF0;
        double n6 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF * 16.0) / 256.0;
        double n7 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 * 16.0 - 0.01) / 256.0;
        double n8 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 * 16.0) / 512.0;
        double n9 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g * 16.0 - 0.01) / 512.0;
        if (this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy) {
            final double n10 = n6;
            n6 = n7;
            n7 = n10;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 > 1.0) {
            n6 = (n4 + 0.0f) / 256.0f;
            n7 = (n4 + 15.99f) / 256.0f;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g > 1.0) {
            n8 = (n5 + 0.0f) / 512.0f;
            n9 = (n5 + 15.99f) / 512.0f;
        }
        final double n11 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF;
        final double n12 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0;
        final double n13 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99;
        final double n14 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g;
        final double n15 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n14, n15, n7, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n14, n15, n6, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n13, n15, n6, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n13, n15, n7, n9);
    }
    
    public void 0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final double n, final double n2, final double n3, int 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n4 = (5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xF) << 4;
        final int n5 = 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xFF0;
        double n6 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF * 16.0) / 256.0;
        double n7 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 * 16.0 - 0.01) / 256.0;
        double n8 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 * 16.0) / 512.0;
        double n9 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g * 16.0 - 0.01) / 512.0;
        if (this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy) {
            final double n10 = n6;
            n6 = n7;
            n7 = n10;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0 > 1.0) {
            n6 = (n4 + 0.0f) / 256.0f;
            n7 = (n4 + 15.99f) / 256.0f;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g > 1.0) {
            n8 = (n5 + 0.0f) / 512.0f;
            n9 = (n5 + 15.99f) / 512.0f;
        }
        final double n11 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF;
        final double n12 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0;
        final double n13 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99;
        final double n14 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g;
        final double n15 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n14, n15, n6, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n13, n15, n6, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n13, n15, n7, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n12, n14, n15, n7, n8);
    }
    
    public void 9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final double n, final double n2, final double n3, int 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n4 = (5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xF) << 4;
        final int n5 = 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xFF0;
        double n6 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 * 16.0) / 256.0;
        double n7 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 * 16.0 - 0.01) / 256.0;
        double n8 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 * 16.0) / 512.0;
        double n9 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g * 16.0 - 0.01) / 512.0;
        if (this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy) {
            final double n10 = n6;
            n6 = n7;
            n7 = n10;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 > 1.0) {
            n6 = (n4 + 0.0f) / 256.0f;
            n7 = (n4 + 15.99f) / 256.0f;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g > 1.0) {
            n8 = (n5 + 0.0f) / 512.0f;
            n9 = (n5 + 15.99f) / 512.0f;
        }
        final double n11 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5JdkHyxdY6O633KVXs1eL8vE34YJdAR3Teb47Uc86xC3gjaT9481bmfkG7mF;
        final double n12 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99;
        final double n13 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g;
        final double n14 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7;
        final double n15 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n13, n15, n7, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n13, n14, n6, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n12, n14, n6, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n12, n15, n7, n9);
    }
    
    public void 9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final double n, final double n2, final double n3, int 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258) {
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        if (this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 >= 0) {
            5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 = this.5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258;
        }
        final int n4 = (5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xF) << 4;
        final int n5 = 5g9zFEeRE4G3n5L9yG9Ut46h3cu6cFtq492S4H3w3B55l96pK37Y4oxix258 & 0xFF0;
        double n6 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 * 16.0) / 256.0;
        double n7 = (n4 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 * 16.0 - 0.01) / 256.0;
        double n8 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 * 16.0) / 512.0;
        double n9 = (n5 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g * 16.0 - 0.01) / 512.0;
        if (this.3z2FWZNv4nLkj62FK5VO8Dhepg1osT91l22oMooN9349WN897NM0W3K6Wuyy) {
            final double n10 = n6;
            n6 = n7;
            n7 = n10;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7 < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16 > 1.0) {
            n6 = (n4 + 0.0f) / 256.0f;
            n7 = (n4 + 15.99f) / 256.0f;
        }
        if (1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99 < 0.0 || 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g > 1.0) {
            n8 = (n5 + 0.0f) / 512.0f;
            n9 = (n5 + 15.99f) / 512.0f;
        }
        final double n11 = n + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.38s9OE2rFcHXvGpNTz34h3933zVJfVK23y8knI7vDh9n3o0Mx9msUDA78Js0;
        final double n12 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.984wD2STj4I3KjrH5Ubnbvu2II5Vzs4Z7hwaRiPhiBwqtJZoU1rbTBkxWk99;
        final double n13 = n2 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.06IMVpwqf3wFiay8qR9O8kDdE9i788Lf0j8AT5ynQOD0zEgLyDu5I0Toox8g;
        final double n14 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4K1Y7i5YMk435J42mV5t6meD3M5DNXYTTTnpni258YiVKiKd5Ss55b8lQ2p7;
        final double n15 = n3 + 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.4AHO88W573k0Rji2072w5hu3Mob1j9KK0MBEwVBZM2C3ycLsxvBvU2ilmb16;
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n12, n15, n6, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n12, n14, n7, n9);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n13, n14, n7, n8);
        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.1ORn6lX5GMFEsWn2wqLuH5iZCnSek18x3v553RlX264C4g2z48J419J5eWrY(n11, n13, n15, n6, n8);
    }
    
    public void 2htemQ8zvj6rbx7qf98b011f5MfwDlve82DWCayi58TyN5yoHy4W5D535B6O(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final float n) {
        this.47uFsco7k3MB69GCB74UB9R3EkROVQhfTX6e4vfh9tGQb5JpV1NpUJJZFMS4(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, false);
    }
    
    public void 47uFsco7k3MB69GCB74UB9R3EkROVQhfTX6e4vfh9tGQb5JpV1NpUJJZFMS4(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, final float n, final boolean b) {
        final int 9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP();
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        if (9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP == 0) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5AncSXf5ChdY7QTJ79bza7Vo6fa3K362vz7B1chH92y88dV7p6nNvh9K027w();
            GL11.glTranslatef(-0.5f, -0.5f, -0.5f);
            final float n2 = 0.5f;
            final float n3 = 1.0f;
            final float n4 = 0.8f;
            final float n5 = 0.6f;
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(b);
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5o3NqiN89dd1lqO4U97EwCDWF6Z7M0u2x3alzse9wcJo7oGMyy47h61MTMSu(n3, n3, n3, n);
            this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0));
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5o3NqiN89dd1lqO4U97EwCDWF6Z7M0u2x3alzse9wcJo7oGMyy47h61MTMSu(n2, n2, n2, n);
            this.684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(1));
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5o3NqiN89dd1lqO4U97EwCDWF6Z7M0u2x3alzse9wcJo7oGMyy47h61MTMSu(n4, n4, n4, n);
            this.11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(2));
            this.0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(3));
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.5o3NqiN89dd1lqO4U97EwCDWF6Z7M0u2x3alzse9wcJo7oGMyy47h61MTMSu(n5, n5, n5, n);
            this.9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(4));
            this.9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(5));
            8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
            GL11.glTranslatef(0.5f, 0.5f, 0.5f);
        }
        if (9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP == 14) {
            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5AncSXf5ChdY7QTJ79bza7Vo6fa3K362vz7B1chH92y88dV7p6nNvh9K027w();
            GL11.glTranslatef(-0.5f, -0.5f, -0.5f);
            this.8B43235r8C9U031fm58MPaJBX5ue76jn55uq1BI2rFGWP6v055e5x5khTmjs(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0, 0, 0, true);
            GL11.glTranslatef(0.5f, 0.5f, 0.5f);
        }
    }
    
    public void 14QtQ8fnKoInPS4TzkS3kYgHyL9AHYWc1iLUUZPZSe1tPb1VV736im3a36ct(final 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC) {
        final int n = -1;
        final 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT 8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk = 4Rwayi21P7U4FG30AO4ZjY1nn17NSFEhgFcp7MRAcX7sJ1ju98vl7h7Z7GxSWAHWajFDqC3o1ymdUca5zNBIGlaAnE0wUT.8PZK90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk;
        final int 9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP = 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP();
        switch (9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP) {
            case 14: {
                GL11.glTranslatef(-0.5f, -0.5f, -0.5f);
                this.8B43235r8C9U031fm58MPaJBX5ue76jn55uq1BI2rFGWP6v055e5x5khTmjs(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0, 0, 0, true);
                GL11.glTranslatef(0.5f, 0.5f, 0.5f);
            }
            case 0: {
                1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5AncSXf5ChdY7QTJ79bza7Vo6fa3K362vz7B1chH92y88dV7p6nNvh9K027w();
                GL11.glTranslatef(-0.5f, -0.5f, -0.5f);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, -1.0f, 0.0f);
                this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 1.0f, 0.0f);
                this.684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(1));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 0.0f, -1.0f);
                this.11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(2));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 0.0f, 1.0f);
                this.0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(3));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(-1.0f, 0.0f, 0.0f);
                this.9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(4));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(1.0f, 0.0f, 0.0f);
                this.9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(5));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                GL11.glTranslatef(0.5f, 0.5f, 0.5f);
                break;
            }
            case 1: {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, -1.0f, 0.0f);
                this.5Tty6465kPS2a8fEVS8kON27ApL089XmrR7FmOrMdg4AFs4nyY8dXttzus98(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, -0.5, -0.5, -0.5);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                break;
            }
            case 13: {
                1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.5AncSXf5ChdY7QTJ79bza7Vo6fa3K362vz7B1chH92y88dV7p6nNvh9K027w();
                GL11.glTranslatef(-0.5f, -0.5f, -0.5f);
                final float n2 = 0.0625f;
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, -1.0f, 0.0f);
                this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 1.0f, 0.0f);
                this.684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(1));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 0.0f, -1.0f);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(0.0f, 0.0f, n2);
                this.11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(2));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(0.0f, 0.0f, -n2);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 0.0f, 1.0f);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(0.0f, 0.0f, -n2);
                this.0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(3));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(0.0f, 0.0f, n2);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(-1.0f, 0.0f, 0.0f);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(n2, 0.0f, 0.0f);
                this.9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(4));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(-n2, 0.0f, 0.0f);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(1.0f, 0.0f, 0.0f);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(-n2, 0.0f, 0.0f);
                this.9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(5));
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.61t5gqsh7T5J5wQRZ2mHTz6iA6HxzhhR2M1MH8le8a00gfs5peqOWQ9RgdVB(n2, 0.0f, 0.0f);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                GL11.glTranslatef(0.5f, 0.5f, 0.5f);
                break;
            }
            case 6: {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, -1.0f, 0.0f);
                this.55NY14L243YUTKwU1D4Z3DnPc7HIAmZpR4A2G0Kec99iQDO4Ss35ixOJ15M3(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, n, -0.5, -0.5, -0.5);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                break;
            }
            case 2: {
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, -1.0f, 0.0f);
                this.2d040vjeuigO94rTcLCz673jfA79MB6yE4BOaIcHIi9yHHFMH7a2no0a61vr(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, -0.5, -0.5, -0.5, 0.0, 0.0);
                8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                break;
            }
            default: {
                if (9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP == 10) {
                    for (int i = 0; i < 2; ++i) {
                        if (i == 0) {
                            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.5f);
                        }
                        if (i == 1) {
                            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.5f, 1.0f, 0.5f, 1.0f);
                        }
                        GL11.glTranslatef(-0.5f, -0.5f, -0.5f);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, -1.0f, 0.0f);
                        this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 1.0f, 0.0f);
                        this.684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(1));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 0.0f, -1.0f);
                        this.11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(2));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 0.0f, 1.0f);
                        this.0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(3));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(-1.0f, 0.0f, 0.0f);
                        this.9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(4));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(1.0f, 0.0f, 0.0f);
                        this.9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(5));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        GL11.glTranslatef(0.5f, 0.5f, 0.5f);
                    }
                    break;
                }
                if (9hCH4oKpqF2ugUU63hBZB65WzRCQt68Z9E59EXBrw6t7D7iODWrjsSmZ6SkP == 11) {
                    for (int j = 0; j < 4; ++j) {
                        final float n3 = 0.125f;
                        if (j == 0) {
                            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f - n3, 0.0f, 0.0f, 0.5f + n3, 1.0f, n3 * 2.0f);
                        }
                        if (j == 1) {
                            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f - n3, 0.0f, 1.0f - n3 * 2.0f, 0.5f + n3, 1.0f, 1.0f);
                        }
                        final float n4 = 0.0625f;
                        if (j == 2) {
                            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f - n4, 1.0f - n4 * 3.0f, -n4 * 2.0f, 0.5f + n4, 1.0f - n4, 1.0f + n4 * 2.0f);
                        }
                        if (j == 3) {
                            1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.5f - n4, 0.5f - n4 * 3.0f, -n4 * 2.0f, 0.5f + n4, 0.5f - n4, 1.0f + n4 * 2.0f);
                        }
                        GL11.glTranslatef(-0.5f, -0.5f, -0.5f);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, -1.0f, 0.0f);
                        this.5mMHPj9NVf4IbOvNb1uMJ5v1p4G1dNN01c2vIXjoY52wKHd8yL76YM2zqxxo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(0));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 1.0f, 0.0f);
                        this.684dypq628ox6B9LQpo0WbZES1gg7fce68CR1T0FOHMC4x4e82JB7ZM6NTq6(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(1));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 0.0f, -1.0f);
                        this.11Lu209Od6tQ625ge27m69HX26EP48WTgrR7UNlzO9jsm0bH94ZlQoK31b1B(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(2));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(0.0f, 0.0f, 1.0f);
                        this.0039i1j02t6a97o437zE3zzeKrW30W2b99X4bYykRdAf5haD2HsJJibTTYYo(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(3));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(-1.0f, 0.0f, 0.0f);
                        this.9M99GPlqjKK4I0WUhGN3L48W55M4VH7eT6595OXIL6k5mT7N3s84bnHhxv00(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(4));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.6ayZ4y0DKzlBw0qR3TwrtIK08f0p5iZQu8xsah0R4i2XaEr9LQwCue6wKB06(true);
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.2l4Wz92azU3Qj3VfS3G8kPr6Auzw0XMR9WRdg50UU2z38n536XL9512A4oSa(1.0f, 0.0f, 0.0f);
                        this.9HYDvWW0wkLFbEZ4g641GXsb32GD77q7zzUz80aS0996406CK982510yI4Ml(1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC, 0.0, 0.0, 0.0, 1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.8q3B6kZIhW1c70T9R652N8u39X1baMGeU8QVh9noJ3qCWo545Dcm4hvI9kSd(5));
                        8pzk90pwbY0Ix8mw49n397dpnEeWy4IV27LT8PITn9P4MFQYVE345V9X89Qk.217DqV88NBKYV391UN4J3avyBa7x1t8ArRJwQSwE9iAUknUSm2Wsg5YkG9K2();
                        GL11.glTranslatef(0.5f, 0.5f, 0.5f);
                    }
                    1KjQq26tT3cUE2h3zt5BGj42wc3w980gyGiZq6kKyY7ZMFEN9ALFlPXIX0VW57Z1b0KvTE8sQt8RQ8RBg8xGKhFSDuxaZGCi226hC.89p69iaMsfekm84QwC93ft49LXyyPoFk4mGz1UcvUf2WX6HCIASTjiJZhOYQ(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
                    break;
                }
                break;
            }
        }
    }
    
    public static boolean 3xK949kiE268a0lKOK85mbXoGx941g57d1l06y3H2GL9Vq8lo0RA85Bt6q7g(final int n) {
        return n == 0 || n == 13 || n == 10 || n == 11;
    }
}
