import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

// 
// Decompiled by Procyon v0.6.0
// 

public class 78DIpEh9SVq7hS6dQh8gdGiK9xh8ACd2laB5qVDyM2981663qeDtN93S7D377P61z2PIXlWb3mZKVb2U62XEn227hK2l3AzyxsvT extends Thread
{
    private Socket 4hdM3x8x8H8xEQ0ApXxlRNQR232f3fOfOfPT0IFp1CtkLU1lXOLn86O2d3Mz;
    private DataOutputStream 1h0hvhMOvMFEC16745QxjO6JSpJY885qFBhBiNQPXr4Q1i56CVAZcl6Ui54Q;
    private DataInputStream 0SWy28Y9aXmBJGl4Gs73a9MB7Rjbu6YmAldQFJct67QCiWR1c9fHgaENntwS;
    public String 58G5qxDMzYaXPW0901anYR4qxrI51kMWgxTtaQ7RQ7qCgMR2V5R5Pzt54AxG;
    public int 16Do29F4vXoUq5C0MgZPy9kqphHdZu66vWE0hab183ldzlV1r63ty40b019p;
    public boolean 9X4nqGUAf1yWS2Iw8y1bfym67t28ZwOo30CC4gFwXh6Oy5y2G97G3p394Xvr;
    public List<7oYzM8i6AvFU5A2Q9o06FwWA68w3Dp2ArdLj15snf6NN0E35Zh0AOuf8ng43ing0w36d96tbAwF90VWODNYhVQUGYNdmdo> 4ua37WpvR0Sr61vSI62VmM7R4cBfrcdMtQFUsZaiN2N1Etp9miZWvcp0Ba7n;
    
    public 78DIpEh9SVq7hS6dQh8gdGiK9xh8ACd2laB5qVDyM2981663qeDtN93S7D377P61z2PIXlWb3mZKVb2U62XEn227hK2l3AzyxsvT(final String 58G5qxDMzYaXPW0901anYR4qxrI51kMWgxTtaQ7RQ7qCgMR2V5R5Pzt54AxG, final int 16Do29F4vXoUq5C0MgZPy9kqphHdZu66vWE0hab183ldzlV1r63ty40b019p) {
        this.9X4nqGUAf1yWS2Iw8y1bfym67t28ZwOo30CC4gFwXh6Oy5y2G97G3p394Xvr = true;
        this.4ua37WpvR0Sr61vSI62VmM7R4cBfrcdMtQFUsZaiN2N1Etp9miZWvcp0Ba7n = new ArrayList<7oYzM8i6AvFU5A2Q9o06FwWA68w3Dp2ArdLj15snf6NN0E35Zh0AOuf8ng43ing0w36d96tbAwF90VWODNYhVQUGYNdmdo>();
        this.58G5qxDMzYaXPW0901anYR4qxrI51kMWgxTtaQ7RQ7qCgMR2V5R5Pzt54AxG = 58G5qxDMzYaXPW0901anYR4qxrI51kMWgxTtaQ7RQ7qCgMR2V5R5Pzt54AxG;
        this.16Do29F4vXoUq5C0MgZPy9kqphHdZu66vWE0hab183ldzlV1r63ty40b019p = 16Do29F4vXoUq5C0MgZPy9kqphHdZu66vWE0hab183ldzlV1r63ty40b019p;
    }
    
    @Override
    public void run() {
        try {
            this.4hdM3x8x8H8xEQ0ApXxlRNQR232f3fOfOfPT0IFp1CtkLU1lXOLn86O2d3Mz = new Socket(this.58G5qxDMzYaXPW0901anYR4qxrI51kMWgxTtaQ7RQ7qCgMR2V5R5Pzt54AxG, this.16Do29F4vXoUq5C0MgZPy9kqphHdZu66vWE0hab183ldzlV1r63ty40b019p);
            this.1h0hvhMOvMFEC16745QxjO6JSpJY885qFBhBiNQPXr4Q1i56CVAZcl6Ui54Q = new DataOutputStream(this.4hdM3x8x8H8xEQ0ApXxlRNQR232f3fOfOfPT0IFp1CtkLU1lXOLn86O2d3Mz.getOutputStream());
            this.0SWy28Y9aXmBJGl4Gs73a9MB7Rjbu6YmAldQFJct67QCiWR1c9fHgaENntwS = new DataInputStream(this.4hdM3x8x8H8xEQ0ApXxlRNQR232f3fOfOfPT0IFp1CtkLU1lXOLn86O2d3Mz.getInputStream());
            while (this.9X4nqGUAf1yWS2Iw8y1bfym67t28ZwOo30CC4gFwXh6Oy5y2G97G3p394Xvr) {
                while (this.4ua37WpvR0Sr61vSI62VmM7R4cBfrcdMtQFUsZaiN2N1Etp9miZWvcp0Ba7n.size() == 0) {}
                2K4b2ZR0cq4RX3c76EgL7JeZQQ3322E9qpk1Ro98dsNOu8W54XfX837WeKljd3qBnZF1854Rb39cQ7H9KOWJRBQ3yve2kQcM.5EeMh0K4mokuILvAMVW3c5AkfOMON84Dme338HsIOH6KOV89Pi6o1zIzTo5z(this.1h0hvhMOvMFEC16745QxjO6JSpJY885qFBhBiNQPXr4Q1i56CVAZcl6Ui54Q, new 71xMuDn0tGT5SIsxHFQURYNWWOY9GH1xM4W9bvN2erLUWLKk5m9nf4M7BDY3JQ5h889tiREgUCF660EGl6Y2nRNMSQALv317SxM20());
            }
            this.1h0hvhMOvMFEC16745QxjO6JSpJY885qFBhBiNQPXr4Q1i56CVAZcl6Ui54Q.close();
            this.0SWy28Y9aXmBJGl4Gs73a9MB7Rjbu6YmAldQFJct67QCiWR1c9fHgaENntwS.close();
            this.4hdM3x8x8H8xEQ0ApXxlRNQR232f3fOfOfPT0IFp1CtkLU1lXOLn86O2d3Mz.close();
            7l2e0fYR96rf6dpREUY30xWh65d1rOc3abJQrqtvYEW6GNMN9qeJW237wlzS37y9Xt8xV209FRDRzpsI4HOsGN7skzB8a0.4TOtWqH41d7jD9655kwO3Cg5UDFI8gwADO0lrcf8Wo27yqT11iUXxA20819F("client thread finished");
        }
        catch (final IOException ex) {
            ex.printStackTrace();
        }
    }
}
