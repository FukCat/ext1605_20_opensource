import java.util.Random;

// 
// Decompiled by Procyon v0.6.0
// 

public class 7071C3i0zJ2BF888dT0Slby3gA2HIN1ULW41PU6xoySxAjSf3rhkYBiArsEA6sjtu0oX9M07Sja0VHjntCHic4y8oU307j31 extends 87r662IMou2U51CG8J9u9f3z6153fTpz3Nrsb390O86zGRaf2G88hDdjm7N0kISc6CYl8iJiK499bHBWkppuriW92p9X
{
    private int 2q949kfun6613o8m6TY2a09FCg9HKge0udDw1Zrq8H8crYBgR59f9HSnPUqC;
    
    public 7071C3i0zJ2BF888dT0Slby3gA2HIN1ULW41PU6xoySxAjSf3rhkYBiArsEA6sjtu0oX9M07Sja0VHjntCHic4y8oU307j31(final int 2q949kfun6613o8m6TY2a09FCg9HKge0udDw1Zrq8H8crYBgR59f9HSnPUqC) {
        this.2q949kfun6613o8m6TY2a09FCg9HKge0udDw1Zrq8H8crYBgR59f9HSnPUqC = 2q949kfun6613o8m6TY2a09FCg9HKge0udDw1Zrq8H8crYBgR59f9HSnPUqC;
    }
    
    @Override
    public boolean 1IYSwaCYs0yCiLTHKOX4VGSA0bsiu2jYX0c40mllPE4v40g1Gefmn0q33ame(final 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 64; ++i) {
            final int n4 = n + random.nextInt(8) - random.nextInt(8);
            final int n5;
            final int n6;
            final int 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM = 5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n4, (n5 = n2 + random.nextInt(4) - random.nextInt(4)) - 1, n6 = n3 + random.nextInt(8) - random.nextInt(8));
            final boolean b = 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != 0 && 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != 9 && 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != 116 && 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != 18 && 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.0D8i5Qq7S3z8Gkn5MmZaF1g9yTS2WdGSLMnw1uoI93vb99E2K1toc1X2lfZj.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0 && 1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM != 4o1fC67C3ib7OG1q0Ru4615KorPqPtumwI3cxETG8ch1cILv9mOTo12iY8l4uKp2r3pQv4Jz6b76HWLc4nB7895GvMshP0RV.2Y3Clg20970v2mp9d176cotm46Aq1NW0XxWyu412rOVKJ47iya5Z1vsgA9uL.6eYzDMQF09g6izPuwQHhO952GYS7T3Drt11u0692dlqn6aEztEFQqC6uvfv0;
            if (5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.1067QNIae5R60ff7g36pb246iC4n70M0i8O4gNU913m40r0rAiIY6V14ECmM(n4, n5, n6) == 0) {
                if (b) {
                    5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n4, n5, n6, this.2q949kfun6613o8m6TY2a09FCg9HKge0udDw1Zrq8H8crYBgR59f9HSnPUqC);
                    if (random.nextInt(100) > 50) {
                        5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n4, n5 + 1, n6, this.2q949kfun6613o8m6TY2a09FCg9HKge0udDw1Zrq8H8crYBgR59f9HSnPUqC);
                        if (random.nextInt(100) > 50) {
                            5gdApI3fnTM886NnVpNF5whRWSAY3i2e4yaS902KVT3Vi20lFKKqt7hQxQ4Am9w5DexG9374FK1Y5g7W3H8w65kv4VzY.2JDEdeVYSq88HRy1geb9mO45Z5M1x67GrGCq1dob9EWwH22Al39594U6jKIh(n4, n5 + 2, n6, this.2q949kfun6613o8m6TY2a09FCg9HKge0udDw1Zrq8H8crYBgR59f9HSnPUqC);
                        }
                    }
                }
            }
        }
        return true;
    }
}
