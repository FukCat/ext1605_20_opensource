import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 85MDKF0Jq93x8lmdN1iwtO4w9j8lz84vUg3BaKDeZ2m97168ExHMagcSOh73GP5V5u2S1rexvMA2jDApWEYIhxYw8LUuykv extends 3YAC6RZ6s2my387oS7V3td978c0gJo766d6dK3zs6ECjPFD6ZQK1iy5mN7AfUMNKmda06IYmFxb9I08Rby6pbL9Aq6Gu01j7
{
    public 85MDKF0Jq93x8lmdN1iwtO4w9j8lz84vUg3BaKDeZ2m97168ExHMagcSOh73GP5V5u2S1rexvMA2jDApWEYIhxYw8LUuykv() {
        this.04vuai650le37skOuuaCuD1g981wurNsQXbo3O23oV4l4yeKb37061SoTosj = true;
    }
    
    public 85MDKF0Jq93x8lmdN1iwtO4w9j8lz84vUg3BaKDeZ2m97168ExHMagcSOh73GP5V5u2S1rexvMA2jDApWEYIhxYw8LUuykv(final float 5LdwW5nHxgifk2K7iGlkzRhrf9gZ81GXEQZ3eVk4G6qor0iyg1k0sn02N6Kp, final float 02ig4QYKgL5c7nWgPiD644jsh79AVSZIXB4U7y3gVN8Kjw1nLKK0jonY81GX, final boolean 2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e) {
        this.5LdwW5nHxgifk2K7iGlkzRhrf9gZ81GXEQZ3eVk4G6qor0iyg1k0sn02N6Kp = 5LdwW5nHxgifk2K7iGlkzRhrf9gZ81GXEQZ3eVk4G6qor0iyg1k0sn02N6Kp;
        this.02ig4QYKgL5c7nWgPiD644jsh79AVSZIXB4U7y3gVN8Kjw1nLKK0jonY81GX = 02ig4QYKgL5c7nWgPiD644jsh79AVSZIXB4U7y3gVN8Kjw1nLKK0jonY81GX;
        this.2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e = 2ZdLepk3W588HRYRw65i4846Ud97u05QZP3ntB05yzyKm0YR1NSe7w6f0k8e;
        this.04vuai650le37skOuuaCuD1g981wurNsQXbo3O23oV4l4yeKb37061SoTosj = true;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.5LdwW5nHxgifk2K7iGlkzRhrf9gZ81GXEQZ3eVk4G6qor0iyg1k0sn02N6Kp = dataInputStream.readFloat();
        this.02ig4QYKgL5c7nWgPiD644jsh79AVSZIXB4U7y3gVN8Kjw1nLKK0jonY81GX = dataInputStream.readFloat();
        super.5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(dataInputStream);
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeFloat(this.5LdwW5nHxgifk2K7iGlkzRhrf9gZ81GXEQZ3eVk4G6qor0iyg1k0sn02N6Kp);
        dataOutputStream.writeFloat(this.02ig4QYKgL5c7nWgPiD644jsh79AVSZIXB4U7y3gVN8Kjw1nLKK0jonY81GX);
        super.45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(dataOutputStream);
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return 9;
    }
}
