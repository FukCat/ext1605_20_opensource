import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;

// 
// Decompiled by Procyon v0.6.0
// 

public class 0LC72Kgh2W8Eq2lXHWk8AVHmP1bWphkd6dM7i41L1z48d821GhgEG84618HvyPw10WS13956k4w89MkthdcI74zEJSe52Pi72Y7 extends 5tL0rndgg81QbNd36sHc507Ysx4d5UxNJ85xNpWCG1S6wiQC0yXJ0680h00S2Fn5rPDCq6BbHpgoM2bl4m9ZHK8H52ifAj0gneK
{
    public String 902s024v0T40AC31By11eacj2G9ftX6I7oIimZe17emPq6w323bj398K2v81;
    public int 8TA6UV69W9P3wmw711p172l3T8s0Ptbd25wMM71jF6fUH6cq4n64JE8jvFIR;
    
    public 0LC72Kgh2W8Eq2lXHWk8AVHmP1bWphkd6dM7i41L1z48d821GhgEG84618HvyPw10WS13956k4w89MkthdcI74zEJSe52Pi72Y7() {
        this.902s024v0T40AC31By11eacj2G9ftX6I7oIimZe17emPq6w323bj398K2v81 = "";
        this.8TA6UV69W9P3wmw711p172l3T8s0Ptbd25wMM71jF6fUH6cq4n64JE8jvFIR = 5000;
    }
    
    public 0LC72Kgh2W8Eq2lXHWk8AVHmP1bWphkd6dM7i41L1z48d821GhgEG84618HvyPw10WS13956k4w89MkthdcI74zEJSe52Pi72Y7(final String 902s024v0T40AC31By11eacj2G9ftX6I7oIimZe17emPq6w323bj398K2v81, final int 8ta6UV69W9P3wmw711p172l3T8s0Ptbd25wMM71jF6fUH6cq4n64JE8jvFIR) {
        this.902s024v0T40AC31By11eacj2G9ftX6I7oIimZe17emPq6w323bj398K2v81 = "";
        this.8TA6UV69W9P3wmw711p172l3T8s0Ptbd25wMM71jF6fUH6cq4n64JE8jvFIR = 5000;
        this.902s024v0T40AC31By11eacj2G9ftX6I7oIimZe17emPq6w323bj398K2v81 = 902s024v0T40AC31By11eacj2G9ftX6I7oIimZe17emPq6w323bj398K2v81;
        this.8TA6UV69W9P3wmw711p172l3T8s0Ptbd25wMM71jF6fUH6cq4n64JE8jvFIR = 8ta6UV69W9P3wmw711p172l3T8s0Ptbd25wMM71jF6fUH6cq4n64JE8jvFIR;
    }
    
    @Override
    public void 5t2R3RVJsoYj9B2a380xVYlo7WZFUfuAfb6wnneCWDNK5rEczcPme6sK1blM(final DataInputStream dataInputStream) throws IOException {
        this.902s024v0T40AC31By11eacj2G9ftX6I7oIimZe17emPq6w323bj398K2v81 = dataInputStream.readUTF();
        this.8TA6UV69W9P3wmw711p172l3T8s0Ptbd25wMM71jF6fUH6cq4n64JE8jvFIR = dataInputStream.readInt();
    }
    
    @Override
    public void 45i5X5zy1OVOY1fU3430Vh8d48Hp64UcyqPb124NCs5R3O5T7jovN4MYko9g(final DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeUTF(this.902s024v0T40AC31By11eacj2G9ftX6I7oIimZe17emPq6w323bj398K2v81);
        dataOutputStream.writeInt(this.8TA6UV69W9P3wmw711p172l3T8s0Ptbd25wMM71jF6fUH6cq4n64JE8jvFIR);
    }
    
    @Override
    public void 9ZUE51XBA7cufsC4P0Gzthkn2brI5TD00L1vh7N4tr0nuTtiT5XlO3Auyv8w(final 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2) {
        if (01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2 instanceof 49btkL6nY65UaC1HL6phMlN4O49JsjCZoD6JFDzeKE19K4p69DUfO8NBMBQkGKPfle6zC66kywH11EcDRF9ysSUahYv6Y) {
            ((49btkL6nY65UaC1HL6phMlN4O49JsjCZoD6JFDzeKE19K4p69DUfO8NBMBQkGKPfle6zC66kywH11EcDRF9ysSUahYv6Y)01d2bz82cvo258OoW5QRv9227He83KMS72rx7dJZ4kIt4pQsda5dD462E9lwI08y654TCAdha0LafNWBKZv6XEJe46UFVB2d7u2).0Y8HJW4TgPPE2z549sYe11V6j33RgAx30G8Wqd6O07L94mxIBzIR8Xpj72GI(this);
        }
    }
    
    @Override
    public int 8744JpaofDfd41Z04dPUDpJid52wVS14o4PF77eSx3C6aWXwZr5Pr9x581cD() {
        return this.902s024v0T40AC31By11eacj2G9ftX6I7oIimZe17emPq6w323bj398K2v81.getBytes().length + 4;
    }
}
